var rs=1;var ss=3;var vi=0,_i=1,xi=2,yi=3,Si=4,Mi=5,bi=6,wi=7,as=0,os=1,ls=2;var qi=1,$i=2,Yi=3,Zi=4,Ji=5,Ki=6,ji=7;var cs=300,hs=301,Qi=302;var us=306,Ti=1e3,nn=1001,Ai=1002;var tr=1006;var fs=1008;var ds=1009;var ps=1015;var ms=1023;var Pn=2300,Ei=2301,si=2302,zr=2303,Vr=2400,kr=2401,Hr=2402;var er="",Xt="srgb",Ci="srgb-linear",Ri="linear",Rn="srgb";var Bo=35044;var rn=2e3,Gr=2001;function zo(c){for(let t=c.length-1;t>=0;--t)if(c[t]>=65535)return!0;return!1}function Vo(c){return ArrayBuffer.isView(c)&&!(c instanceof DataView)}function Pi(c){return document.createElementNS("http://www.w3.org/1999/xhtml",c)}var Wr={},In=null;function gs(c){let t=c[0];if(typeof t=="string"&&t.startsWith("TSL:")){let e=c[1];e&&e.isStackTrace?c[0]+=" "+e.getLocation():c[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return c}function Tt(...c){c=gs(c);let t="THREE."+c.shift();if(In)In("warn",t,...c);else{let e=c[0];e&&e.isStackTrace?console.warn(e.getError(t)):console.warn(t,...c)}}function mt(...c){c=gs(c);let t="THREE."+c.shift();if(In)In("error",t,...c);else{let e=c[0];e&&e.isStackTrace?console.error(e.getError(t)):console.error(t,...c)}}function ke(...c){let t=c.join(" ");t in Wr||(Wr[t]=!0,Tt(...c))}var ko={[vi]:_i,[xi]:bi,[Si]:wi,[yi]:Mi,[_i]:vi,[bi]:xi,[wi]:Si,[Mi]:yi},Se=class{addEventListener(t,e){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[t]===void 0&&(n[t]=[]),n[t].indexOf(e)===-1&&n[t].push(e)}hasEventListener(t,e){let n=this._listeners;return n===void 0?!1:n[t]!==void 0&&n[t].indexOf(e)!==-1}removeEventListener(t,e){let n=this._listeners;if(n===void 0)return;let i=n[t];if(i!==void 0){let r=i.indexOf(e);r!==-1&&i.splice(r,1)}}dispatchEvent(t){let e=this._listeners;if(e===void 0)return;let n=e[t.type];if(n!==void 0){t.target=this;let i=n.slice(0);for(let r=0,s=i.length;r<s;r++)i[r].call(this,t);t.target=null}}},Pt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];var Au=Math.PI/180,Ho=180/Math.PI;function Bn(){let c=Math.random()*4294967295|0,t=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Pt[c&255]+Pt[c>>8&255]+Pt[c>>16&255]+Pt[c>>24&255]+"-"+Pt[t&255]+Pt[t>>8&255]+"-"+Pt[t>>16&15|64]+Pt[t>>24&255]+"-"+Pt[e&63|128]+Pt[e>>8&255]+"-"+Pt[e>>16&255]+Pt[e>>24&255]+Pt[n&255]+Pt[n>>8&255]+Pt[n>>16&255]+Pt[n>>24&255]).toLowerCase()}function nt(c,t,e){return Math.max(t,Math.min(e,c))}function Go(c,t){return(c%t+t)%t}function ai(c,t,e){return(1-e)*c+e*t}function Ke(c,t){switch(t.constructor){case Float32Array:return c;case Uint32Array:return c/4294967295;case Uint16Array:return c/65535;case Uint8Array:case Uint8ClampedArray:return c/255;case Int32Array:return Math.max(c/2147483647,-1);case Int16Array:return Math.max(c/32767,-1);case Int8Array:return Math.max(c/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function Ot(c,t){switch(t.constructor){case Float32Array:return c;case Uint32Array:return Math.round(c*4294967295);case Uint16Array:return Math.round(c*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(c*255);case Int32Array:return Math.round(c*2147483647);case Int16Array:return Math.round(c*32767);case Int8Array:return Math.round(c*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}var Dt=class c{static{c.prototype.isVector2=!0}constructor(t=0,e=0){this.x=t,this.y=e}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,e){return this.x=t,this.y=e,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;default:throw new Error("THREE.Vector2: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){let e=this.x,n=this.y,i=t.elements;return this.x=i[0]*e+i[3]*n+i[6],this.y=i[1]*e+i[4]*n+i[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,e){return this.x=nt(this.x,t.x,e.x),this.y=nt(this.y,t.y,e.y),this}clampScalar(t,e){return this.x=nt(this.x,t,e),this.y=nt(this.y,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(nt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(nt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y;return e*e+n*n}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this}rotateAround(t,e){let n=Math.cos(e),i=Math.sin(e),r=this.x-t.x,s=this.y-t.y;return this.x=r*n-s*i+t.x,this.y=r*i+s*n+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},fe=class{constructor(t=0,e=0,n=0,i=1){this.isQuaternion=!0,this._x=t,this._y=e,this._z=n,this._w=i}static slerpFlat(t,e,n,i,r,s,o){let u=n[i+0],h=n[i+1],f=n[i+2],d=n[i+3],g=r[s+0],m=r[s+1],v=r[s+2],y=r[s+3];if(d!==y||u!==g||h!==m||f!==v){let T=u*g+h*m+f*v+d*y;T<0&&(g=-g,m=-m,v=-v,y=-y,T=-T);let C=1-o;if(T<.9995){let D=Math.acos(T),I=Math.sin(D);C=Math.sin(C*D)/I,o=Math.sin(o*D)/I,u=u*C+g*o,h=h*C+m*o,f=f*C+v*o,d=d*C+y*o}else{u=u*C+g*o,h=h*C+m*o,f=f*C+v*o,d=d*C+y*o;let D=1/Math.sqrt(u*u+h*h+f*f+d*d);u*=D,h*=D,f*=D,d*=D}}t[e]=u,t[e+1]=h,t[e+2]=f,t[e+3]=d}static multiplyQuaternionsFlat(t,e,n,i,r,s){let o=n[i],u=n[i+1],h=n[i+2],f=n[i+3],d=r[s],g=r[s+1],m=r[s+2],v=r[s+3];return t[e]=o*v+f*d+u*m-h*g,t[e+1]=u*v+f*g+h*d-o*m,t[e+2]=h*v+f*m+o*g-u*d,t[e+3]=f*v-o*d-u*g-h*m,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,e,n,i){return this._x=t,this._y=e,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,e=!0){let n=t._x,i=t._y,r=t._z,s=t._order,o=Math.cos,u=Math.sin,h=o(n/2),f=o(i/2),d=o(r/2),g=u(n/2),m=u(i/2),v=u(r/2);switch(s){case"XYZ":this._x=g*f*d+h*m*v,this._y=h*m*d-g*f*v,this._z=h*f*v+g*m*d,this._w=h*f*d-g*m*v;break;case"YXZ":this._x=g*f*d+h*m*v,this._y=h*m*d-g*f*v,this._z=h*f*v-g*m*d,this._w=h*f*d+g*m*v;break;case"ZXY":this._x=g*f*d-h*m*v,this._y=h*m*d+g*f*v,this._z=h*f*v+g*m*d,this._w=h*f*d-g*m*v;break;case"ZYX":this._x=g*f*d-h*m*v,this._y=h*m*d+g*f*v,this._z=h*f*v-g*m*d,this._w=h*f*d+g*m*v;break;case"YZX":this._x=g*f*d+h*m*v,this._y=h*m*d+g*f*v,this._z=h*f*v-g*m*d,this._w=h*f*d-g*m*v;break;case"XZY":this._x=g*f*d-h*m*v,this._y=h*m*d-g*f*v,this._z=h*f*v+g*m*d,this._w=h*f*d+g*m*v;break;default:Tt("Quaternion: .setFromEuler() encountered an unknown order: "+s)}return e===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,e){let n=e/2,i=Math.sin(n);return this._x=t.x*i,this._y=t.y*i,this._z=t.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(t){let e=t.elements,n=e[0],i=e[4],r=e[8],s=e[1],o=e[5],u=e[9],h=e[2],f=e[6],d=e[10],g=n+o+d;if(g>0){let m=.5/Math.sqrt(g+1);this._w=.25/m,this._x=(f-u)*m,this._y=(r-h)*m,this._z=(s-i)*m}else if(n>o&&n>d){let m=2*Math.sqrt(1+n-o-d);this._w=(f-u)/m,this._x=.25*m,this._y=(i+s)/m,this._z=(r+h)/m}else if(o>d){let m=2*Math.sqrt(1+o-n-d);this._w=(r-h)/m,this._x=(i+s)/m,this._y=.25*m,this._z=(u+f)/m}else{let m=2*Math.sqrt(1+d-n-o);this._w=(s-i)/m,this._x=(r+h)/m,this._y=(u+f)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(t,e){let n=t.dot(e)+1;return n<1e-8?(n=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=n):(this._x=0,this._y=-t.z,this._z=t.y,this._w=n)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x,this._w=n),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(nt(this.dot(t),-1,1)))}rotateTowards(t,e){let n=this.angleTo(t);if(n===0)return this;let i=Math.min(1,e/n);return this.slerp(t,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,e){let n=t._x,i=t._y,r=t._z,s=t._w,o=e._x,u=e._y,h=e._z,f=e._w;return this._x=n*f+s*o+i*h-r*u,this._y=i*f+s*u+r*o-n*h,this._z=r*f+s*h+n*u-i*o,this._w=s*f-n*o-i*u-r*h,this._onChangeCallback(),this}slerp(t,e){let n=t._x,i=t._y,r=t._z,s=t._w,o=this.dot(t);o<0&&(n=-n,i=-i,r=-r,s=-s,o=-o);let u=1-e;if(o<.9995){let h=Math.acos(o),f=Math.sin(h);u=Math.sin(u*h)/f,e=Math.sin(e*h)/f,this._x=this._x*u+n*e,this._y=this._y*u+i*e,this._z=this._z*u+r*e,this._w=this._w*u+s*e,this._onChangeCallback()}else this._x=this._x*u+n*e,this._y=this._y*u+i*e,this._z=this._z*u+r*e,this._w=this._w*u+s*e,this.normalize();return this}slerpQuaternions(t,e,n){return this.copy(t).slerp(e,n)}random(){let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),r=Math.sqrt(n);return this.set(i*Math.sin(t),i*Math.cos(t),r*Math.sin(e),r*Math.cos(e))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,e=0){return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t}fromBufferAttribute(t,e){return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},O=class c{static{c.prototype.isVector3=!0}constructor(t=0,e=0,n=0){this.x=t,this.y=e,this.z=n}set(t,e,n){return n===void 0&&(n=this.z),this.x=t,this.y=e,this.z=n,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;default:throw new Error("THREE.Vector3: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,e){return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this}applyEuler(t){return this.applyQuaternion(Xr.setFromEuler(t))}applyAxisAngle(t,e){return this.applyQuaternion(Xr.setFromAxisAngle(t,e))}applyMatrix3(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[3]*n+r[6]*i,this.y=r[1]*e+r[4]*n+r[7]*i,this.z=r[2]*e+r[5]*n+r[8]*i,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=t.elements,s=1/(r[3]*e+r[7]*n+r[11]*i+r[15]);return this.x=(r[0]*e+r[4]*n+r[8]*i+r[12])*s,this.y=(r[1]*e+r[5]*n+r[9]*i+r[13])*s,this.z=(r[2]*e+r[6]*n+r[10]*i+r[14])*s,this}applyQuaternion(t){let e=this.x,n=this.y,i=this.z,r=t.x,s=t.y,o=t.z,u=t.w,h=2*(s*i-o*n),f=2*(o*e-r*i),d=2*(r*n-s*e);return this.x=e+u*h+s*d-o*f,this.y=n+u*f+o*h-r*d,this.z=i+u*d+r*f-s*h,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){let e=this.x,n=this.y,i=this.z,r=t.elements;return this.x=r[0]*e+r[4]*n+r[8]*i,this.y=r[1]*e+r[5]*n+r[9]*i,this.z=r[2]*e+r[6]*n+r[10]*i,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,e){return this.x=nt(this.x,t.x,e.x),this.y=nt(this.y,t.y,e.y),this.z=nt(this.z,t.z,e.z),this}clampScalar(t,e){return this.x=nt(this.x,t,e),this.y=nt(this.y,t,e),this.z=nt(this.z,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(nt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,e){let n=t.x,i=t.y,r=t.z,s=e.x,o=e.y,u=e.z;return this.x=i*u-r*o,this.y=r*s-n*u,this.z=n*o-i*s,this}projectOnVector(t){let e=t.lengthSq();if(e===0)return this.set(0,0,0);let n=t.dot(this)/e;return this.copy(t).multiplyScalar(n)}projectOnPlane(t){return oi.copy(this).projectOnVector(t),this.sub(oi)}reflect(t){return this.sub(oi.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){let e=Math.sqrt(this.lengthSq()*t.lengthSq());if(e===0)return Math.PI/2;let n=this.dot(t)/e;return Math.acos(nt(n,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){let e=this.x-t.x,n=this.y-t.y,i=this.z-t.z;return e*e+n*n+i*i}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,e,n){let i=Math.sin(e)*t;return this.x=i*Math.sin(n),this.y=Math.cos(e)*t,this.z=i*Math.cos(n),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,e,n){return this.x=t*Math.sin(e),this.y=n,this.z=t*Math.cos(e),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this}setFromMatrixScale(t){let e=this.setFromMatrixColumn(t,0).length(),n=this.setFromMatrixColumn(t,1).length(),i=this.setFromMatrixColumn(t,2).length();return this.x=e,this.y=n,this.z=i,this}setFromMatrixColumn(t,e){return this.fromArray(t.elements,e*4)}setFromMatrix3Column(t,e){return this.fromArray(t.elements,e*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let t=Math.random()*Math.PI*2,e=Math.random()*2-1,n=Math.sqrt(1-e*e);return this.x=n*Math.cos(t),this.y=e,this.z=n*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},oi=new O,Xr=new fe,K=class c{static{c.prototype.isMatrix3=!0}constructor(t,e,n,i,r,s,o,u,h){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,s,o,u,h)}set(t,e,n,i,r,s,o,u,h){let f=this.elements;return f[0]=t,f[1]=i,f[2]=o,f[3]=e,f[4]=r,f[5]=u,f[6]=n,f[7]=s,f[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],this}extractBasis(t,e,n){return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(t){let e=t.elements;return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,s=n[0],o=n[3],u=n[6],h=n[1],f=n[4],d=n[7],g=n[2],m=n[5],v=n[8],y=i[0],T=i[3],C=i[6],D=i[1],I=i[4],V=i[7],P=i[2],k=i[5],H=i[8];return r[0]=s*y+o*D+u*P,r[3]=s*T+o*I+u*k,r[6]=s*C+o*V+u*H,r[1]=h*y+f*D+d*P,r[4]=h*T+f*I+d*k,r[7]=h*C+f*V+d*H,r[2]=g*y+m*D+v*P,r[5]=g*T+m*I+v*k,r[8]=g*C+m*V+v*H,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],s=t[4],o=t[5],u=t[6],h=t[7],f=t[8];return e*s*f-e*o*h-n*r*f+n*o*u+i*r*h-i*s*u}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],s=t[4],o=t[5],u=t[6],h=t[7],f=t[8],d=f*s-o*h,g=o*u-f*r,m=h*r-s*u,v=e*d+n*g+i*m;if(v===0)return this.set(0,0,0,0,0,0,0,0,0);let y=1/v;return t[0]=d*y,t[1]=(i*h-f*n)*y,t[2]=(o*n-i*s)*y,t[3]=g*y,t[4]=(f*e-i*u)*y,t[5]=(i*r-o*e)*y,t[6]=m*y,t[7]=(n*u-h*e)*y,t[8]=(s*e-n*r)*y,this}transpose(){let t,e=this.elements;return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){let e=this.elements;return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this}setUvTransform(t,e,n,i,r,s,o){let u=Math.cos(r),h=Math.sin(r);return this.set(n*u,n*h,-n*(u*s+h*o)+s+t,-i*h,i*u,-i*(-h*s+u*o)+o+e,0,0,1),this}scale(t,e){return ke("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(li.makeScale(t,e)),this}rotate(t){return ke("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(li.makeRotation(-t)),this}translate(t,e){return ke("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(li.makeTranslation(t,e)),this}makeTranslation(t,e){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this}makeRotation(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,n,e,0,0,0,1),this}makeScale(t,e){return this.set(t,0,0,0,e,0,0,0,1),this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<9;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<9;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t}clone(){return new this.constructor().fromArray(this.elements)}},li=new K,qr=new K().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),$r=new K().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Wo(){let c={enabled:!0,workingColorSpace:Ci,spaces:{},convert:function(i,r,s){return this.enabled===!1||r===s||!r||!s||(this.spaces[r].transfer===Rn&&(i.r=ee(i.r),i.g=ee(i.g),i.b=ee(i.b)),this.spaces[r].primaries!==this.spaces[s].primaries&&(i.applyMatrix3(this.spaces[r].toXYZ),i.applyMatrix3(this.spaces[s].fromXYZ)),this.spaces[s].transfer===Rn&&(i.r=He(i.r),i.g=He(i.g),i.b=He(i.b))),i},workingToColorSpace:function(i,r){return this.convert(i,this.workingColorSpace,r)},colorSpaceToWorking:function(i,r){return this.convert(i,r,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===er?Ri:this.spaces[i].transfer},getToneMappingMode:function(i){return this.spaces[i].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(i,r=this.workingColorSpace){return i.fromArray(this.spaces[r].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,r,s){return i.copy(this.spaces[r].toXYZ).multiply(this.spaces[s].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(i,r){return ke("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),c.workingToColorSpace(i,r)},toWorkingColorSpace:function(i,r){return ke("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),c.colorSpaceToWorking(i,r)}},t=[.64,.33,.3,.6,.15,.06],e=[.2126,.7152,.0722],n=[.3127,.329];return c.define({[Ci]:{primaries:t,whitePoint:n,transfer:Ri,toXYZ:qr,fromXYZ:$r,luminanceCoefficients:e,workingColorSpaceConfig:{unpackColorSpace:Xt},outputColorSpaceConfig:{drawingBufferColorSpace:Xt}},[Xt]:{primaries:t,whitePoint:n,transfer:Rn,toXYZ:qr,fromXYZ:$r,luminanceCoefficients:e,outputColorSpaceConfig:{drawingBufferColorSpace:Xt}}}),c}var Wt=Wo();function ee(c){return c<.04045?c*.0773993808:Math.pow(c*.9478672986+.0521327014,2.4)}function He(c){return c<.0031308?c*12.92:1.055*Math.pow(c,.41666)-.055}var Le,Ii=class{static getDataURL(t,e="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let n;if(t instanceof HTMLCanvasElement)n=t;else{Le===void 0&&(Le=Pi("canvas")),Le.width=t.width,Le.height=t.height;let i=Le.getContext("2d");t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),n=Le}return n.toDataURL(e)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){let e=Pi("canvas");e.width=t.width,e.height=t.height;let n=e.getContext("2d");n.drawImage(t,0,0,t.width,t.height);let i=n.getImageData(0,0,t.width,t.height),r=i.data;for(let s=0;s<r.length;s++)r[s]=ee(r[s]/255)*255;return n.putImageData(i,0,0),e}else if(t.data){let e=t.data.slice(0);for(let n=0;n<e.length;n++)e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[n]=Math.floor(ee(e[n]/255)*255):e[n]=ee(e[n]);return{data:e,width:t.width,height:t.height}}else return Tt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}},Xo=0,Li=class{constructor(t=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Xo++}),this.uuid=Bn(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){let e=this.data;return typeof HTMLVideoElement<"u"&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):typeof VideoFrame<"u"&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):e!==null?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.images[this.uuid]!==void 0)return t.images[this.uuid];let n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let r;if(Array.isArray(i)){r=[];for(let s=0,o=i.length;s<o;s++)i[s].isDataTexture?r.push(ci(i[s].image)):r.push(ci(i[s]))}else r=ci(i);n.url=r}return e||(t.images[this.uuid]=n),n}};function ci(c){return typeof HTMLImageElement<"u"&&c instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&c instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&c instanceof ImageBitmap?Ii.getDataURL(c):c.data?{data:Array.from(c.data),width:c.width,height:c.height,type:c.data.constructor.name}:(Tt("Texture: Unable to serialize Texture."),{})}var qo=0,hi=new O,Ge=class c extends Se{constructor(t=c.DEFAULT_IMAGE,e=c.DEFAULT_MAPPING,n=nn,i=nn,r=tr,s=fs,o=ms,u=ds,h=c.DEFAULT_ANISOTROPY,f=er){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:qo++}),this.uuid=Bn(),this.name="",this.source=new Li(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=r,this.minFilter=s,this.anisotropy=h,this.format=o,this.internalFormat=null,this.type=u,this.offset=new Dt(0,0),this.repeat=new Dt(1,1),this.center=new Dt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new K,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=f,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(hi).x}get height(){return this.source.getSize(hi).y}get depth(){return this.source.getSize(hi).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(let e in t){let n=t[e];if(n===void 0){Tt(`Texture.setValues(): parameter '${e}' has value of undefined.`);continue}let i=this[e];if(i===void 0){Tt(`Texture.setValues(): property '${e}' does not exist.`);continue}i&&n&&i.isVector2&&n.isVector2||i&&n&&i.isVector3&&n.isVector3||i&&n&&i.isMatrix3&&n.isMatrix3?i.copy(n):this[e]=n}}toJSON(t){let e=t===void 0||typeof t=="string";if(!e&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];let n={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),e||(t.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==cs)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Ti:t.x=t.x-Math.floor(t.x);break;case nn:t.x=t.x<0?0:1;break;case Ai:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Ti:t.y=t.y-Math.floor(t.y);break;case nn:t.y=t.y<0?0:1;break;case Ai:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}};Ge.DEFAULT_IMAGE=null;Ge.DEFAULT_MAPPING=cs;Ge.DEFAULT_ANISOTROPY=1;var Di=class c{static{c.prototype.isVector4=!0}constructor(t=0,e=0,n=0,i=1){this.x=t,this.y=e,this.z=n,this.w=i}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,e,n,i){return this.x=t,this.y=e,this.z=n,this.w=i,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,e){switch(t){case 0:this.x=e;break;case 1:this.y=e;break;case 2:this.z=e;break;case 3:this.w=e;break;default:throw new Error("THREE.Vector4: index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,e){return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this}addScaledVector(t,e){return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,e){return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){let e=this.x,n=this.y,i=this.z,r=this.w,s=t.elements;return this.x=s[0]*e+s[4]*n+s[8]*i+s[12]*r,this.y=s[1]*e+s[5]*n+s[9]*i+s[13]*r,this.z=s[2]*e+s[6]*n+s[10]*i+s[14]*r,this.w=s[3]*e+s[7]*n+s[11]*i+s[15]*r,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);let e=Math.sqrt(1-t.w*t.w);return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this}setAxisAngleFromRotationMatrix(t){let e,n,i,r,u=t.elements,h=u[0],f=u[4],d=u[8],g=u[1],m=u[5],v=u[9],y=u[2],T=u[6],C=u[10];if(Math.abs(f-g)<.01&&Math.abs(d-y)<.01&&Math.abs(v-T)<.01){if(Math.abs(f+g)<.1&&Math.abs(d+y)<.1&&Math.abs(v+T)<.1&&Math.abs(h+m+C-3)<.1)return this.set(1,0,0,0),this;e=Math.PI;let I=(h+1)/2,V=(m+1)/2,P=(C+1)/2,k=(f+g)/4,H=(d+y)/4,U=(v+T)/4;return I>V&&I>P?I<.01?(n=0,i=.707106781,r=.707106781):(n=Math.sqrt(I),i=k/n,r=H/n):V>P?V<.01?(n=.707106781,i=0,r=.707106781):(i=Math.sqrt(V),n=k/i,r=U/i):P<.01?(n=.707106781,i=.707106781,r=0):(r=Math.sqrt(P),n=H/r,i=U/r),this.set(n,i,r,e),this}let D=Math.sqrt((T-v)*(T-v)+(d-y)*(d-y)+(g-f)*(g-f));return Math.abs(D)<.001&&(D=1),this.x=(T-v)/D,this.y=(d-y)/D,this.z=(g-f)/D,this.w=Math.acos((h+m+C-1)/2),this}setFromMatrixPosition(t){let e=t.elements;return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,e){return this.x=nt(this.x,t.x,e.x),this.y=nt(this.y,t.y,e.y),this.z=nt(this.z,t.z,e.z),this.w=nt(this.w,t.w,e.w),this}clampScalar(t,e){return this.x=nt(this.x,t,e),this.y=nt(this.y,t,e),this.z=nt(this.z,t,e),this.w=nt(this.w,t,e),this}clampLength(t,e){let n=this.length();return this.divideScalar(n||1).multiplyScalar(nt(n,t,e))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,e){return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this}lerpVectors(t,e,n){return this.x=t.x+(e.x-t.x)*n,this.y=t.y+(e.y-t.y)*n,this.z=t.z+(e.z-t.z)*n,this.w=t.w+(e.w-t.w)*n,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,e=0){return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this}toArray(t=[],e=0){return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t}fromBufferAttribute(t,e){return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};var Kt=class c{static{c.prototype.isMatrix4=!0}constructor(t,e,n,i,r,s,o,u,h,f,d,g,m,v,y,T){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,e,n,i,r,s,o,u,h,f,d,g,m,v,y,T)}set(t,e,n,i,r,s,o,u,h,f,d,g,m,v,y,T){let C=this.elements;return C[0]=t,C[4]=e,C[8]=n,C[12]=i,C[1]=r,C[5]=s,C[9]=o,C[13]=u,C[2]=h,C[6]=f,C[10]=d,C[14]=g,C[3]=m,C[7]=v,C[11]=y,C[15]=T,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new c().fromArray(this.elements)}copy(t){let e=this.elements,n=t.elements;return e[0]=n[0],e[1]=n[1],e[2]=n[2],e[3]=n[3],e[4]=n[4],e[5]=n[5],e[6]=n[6],e[7]=n[7],e[8]=n[8],e[9]=n[9],e[10]=n[10],e[11]=n[11],e[12]=n[12],e[13]=n[13],e[14]=n[14],e[15]=n[15],this}copyPosition(t){let e=this.elements,n=t.elements;return e[12]=n[12],e[13]=n[13],e[14]=n[14],this}setFromMatrix3(t){let e=t.elements;return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this}extractBasis(t,e,n){return this.determinantAffine()===0?(t.set(1,0,0),e.set(0,1,0),n.set(0,0,1),this):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(t,e,n){return this.set(t.x,e.x,n.x,0,t.y,e.y,n.y,0,t.z,e.z,n.z,0,0,0,0,1),this}extractRotation(t){if(t.determinantAffine()===0)return this.identity();let e=this.elements,n=t.elements,i=1/De.setFromMatrixColumn(t,0).length(),r=1/De.setFromMatrixColumn(t,1).length(),s=1/De.setFromMatrixColumn(t,2).length();return e[0]=n[0]*i,e[1]=n[1]*i,e[2]=n[2]*i,e[3]=0,e[4]=n[4]*r,e[5]=n[5]*r,e[6]=n[6]*r,e[7]=0,e[8]=n[8]*s,e[9]=n[9]*s,e[10]=n[10]*s,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromEuler(t){let e=this.elements,n=t.x,i=t.y,r=t.z,s=Math.cos(n),o=Math.sin(n),u=Math.cos(i),h=Math.sin(i),f=Math.cos(r),d=Math.sin(r);if(t.order==="XYZ"){let g=s*f,m=s*d,v=o*f,y=o*d;e[0]=u*f,e[4]=-u*d,e[8]=h,e[1]=m+v*h,e[5]=g-y*h,e[9]=-o*u,e[2]=y-g*h,e[6]=v+m*h,e[10]=s*u}else if(t.order==="YXZ"){let g=u*f,m=u*d,v=h*f,y=h*d;e[0]=g+y*o,e[4]=v*o-m,e[8]=s*h,e[1]=s*d,e[5]=s*f,e[9]=-o,e[2]=m*o-v,e[6]=y+g*o,e[10]=s*u}else if(t.order==="ZXY"){let g=u*f,m=u*d,v=h*f,y=h*d;e[0]=g-y*o,e[4]=-s*d,e[8]=v+m*o,e[1]=m+v*o,e[5]=s*f,e[9]=y-g*o,e[2]=-s*h,e[6]=o,e[10]=s*u}else if(t.order==="ZYX"){let g=s*f,m=s*d,v=o*f,y=o*d;e[0]=u*f,e[4]=v*h-m,e[8]=g*h+y,e[1]=u*d,e[5]=y*h+g,e[9]=m*h-v,e[2]=-h,e[6]=o*u,e[10]=s*u}else if(t.order==="YZX"){let g=s*u,m=s*h,v=o*u,y=o*h;e[0]=u*f,e[4]=y-g*d,e[8]=v*d+m,e[1]=d,e[5]=s*f,e[9]=-o*f,e[2]=-h*f,e[6]=m*d+v,e[10]=g-y*d}else if(t.order==="XZY"){let g=s*u,m=s*h,v=o*u,y=o*h;e[0]=u*f,e[4]=-d,e[8]=h*f,e[1]=g*d+y,e[5]=s*f,e[9]=m*d-v,e[2]=v*d-m,e[6]=o*f,e[10]=y*d+g}return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this}makeRotationFromQuaternion(t){return this.compose($o,t,Yo)}lookAt(t,e,n){let i=this.elements;return Vt.subVectors(t,e),Vt.lengthSq()===0&&(Vt.z=1),Vt.normalize(),le.crossVectors(n,Vt),le.lengthSq()===0&&(Math.abs(n.z)===1?Vt.x+=1e-4:Vt.z+=1e-4,Vt.normalize(),le.crossVectors(n,Vt)),le.normalize(),Mn.crossVectors(Vt,le),i[0]=le.x,i[4]=Mn.x,i[8]=Vt.x,i[1]=le.y,i[5]=Mn.y,i[9]=Vt.y,i[2]=le.z,i[6]=Mn.z,i[10]=Vt.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,e){let n=t.elements,i=e.elements,r=this.elements,s=n[0],o=n[4],u=n[8],h=n[12],f=n[1],d=n[5],g=n[9],m=n[13],v=n[2],y=n[6],T=n[10],C=n[14],D=n[3],I=n[7],V=n[11],P=n[15],k=i[0],H=i[4],U=i[8],F=i[12],G=i[1],Y=i[5],X=i[9],N=i[13],Z=i[2],q=i[6],it=i[10],J=i[14],st=i[3],lt=i[7],ht=i[11],ct=i[15];return r[0]=s*k+o*G+u*Z+h*st,r[4]=s*H+o*Y+u*q+h*lt,r[8]=s*U+o*X+u*it+h*ht,r[12]=s*F+o*N+u*J+h*ct,r[1]=f*k+d*G+g*Z+m*st,r[5]=f*H+d*Y+g*q+m*lt,r[9]=f*U+d*X+g*it+m*ht,r[13]=f*F+d*N+g*J+m*ct,r[2]=v*k+y*G+T*Z+C*st,r[6]=v*H+y*Y+T*q+C*lt,r[10]=v*U+y*X+T*it+C*ht,r[14]=v*F+y*N+T*J+C*ct,r[3]=D*k+I*G+V*Z+P*st,r[7]=D*H+I*Y+V*q+P*lt,r[11]=D*U+I*X+V*it+P*ht,r[15]=D*F+I*N+V*J+P*ct,this}multiplyScalar(t){let e=this.elements;return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this}determinant(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[12],s=t[1],o=t[5],u=t[9],h=t[13],f=t[2],d=t[6],g=t[10],m=t[14],v=t[3],y=t[7],T=t[11],C=t[15],D=u*m-h*g,I=o*m-h*d,V=o*g-u*d,P=s*m-h*f,k=s*g-u*f,H=s*d-o*f;return e*(y*D-T*I+C*V)-n*(v*D-T*P+C*k)+i*(v*I-y*P+C*H)-r*(v*V-y*k+T*H)}determinantAffine(){let t=this.elements,e=t[0],n=t[4],i=t[8],r=t[1],s=t[5],o=t[9],u=t[2],h=t[6],f=t[10];return e*(s*f-o*h)-n*(r*f-o*u)+i*(r*h-s*u)}transpose(){let t=this.elements,e;return e=t[1],t[1]=t[4],t[4]=e,e=t[2],t[2]=t[8],t[8]=e,e=t[6],t[6]=t[9],t[9]=e,e=t[3],t[3]=t[12],t[12]=e,e=t[7],t[7]=t[13],t[13]=e,e=t[11],t[11]=t[14],t[14]=e,this}setPosition(t,e,n){let i=this.elements;return t.isVector3?(i[12]=t.x,i[13]=t.y,i[14]=t.z):(i[12]=t,i[13]=e,i[14]=n),this}invert(){let t=this.elements,e=t[0],n=t[1],i=t[2],r=t[3],s=t[4],o=t[5],u=t[6],h=t[7],f=t[8],d=t[9],g=t[10],m=t[11],v=t[12],y=t[13],T=t[14],C=t[15],D=e*o-n*s,I=e*u-i*s,V=e*h-r*s,P=n*u-i*o,k=n*h-r*o,H=i*h-r*u,U=f*y-d*v,F=f*T-g*v,G=f*C-m*v,Y=d*T-g*y,X=d*C-m*y,N=g*C-m*T,Z=D*N-I*X+V*Y+P*G-k*F+H*U;if(Z===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let q=1/Z;return t[0]=(o*N-u*X+h*Y)*q,t[1]=(i*X-n*N-r*Y)*q,t[2]=(y*H-T*k+C*P)*q,t[3]=(g*k-d*H-m*P)*q,t[4]=(u*G-s*N-h*F)*q,t[5]=(e*N-i*G+r*F)*q,t[6]=(T*V-v*H-C*I)*q,t[7]=(f*H-g*V+m*I)*q,t[8]=(s*X-o*G+h*U)*q,t[9]=(n*G-e*X-r*U)*q,t[10]=(v*k-y*V+C*D)*q,t[11]=(d*V-f*k-m*D)*q,t[12]=(o*F-s*Y-u*U)*q,t[13]=(e*Y-n*F+i*U)*q,t[14]=(y*I-v*P-T*D)*q,t[15]=(f*P-d*I+g*D)*q,this}scale(t){let e=this.elements,n=t.x,i=t.y,r=t.z;return e[0]*=n,e[4]*=i,e[8]*=r,e[1]*=n,e[5]*=i,e[9]*=r,e[2]*=n,e[6]*=i,e[10]*=r,e[3]*=n,e[7]*=i,e[11]*=r,this}getMaxScaleOnAxis(){let t=this.elements,e=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],n=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],i=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(e,n,i))}makeTranslation(t,e,n){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,n,0,0,0,1),this}makeRotationX(t){let e=Math.cos(t),n=Math.sin(t);return this.set(1,0,0,0,0,e,-n,0,0,n,e,0,0,0,0,1),this}makeRotationY(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,0,n,0,0,1,0,0,-n,0,e,0,0,0,0,1),this}makeRotationZ(t){let e=Math.cos(t),n=Math.sin(t);return this.set(e,-n,0,0,n,e,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,e){let n=Math.cos(e),i=Math.sin(e),r=1-n,s=t.x,o=t.y,u=t.z,h=r*s,f=r*o;return this.set(h*s+n,h*o-i*u,h*u+i*o,0,h*o+i*u,f*o+n,f*u-i*s,0,h*u-i*o,f*u+i*s,r*u*u+n,0,0,0,0,1),this}makeScale(t,e,n){return this.set(t,0,0,0,0,e,0,0,0,0,n,0,0,0,0,1),this}makeShear(t,e,n,i,r,s){return this.set(1,n,r,0,t,1,s,0,e,i,1,0,0,0,0,1),this}compose(t,e,n){let i=this.elements,r=e._x,s=e._y,o=e._z,u=e._w,h=r+r,f=s+s,d=o+o,g=r*h,m=r*f,v=r*d,y=s*f,T=s*d,C=o*d,D=u*h,I=u*f,V=u*d,P=n.x,k=n.y,H=n.z;return i[0]=(1-(y+C))*P,i[1]=(m+V)*P,i[2]=(v-I)*P,i[3]=0,i[4]=(m-V)*k,i[5]=(1-(g+C))*k,i[6]=(T+D)*k,i[7]=0,i[8]=(v+I)*H,i[9]=(T-D)*H,i[10]=(1-(g+y))*H,i[11]=0,i[12]=t.x,i[13]=t.y,i[14]=t.z,i[15]=1,this}decompose(t,e,n){let i=this.elements;t.x=i[12],t.y=i[13],t.z=i[14];let r=this.determinantAffine();if(r===0)return n.set(1,1,1),e.identity(),this;let s=De.set(i[0],i[1],i[2]).length(),o=De.set(i[4],i[5],i[6]).length(),u=De.set(i[8],i[9],i[10]).length();r<0&&(s=-s),Zt.copy(this);let h=1/s,f=1/o,d=1/u;return Zt.elements[0]*=h,Zt.elements[1]*=h,Zt.elements[2]*=h,Zt.elements[4]*=f,Zt.elements[5]*=f,Zt.elements[6]*=f,Zt.elements[8]*=d,Zt.elements[9]*=d,Zt.elements[10]*=d,e.setFromRotationMatrix(Zt),n.x=s,n.y=o,n.z=u,this}makePerspective(t,e,n,i,r,s,o=rn,u=!1){let h=this.elements,f=2*r/(e-t),d=2*r/(n-i),g=(e+t)/(e-t),m=(n+i)/(n-i),v,y;if(u)v=r/(s-r),y=s*r/(s-r);else if(o===rn)v=-(s+r)/(s-r),y=-2*s*r/(s-r);else if(o===Gr)v=-s/(s-r),y=-s*r/(s-r);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return h[0]=f,h[4]=0,h[8]=g,h[12]=0,h[1]=0,h[5]=d,h[9]=m,h[13]=0,h[2]=0,h[6]=0,h[10]=v,h[14]=y,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(t,e,n,i,r,s,o=rn,u=!1){let h=this.elements,f=2/(e-t),d=2/(n-i),g=-(e+t)/(e-t),m=-(n+i)/(n-i),v,y;if(u)v=1/(s-r),y=s/(s-r);else if(o===rn)v=-2/(s-r),y=-(s+r)/(s-r);else if(o===Gr)v=-1/(s-r),y=-r/(s-r);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return h[0]=f,h[4]=0,h[8]=0,h[12]=g,h[1]=0,h[5]=d,h[9]=0,h[13]=m,h[2]=0,h[6]=0,h[10]=v,h[14]=y,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(t){let e=this.elements,n=t.elements;for(let i=0;i<16;i++)if(e[i]!==n[i])return!1;return!0}fromArray(t,e=0){for(let n=0;n<16;n++)this.elements[n]=t[n+e];return this}toArray(t=[],e=0){let n=this.elements;return t[e]=n[0],t[e+1]=n[1],t[e+2]=n[2],t[e+3]=n[3],t[e+4]=n[4],t[e+5]=n[5],t[e+6]=n[6],t[e+7]=n[7],t[e+8]=n[8],t[e+9]=n[9],t[e+10]=n[10],t[e+11]=n[11],t[e+12]=n[12],t[e+13]=n[13],t[e+14]=n[14],t[e+15]=n[15],t}},De=new O,Zt=new Kt,$o=new O(0,0,0),Yo=new O(1,1,1),le=new O,Mn=new O,Vt=new O,Yr=new Kt,Zr=new fe,Ln=class c{constructor(t=0,e=0,n=0,i=c.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=e,this._z=n,this._order=i}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,e,n,i=this._order){return this._x=t,this._y=e,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,e=this._order,n=!0){let i=t.elements,r=i[0],s=i[4],o=i[8],u=i[1],h=i[5],f=i[9],d=i[2],g=i[6],m=i[10];switch(e){case"XYZ":this._y=Math.asin(nt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-f,m),this._z=Math.atan2(-s,r)):(this._x=Math.atan2(g,h),this._z=0);break;case"YXZ":this._x=Math.asin(-nt(f,-1,1)),Math.abs(f)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(u,h)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(nt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-d,m),this._z=Math.atan2(-s,h)):(this._y=0,this._z=Math.atan2(u,r));break;case"ZYX":this._y=Math.asin(-nt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(g,m),this._z=Math.atan2(u,r)):(this._x=0,this._z=Math.atan2(-s,h));break;case"YZX":this._z=Math.asin(nt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(-f,h),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-nt(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(g,h),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-f,m),this._y=0);break;default:Tt("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)}return this._order=e,n===!0&&this._onChangeCallback(),this}setFromQuaternion(t,e,n){return Yr.makeRotationFromQuaternion(t),this.setFromRotationMatrix(Yr,e,n)}setFromVector3(t,e=this._order){return this.set(t.x,t.y,t.z,e)}reorder(t){return Zr.setFromEuler(this),this.setFromQuaternion(Zr,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],e=0){return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Ln.DEFAULT_ORDER="XYZ";var Dn=class{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}},Zo=0,Jr=new O,Ue=new fe,Qt=new Kt,bn=new O,je=new O,Jo=new O,Ko=new fe,Kr=new O(1,0,0),jr=new O(0,1,0),Qr=new O(0,0,1),ts={type:"added"},jo={type:"removed"},Ne={type:"childadded",child:null},ui={type:"childremoved",child:null},We=class c extends Se{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Zo++}),this.uuid=Bn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=c.DEFAULT_UP.clone();let t=new O,e=new Ln,n=new fe,i=new O(1,1,1);function r(){n.setFromEuler(e,!1)}function s(){e.setFromQuaternion(n,void 0,!1)}e._onChange(r),n._onChange(s),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Kt},normalMatrix:{value:new K}}),this.matrix=new Kt,this.matrixWorld=new Kt,this.matrixAutoUpdate=c.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=c.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Dn,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,e){this.quaternion.setFromAxisAngle(t,e)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,e){return Ue.setFromAxisAngle(t,e),this.quaternion.multiply(Ue),this}rotateOnWorldAxis(t,e){return Ue.setFromAxisAngle(t,e),this.quaternion.premultiply(Ue),this}rotateX(t){return this.rotateOnAxis(Kr,t)}rotateY(t){return this.rotateOnAxis(jr,t)}rotateZ(t){return this.rotateOnAxis(Qr,t)}translateOnAxis(t,e){return Jr.copy(t).applyQuaternion(this.quaternion),this.position.add(Jr.multiplyScalar(e)),this}translateX(t){return this.translateOnAxis(Kr,t)}translateY(t){return this.translateOnAxis(jr,t)}translateZ(t){return this.translateOnAxis(Qr,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Qt.copy(this.matrixWorld).invert())}lookAt(t,e,n){t.isVector3?bn.copy(t):bn.set(t,e,n);let i=this.parent;this.updateWorldMatrix(!0,!1),je.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Qt.lookAt(je,bn,this.up):Qt.lookAt(bn,je,this.up),this.quaternion.setFromRotationMatrix(Qt),i&&(Qt.extractRotation(i.matrixWorld),Ue.setFromRotationMatrix(Qt),this.quaternion.premultiply(Ue.invert()))}add(t){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return t===this?(mt("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(ts),Ne.child=t,this.dispatchEvent(Ne),Ne.child=null):mt("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}let e=this.children.indexOf(t);return e!==-1&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(jo),ui.child=t,this.dispatchEvent(ui),ui.child=null),this}removeFromParent(){let t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Qt.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Qt.multiply(t.parent.matrixWorld)),t.applyMatrix4(Qt),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(ts),Ne.child=t,this.dispatchEvent(Ne),Ne.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,e){if(this[t]===e)return this;for(let n=0,i=this.children.length;n<i;n++){let s=this.children[n].getObjectByProperty(t,e);if(s!==void 0)return s}}getObjectsByProperty(t,e,n=[]){this[t]===e&&n.push(this);let i=this.children;for(let r=0,s=i.length;r<s;r++)i[r].getObjectsByProperty(t,e,n);return n}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(je,t,Jo),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(je,Ko,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);let e=this.matrixWorld.elements;return t.set(e[8],e[9],e[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(t){t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].traverseVisible(t)}traverseAncestors(t){let e=this.parent;e!==null&&(t(e),e.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let t=this.pivot;if(t!==null){let e=t.x,n=t.y,i=t.z,r=this.matrix.elements;r[12]+=e-r[0]*e-r[4]*n-r[8]*i,r[13]+=n-r[1]*e-r[5]*n-r[9]*i,r[14]+=i-r[2]*e-r[6]*n-r[10]*i}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);let e=this.children;for(let n=0,i=e.length;n<i;n++)e[n].updateMatrixWorld(t)}updateWorldMatrix(t,e,n=!1){let i=this.parent;if(t===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),e===!0){let r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].updateWorldMatrix(!1,!0,n)}}toJSON(t){let e=t===void 0||typeof t=="string",n={};e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let i={};i.uuid=this.uuid,i.type=this.type,i.name=this.name,i.castShadow=this.castShadow,i.receiveShadow=this.receiveShadow,i.visible=this.visible,i.frustumCulled=this.frustumCulled,i.renderOrder=this.renderOrder,i.static=this.static,i.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.pivot!==null&&(i.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(i.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(i.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.geometryInfo=this._geometryInfo.map(o=>({...o,boundingBox:o.boundingBox?o.boundingBox.toJSON():void 0,boundingSphere:o.boundingSphere?o.boundingSphere.toJSON():void 0})),i.instanceInfo=this._instanceInfo.map(o=>({...o})),i.availableInstanceIds=this._availableInstanceIds.slice(),i.availableGeometryIds=this._availableGeometryIds.slice(),i.nextIndexStart=this._nextIndexStart,i.nextVertexStart=this._nextVertexStart,i.geometryCount=this._geometryCount,i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.matricesTexture=this._matricesTexture.toJSON(t),i.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(i.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(i.boundingBox=this.boundingBox.toJSON()));function r(o,u){return o[u.uuid]===void 0&&(o[u.uuid]=u.toJSON(t)),u.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=r(t.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let u=o.shapes;if(Array.isArray(u))for(let h=0,f=u.length;h<f;h++){let d=u[h];r(t.shapes,d)}else r(t.shapes,u)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(t.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let u=0,h=this.material.length;u<h;u++)o.push(r(t.materials,this.material[u]));i.material=o}else i.material=r(t.materials,this.material);if(this.children.length>0){i.children=[];for(let o=0;o<this.children.length;o++)i.children.push(this.children[o].toJSON(t).object)}if(this.animations.length>0){i.animations=[];for(let o=0;o<this.animations.length;o++){let u=this.animations[o];i.animations.push(r(t.animations,u))}}if(e){let o=s(t.geometries),u=s(t.materials),h=s(t.textures),f=s(t.images),d=s(t.shapes),g=s(t.skeletons),m=s(t.animations),v=s(t.nodes);o.length>0&&(n.geometries=o),u.length>0&&(n.materials=u),h.length>0&&(n.textures=h),f.length>0&&(n.images=f),d.length>0&&(n.shapes=d),g.length>0&&(n.skeletons=g),m.length>0&&(n.animations=m),v.length>0&&(n.nodes=v)}return n.object=i,n;function s(o){let u=[];for(let h in o){let f=o[h];delete f.metadata,u.push(f)}return u}}clone(t){return new this.constructor().copy(this,t)}copy(t,e=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),e===!0)for(let n=0;n<t.children.length;n++){let i=t.children[n];this.add(i.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}};We.DEFAULT_UP=new O(0,1,0);We.DEFAULT_MATRIX_AUTO_UPDATE=!0;We.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var vs={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ce={h:0,s:0,l:0},wn={h:0,s:0,l:0};function fi(c,t,e){return e<0&&(e+=1),e>1&&(e-=1),e<1/6?c+(t-c)*6*e:e<1/2?t:e<2/3?c+(t-c)*6*(2/3-e):c}var yt=class{constructor(t,e,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,n)}set(t,e,n){if(e===void 0&&n===void 0){let i=t;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(t,e,n);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,e=Xt){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Wt.colorSpaceToWorking(this,e),this}setRGB(t,e,n,i=Wt.workingColorSpace){return this.r=t,this.g=e,this.b=n,Wt.colorSpaceToWorking(this,i),this}setHSL(t,e,n,i=Wt.workingColorSpace){if(t=Go(t,1),e=nt(e,0,1),n=nt(n,0,1),e===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+e):n+e-n*e,s=2*n-r;this.r=fi(s,r,t+1/3),this.g=fi(s,r,t),this.b=fi(s,r,t-1/3)}return Wt.colorSpaceToWorking(this,i),this}setStyle(t,e=Xt){function n(r){r!==void 0&&parseFloat(r)<1&&Tt("Color: Alpha component of "+t+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){let r,s=i[1],o=i[2];switch(s){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);break;default:Tt("Color: Unknown color model "+t)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){let r=i[1],s=r.length;if(s===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,e);if(s===6)return this.setHex(parseInt(r,16),e);Tt("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,e);return this}setColorName(t,e=Xt){let n=vs[t.toLowerCase()];return n!==void 0?this.setHex(n,e):Tt("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=ee(t.r),this.g=ee(t.g),this.b=ee(t.b),this}copyLinearToSRGB(t){return this.r=He(t.r),this.g=He(t.g),this.b=He(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Xt){return Wt.workingToColorSpace(It.copy(this),t),Math.round(nt(It.r*255,0,255))*65536+Math.round(nt(It.g*255,0,255))*256+Math.round(nt(It.b*255,0,255))}getHexString(t=Xt){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,e=Wt.workingColorSpace){Wt.workingToColorSpace(It.copy(this),e);let n=It.r,i=It.g,r=It.b,s=Math.max(n,i,r),o=Math.min(n,i,r),u,h,f=(o+s)/2;if(o===s)u=0,h=0;else{let d=s-o;switch(h=f<=.5?d/(s+o):d/(2-s-o),s){case n:u=(i-r)/d+(i<r?6:0);break;case i:u=(r-n)/d+2;break;case r:u=(n-i)/d+4;break}u/=6}return t.h=u,t.s=h,t.l=f,t}getRGB(t,e=Wt.workingColorSpace){return Wt.workingToColorSpace(It.copy(this),e),t.r=It.r,t.g=It.g,t.b=It.b,t}getStyle(t=Xt){Wt.workingToColorSpace(It.copy(this),t);let e=It.r,n=It.g,i=It.b;return t!==Xt?`color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(e*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(t,e,n){return this.getHSL(ce),this.setHSL(ce.h+t,ce.s+e,ce.l+n)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,e){return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,e){return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this}lerpColors(t,e,n){return this.r=t.r+(e.r-t.r)*n,this.g=t.g+(e.g-t.g)*n,this.b=t.b+(e.b-t.b)*n,this}lerpHSL(t,e){this.getHSL(ce),t.getHSL(wn);let n=ai(ce.h,wn.h,e),i=ai(ce.s,wn.s,e),r=ai(ce.l,wn.l,e);return this.setHSL(n,i,r),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){let e=this.r,n=this.g,i=this.b,r=t.elements;return this.r=r[0]*e+r[3]*n+r[6]*i,this.g=r[1]*e+r[4]*n+r[7]*i,this.b=r[2]*e+r[5]*n+r[8]*i,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,e=0){return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this}toArray(t=[],e=0){return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t}fromBufferAttribute(t,e){return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},It=new yt;yt.NAMES=vs;var Me=class{constructor(t=new O(1/0,1/0,1/0),e=new O(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=e}set(t,e){return this.min.copy(t),this.max.copy(e),this}setFromArray(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e+=3)this.expandByPoint(Jt.fromArray(t,e));return this}setFromBufferAttribute(t){this.makeEmpty();for(let e=0,n=t.count;e<n;e++)this.expandByPoint(Jt.fromBufferAttribute(t,e));return this}setFromPoints(t){this.makeEmpty();for(let e=0,n=t.length;e<n;e++)this.expandByPoint(t[e]);return this}setFromCenterAndSize(t,e){let n=Jt.copy(e).multiplyScalar(.5);return this.min.copy(t).sub(n),this.max.copy(t).add(n),this}setFromObject(t,e=!1){return this.makeEmpty(),this.expandByObject(t,e)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,e=!1){t.updateWorldMatrix(!1,!1);let n=t.geometry;if(n!==void 0){let r=n.getAttribute("position");if(e===!0&&r!==void 0&&t.isInstancedMesh!==!0)for(let s=0,o=r.count;s<o;s++)t.isMesh===!0?t.getVertexPosition(s,Jt):Jt.fromBufferAttribute(r,s),Jt.applyMatrix4(t.matrixWorld),this.expandByPoint(Jt);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Tn.copy(t.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),Tn.copy(n.boundingBox)),Tn.applyMatrix4(t.matrixWorld),this.union(Tn)}let i=t.children;for(let r=0,s=i.length;r<s;r++)this.expandByObject(i[r],e);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,e){return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Jt),Jt.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let e,n;return t.normal.x>0?(e=t.normal.x*this.min.x,n=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,n=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,n+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,n+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,n+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,n+=t.normal.z*this.min.z),e<=-t.constant&&n>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Qe),An.subVectors(this.max,Qe),Fe.subVectors(t.a,Qe),Oe.subVectors(t.b,Qe),Be.subVectors(t.c,Qe),he.subVectors(Oe,Fe),ue.subVectors(Be,Oe),xe.subVectors(Fe,Be);let e=[0,-he.z,he.y,0,-ue.z,ue.y,0,-xe.z,xe.y,he.z,0,-he.x,ue.z,0,-ue.x,xe.z,0,-xe.x,-he.y,he.x,0,-ue.y,ue.x,0,-xe.y,xe.x,0];return!di(e,Fe,Oe,Be,An)||(e=[1,0,0,0,1,0,0,0,1],!di(e,Fe,Oe,Be,An))?!1:(En.crossVectors(he,ue),e=[En.x,En.y,En.z],di(e,Fe,Oe,Be,An))}clampPoint(t,e){return e.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Jt).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Jt).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(te[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),te[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),te[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),te[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),te[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),te[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),te[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),te[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(te),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}},te=[new O,new O,new O,new O,new O,new O,new O,new O],Jt=new O,Tn=new Me,Fe=new O,Oe=new O,Be=new O,he=new O,ue=new O,xe=new O,Qe=new O,An=new O,En=new O,ye=new O;function di(c,t,e,n,i){for(let r=0,s=c.length-3;r<=s;r+=3){ye.fromArray(c,r);let o=i.x*Math.abs(ye.x)+i.y*Math.abs(ye.y)+i.z*Math.abs(ye.z),u=t.dot(ye),h=e.dot(ye),f=n.dot(ye);if(Math.max(-Math.max(u,h,f),Math.min(u,h,f))>o)return!1}return!0}var xt=new O,Cn=new Dt,Qo=0,Bt=class extends Se{constructor(t,e,n=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Qo++}),this.name="",this.array=t,this.itemSize=e,this.count=t!==void 0?t.length/e:0,this.normalized=n,this.usage=Bo,this.updateRanges=[],this.gpuType=ps,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,e){this.updateRanges.push({start:t,count:e})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,e,n){t*=this.itemSize,n*=e.itemSize;for(let i=0,r=this.itemSize;i<r;i++)this.array[t+i]=e.array[n+i];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let e=0,n=this.count;e<n;e++)Cn.fromBufferAttribute(this,e),Cn.applyMatrix3(t),this.setXY(e,Cn.x,Cn.y);else if(this.itemSize===3)for(let e=0,n=this.count;e<n;e++)xt.fromBufferAttribute(this,e),xt.applyMatrix3(t),this.setXYZ(e,xt.x,xt.y,xt.z);return this}applyMatrix4(t){for(let e=0,n=this.count;e<n;e++)xt.fromBufferAttribute(this,e),xt.applyMatrix4(t),this.setXYZ(e,xt.x,xt.y,xt.z);return this}applyNormalMatrix(t){for(let e=0,n=this.count;e<n;e++)xt.fromBufferAttribute(this,e),xt.applyNormalMatrix(t),this.setXYZ(e,xt.x,xt.y,xt.z);return this}transformDirection(t){for(let e=0,n=this.count;e<n;e++)xt.fromBufferAttribute(this,e),xt.transformDirection(t),this.setXYZ(e,xt.x,xt.y,xt.z);return this}set(t,e=0){return this.array.set(t,e),this}getComponent(t,e){let n=this.array[t*this.itemSize+e];return this.normalized&&(n=Ke(n,this.array)),n}setComponent(t,e,n){return this.normalized&&(n=Ot(n,this.array)),this.array[t*this.itemSize+e]=n,this}getX(t){let e=this.array[t*this.itemSize];return this.normalized&&(e=Ke(e,this.array)),e}setX(t,e){return this.normalized&&(e=Ot(e,this.array)),this.array[t*this.itemSize]=e,this}getY(t){let e=this.array[t*this.itemSize+1];return this.normalized&&(e=Ke(e,this.array)),e}setY(t,e){return this.normalized&&(e=Ot(e,this.array)),this.array[t*this.itemSize+1]=e,this}getZ(t){let e=this.array[t*this.itemSize+2];return this.normalized&&(e=Ke(e,this.array)),e}setZ(t,e){return this.normalized&&(e=Ot(e,this.array)),this.array[t*this.itemSize+2]=e,this}getW(t){let e=this.array[t*this.itemSize+3];return this.normalized&&(e=Ke(e,this.array)),e}setW(t,e){return this.normalized&&(e=Ot(e,this.array)),this.array[t*this.itemSize+3]=e,this}setXY(t,e,n){return t*=this.itemSize,this.normalized&&(e=Ot(e,this.array),n=Ot(n,this.array)),this.array[t+0]=e,this.array[t+1]=n,this}setXYZ(t,e,n,i){return t*=this.itemSize,this.normalized&&(e=Ot(e,this.array),n=Ot(n,this.array),i=Ot(i,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this}setXYZW(t,e,n,i,r){return t*=this.itemSize,this.normalized&&(e=Ot(e,this.array),n=Ot(n,this.array),i=Ot(i,this.array),r=Ot(r,this.array)),this.array[t+0]=e,this.array[t+1]=n,this.array[t+2]=i,this.array[t+3]=r,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return t.name=this.name,t.usage=this.usage,t.gpuType=this.gpuType,t}dispose(){this.dispatchEvent({type:"dispose"})}};var Un=class extends Bt{constructor(t,e,n){super(new Uint16Array(t),e,n)}};var Nn=class extends Bt{constructor(t,e,n){super(new Uint32Array(t),e,n)}};var Fn=class extends Bt{constructor(t,e,n){super(new Float32Array(t),e,n)}},tl=new Me,tn=new O,pi=new O,Ui=class{constructor(t=new O,e=-1){this.isSphere=!0,this.center=t,this.radius=e}set(t,e){return this.center.copy(t),this.radius=e,this}setFromPoints(t,e){let n=this.center;e!==void 0?n.copy(e):tl.setFromPoints(t).getCenter(n);let i=0;for(let r=0,s=t.length;r<s;r++)i=Math.max(i,n.distanceToSquared(t[r]));return this.radius=Math.sqrt(i),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){let e=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=e*e}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,e){let n=this.center.distanceToSquared(t);return e.copy(t),n>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;tn.subVectors(t,this.center);let e=tn.lengthSq();if(e>this.radius*this.radius){let n=Math.sqrt(e),i=(n-this.radius)*.5;this.center.addScaledVector(tn,i/n),this.radius+=i}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(pi.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(tn.copy(t.center).add(pi)),this.expandByPoint(tn.copy(t.center).sub(pi))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}},el=0,Gt=new Kt,mi=new We,ze=new O,kt=new Me,en=new Me,wt=new O,be=class c extends Se{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:el++}),this.uuid=Bn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(zo(t)?Nn:Un)(t,1):this.index=t,this}setIndirect(t,e=0){return this.indirect=t,this.indirectOffset=e,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,e){return this.attributes[t]=e,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,e,n=0){this.groups.push({start:t,count:e,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(t,e){this.drawRange.start=t,this.drawRange.count=e}applyMatrix4(t){let e=this.attributes.position;e!==void 0&&(e.applyMatrix4(t),e.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let r=new K().getNormalMatrix(t);n.applyNormalMatrix(r),n.needsUpdate=!0}let i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(t),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(t){return Gt.makeRotationFromQuaternion(t),this.applyMatrix4(Gt),this}rotateX(t){return Gt.makeRotationX(t),this.applyMatrix4(Gt),this}rotateY(t){return Gt.makeRotationY(t),this.applyMatrix4(Gt),this}rotateZ(t){return Gt.makeRotationZ(t),this.applyMatrix4(Gt),this}translate(t,e,n){return Gt.makeTranslation(t,e,n),this.applyMatrix4(Gt),this}scale(t,e,n){return Gt.makeScale(t,e,n),this.applyMatrix4(Gt),this}lookAt(t){return mi.lookAt(t),mi.updateMatrix(),this.applyMatrix4(mi.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ze).negate(),this.translate(ze.x,ze.y,ze.z),this}setFromPoints(t){let e=this.getAttribute("position");if(e===void 0){let n=[];for(let i=0,r=t.length;i<r;i++){let s=t[i];n.push(s.x,s.y,s.z||0)}this.setAttribute("position",new Fn(n,3))}else{let n=Math.min(t.length,e.count);for(let i=0;i<n;i++){let r=t[i];e.setXYZ(i,r.x,r.y,r.z||0)}t.length>e.count&&Tt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Me);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){mt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new O(-1/0,-1/0,-1/0),new O(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),e)for(let n=0,i=e.length;n<i;n++){let r=e[n];kt.setFromBufferAttribute(r),this.morphTargetsRelative?(wt.addVectors(this.boundingBox.min,kt.min),this.boundingBox.expandByPoint(wt),wt.addVectors(this.boundingBox.max,kt.max),this.boundingBox.expandByPoint(wt)):(this.boundingBox.expandByPoint(kt.min),this.boundingBox.expandByPoint(kt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&mt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ui);let t=this.attributes.position,e=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){mt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new O,1/0);return}if(t){let n=this.boundingSphere.center;if(kt.setFromBufferAttribute(t),e)for(let r=0,s=e.length;r<s;r++){let o=e[r];en.setFromBufferAttribute(o),this.morphTargetsRelative?(wt.addVectors(kt.min,en.min),kt.expandByPoint(wt),wt.addVectors(kt.max,en.max),kt.expandByPoint(wt)):(kt.expandByPoint(en.min),kt.expandByPoint(en.max))}kt.getCenter(n);let i=0;for(let r=0,s=t.count;r<s;r++)wt.fromBufferAttribute(t,r),i=Math.max(i,n.distanceToSquared(wt));if(e)for(let r=0,s=e.length;r<s;r++){let o=e[r],u=this.morphTargetsRelative;for(let h=0,f=o.count;h<f;h++)wt.fromBufferAttribute(o,h),u&&(ze.fromBufferAttribute(t,h),wt.add(ze)),i=Math.max(i,n.distanceToSquared(wt))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&mt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let t=this.index,e=this.attributes;if(t===null||e.position===void 0||e.normal===void 0||e.uv===void 0){mt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let n=e.position,i=e.normal,r=e.uv,s=this.getAttribute("tangent");(s===void 0||s.count!==n.count)&&(s=new Bt(new Float32Array(4*n.count),4),this.setAttribute("tangent",s));let o=[],u=[];for(let U=0;U<n.count;U++)o[U]=new O,u[U]=new O;let h=new O,f=new O,d=new O,g=new Dt,m=new Dt,v=new Dt,y=new O,T=new O;function C(U,F,G){h.fromBufferAttribute(n,U),f.fromBufferAttribute(n,F),d.fromBufferAttribute(n,G),g.fromBufferAttribute(r,U),m.fromBufferAttribute(r,F),v.fromBufferAttribute(r,G),f.sub(h),d.sub(h),m.sub(g),v.sub(g);let Y=1/(m.x*v.y-v.x*m.y);isFinite(Y)&&(y.copy(f).multiplyScalar(v.y).addScaledVector(d,-m.y).multiplyScalar(Y),T.copy(d).multiplyScalar(m.x).addScaledVector(f,-v.x).multiplyScalar(Y),o[U].add(y),o[F].add(y),o[G].add(y),u[U].add(T),u[F].add(T),u[G].add(T))}let D=this.groups;D.length===0&&(D=[{start:0,count:t.count}]);for(let U=0,F=D.length;U<F;++U){let G=D[U],Y=G.start,X=G.count;for(let N=Y,Z=Y+X;N<Z;N+=3)C(t.getX(N+0),t.getX(N+1),t.getX(N+2))}let I=new O,V=new O,P=new O,k=new O;function H(U){P.fromBufferAttribute(i,U),k.copy(P);let F=o[U];I.copy(F),I.sub(P.multiplyScalar(P.dot(F))).normalize(),V.crossVectors(k,F);let Y=V.dot(u[U])<0?-1:1;s.setXYZW(U,I.x,I.y,I.z,Y)}for(let U=0,F=D.length;U<F;++U){let G=D[U],Y=G.start,X=G.count;for(let N=Y,Z=Y+X;N<Z;N+=3)H(t.getX(N+0)),H(t.getX(N+1)),H(t.getX(N+2))}this._transformed=!0}computeVertexNormals(){let t=this.index,e=this.getAttribute("position");if(e!==void 0){let n=this.getAttribute("normal");if(n===void 0||n.count!==e.count)n=new Bt(new Float32Array(e.count*3),3),this.setAttribute("normal",n);else for(let g=0,m=n.count;g<m;g++)n.setXYZ(g,0,0,0);let i=new O,r=new O,s=new O,o=new O,u=new O,h=new O,f=new O,d=new O;if(t)for(let g=0,m=t.count;g<m;g+=3){let v=t.getX(g+0),y=t.getX(g+1),T=t.getX(g+2);i.fromBufferAttribute(e,v),r.fromBufferAttribute(e,y),s.fromBufferAttribute(e,T),f.subVectors(s,r),d.subVectors(i,r),f.cross(d),o.fromBufferAttribute(n,v),u.fromBufferAttribute(n,y),h.fromBufferAttribute(n,T),o.add(f),u.add(f),h.add(f),n.setXYZ(v,o.x,o.y,o.z),n.setXYZ(y,u.x,u.y,u.z),n.setXYZ(T,h.x,h.y,h.z)}else for(let g=0,m=e.count;g<m;g+=3)i.fromBufferAttribute(e,g+0),r.fromBufferAttribute(e,g+1),s.fromBufferAttribute(e,g+2),f.subVectors(s,r),d.subVectors(i,r),f.cross(d),n.setXYZ(g+0,f.x,f.y,f.z),n.setXYZ(g+1,f.x,f.y,f.z),n.setXYZ(g+2,f.x,f.y,f.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let t=this.attributes.normal;for(let e=0,n=t.count;e<n;e++)wt.fromBufferAttribute(t,e),wt.normalize(),t.setXYZ(e,wt.x,wt.y,wt.z)}toNonIndexed(){function t(o,u){let h=o.array,f=o.itemSize,d=o.normalized,g=new h.constructor(u.length*f),m=0,v=0;for(let y=0,T=u.length;y<T;y++){o.isInterleavedBufferAttribute?m=u[y]*o.data.stride+o.offset:m=u[y]*f;for(let C=0;C<f;C++)g[v++]=h[m++]}return new Bt(g,f,d)}if(this.index===null)return Tt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let e=new c,n=this.index.array,i=this.attributes;for(let o in i){let u=i[o],h=t(u,n);e.setAttribute(o,h)}let r=this.morphAttributes;for(let o in r){let u=[],h=r[o];for(let f=0,d=h.length;f<d;f++){let g=h[f],m=t(g,n);u.push(m)}e.morphAttributes[o]=u}e.morphTargetsRelative=this.morphTargetsRelative;let s=this.groups;for(let o=0,u=s.length;o<u;o++){let h=s[o];e.addGroup(h.start,h.count,h.materialIndex)}return e}toJSON(){let t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,t.name=this.name,Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let u=this.parameters;for(let h in u)u[h]!==void 0&&(t[h]=u[h]);return t}t.data={attributes:{}};let e=this.index;e!==null&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});let n=this.attributes;for(let u in n){let h=n[u];t.data.attributes[u]=h.toJSON(t.data)}let i={},r=!1;for(let u in this.morphAttributes){let h=this.morphAttributes[u],f=[];for(let d=0,g=h.length;d<g;d++){let m=h[d];f.push(m.toJSON(t.data))}f.length>0&&(i[u]=f,r=!0)}r&&(t.data.morphAttributes=i,t.data.morphTargetsRelative=this.morphTargetsRelative);let s=this.groups;s.length>0&&(t.data.groups=JSON.parse(JSON.stringify(s)));let o=this.boundingSphere;return o!==null&&(t.data.boundingSphere=o.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let e={};this.name=t.name;let n=t.index;n!==null&&this.setIndex(n.clone());let i=t.attributes;for(let h in i){let f=i[h];this.setAttribute(h,f.clone(e))}let r=t.morphAttributes;for(let h in r){let f=[],d=r[h];for(let g=0,m=d.length;g<m;g++)f.push(d[g].clone(e));this.morphAttributes[h]=f}this.morphTargetsRelative=t.morphTargetsRelative;let s=t.groups;for(let h=0,f=s.length;h<f;h++){let d=s[h];this.addGroup(d.start,d.count,d.materialIndex)}let o=t.boundingBox;o!==null&&(this.boundingBox=o.clone());let u=t.boundingSphere;return u!==null&&(this.boundingSphere=u.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this._transformed=t._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}};function _s(c){let t={};for(let e in c){t[e]={};for(let n in c[e]){let i=c[e][n];if(es(i))i.isRenderTargetTexture?(Tt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[e][n]=null):t[e][n]=i.clone();else if(Array.isArray(i))if(es(i[0])){let r=[];for(let s=0,o=i.length;s<o;s++)r[s]=i[s].clone();t[e][n]=r}else t[e][n]=i.slice();else t[e][n]=i}}return t}function Ut(c){let t={};for(let e=0;e<c.length;e++){let n=_s(c[e]);for(let i in n)t[i]=n[i]}return t}function es(c){return c&&(c.isColor||c.isMatrix3||c.isMatrix4||c.isVector2||c.isVector3||c.isVector4||c.isTexture||c.isQuaternion)}function Ve(c,t){return!c||c.constructor===t?c:typeof t.BYTES_PER_ELEMENT=="number"?new t(c):Array.prototype.slice.call(c)}function gi(c){return c!==void 0&&c.inTangents!==void 0&&c.outTangents!==void 0}var we=class{constructor(t,e,n,i){this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new e.constructor(n),this.sampleValues=e,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(t){let e=this.parameterPositions,n=this._cachedIndex,i=e[n],r=e[n-1];n:{t:{let s;e:{i:if(!(t<i)){for(let o=n+2;;){if(i===void 0){if(t<r)break i;return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===o)break;if(r=i,i=e[++n],t<i)break t}s=e.length;break e}if(!(t>=r)){let o=e[1];t<o&&(n=2,r=o);for(let u=n-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===u)break;if(i=r,r=e[--n-1],t>=r)break t}s=n,n=0;break e}break n}for(;n<s;){let o=n+s>>>1;t<e[o]?s=o:n=o+1}if(i=e[n],r=e[n-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=e.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,r,i)}return this.interpolate_(n,r,t,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(t){let e=this.resultBuffer,n=this.sampleValues,i=this.valueSize,r=t*i;for(let s=0;s!==i;++s)e[s]=n[r+s];return e}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}},Ni=class extends we{constructor(t,e,n,i){super(t,e,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Vr,endingEnd:Vr}}intervalChanged_(t,e,n){let i=this.parameterPositions,r=t-2,s=t+1,o=i[r],u=i[s];if(o===void 0)switch(this.getSettings_().endingStart){case kr:r=t,o=2*e-n;break;case Hr:r=i.length-2,o=e+i[r]-i[r+1];break;default:r=t,o=n}if(u===void 0)switch(this.getSettings_().endingEnd){case kr:s=t,u=2*n-e;break;case Hr:s=1,u=n+i[1]-i[0];break;default:s=t-1,u=e}let h=(n-e)*.5,f=this.valueSize;this._weightPrev=h/(e-o),this._weightNext=h/(u-n),this._offsetPrev=r*f,this._offsetNext=s*f}interpolate_(t,e,n,i){let r=this.resultBuffer,s=this.sampleValues,o=this.valueSize,u=t*o,h=u-o,f=this._offsetPrev,d=this._offsetNext,g=this._weightPrev,m=this._weightNext,v=(n-e)/(i-e),y=v*v,T=y*v,C=-g*T+2*g*y-g*v,D=(1+g)*T+(-1.5-2*g)*y+(-.5+g)*v+1,I=(-1-m)*T+(1.5+m)*y+.5*v,V=m*T-m*y;for(let P=0;P!==o;++P)r[P]=C*s[f+P]+D*s[h+P]+I*s[u+P]+V*s[d+P];return r}},Fi=class extends we{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,s=this.sampleValues,o=this.valueSize,u=t*o,h=u-o,f=(n-e)/(i-e),d=1-f;for(let g=0;g!==o;++g)r[g]=s[h+g]*d+s[u+g]*f;return r}},Oi=class extends we{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t){return this.copySampleValue_(t-1)}},Bi=class extends we{interpolate_(t,e,n,i){let r=this.resultBuffer,s=this.sampleValues,o=this.valueSize,u=t*o,h=u-o,f=this.inTangents,d=this.outTangents;if(!f||!d){let v=(n-e)/(i-e),y=1-v;for(let T=0;T!==o;++T)r[T]=s[h+T]*y+s[u+T]*v;return r}let g=o*2,m=t-1;for(let v=0;v!==o;++v){let y=s[h+v],T=s[u+v],C=m*g+v*2,D=d[C],I=d[C+1],V=t*g+v*2,P=f[V],k=f[V+1],H=il(n,e,D,P,i);r[v]=xs(H,y,I,k,T)}return r}};function xs(c,t,e,n,i){let r=1-c;return r*r*r*t+3*r*r*c*e+3*r*c*c*n+c*c*c*i}function nl(c,t,e,n,i){let r=1-c;return 3*r*r*(e-t)+6*r*c*(n-e)+3*c*c*(i-n)}function il(c,t,e,n,i){let r=(c-t)/(i-t);for(let s=0;s<8;s++){let o=xs(r,t,e,n,i)-c;if(Math.abs(o)<1e-10)break;let u=nl(r,t,e,n,i);if(Math.abs(u)<1e-10)break;r=Math.max(0,Math.min(1,r-o/u))}return r}var qt=class{constructor(t,e,n,i){if(t===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(e===void 0||e.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+t);this.name=t,this.times=Ve(e,this.TimeBufferType),this.values=Ve(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(t){let e=t.constructor,n;if(e.toJSON!==this.toJSON)n=e.toJSON(t);else{n={name:t.name,times:Ve(t.times,Array),values:Ve(t.values,Array)};let i=t.getInterpolation();i!==t.DefaultInterpolation&&(n.interpolation=i),gi(t.settings)&&(n.settings={inTangents:Ve(t.settings.inTangents,Array),outTangents:Ve(t.settings.outTangents,Array)})}return n.type=t.ValueTypeName,n}InterpolantFactoryMethodDiscrete(t){return new Oi(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodLinear(t){return new Fi(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodSmooth(t){return new Ni(this.times,this.values,this.getValueSize(),t)}InterpolantFactoryMethodBezier(t){let e=new Bi(this.times,this.values,this.getValueSize(),t);return this.settings&&(e.inTangents=this.settings.inTangents,e.outTangents=this.settings.outTangents),e}setInterpolation(t){let e;switch(t){case Pn:e=this.InterpolantFactoryMethodDiscrete;break;case Ei:e=this.InterpolantFactoryMethodLinear;break;case si:e=this.InterpolantFactoryMethodSmooth;break;case zr:e=this.InterpolantFactoryMethodBezier;break}if(e===void 0){let n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(t!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return Tt("KeyframeTrack:",n),this}return this.createInterpolant=e,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Pn;case this.InterpolantFactoryMethodLinear:return Ei;case this.InterpolantFactoryMethodSmooth:return si;case this.InterpolantFactoryMethodBezier:return zr}}getValueSize(){return this.values.length/this.times.length}shift(t){if(t!==0){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]+=t}return this}scale(t){if(t!==1){let e=this.times;for(let n=0,i=e.length;n!==i;++n)e[n]*=t;gi(this.settings)&&(ns(this.settings.inTangents,t),ns(this.settings.outTangents,t))}return this}trim(t,e){let n=this.times,i=n.length,r=0,s=i-1;for(;r!==i&&n[r]<t;)++r;for(;s!==-1&&n[s]>e;)--s;if(++s,r!==0||s!==i){r>=s&&(s=Math.max(s,1),r=s-1);let o=this.getValueSize();this.times=n.slice(r,s),this.values=this.values.slice(r*o,s*o)}return this}validate(){let t=!0,e=this.getValueSize();e-Math.floor(e)!==0&&(mt("KeyframeTrack: Invalid value size in track.",this),t=!1);let n=this.times,i=this.values,r=n.length;r===0&&(mt("KeyframeTrack: Track is empty.",this),t=!1);let s=null;for(let o=0;o!==r;o++){let u=n[o];if(typeof u=="number"&&isNaN(u)){mt("KeyframeTrack: Time is not a valid number.",this,o,u),t=!1;break}if(s!==null&&s>u){mt("KeyframeTrack: Out of order keys.",this,o,u,s),t=!1;break}s=u}if(i!==void 0&&Vo(i))for(let o=0,u=i.length;o!==u;++o){let h=i[o];if(isNaN(h)){mt("KeyframeTrack: Value is not a valid number.",this,o,h),t=!1;break}}return t}optimize(){let t=this.times.slice(),e=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===si,r=t.length-1,s=1;for(let o=1;o<r;++o){let u=!1,h=t[o],f=t[o+1];if(h!==f&&(o!==1||h!==t[0]))if(i)u=!0;else{let d=o*n,g=d-n,m=d+n;for(let v=0;v!==n;++v){let y=e[d+v];if(y!==e[g+v]||y!==e[m+v]){u=!0;break}}}if(u){if(o!==s){t[s]=t[o];let d=o*n,g=s*n;for(let m=0;m!==n;++m)e[g+m]=e[d+m]}++s}}if(r>0){t[s]=t[r];for(let o=r*n,u=s*n,h=0;h!==n;++h)e[u+h]=e[o+h];++s}return s!==t.length?(this.times=t.slice(0,s),this.values=e.slice(0,s*n)):(this.times=t,this.values=e),this}clone(){let t=this.times.slice(),e=this.values.slice(),n=this.constructor,i=new n(this.name,t,e);return i.createInterpolant=this.createInterpolant,gi(this.settings)&&(i.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),i}};function ns(c,t){for(let e=0,n=c.length;e!==n;e+=2)c[e]*=t}qt.prototype.ValueTypeName="";qt.prototype.TimeBufferType=Float32Array;qt.prototype.ValueBufferType=Float32Array;qt.prototype.DefaultInterpolation=Ei;var Te=class extends qt{constructor(t,e,n){super(t,e,n)}};Te.prototype.ValueTypeName="bool";Te.prototype.ValueBufferType=Array;Te.prototype.DefaultInterpolation=Pn;Te.prototype.InterpolantFactoryMethodLinear=void 0;Te.prototype.InterpolantFactoryMethodSmooth=void 0;var zi=class extends qt{constructor(t,e,n,i){super(t,e,n,i)}};zi.prototype.ValueTypeName="color";var Vi=class extends qt{constructor(t,e,n,i){super(t,e,n,i)}};Vi.prototype.ValueTypeName="number";var ki=class extends we{constructor(t,e,n,i){super(t,e,n,i)}interpolate_(t,e,n,i){let r=this.resultBuffer,s=this.sampleValues,o=this.valueSize,u=(n-e)/(i-e),h=t*o;for(let f=h+o;h!==f;h+=4)fe.slerpFlat(r,0,s,h-o,s,h,u);return r}},On=class extends qt{constructor(t,e,n,i){super(t,e,n,i)}InterpolantFactoryMethodLinear(t){return new ki(this.times,this.values,this.getValueSize(),t)}};On.prototype.ValueTypeName="quaternion";On.prototype.InterpolantFactoryMethodSmooth=void 0;var Ae=class extends qt{constructor(t,e,n){super(t,e,n)}};Ae.prototype.ValueTypeName="string";Ae.prototype.ValueBufferType=Array;Ae.prototype.DefaultInterpolation=Pn;Ae.prototype.InterpolantFactoryMethodLinear=void 0;Ae.prototype.InterpolantFactoryMethodSmooth=void 0;var Hi=class extends qt{constructor(t,e,n,i){super(t,e,n,i)}};Hi.prototype.ValueTypeName="vector";var Gi=class{constructor(t,e,n){let i=this,r=!1,s=0,o=0,u,h=[];this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=n,this._abortController=null,this.itemStart=function(f){o++,r===!1&&i.onStart!==void 0&&i.onStart(f,s,o),r=!0},this.itemEnd=function(f){s++,i.onProgress!==void 0&&i.onProgress(f,s,o),s===o&&(r=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(f){i.onError!==void 0&&i.onError(f)},this.resolveURL=function(f){return f=f.normalize("NFC"),u?u(f):f},this.setURLModifier=function(f){return u=f,this},this.addHandler=function(f,d){return h.push(f,d),this},this.removeHandler=function(f){let d=h.indexOf(f);return d!==-1&&h.splice(d,2),this},this.getHandler=function(f){for(let d=0,g=h.length;d<g;d+=2){let m=h[d],v=h[d+1];if(m.global&&(m.lastIndex=0),m.test(f))return v}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}},rl=new Gi,Wi=class{constructor(t){this.manager=t!==void 0?t:rl,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(t,e){let n=this;return new Promise(function(i,r){n.load(t,i,e,r)})}parse(){}setCrossOrigin(t){return this.crossOrigin=t,this}setWithCredentials(t){return this.withCredentials=t,this}setPath(t){return this.path=t,this}setResourcePath(t){return this.resourcePath=t,this}setRequestHeader(t){return this.requestHeader=t,this}abort(){return this}};Wi.DEFAULT_MATERIAL_NAME="__DEFAULT";var nr="\\[\\]\\.:\\/",sl=new RegExp("["+nr+"]","g"),ir="[^"+nr+"]",al="[^"+nr.replace("\\.","")+"]",ol=/((?:WC+[\/:])*)/.source.replace("WC",ir),ll=/(WCOD+)?/.source.replace("WCOD",al),cl=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",ir),hl=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",ir),ul=new RegExp("^"+ol+ll+cl+hl+"$"),fl=["material","materials","bones","map"],Xi=class{constructor(t,e,n){let i=n||pt.parseTrackName(e);this._targetGroup=t,this._bindings=t.subscribe_(e,i)}getValue(t,e){this.bind();let n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(t,e)}setValue(t,e){let n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,r=n.length;i!==r;++i)n[i].setValue(t,e)}bind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].bind()}unbind(){let t=this._bindings;for(let e=this._targetGroup.nCachedObjects_,n=t.length;e!==n;++e)t[e].unbind()}},pt=class c{constructor(t,e,n){this.path=e,this.parsedPath=n||c.parseTrackName(e),this.node=c.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,e,n){return t&&t.isAnimationObjectGroup?new c.Composite(t,e,n):new c(t,e,n)}static sanitizeNodeName(t){return t.replace(/\s/g,"_").replace(sl,"")}static parseTrackName(t){let e=ul.exec(t);if(e===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+t);let n={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){let r=n.nodeName.substring(i+1);fl.indexOf(r)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=r)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+t);return n}static findNode(t,e){if(e===void 0||e===""||e==="."||e===-1||e===t.name||e===t.uuid)return t;if(t.skeleton){let n=t.skeleton.getBoneByName(e);if(n!==void 0)return n}if(t.children){let n=function(r){for(let s=0;s<r.length;s++){let o=r[s];if(o.name===e||o.uuid===e)return o;let u=n(o.children);if(u)return u}return null},i=n(t.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(t,e){t[e]=this.targetObject[this.propertyName]}_getValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)t[e++]=n[i]}_getValue_arrayElement(t,e){t[e]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(t,e){this.resolvedProperty.toArray(t,e)}_setValue_direct(t,e){this.targetObject[this.propertyName]=t[e]}_setValue_direct_setNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(t,e){this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++]}_setValue_array_setNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(t,e){let n=this.resolvedProperty;for(let i=0,r=n.length;i!==r;++i)n[i]=t[e++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(t,e){this.resolvedProperty[this.propertyIndex]=t[e]}_setValue_arrayElement_setNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(t,e){this.resolvedProperty.fromArray(t,e)}_setValue_fromArray_setNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(t,e){this.bind(),this.getValue(t,e)}_setValue_unbound(t,e){this.bind(),this.setValue(t,e)}bind(){let t=this.node,e=this.parsedPath,n=e.objectName,i=e.propertyName,r=e.propertyIndex;if(t||(t=c.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){Tt("PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let h=e.objectIndex;switch(n){case"materials":if(!t.material){mt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.materials){mt("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}t=t.material.materials;break;case"bones":if(!t.skeleton){mt("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}t=t.skeleton.bones;for(let f=0;f<t.length;f++)if(t[f].name===h){h=f;break}break;case"map":if("map"in t){t=t.map;break}if(!t.material){mt("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!t.material.map){mt("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}t=t.material.map;break;default:if(t[n]===void 0){mt("PropertyBinding: Can not bind to objectName of node undefined.",this);return}t=t[n]}if(h!==void 0){if(t[h]===void 0){mt("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);return}t=t[h]}}let s=t[i];if(s===void 0){let h=e.nodeName;mt("PropertyBinding: Trying to update property for track: "+h+"."+i+" but it wasn't found.",t);return}let o=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?o=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let u=this.BindingType.Direct;if(r!==void 0){if(i==="morphTargetInfluences"){if(!t.geometry){mt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!t.geometry.morphAttributes){mt("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}t.morphTargetDictionary[r]!==void 0&&(r=t.morphTargetDictionary[r])}u=this.BindingType.ArrayElement,this.resolvedProperty=s,this.propertyIndex=r}else s.fromArray!==void 0&&s.toArray!==void 0?(u=this.BindingType.HasFromToArray,this.resolvedProperty=s):Array.isArray(s)?(u=this.BindingType.EntireArray,this.resolvedProperty=s):this.propertyName=i;this.getValue=this.GetterByBindingType[u],this.setValue=this.SetterByBindingTypeAndVersioning[u][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};pt.Composite=Xi;pt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};pt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};pt.prototype.GetterByBindingType=[pt.prototype._getValue_direct,pt.prototype._getValue_array,pt.prototype._getValue_arrayElement,pt.prototype._getValue_toArray];pt.prototype.SetterByBindingTypeAndVersioning=[[pt.prototype._setValue_direct,pt.prototype._setValue_direct_setNeedsUpdate,pt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[pt.prototype._setValue_array,pt.prototype._setValue_array_setNeedsUpdate,pt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[pt.prototype._setValue_arrayElement,pt.prototype._setValue_arrayElement_setNeedsUpdate,pt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[pt.prototype._setValue_fromArray,pt.prototype._setValue_fromArray_setNeedsUpdate,pt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Eu=new Float32Array(1);var is=class c{static{c.prototype.isMatrix2=!0}constructor(t,e,n,i){this.elements=[1,0,0,1],t!==void 0&&this.set(t,e,n,i)}identity(){return this.set(1,0,0,1),this}fromArray(t,e=0){for(let n=0;n<4;n++)this.elements[n]=t[n+e];return this}set(t,e,n,i){let r=this.elements;return r[0]=t,r[2]=e,r[1]=n,r[3]=i,this}};typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"186"}}));typeof window<"u"&&(window.__THREE__?Tt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="186");var _l=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,xl=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,yl=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Sl=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ml=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,bl=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,wl=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Tl=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Al=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,El=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Cl=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Rl=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Pl=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Il=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Ll=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Dl=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Ul=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Nl=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Fl=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ol=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,Bl=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,zl=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,Vl=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,kl=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Hl=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Gl=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,Wl=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Xl=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ql=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,$l=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Yl="gl_FragColor = linearToOutputTexel( gl_FragColor );",Zl=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Jl=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Kl=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,jl=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Ql=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,tc=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,ec=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,nc=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ic=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,rc=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,sc=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ac=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,oc=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lc=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,cc=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,hc=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,uc=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,fc=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,dc=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,pc=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,mc=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,gc=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,vc=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,_c=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,xc=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,yc=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Sc=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Mc=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,bc=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,wc=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Tc=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Ac=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ec=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Cc=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Rc=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Pc=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ic=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Lc=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Dc=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Uc=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Nc=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Fc=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Oc=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Bc=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,zc=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Vc=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,kc=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Hc=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Gc=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Wc=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Xc=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,qc=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,$c=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,Yc=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Zc=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Jc=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Kc=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,jc=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Qc=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,th=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,eh=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,nh=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,ih=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,rh=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,sh=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,ah=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,oh=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,lh=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,ch=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,hh=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,uh=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,fh=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,dh=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,ph=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,mh=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,gh=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,vh=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,_h=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,xh=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,yh=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Sh=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Mh=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,bh=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,wh=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Th=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Ah=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Eh=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,Ch=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Rh=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ph=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ih=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Lh=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Dh=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Uh=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nh=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Fh=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Oh=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bh=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,zh=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Vh=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,kh=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Hh=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Gh=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Wh=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Xh=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qh=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,$h=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Yh=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zh=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Jh=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Kh=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Q={alphahash_fragment:_l,alphahash_pars_fragment:xl,alphamap_fragment:yl,alphamap_pars_fragment:Sl,alphatest_fragment:Ml,alphatest_pars_fragment:bl,aomap_fragment:wl,aomap_pars_fragment:Tl,batching_pars_vertex:Al,batching_vertex:El,begin_vertex:Cl,beginnormal_vertex:Rl,bsdfs:Pl,iridescence_fragment:Il,bumpmap_pars_fragment:Ll,clipping_planes_fragment:Dl,clipping_planes_pars_fragment:Ul,clipping_planes_pars_vertex:Nl,clipping_planes_vertex:Fl,color_fragment:Ol,color_pars_fragment:Bl,color_pars_vertex:zl,color_vertex:Vl,common:kl,cube_uv_reflection_fragment:Hl,defaultnormal_vertex:Gl,displacementmap_pars_vertex:Wl,displacementmap_vertex:Xl,emissivemap_fragment:ql,emissivemap_pars_fragment:$l,colorspace_fragment:Yl,colorspace_pars_fragment:Zl,envmap_fragment:Jl,envmap_common_pars_fragment:Kl,envmap_pars_fragment:jl,envmap_pars_vertex:Ql,envmap_physical_pars_fragment:hc,envmap_vertex:tc,fog_vertex:ec,fog_pars_vertex:nc,fog_fragment:ic,fog_pars_fragment:rc,gradientmap_pars_fragment:sc,lightmap_pars_fragment:ac,lights_lambert_fragment:oc,lights_lambert_pars_fragment:lc,lights_pars_begin:cc,lights_toon_fragment:uc,lights_toon_pars_fragment:fc,lights_phong_fragment:dc,lights_phong_pars_fragment:pc,lights_physical_fragment:mc,lights_physical_pars_fragment:gc,lights_fragment_begin:vc,lights_fragment_maps:_c,lights_fragment_end:xc,lightprobes_pars_fragment:yc,logdepthbuf_fragment:Sc,logdepthbuf_pars_fragment:Mc,logdepthbuf_pars_vertex:bc,logdepthbuf_vertex:wc,map_fragment:Tc,map_pars_fragment:Ac,map_particle_fragment:Ec,map_particle_pars_fragment:Cc,metalnessmap_fragment:Rc,metalnessmap_pars_fragment:Pc,morphinstance_vertex:Ic,morphcolor_vertex:Lc,morphnormal_vertex:Dc,morphtarget_pars_vertex:Uc,morphtarget_vertex:Nc,normal_fragment_begin:Fc,normal_fragment_maps:Oc,normal_pars_fragment:Bc,normal_pars_vertex:zc,normal_vertex:Vc,normalmap_pars_fragment:kc,clearcoat_normal_fragment_begin:Hc,clearcoat_normal_fragment_maps:Gc,clearcoat_pars_fragment:Wc,iridescence_pars_fragment:Xc,opaque_fragment:qc,packing:$c,premultiplied_alpha_fragment:Yc,project_vertex:Zc,dithering_fragment:Jc,dithering_pars_fragment:Kc,roughnessmap_fragment:jc,roughnessmap_pars_fragment:Qc,shadowmap_pars_fragment:th,shadowmap_pars_vertex:eh,shadowmap_vertex:nh,shadowmask_pars_fragment:ih,skinbase_vertex:rh,skinning_pars_vertex:sh,skinning_vertex:ah,skinnormal_vertex:oh,specularmap_fragment:lh,specularmap_pars_fragment:ch,tonemapping_fragment:hh,tonemapping_pars_fragment:uh,transmission_fragment:fh,transmission_pars_fragment:dh,uv_pars_fragment:ph,uv_pars_vertex:mh,uv_vertex:gh,worldpos_vertex:vh,background_vert:_h,background_frag:xh,backgroundCube_vert:yh,backgroundCube_frag:Sh,cube_vert:Mh,cube_frag:bh,depth_vert:wh,depth_frag:Th,distance_vert:Ah,distance_frag:Eh,equirect_vert:Ch,equirect_frag:Rh,linedashed_vert:Ph,linedashed_frag:Ih,meshbasic_vert:Lh,meshbasic_frag:Dh,meshlambert_vert:Uh,meshlambert_frag:Nh,meshmatcap_vert:Fh,meshmatcap_frag:Oh,meshnormal_vert:Bh,meshnormal_frag:zh,meshphong_vert:Vh,meshphong_frag:kh,meshphysical_vert:Hh,meshphysical_frag:Gh,meshtoon_vert:Wh,meshtoon_frag:Xh,points_vert:qh,points_frag:$h,shadow_vert:Yh,shadow_frag:Zh,sprite_vert:Jh,sprite_frag:Kh},z={common:{diffuse:{value:new yt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new K},alphaMap:{value:null},alphaMapTransform:{value:new K},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new K}},envmap:{envMap:{value:null},envMapRotation:{value:new K},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new K}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new K}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new K},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new K},normalScale:{value:new Dt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new K},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new K}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new K}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new K}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new yt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new O},probesMax:{value:new O},probesResolution:{value:new O}},points:{diffuse:{value:new yt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new K},alphaTest:{value:0},uvTransform:{value:new K}},sprite:{diffuse:{value:new yt(16777215)},opacity:{value:1},center:{value:new Dt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new K},alphaMap:{value:null},alphaMapTransform:{value:new K},alphaTest:{value:0}}},ys={basic:{uniforms:Ut([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.fog]),vertexShader:Q.meshbasic_vert,fragmentShader:Q.meshbasic_frag},lambert:{uniforms:Ut([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.fog,z.lights,{emissive:{value:new yt(0)},envMapIntensity:{value:1}}]),vertexShader:Q.meshlambert_vert,fragmentShader:Q.meshlambert_frag},phong:{uniforms:Ut([z.common,z.specularmap,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.fog,z.lights,{emissive:{value:new yt(0)},specular:{value:new yt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Q.meshphong_vert,fragmentShader:Q.meshphong_frag},standard:{uniforms:Ut([z.common,z.envmap,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.roughnessmap,z.metalnessmap,z.fog,z.lights,{emissive:{value:new yt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag},toon:{uniforms:Ut([z.common,z.aomap,z.lightmap,z.emissivemap,z.bumpmap,z.normalmap,z.displacementmap,z.gradientmap,z.fog,z.lights,{emissive:{value:new yt(0)}}]),vertexShader:Q.meshtoon_vert,fragmentShader:Q.meshtoon_frag},matcap:{uniforms:Ut([z.common,z.bumpmap,z.normalmap,z.displacementmap,z.fog,{matcap:{value:null}}]),vertexShader:Q.meshmatcap_vert,fragmentShader:Q.meshmatcap_frag},points:{uniforms:Ut([z.points,z.fog]),vertexShader:Q.points_vert,fragmentShader:Q.points_frag},dashed:{uniforms:Ut([z.common,z.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Q.linedashed_vert,fragmentShader:Q.linedashed_frag},depth:{uniforms:Ut([z.common,z.displacementmap]),vertexShader:Q.depth_vert,fragmentShader:Q.depth_frag},normal:{uniforms:Ut([z.common,z.bumpmap,z.normalmap,z.displacementmap,{opacity:{value:1}}]),vertexShader:Q.meshnormal_vert,fragmentShader:Q.meshnormal_frag},sprite:{uniforms:Ut([z.sprite,z.fog]),vertexShader:Q.sprite_vert,fragmentShader:Q.sprite_frag},background:{uniforms:{uvTransform:{value:new K},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Q.background_vert,fragmentShader:Q.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new K}},vertexShader:Q.backgroundCube_vert,fragmentShader:Q.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Q.cube_vert,fragmentShader:Q.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Q.equirect_vert,fragmentShader:Q.equirect_frag},distance:{uniforms:Ut([z.common,z.displacementmap,{referencePosition:{value:new O},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Q.distance_vert,fragmentShader:Q.distance_frag},shadow:{uniforms:Ut([z.lights,z.fog,{color:{value:new yt(0)},opacity:{value:1}}]),vertexShader:Q.shadow_vert,fragmentShader:Q.shadow_frag}};ys.physical={uniforms:Ut([ys.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new K},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new K},clearcoatNormalScale:{value:new Dt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new K},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new K},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new K},sheen:{value:0},sheenColor:{value:new yt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new K},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new K},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new K},transmissionSamplerSize:{value:new Dt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new K},attenuationDistance:{value:0},attenuationColor:{value:new yt(0)},specularColor:{value:new yt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new K},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new K},anisotropyVector:{value:new Dt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new K}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag};var jh=new K;jh.set(-1,0,0,0,1,0,0,0,1);var ep={[qi]:"LINEAR_TONE_MAPPING",[$i]:"REINHARD_TONE_MAPPING",[Yi]:"CINEON_TONE_MAPPING",[Zi]:"ACES_FILMIC_TONE_MAPPING",[Ki]:"AGX_TONE_MAPPING",[ji]:"NEUTRAL_TONE_MAPPING",[Ji]:"CUSTOM_TONE_MAPPING"};var np=new Float32Array(16),ip=new Float32Array(9),rp=new Float32Array(4);var sp={[qi]:"Linear",[$i]:"Reinhard",[Yi]:"Cineon",[Zi]:"ACESFilmic",[Ki]:"AgX",[ji]:"Neutral",[Ji]:"Custom"};var ap={[rs]:"SHADOWMAP_TYPE_PCF",[ss]:"SHADOWMAP_TYPE_VSM"};var op={[hs]:"ENVMAP_TYPE_CUBE",[Qi]:"ENVMAP_TYPE_CUBE",[us]:"ENVMAP_TYPE_CUBE_UV"};var lp={[Qi]:"ENVMAP_MODE_REFRACTION"};var cp={[as]:"ENVMAP_BLENDING_MULTIPLY",[os]:"ENVMAP_BLENDING_MIX",[ls]:"ENVMAP_BLENDING_ADD"};var Qh=new K;Qh.set(-1,0,0,0,1,0,0,0,1);var hp=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);var eu={cutterBase:{enabled:!1,type:"parallel",mode:"overlay",rotation:28,color:"#65584d",thickness:.12,scale:4.8,intensity:.42},blade:{enabled:!1,type:"parallel",mode:"overlay",rotation:-28,color:"#65584d",thickness:.11,scale:4,intensity:.38},stampBase:{enabled:!1,type:"cross",mode:"overlay",rotation:42,color:"#65584d",thickness:.1,scale:5.2,intensity:.38},relief:{enabled:!1,type:"double45",mode:"overlay",rotation:18,color:"#65584d",thickness:.09,scale:3.6,intensity:.34},shadow:{enabled:!1,type:"cross",mode:"replace",rotation:45,color:"#4d443e",thickness:.1,scale:4.4,intensity:.44}},gp={style:"illustrated",shadeSoftness:.65,background:"#a9eaf8",modelColor:"#ffba24",componentColors:!0,colors:{cutterBase:"#e18e25",blade:"#ffbf28",stampBase:"#38bfb8",relief:"#f07891"},lightAzimuth:-40,lightElevation:55,lightIntensity:2.4,ambient:.8,shadows:!0,groundDistance:4,projectedShadows:!0,modelShadows:!0,modelShadowMode:"soft",aoIntensity:.32,aoRadius:1.4,shadowOpacity:.3,shadowSoftness:3,lineColor:"#382a24",lineWidth:1.4,internalEdges:!0,hatching:.45,hatchMaster:!1,hatchProfiles:structuredClone(eu),projection:"perspective",showDims:!1,transparent:!1,exportSize:1600};function Ss(c,t={}){let e=c.attributes.position.array,n=c.index?.array||Uint32Array.from({length:e.length/3},(f,d)=>d),i=[],r=[],s=[],o=new Map,u=t.height-t.chamferHeight;for(let f=0;f<n.length;f+=3){let d=[n[f],n[f+1],n[f+2]],g=d.map(I=>[e[I*3],e[I*3+1],e[I*3+2]]),m=g[1].map((I,V)=>I-g[0][V]),v=g[2].map((I,V)=>I-g[0][V]),y=[m[1]*v[2]-m[2]*v[1],m[2]*v[0]-m[0]*v[2],m[0]*v[1]-m[1]*v[0]],T=Math.hypot(...y);if(T<1e-15)continue;y=y.map(I=>I/T);let C=g.map(I=>I[2]),D=Math.abs(y[2])>.9999?"cap:"+Math.round(C[0]*1e4):t.chamfer&&Math.min(...C)>=u-1e-4&&Math.max(...C)>u+1e-4&&y[2]>.001?"bevel":"wall";for(let I=0;I<3;I++){let V=D+":"+d[I],P=o.get(V);P||(P=[],o.set(V,P));let k=P.find(G=>G.n[0]*y[0]+G.n[1]*y[1]+G.n[2]*y[2]>.2);k||(k={n:y,id:i.length/3},P.push(k),i.push(...g[I]),r.push(0,0,0));let H=g[(I+1)%3].map((G,Y)=>G-g[I][Y]),U=g[(I+2)%3].map((G,Y)=>G-g[I][Y]),F=Math.acos(Math.max(-1,Math.min(1,(H[0]*U[0]+H[1]*U[1]+H[2]*U[2])/(Math.hypot(...H)*Math.hypot(...U)||1))));for(let G=0;G<3;G++)r[k.id*3+G]+=y[G]*F;s.push(k.id)}}for(let f=0;f<r.length;f+=3){let d=Math.hypot(r[f],r[f+1],r[f+2])||1;for(let g=0;g<3;g++)r[f+g]/=d}let h=new be;return h.setAttribute("position",new Bt(new Float32Array(i),3)),h.setAttribute("normal",new Bt(new Float32Array(r),3)),h.setIndex(s),h}async function nu(c={}){var t,e=c,n=!!globalThis.window,i=!!globalThis.WorkerGlobalScope,r=globalThis.process?.versions?.node&&globalThis.process?.type!="renderer";if(r){let{createRequire:a}=await import("node:module");var s=a(import.meta.url)}var o=!1;e.setup=function(){if(o)return;o=!0,e.initTBB();function a(x,M,A=(R=>R)){if(M)for(let R of M)x.push_back(A(R));return x}function l(x,M=(A=>A)){let A=[],R=x.size();for(let $=0;$<R;$++)A.push(M(x.get($)));return A}function p(x,M=(A=>A)){let A=[],R=x.size();for(let $=0;$<R;$++){let j=x.get($),ut=j.size(),At=[];for(let gt=0;gt<ut;gt++)At.push(M(j.get(gt)));A.push(At)}return A}function _(x){return x[0].length<3&&(x=[x]),a(new e.Vector2_vec2,x,M=>a(new e.Vector_vec2,M,A=>A instanceof Array?{x:A[0],y:A[1]}:A))}function S(x){for(let M=0;M<x.size();M++)x.get(M).delete();x.delete()}function b(x){return x[0]instanceof Array?{x:x[0][0],y:x[0][1]}:typeof x[0]=="number"?{x:x[0]||0,y:x[1]||0}:x[0]}function w(x){return x[0]instanceof Array?{x:x[0][0],y:x[0][1],z:x[0][2]}:typeof x[0]=="number"?{x:x[0]||0,y:x[1]||0,z:x[2]||0}:x[0]}function E(x){return x=="EvenOdd"?0:x=="NonZero"?1:x=="Negative"?3:2}function L(x){return x=="Round"?1:x=="Miter"?2:0}let B=e.CrossSection;function W(x,M="Positive"){if(x instanceof B)return x;{let A=_(x),R=new B(A,E(M));return S(A),R}}e.CrossSection.prototype.translate=function(...x){return this._Translate(b(x))},e.CrossSection.prototype.scale=function(x){return typeof x=="number"?this._Scale({x,y:x}):this._Scale(b([x]))},e.CrossSection.prototype.mirror=function(x){return this._Mirror(b([x]))},e.CrossSection.prototype.warp=function(x){let M=ge(function(R){let $=Nt(R,"double"),j=Nt(R+8,"double"),ut=[$,j];x(ut),Pe(R,ut[0],"double"),Pe(R+8,ut[1],"double")},"vi"),A=this._Warp(M);return ve(M),A},e.CrossSection.prototype.decompose=function(){let x=this._Decompose(),M=l(x);return x.delete(),M},e.CrossSection.prototype.bounds=function(){let x=this._Bounds();return{min:["x","y"].map(M=>x.min[M]),max:["x","y"].map(M=>x.max[M])}},e.CrossSection.prototype.offset=function(x,M="Round",A=2,R=0){return this._Offset(x,L(M),A,R)},e.CrossSection.prototype.simplify=function(x=1e-6){return this._Simplify(x)},e.CrossSection.prototype.extrude=function(x,M=0,A=0,R=[1,1],$=!1){R=b([R]);let j=e._Extrude(this._ToPolygons(),x,M,A,R);return $?j.translate([0,0,-x/2]):j},e.CrossSection.prototype.revolve=function(x=0,M=360){return e._Revolve(this._ToPolygons(),x,M)},e.CrossSection.prototype.add=function(x){return this._add(W(x))},e.CrossSection.prototype.subtract=function(x){return this._subtract(W(x))},e.CrossSection.prototype.intersect=function(x){return this._intersect(W(x))},e.CrossSection.prototype.toPolygons=function(){let x=this._ToPolygons(),M=p(x,A=>[A.x,A.y]);return x.delete(),M},e.Manifold.prototype.smoothOut=function(x=52.5,M=0){return this._SmoothOut(x,M)},e.Manifold.prototype.warp=function(x){let M=ge(function($){let j=Nt($,"double"),ut=Nt($+8,"double"),At=Nt($+16,"double"),gt=[j,ut,At];x(gt),Pe($,gt[0],"double"),Pe($+8,gt[1],"double"),Pe($+16,gt[2],"double")},"vi"),A=this._Warp(M);ve(M);let R=A.status();if(R!=="NoError")throw new e.ManifoldError(R);return A},e.Manifold.prototype.warpBatch=function(x){let M=ge(function($,j){let ut=e.HEAPF64??q;if(!ut)throw new Error("WASM heap is not initialized (HEAPF64 unavailable)");let At=new Float64Array(ut.buffer,$,j*3);x(At,j)},"vii"),A=this._WarpBatch(M);ve(M);let R=A.status();if(R!=="NoError")throw new e.ManifoldError(R);return A},e.Manifold.prototype.calculateNormals=function(x=0,M=52.5){return this._CalculateNormals(x,M)},e.Manifold.prototype.smoothByNormals=function(x=0){return this._SmoothByNormals(x)},e.Manifold.prototype.setProperties=function(x,M){let A=this.numProp(),R=ge(function(j,ut,At){let gt=[];for(let dt=0;dt<x;++dt)gt[dt]=Nt(j+8*dt,"double");let ae=[];for(let dt=0;dt<3;++dt)ae[dt]=Nt(ut+8*dt,"double");let oe=[];for(let dt=0;dt<A;++dt)oe[dt]=Nt(At+8*dt,"double");M(gt,ae,oe);for(let dt=0;dt<x;++dt)Pe(j+8*dt,gt[dt],"double")},"viii"),$=this._SetProperties(x,R);return ve(R),$},e.Manifold.prototype.translate=function(...x){return this._Translate(w(x))},e.Manifold.prototype.rotate=function(x,M,A){return Array.isArray(x)?this._Rotate(...x):this._Rotate(x,M||0,A||0)},e.Manifold.prototype.scale=function(x){return typeof x=="number"?this._Scale({x,y:x,z:x}):this._Scale(w([x]))},e.Manifold.prototype.mirror=function(x){return this._Mirror(w([x]))},e.Manifold.prototype.trimByPlane=function(x,M=0){return this._TrimByPlane(w([x]),M)},e.Manifold.prototype.slice=function(x=0){let M=this._Slice(x),A=new B(M,E("Positive"));return S(M),A},e.Manifold.prototype.project=function(){let x=this._Project(),M=new B(x,E("Positive"));return S(x),M},e.Manifold.prototype.rayCast=function(x,M){let A=this._RayCast(w([x]),w([M])),R=l(A,$=>({faceID:$.faceID,distance:$.distance,position:["x","y","z"].map(j=>$.position[j]),normal:["x","y","z"].map(j=>$.normal[j])}));return A.delete(),R},e.Manifold.prototype.split=function(x){let M=this._Split(x),A=l(M);return M.delete(),A},e.Manifold.prototype.splitByPlane=function(x,M=0){let A=this._SplitByPlane(w([x]),M),R=l(A);return A.delete(),R},e.Manifold.prototype.decompose=function(){let x=this._Decompose(),M=l(x);return x.delete(),M},e.Manifold.prototype.boundingBox=function(){let x=this._boundingBox();return{min:["x","y","z"].map(M=>x.min[M]),max:["x","y","z"].map(M=>x.max[M])}},e.Manifold.prototype.simplify=function(x=0){return this._Simplify(x)};class tt{constructor({numProp:M=3,triVerts:A=new Uint32Array,vertProperties:R=new Float32Array,mergeFromVert:$,mergeToVert:j,runIndex:ut,runOriginalID:At,faceID:gt,halfedgeTangent:ae,runTransform:oe,runFlags:dt,tolerance:ri=0}={}){this.numProp=M,this.triVerts=A,this.vertProperties=R,this.mergeFromVert=$,this.mergeToVert=j,this.runIndex=ut,this.runOriginalID=At,this.faceID=gt,this.halfedgeTangent=ae,this.runTransform=oe,this.runFlags=dt,this.tolerance=ri}get numTri(){return this.triVerts.length/3}get numVert(){return this.vertProperties.length/this.numProp}get numRun(){return this.runOriginalID.length}merge(){let{changed:M,mesh:A}=e._Merge(this);return Object.assign(this,{...A}),M}verts(M){return this.triVerts.subarray(3*M,3*(M+1))}position(M){return this.vertProperties.subarray(this.numProp*M,this.numProp*M+3)}extras(M){return this.vertProperties.subarray(this.numProp*M+3,this.numProp*(M+1))}tangent(M){return this.halfedgeTangent.subarray(4*M,4*(M+1))}transform(M){let A=new Array(16);for(let R of[0,1,2,3])for(let $ of[0,1,2])A[4*R+$]=this.runTransform[12*M+3*R+$];return A[15]=1,A}backside(M){return this.runFlags!=null&&M<this.runFlags.length&&(this.runFlags[M]&1)!==0}hasNormals(M){return this.runFlags!=null&&M<this.runFlags.length&&(this.runFlags[M]&2)!==0}}e.Mesh=tt,e.Manifold.prototype.getMesh=function(x=-1){return new tt(this._GetMeshJS(x))},e.ManifoldError=function(M,...A){let R="Unknown error";switch(M){case"NonFiniteVertex":R="Non-finite vertex";break;case"NotManifold":R="Not manifold";break;case"VertexOutOfBounds":R="Vertex index out of bounds";break;case"PropertiesWrongLength":R="Properties have wrong length";break;case"MissingPositionProperties":R="Less than three properties";break;case"MergeVectorsDifferentLengths":R="Merge vectors have different lengths";break;case"MergeIndexOutOfBounds":R="Merge index out of bounds";break;case"TransformWrongLength":R="Transform vector has wrong length";break;case"RunIndexWrongLength":R="Run index vector has wrong length";break;case"FaceIDWrongLength":R="Face ID vector has wrong length";break;case"InvalidConstruction":R="Manifold constructed with invalid parameters";break;case"ResultTooLarge":R="Result exceeds maximum size";break;case"InvalidTangents":R="Invalid halfedge tangents";break}let $=Error.apply(this,[R,...A]);$.name=this.name="ManifoldError",this.message=$.message,this.stack=$.stack,this.code=M},e.ManifoldError.prototype=Object.create(Error.prototype,{constructor:{value:e.ManifoldError,writable:!0,configurable:!0}}),e.CrossSection=function(x,M="Positive"){let A=_(x),R=new B(A,E(M));return S(A),R},e.CrossSection.ofPolygons=function(x,M="Positive"){return new e.CrossSection(x,M)},e.CrossSection.square=function(...x){let M;x.length==0?M={x:1,y:1}:typeof x[0]=="number"?M={x:x[0],y:x[0]}:M=b(x);let A=x[1]||!1;return e._Square(M,A)},e.CrossSection.circle=function(x,M=0){return e._Circle(x,M)};function rt(x){return function(...M){M.length==1&&(M=M[0]);let A=new e.Vector_crossSection;for(let $ of M)A.push_back(W($));let R=e["_crossSection"+x](A);return A.delete(),R}}e.CrossSection.compose=rt("Compose"),e.CrossSection.union=rt("UnionN"),e.CrossSection.difference=rt("DifferenceN"),e.CrossSection.intersection=rt("IntersectionN");function et(x,M){a(x,M,A=>A instanceof Array?{x:A[0],y:A[1]}:A)}e.CrossSection.hull=function(...x){x.length==1&&(x=x[0]);let M=new e.Vector_vec2;for(let R of x)if(R instanceof B)e._crossSectionCollectVertices(M,R);else if(R instanceof Array&&R.length==2&&typeof R[0]=="number")M.push_back({x:R[0],y:R[1]});else if(R.x)M.push_back(R);else{let j=R[0].length==2&&typeof R[0][0]=="number"||R[0].x?[R]:R;for(let ut of j)et(M,ut)}let A=e._crossSectionHullPoints(M);return M.delete(),A},e.CrossSection.prototype=Object.create(B.prototype),Object.defineProperty(e.CrossSection,Symbol.hasInstance,{get:()=>x=>x instanceof B});let ft=e.Manifold;e.Manifold=function(x){let M=new ft(x),A=M.status();if(A!=="NoError")throw new e.ManifoldError(A);return M},e.Manifold.ofMesh=function(x){return new e.Manifold(x)},e.Manifold.tetrahedron=function(){return e._Tetrahedron()},e.Manifold.cube=function(...x){let M;x.length==0?M={x:1,y:1,z:1}:typeof x[0]=="number"?M={x:x[0],y:x[0],z:x[0]}:M=w(x);let A=x[1]||!1;return e._Cube(M,A)},e.Manifold.cylinder=function(x,M,A=-1,R=0,$=!1){return e._Cylinder(x,M,A,R,$)},e.Manifold.sphere=function(x,M=0){return e._Sphere(x,M)},e.Manifold.smooth=function(x,M=[]){let A=new e.Vector_smoothness;a(A,M);let R=e._Smooth(x,A);return A.delete(),R},e.Manifold.extrude=function(x,M,A=0,R=0,$=[1,1],j=!1){return(x instanceof B?x:e.CrossSection(x,"Positive")).extrude(M,A,R,$,j)},e.Manifold.revolve=function(x,M=0,A=360){return(x instanceof B?x:e.CrossSection(x,"Positive")).revolve(M,A)},e.Manifold.reserveIDs=function(x){return e._ReserveIDs(x)};function bt(x){return function(...M){M.length==1&&(M=M[0]);let A=new e.Vector_manifold;for(let $ of M)A.push_back($);let R=e["_manifold"+x+"N"](A);return A.delete(),R}}e.Manifold.union=bt("Union"),e.Manifold.compose=e.Manifold.union,e.Manifold.difference=bt("Difference"),e.Manifold.intersection=bt("Intersection"),e.Manifold.levelSet=function(x,M,A,R=0,$=-1){let j={min:{x:M.min[0],y:M.min[1],z:M.min[2]},max:{x:M.max[0],y:M.max[1],z:M.max[2]}},ut=ge(function(gt){let ae=Nt(gt,"double"),oe=Nt(gt+8,"double"),dt=Nt(gt+16,"double");return x([ae,oe,dt])},"di"),At=e._LevelSet(ut,j,A,R,$);return ve(ut),At},e.ExecutionContext.prototype.fromMesh=function(x){return this._FromMesh(x)},e.ExecutionContext.prototype.smooth=function(x,M=[]){let A=new e.Vector_smoothness;a(A,M);let R=this._Smooth(x,A);return A.delete(),R},e.ExecutionContext.prototype.levelSet=function(x,M,A,R=0,$=-1){let j={min:{x:M.min[0],y:M.min[1],z:M.min[2]},max:{x:M.max[0],y:M.max[1],z:M.max[2]}},ut=ge(function(gt){let ae=Nt(gt,"double"),oe=Nt(gt+8,"double"),dt=Nt(gt+16,"double");return x([ae,oe,dt])},"di"),At=this._LevelSet(ut,j,A,R,$);return ve(ut),At};function zt(x,M){a(x,M,A=>A instanceof Array?{x:A[0],y:A[1],z:A[2]}:A)}e.Manifold.hull=function(...x){x.length==1&&(x=x[0]);let M=new e.Vector_vec3;for(let R of x)R instanceof ft?e._manifoldCollectVertices(M,R):R instanceof Array&&R.length==3&&typeof R[0]=="number"?M.push_back({x:R[0],y:R[1],z:R[2]}):R.x?M.push_back(R):zt(M,R);let A=e._manifoldHullPoints(M);return M.delete(),A},e.Manifold.prototype=Object.create(ft.prototype),Object.defineProperty(e.Manifold,Symbol.hasInstance,{get:()=>x=>x instanceof ft}),e.triangulate=function(x,M=-1,A=!0){let R=_(x),$=l(e._Triangulate(R,M,A),j=>[j[0],j[1],j[2]]);return S(R),$}};var u=[],h="./this.program",f=(a,l)=>{throw l},d=import.meta.url,g="";function m(a){return e.locateFile?e.locateFile(a,g):g+a}var v,y;if(r){var T=s("node:fs");d.startsWith("file:")&&(g=s("node:path").dirname(s("node:url").fileURLToPath(d))+"/"),y=a=>{a=P(a)?new URL(a):a;var l=T.readFileSync(a);return l},v=async(a,l=!0)=>{a=P(a)?new URL(a):a;var p=T.readFileSync(a,l?void 0:"utf8");return p},process.argv.length>1&&(h=process.argv[1].replace(/\\/g,"/")),u=process.argv.slice(2),f=(a,l)=>{throw process.exitCode=a,l}}else if(n||i){try{g=new URL(".",d).href}catch{}i&&(y=a=>{var l=new XMLHttpRequest;return l.open("GET",a,!1),l.responseType="arraybuffer",l.send(null),new Uint8Array(l.response)}),v=async a=>{if(P(a))return new Promise((p,_)=>{var S=new XMLHttpRequest;S.open("GET",a,!0),S.responseType="arraybuffer",S.onload=()=>{if(S.status==200||S.status==0&&S.response){p(S.response);return}_(S.status)},S.onerror=_,S.send(null)});var l=await fetch(a,{credentials:"same-origin"});if(l.ok)return l.arrayBuffer();throw new Error(l.status+" : "+l.url)}}var C=console.log.bind(console),D=console.error.bind(console),I,V=!1,P=a=>a.startsWith("file://"),k,H,U,F,G,Y,X,N,Z,q,it,J,st=!1;function lt(){var a=Sn.buffer;U=new Int8Array(a),G=new Int16Array(a),F=new Uint8Array(a),Y=new Uint16Array(a),X=new Int32Array(a),N=new Uint32Array(a),Z=new Float32Array(a),q=new Float64Array(a),it=new BigInt64Array(a),J=new BigUint64Array(a)}function ht(){if(e.preRun)for(typeof e.preRun=="function"&&(e.preRun=[e.preRun]);e.preRun.length;)Qs(e.preRun.shift());Ce(gr)}function ct(){st=!0,_e.J()}function Ct(){if(e.postRun)for(typeof e.postRun=="function"&&(e.postRun=[e.postRun]);e.postRun.length;)js(e.postRun.shift());Ce(Re)}function vt(a){e.onAbort?.(a),a="Aborted("+a+")",D(a),V=!0,a+=". Build with -sASSERTIONS for more info.";var l=new WebAssembly.RuntimeError(a);throw H?.(l),l}var Rt;function St(){return e.locateFile?m("manifold.wasm"):new URL("manifold.wasm",import.meta.url).href}function re(a){if(a==Rt&&I)return new Uint8Array(I);if(y)return y(a);throw"both async and sync fetching of the wasm failed"}async function ln(a){if(!I)try{var l=await v(a);return new Uint8Array(l)}catch{}return re(a)}async function Xe(a,l){try{var p=await ln(a),_=await WebAssembly.instantiate(p,l);return _}catch(S){D(`failed to asynchronously prepare wasm: ${S}`),vt(S)}}async function Gn(a,l,p){if(!a&&!P(l)&&!r)try{var _=fetch(l,{credentials:"same-origin"}),S=await WebAssembly.instantiateStreaming(_,p);return S}catch(b){D(`wasm streaming compile failed: ${b}`),D("falling back to ArrayBuffer instantiation")}return Xe(l,p)}function cn(){var a={a:No};return a}async function hn(){function a(b,w){return _e=b.exports,_e=Fo(_e),Uo(_e),lt(),_e}function l(b){return a(b.instance)}var p=cn();if(e.instantiateWasm)return new Promise((b,w)=>{e.instantiateWasm(p,(E,L)=>{b(a(E,L))})});Rt??=St();var _=await Gn(I,Rt,p),S=l(_);return S}class Wn{name="ExitStatus";constructor(l){this.message=`Program terminated with exit(${l})`,this.status=l}}var Ce=a=>{for(;a.length>0;)a.shift()(e)},Re=[],js=a=>Re.push(a),gr=[],Qs=a=>gr.push(a);function Nt(a,l="i8"){switch(l.endsWith("*")&&(l="*"),l){case"i1":return U[a>>>0];case"i8":return U[a>>>0];case"i16":return G[a>>>1>>>0];case"i32":return X[a>>>2>>>0];case"i64":return it[a>>>3>>>0];case"float":return Z[a>>>2>>>0];case"double":return q[a>>>3>>>0];case"*":return N[a>>>2>>>0];default:vt(`invalid type for getValue: ${l}`)}}var ta=!0;function Pe(a,l,p="i8"){switch(p.endsWith("*")&&(p="*"),p){case"i1":U[a>>>0]=l;break;case"i8":U[a>>>0]=l;break;case"i16":G[a>>>1>>>0]=l;break;case"i32":X[a>>>2>>>0]=l;break;case"i64":it[a>>>3>>>0]=BigInt(l);break;case"float":Z[a>>>2>>>0]=l;break;case"double":q[a>>>3>>>0]=l;break;case"*":N[a>>>2>>>0]=l;break;default:vt(`invalid type for setValue: ${p}`)}}class ea{constructor(l){this.excPtr=l,this.ptr=l-24}set_type(l){N[this.ptr+4>>>2>>>0]=l}get_type(){return N[this.ptr+4>>>2>>>0]}set_destructor(l){N[this.ptr+8>>>2>>>0]=l}get_destructor(){return N[this.ptr+8>>>2>>>0]}set_caught(l){l=l?1:0,U[this.ptr+12>>>0]=l}get_caught(){return U[this.ptr+12>>>0]!=0}set_rethrown(l){l=l?1:0,U[this.ptr+13>>>0]=l}get_rethrown(){return U[this.ptr+13>>>0]!=0}init(l,p){this.set_adjusted_ptr(0),this.set_type(l),this.set_destructor(p)}set_adjusted_ptr(l){N[this.ptr+16>>>2>>>0]=l}get_adjusted_ptr(){return N[this.ptr+16>>>2>>>0]}}var vr=0,na=0;function ia(a,l,p){a>>>=0,l>>>=0,p>>>=0;var _=new ea(a);throw _.init(l,p),vr=a,na++,vr}var ra=()=>vt(""),un={},Xn=a=>{for(;a.length;){var l=a.pop(),p=a.pop();p(l)}};function qe(a){return this.fromWireType(N[a>>>2>>>0])}var Ie={},de={},fn={},sa=class extends Error{constructor(l){super(l),this.name="InternalError"}},dn=a=>{throw new sa(a)},se=(a,l,p)=>{a.forEach(E=>fn[E]=l);function _(E){var L=p(E);L.length!==a.length&&dn("Mismatched type converter count");for(var B=0;B<a.length;++B)Ft(a[B],L[B])}var S=new Array(l.length),b=[],w=0;for(let[E,L]of l.entries())de.hasOwnProperty(L)?S[E]=de[L]:(b.push(L),Ie.hasOwnProperty(L)||(Ie[L]=[]),Ie[L].push(()=>{S[E]=de[L],++w,w===b.length&&_(S)}));b.length===0&&_(S)},aa=function(a){a>>>=0;var l=un[a];delete un[a];var p=l.rawConstructor,_=l.rawDestructor,S=l.fields,b=S.map(w=>w.getterReturnType).concat(S.map(w=>w.setterArgumentType));se([a],b,w=>{var E={};for(var[L,B]of S.entries()){let W=w[L],tt=B.getter,rt=B.getterContext,et=w[L+S.length],ft=B.setter,bt=B.setterContext;E[B.fieldName]={read:zt=>W.fromWireType(tt(rt,zt)),write:(zt,x)=>{var M=[];ft(bt,zt,et.toWireType(M,x)),Xn(M)},optional:W.optional}}return[{name:l.name,fromWireType:W=>{var tt={};for(var rt in E)tt[rt]=E[rt].read(W);return _(W),tt},toWireType:(W,tt)=>{for(var rt in E)if(!(rt in tt)&&!E[rt].optional)throw new TypeError(`Missing field: "${rt}"`);var et=p();for(rt in E)E[rt].write(et,tt[rt]);return W!==null&&W.push(_,et),et},readValueFromPointer:qe,destructorFunction:_}]})},_t=a=>{a>>>=0;for(var l="";;){var p=F[a++>>>0];if(!p)return l;l+=String.fromCharCode(p)}},$e=class extends Error{constructor(l){super(l),this.name="BindingError"}},at=a=>{throw new $e(a)};function oa(a,l,p={}){var _=l.name;if(a||at(`type "${_}" must have a positive integer typeid pointer`),de.hasOwnProperty(a)){if(p.ignoreDuplicateRegistrations)return;at(`Cannot register type '${_}' twice`)}if(de[a]=l,delete fn[a],Ie.hasOwnProperty(a)){var S=Ie[a];delete Ie[a],S.forEach(b=>b())}}function Ft(a,l,p={}){return oa(a,l,p)}var _r=(a,l,p)=>{switch(l){case 1:return p?_=>U[_>>>0]:_=>F[_>>>0];case 2:return p?_=>G[_>>>1>>>0]:_=>Y[_>>>1>>>0];case 4:return p?_=>X[_>>>2>>>0]:_=>N[_>>>2>>>0];case 8:return p?_=>it[_>>>3>>>0]:_=>J[_>>>3>>>0];default:throw new TypeError(`invalid integer width (${l}): ${a}`)}},la=function(a,l,p,_,S){a>>>=0,l>>>=0,p>>>=0,l=_t(l);let b=_===0n,w=E=>E;if(b){let E=p*8;w=L=>BigInt.asUintN(E,L),S=w(S)}Ft(a,{name:l,fromWireType:w,toWireType:(E,L)=>(typeof L=="number"&&(L=BigInt(L)),L),readValueFromPointer:_r(l,p,!b),destructorFunction:null})};function ca(a,l,p,_){a>>>=0,l>>>=0,l=_t(l),Ft(a,{name:l,fromWireType:function(S){return!!S},toWireType:function(S,b){return b?p:_},readValueFromPointer:function(S){return this.fromWireType(F[S>>>0])},destructorFunction:null})}var ha=a=>({count:a.count,deleteScheduled:a.deleteScheduled,preservePointerOnDelete:a.preservePointerOnDelete,ptr:a.ptr,ptrType:a.ptrType,smartPtr:a.smartPtr,smartPtrType:a.smartPtrType}),qn=a=>{function l(p){return p.$$.ptrType.registeredClass.name}at(l(a)+" instance already deleted")},$n=!1,xr=a=>{},ua=a=>{a.smartPtr?a.smartPtrType.rawDestructor(a.smartPtr):a.ptrType.registeredClass.rawDestructor(a.ptr)},yr=a=>{a.count.value-=1;var l=a.count.value===0;l&&ua(a)},Ye=a=>globalThis.FinalizationRegistry?($n=new FinalizationRegistry(l=>{yr(l.$$)}),Ye=l=>{var p=l.$$,_=!!p.smartPtr;if(_){var S={$$:p};$n.register(l,S,l)}return l},xr=l=>$n.unregister(l),Ye(a)):(Ye=l=>l,a),pn=[],fa=()=>{for(;pn.length;){var a=pn.pop();a.$$.deleteScheduled=!1,a.delete()}},Sr,da=()=>{let a=mn.prototype;Object.assign(a,{isAliasOf(p){if(!(this instanceof mn)||!(p instanceof mn))return!1;var _=this.$$.ptrType.registeredClass,S=this.$$.ptr;p.$$=p.$$;for(var b=p.$$.ptrType.registeredClass,w=p.$$.ptr;_.baseClass;)S=_.upcast(S),_=_.baseClass;for(;b.baseClass;)w=b.upcast(w),b=b.baseClass;return _===b&&S===w},clone(){if(this.$$.ptr||qn(this),this.$$.preservePointerOnDelete)return this.$$.count.value+=1,this;var p=Ye(Object.create(Object.getPrototypeOf(this),{$$:{value:ha(this.$$)}}));return p.$$.count.value+=1,p.$$.deleteScheduled=!1,p},delete(){this.$$.ptr||qn(this),this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete&&at("Object already scheduled for deletion"),xr(this),yr(this.$$),this.$$.preservePointerOnDelete||(this.$$.smartPtr=void 0,this.$$.ptr=void 0)},isDeleted(){return!this.$$.ptr},deleteLater(){return this.$$.ptr||qn(this),this.$$.deleteScheduled&&!this.$$.preservePointerOnDelete&&at("Object already scheduled for deletion"),pn.push(this),pn.length===1&&Sr&&Sr(fa),this.$$.deleteScheduled=!0,this}});let l=Symbol.dispose;l&&(a[l]=a.delete)};function mn(){}var gn=(a,l)=>Object.defineProperty(l,"name",{value:a}),Mr={},br=(a,l,p)=>{if(a[l].overloadTable===void 0){var _=a[l];a[l]=function(...S){return a[l].overloadTable.hasOwnProperty(S.length)||at(`Function '${p}' called with an invalid number of arguments (${S.length}) - expects one of (${a[l].overloadTable})!`),a[l].overloadTable[S.length].apply(this,S)},a[l].overloadTable=[],a[l].overloadTable[_.argCount]=_}},Ze=(a,l,p)=>{e.hasOwnProperty(a)?((p===void 0||e[a].overloadTable!==void 0&&e[a].overloadTable[p]!==void 0)&&at(`Cannot register public name '${a}' twice`),br(e,a,a),e[a].overloadTable.hasOwnProperty(p)&&at(`Cannot register multiple overloads of a function with the same number of arguments (${p})!`),e[a].overloadTable[p]=l):(e[a]=l,e[a].argCount=p)},pa=48,ma=57,ga=a=>{a=a.replace(/[^a-zA-Z0-9_]/g,"$");var l=a.charCodeAt(0);return l>=pa&&l<=ma?`_${a}`:a};function va(a,l,p,_,S,b,w,E){this.name=a,this.constructor=l,this.instancePrototype=p,this.rawDestructor=_,this.baseClass=S,this.getActualType=b,this.upcast=w,this.downcast=E,this.pureVirtualFunctions=[]}var Yn=(a,l,p)=>{for(;l!==p;)l.upcast||at(`Expected null or instance of ${p.name}, got an instance of ${l.name}`),a=l.upcast(a),l=l.baseClass;return a},Zn=a=>{if(a===null)return"null";var l=typeof a;return l==="object"||l==="array"||l==="function"?a.toString():""+a};function _a(a,l){if(l===null)return this.isReference&&at(`null is not a valid ${this.name}`),0;l.$$||at(`Cannot pass "${Zn(l)}" as a ${this.name}`),l.$$.ptr||at(`Cannot pass deleted object as a pointer of type ${this.name}`);var p=l.$$.ptrType.registeredClass,_=Yn(l.$$.ptr,p,this.registeredClass);return _}function xa(a,l){var p;if(l===null)return this.isReference&&at(`null is not a valid ${this.name}`),this.isSmartPointer?(p=this.rawConstructor(),a!==null&&a.push(this.rawDestructor,p),p):0;(!l||!l.$$)&&at(`Cannot pass "${Zn(l)}" as a ${this.name}`),l.$$.ptr||at(`Cannot pass deleted object as a pointer of type ${this.name}`),!this.isConst&&l.$$.ptrType.isConst&&at(`Cannot convert argument of type ${l.$$.smartPtrType?l.$$.smartPtrType.name:l.$$.ptrType.name} to parameter type ${this.name}`);var _=l.$$.ptrType.registeredClass;if(p=Yn(l.$$.ptr,_,this.registeredClass),this.isSmartPointer)switch(l.$$.smartPtr===void 0&&at("Passing raw pointer to smart pointer is illegal"),this.sharingPolicy){case 0:l.$$.smartPtrType===this?p=l.$$.smartPtr:at(`Cannot convert argument of type ${l.$$.smartPtrType?l.$$.smartPtrType.name:l.$$.ptrType.name} to parameter type ${this.name}`);break;case 1:p=l.$$.smartPtr;break;case 2:if(l.$$.smartPtrType===this)p=l.$$.smartPtr;else{var S=l.clone();p=this.rawShare(p,Mt.toHandle(()=>S.delete())),a!==null&&a.push(this.rawDestructor,p)}break;default:at("Unsupported sharing policy")}return p}function ya(a,l){if(l===null)return this.isReference&&at(`null is not a valid ${this.name}`),0;l.$$||at(`Cannot pass "${Zn(l)}" as a ${this.name}`),l.$$.ptr||at(`Cannot pass deleted object as a pointer of type ${this.name}`),l.$$.ptrType.isConst&&at(`Cannot convert argument of type ${l.$$.ptrType.name} to parameter type ${this.name}`);var p=l.$$.ptrType.registeredClass,_=Yn(l.$$.ptr,p,this.registeredClass);return _}var wr=(a,l,p)=>{if(l===p)return a;if(p.baseClass===void 0)return null;var _=wr(a,l,p.baseClass);return _===null?null:p.downcast(_)},Sa={},Ma=(a,l)=>{for(l===void 0&&at("ptr should not be undefined");a.baseClass;)l=a.upcast(l),a=a.baseClass;return l},ba=(a,l)=>(l=Ma(a,l),Sa[l]),vn=(a,l)=>{(!l.ptrType||!l.ptr)&&dn("makeClassHandle requires ptr and ptrType");var p=!!l.smartPtrType,_=!!l.smartPtr;return p!==_&&dn("Both smartPtrType and smartPtr must be specified"),l.count={value:1},Ye(Object.create(a,{$$:{value:l,writable:!0}}))};function wa(a){var l=this.getPointee(a);if(!l)return this.destructor(a),null;var p=ba(this.registeredClass,l);if(p!==void 0){if(p.$$.count.value===0)return p.$$.ptr=l,p.$$.smartPtr=a,p.clone();var _=p.clone();return this.destructor(a),_}function S(){return this.isSmartPointer?vn(this.registeredClass.instancePrototype,{ptrType:this.pointeeType,ptr:l,smartPtrType:this,smartPtr:a}):vn(this.registeredClass.instancePrototype,{ptrType:this,ptr:a})}var b=this.registeredClass.getActualType(l),w=Mr[b];if(!w)return S.call(this);var E;this.isConst?E=w.constPointerType:E=w.pointerType;var L=wr(l,this.registeredClass,E.registeredClass);return L===null?S.call(this):this.isSmartPointer?vn(E.registeredClass.instancePrototype,{ptrType:E,ptr:L,smartPtrType:this,smartPtr:a}):vn(E.registeredClass.instancePrototype,{ptrType:E,ptr:L})}var Ta=()=>{Object.assign(_n.prototype,{getPointee(a){return this.rawGetPointee&&(a=this.rawGetPointee(a)),a},destructor(a){this.rawDestructor?.(a)},readValueFromPointer:qe,fromWireType:wa})};function _n(a,l,p,_,S,b,w,E,L,B,W){this.name=a,this.registeredClass=l,this.isReference=p,this.isConst=_,this.isSmartPointer=S,this.pointeeType=b,this.sharingPolicy=w,this.rawGetPointee=E,this.rawConstructor=L,this.rawShare=B,this.rawDestructor=W,!S&&l.baseClass===void 0?_?(this.toWireType=_a,this.destructorFunction=null):(this.toWireType=ya,this.destructorFunction=null):this.toWireType=xa}var Tr=(a,l,p)=>{e.hasOwnProperty(a)||dn("Replacing nonexistent public symbol"),e[a].overloadTable!==void 0&&p!==void 0?e[a].overloadTable[p]=l:(e[a]=l,e[a].argCount=p)},xn=a=>Je.get(a),Aa=(a,l,p=[],_=!1)=>{var S=xn(l),b=S(...p);function w(E){return a[0]=="p"?E>>>0:E}return w(b)},Ea=(a,l,p=!1)=>(..._)=>Aa(a,l,_,p),Yt=(a,l,p=!1)=>{a=_t(a);function _(){if(a.includes("p"))return Ea(a,l,p);var b=xn(l);return b}var S=_();return typeof S!="function"&&at(`unknown function pointer with signature ${a}: ${l}`),S};class Ca extends Error{}var Ar=a=>{var l=Br(a),p=_t(l);return jt(l),p},yn=(a,l)=>{var p=[],_={};function S(b){if(!_[b]&&!de[b]){if(fn[b]){fn[b].forEach(S);return}p.push(b),_[b]=!0}}throw l.forEach(S),new Ca(`${a}: `+p.map(Ar).join([", "]))};function Ra(a,l,p,_,S,b,w,E,L,B,W,tt,rt){a>>>=0,l>>>=0,p>>>=0,_>>>=0,S>>>=0,b>>>=0,w>>>=0,E>>>=0,L>>>=0,B>>>=0,W>>>=0,tt>>>=0,rt>>>=0,W=_t(W),b=Yt(S,b),E&&=Yt(w,E),B&&=Yt(L,B),rt=Yt(tt,rt);var et=ga(W);Ze(et,function(){yn(`Cannot construct ${W} due to unbound types`,[_])}),se([a,l,p],_?[_]:[],ft=>{ft=ft[0];var bt,zt;_?(bt=ft.registeredClass,zt=bt.instancePrototype):zt=mn.prototype;var x=gn(W,function(...ut){if(Object.getPrototypeOf(this)!==M)throw new $e(`Use 'new' to construct ${W}`);if(A.constructor_body===void 0)throw new $e(`${W} has no accessible constructor`);var At=A.constructor_body[ut.length];if(At===void 0)throw new $e(`Tried to invoke ctor of ${W} with invalid number of parameters (${ut.length}) - expected (${Object.keys(A.constructor_body).toString()}) parameters instead!`);return At.apply(this,ut)}),M=Object.create(zt,{constructor:{value:x}});x.prototype=M;var A=new va(W,x,M,rt,bt,b,E,B);A.baseClass&&(A.baseClass.__derivedClasses??=[],A.baseClass.__derivedClasses.push(A));var R=new _n(W,A,!0,!1,!1),$=new _n(W+"*",A,!1,!1,!1),j=new _n(W+" const*",A,!1,!0,!1);return Mr[a]={pointerType:$,constPointerType:j},Tr(et,x),[R,$,j]})}var Jn=(a,l)=>{for(var p=[],_=0;_<a;_++)p.push(N[l+_*4>>>2>>>0]);return p};function Er(a){for(var l=1;l<a.length;++l)if(a[l]!==null&&a[l].destructorFunction===void 0)return!0;return!1}function Pa(a,l,p,_){var S=Er(a),b=a.length-2,w=[],E=["fn"];l&&E.push("thisWired");for(var L=0;L<b;++L)w.push(`arg${L}`),E.push(`arg${L}Wired`);w=w.join(","),E=E.join(",");var B=`return function (${w}) {
`;S&&(B+=`var destructors = [];
`);var W=S?"destructors":"null",tt=["humanName","throwBindingError","invoker","fn","runDestructors","fromRetWire","toClassParamWire"];l&&(B+=`var thisWired = toClassParamWire(${W}, this);
`);for(var L=0;L<b;++L){var rt=`toArg${L}Wire`;B+=`var arg${L}Wired = ${rt}(${W}, arg${L});
`,tt.push(rt)}if(B+=(p||_?"var rv = ":"")+`invoker(${E});
`,S)B+=`runDestructors(destructors);
`;else for(var L=l?1:2;L<a.length;++L){var et=L===1?"thisWired":"arg"+(L-2)+"Wired";a[L].destructorFunction!==null&&(B+=`${et}_dtor(${et});
`,tt.push(`${et}_dtor`))}return p&&(B+=`var ret = fromRetWire(rv);
return ret;
`),B+=`}
`,new Function(tt,B)}function Kn(a,l,p,_,S,b){var w=l.length;w<2&&at("argTypes array size mismatch! Must at least get return value and 'this' types!");for(var E=l[1]!==null&&p!==null,L=Er(l),B=!l[0].isVoid,W=l[0],tt=l[1],rt=[a,at,_,S,Xn,W.fromWireType.bind(W),tt?.toWireType.bind(tt)],et=2;et<w;++et){var ft=l[et];rt.push(ft.toWireType.bind(ft))}if(!L)for(var et=E?1:2;et<l.length;++et)l[et].destructorFunction!==null&&rt.push(l[et].destructorFunction);var zt=Pa(l,E,B,b)(...rt);return gn(a,zt)}var Ia=function(a,l,p,_,S,b){a>>>=0,p>>>=0,_>>>=0,S>>>=0,b>>>=0;var w=Jn(l,p);S=Yt(_,S),se([],[a],E=>{E=E[0];var L=`constructor ${E.name}`;if(E.registeredClass.constructor_body===void 0&&(E.registeredClass.constructor_body=[]),E.registeredClass.constructor_body[l-1]!==void 0)throw new $e(`Cannot register multiple constructors with identical number of parameters (${l-1}) for class '${E.name}'! Overload resolution is currently only performed using the parameter count, not actual type info!`);return E.registeredClass.constructor_body[l-1]=()=>{yn(`Cannot construct ${E.name} due to unbound types`,w)},se([],w,B=>(B.splice(1,0,null),E.registeredClass.constructor_body[l-1]=Kn(L,B,null,S,b),[])),[]})},Cr=a=>{a=a.trim();let l=a.indexOf("(");return l===-1?a:a.slice(0,l)},La=function(a,l,p,_,S,b,w,E,L,B){a>>>=0,l>>>=0,_>>>=0,S>>>=0,b>>>=0,w>>>=0;var W=Jn(p,_);l=_t(l),l=Cr(l),b=Yt(S,b,L),se([],[a],tt=>{tt=tt[0];var rt=`${tt.name}.${l}`;l.startsWith("@@")&&(l=Symbol[l.substring(2)]),E&&tt.registeredClass.pureVirtualFunctions.push(l);function et(){yn(`Cannot call ${rt} due to unbound types`,W)}var ft=tt.registeredClass.instancePrototype,bt=ft[l];return bt===void 0||bt.overloadTable===void 0&&bt.className!==tt.name&&bt.argCount===p-2?(et.argCount=p-2,et.className=tt.name,ft[l]=et):(br(ft,l,rt),ft[l].overloadTable[p-2]=et),se([],W,zt=>{var x=Kn(rt,zt,tt,b,w,L);return ft[l].overloadTable===void 0?(x.argCount=p-2,ft[l]=x):ft[l].overloadTable[p-2]=x,[]}),[]})},Rr=[],pe=[0,1,,1,null,1,!0,1,!1,1];function jn(a){a>>>=0,a>9&&--pe[a+1]===0&&(pe[a]=void 0,Rr.push(a))}var Mt={toValue:a=>(a||at(`Cannot use deleted val. handle = ${a}`),pe[a]),toHandle:a=>{switch(a){case void 0:return 2;case null:return 4;case!0:return 6;case!1:return 8;default:{let l=Rr.pop()||pe.length;return pe[l]=a,pe[l+1]=1,l}}}},Pr={name:"emscripten::val",fromWireType:a=>{var l=Mt.toValue(a);return jn(a),l},toWireType:(a,l)=>Mt.toHandle(l),readValueFromPointer:qe,destructorFunction:null};function Da(a){return a>>>=0,Ft(a,Pr)}var Qn=(a,l,p)=>{switch(l){case 1:return p?function(_){return this.fromWireType(U[_>>>0])}:function(_){return this.fromWireType(F[_>>>0])};case 2:return p?function(_){return this.fromWireType(G[_>>>1>>>0])}:function(_){return this.fromWireType(Y[_>>>1>>>0])};case 4:return p?function(_){return this.fromWireType(X[_>>>2>>>0])}:function(_){return this.fromWireType(N[_>>>2>>>0])};default:throw new TypeError(`invalid integer width (${l}): ${a}`)}};function Ua(a){return a===0?"object":a===1?"number":"string"}function Na(a,l,p,_,S){a>>>=0,l>>>=0,p>>>=0,l=_t(l);let b=Ua(S);switch(b){case"object":{let B=function(){};B.values={},Ft(a,{name:l,constructor:B,valueType:b,fromWireType:function(W){return this.constructor.values[W]},toWireType:(W,tt)=>tt.value,readValueFromPointer:Qn(l,p,_),destructorFunction:null}),Ze(l,B);break}case"number":{var w={};Ft(a,{name:l,keysMap:w,valueType:b,fromWireType:B=>B,toWireType:(B,W)=>W,readValueFromPointer:Qn(l,p,_),destructorFunction:null}),Ze(l,w),delete e[l].argCount;break}case"string":{var E={},L={},w={};Ft(a,{name:l,valuesMap:E,reverseMap:L,keysMap:w,valueType:b,fromWireType:function(W){return this.reverseMap[W]},toWireType:function(W,tt){return this.valuesMap[tt]},readValueFromPointer:Qn(l,p,_),destructorFunction:null}),Ze(l,w),delete e[l].argCount;break}}}var Ir=(a,l)=>{var p=de[a];return p===void 0&&at(`${l} has unknown type ${Ar(a)}`),p};function Fa(a,l,p){a>>>=0,l>>>=0;var _=Ir(a,"enum");switch(l=_t(l),_.valueType){case"object":{var S=_.constructor,b=Object.create(_.constructor.prototype,{value:{value:p},constructor:{value:gn(`${_.name}_${l}`,function(){})}});S.values[p]=b,S[l]=b;break}case"number":{_.keysMap[l]=p;break}case"string":{_.valuesMap[l]=p,_.reverseMap[p]=l,_.keysMap[l]=l;break}}}var Oa=(a,l)=>{switch(l){case 4:return function(p){return this.fromWireType(Z[p>>>2>>>0])};case 8:return function(p){return this.fromWireType(q[p>>>3>>>0])};default:throw new TypeError(`invalid float width (${l}): ${a}`)}},Ba=function(a,l,p){a>>>=0,l>>>=0,p>>>=0,l=_t(l),Ft(a,{name:l,fromWireType:_=>_,toWireType:(_,S)=>S,readValueFromPointer:Oa(l,p),destructorFunction:null})};function za(a,l,p,_,S,b,w,E){a>>>=0,p>>>=0,_>>>=0,S>>>=0,b>>>=0;var L=Jn(l,p);a=_t(a),a=Cr(a),S=Yt(_,S,w),Ze(a,function(){yn(`Cannot call ${a} due to unbound types`,L)},l-1),se([],L,B=>{var W=[B[0],null].concat(B.slice(1));return Tr(a,Kn(a,W,null,S,b,w),l-1),[]})}var Va=function(a,l,p,_,S){a>>>=0,l>>>=0,p>>>=0,l=_t(l);let b=_===0,w=L=>L;if(b){var E=32-8*p;w=L=>L<<E>>>E,S=w(S)}Ft(a,{name:l,fromWireType:w,toWireType:(L,B)=>B,readValueFromPointer:_r(l,p,_!==0),destructorFunction:null})},ka=(a,l,p)=>{let _=(S,b)=>{let w=0;return{next(){if(w>=S)return{done:!0};let E=w;return w++,{value:b(E),done:!1}},[Symbol.iterator](){return this}}};a[Symbol.iterator]||(a[Symbol.iterator]=function(){let S=this[l]();return _(S,b=>this[p](b))})},Ha=function(a,l,p,_){a>>>=0,l>>>=0,p>>>=0,_>>>=0,p=_t(p),_=_t(_),se([],[a,l],S=>{let b=S[0];return ka(b.registeredClass.instancePrototype,p,_),[]})};function Ga(a,l,p){a>>>=0,p>>>=0;var _=[Int8Array,Uint8Array,Int16Array,Uint16Array,Int32Array,Uint32Array,Float32Array,Float64Array,BigInt64Array,BigUint64Array],S=_[l];function b(w){var E=N[w>>>2>>>0],L=N[w+4>>>2>>>0];return new S(U.buffer,L,E)}p=_t(p),Ft(a,{name:p,fromWireType:b,readValueFromPointer:b},{ignoreDuplicateRegistrations:!0})}var Wa=Object.assign({optional:!0},Pr);function Xa(a,l){a>>>=0,l>>>=0,Ft(a,Wa)}var qa=(a,l,p,_)=>{if(p>>>=0,!(_>0))return 0;for(var S=p,b=p+_-1,w=0;w<a.length;++w){var E=a.codePointAt(w);if(E<=127){if(p>=b)break;l[p++>>>0]=E}else if(E<=2047){if(p+1>=b)break;l[p++>>>0]=192|E>>6,l[p++>>>0]=128|E&63}else if(E<=65535){if(p+2>=b)break;l[p++>>>0]=224|E>>12,l[p++>>>0]=128|E>>6&63,l[p++>>>0]=128|E&63}else{if(p+3>=b)break;l[p++>>>0]=240|E>>18,l[p++>>>0]=128|E>>12&63,l[p++>>>0]=128|E>>6&63,l[p++>>>0]=128|E&63,w++}}return l[p>>>0]=0,p-S},$a=(a,l,p)=>qa(a,F,l,p),Ya=a=>{for(var l=0,p=0;p<a.length;++p){var _=a.charCodeAt(p);_<=127?l++:_<=2047?l+=2:_>=55296&&_<=57343?(l+=4,++p):l+=3}return l},Lr=globalThis.TextDecoder&&new TextDecoder,Dr=(a,l,p,_)=>{var S=l+p;if(_)return S;for(;a[l]&&!(l>=S);)++l;return l},Za=(a,l=0,p,_)=>{l>>>=0;var S=Dr(a,l,p,_);if(S-l>16&&a.buffer&&Lr)return Lr.decode(a.subarray(l,S));for(var b="";l<S;){var w=a[l++];if(!(w&128)){b+=String.fromCharCode(w);continue}var E=a[l++]&63;if((w&224)==192){b+=String.fromCharCode((w&31)<<6|E);continue}var L=a[l++]&63;if((w&240)==224?w=(w&15)<<12|E<<6|L:w=(w&7)<<18|E<<12|L<<6|a[l++]&63,w<65536)b+=String.fromCharCode(w);else{var B=w-65536;b+=String.fromCharCode(55296|B>>10,56320|B&1023)}}return b},Ja=(a,l,p)=>(a>>>=0,a?Za(F,a,l,p):"");function Ka(a,l){a>>>=0,l>>>=0,l=_t(l);var p=!0;Ft(a,{name:l,fromWireType(_){var S=N[_>>>2>>>0],b=_+4,w;if(p)w=Ja(b,S,!0);else{w="";for(var E=0;E<S;++E)w+=String.fromCharCode(F[b+E>>>0])}return jt(_),w},toWireType(_,S){S instanceof ArrayBuffer&&(S=new Uint8Array(S));var b,w=typeof S=="string";w||ArrayBuffer.isView(S)&&S.BYTES_PER_ELEMENT==1||at("Cannot pass non-string to std::string"),p&&w?b=Ya(S):b=S.length;var E=ii(4+b+1),L=E+4;if(N[E>>>2>>>0]=b,w)if(p)$a(S,L,b+1);else for(var B=0;B<b;++B){var W=S.charCodeAt(B);W>255&&(jt(E),at("String has UTF-16 code units that do not fit in 8 bits")),F[L+B>>>0]=W}else F.set(S,L>>>0);return _!==null&&_.push(jt,E),E},readValueFromPointer:qe,destructorFunction(_){jt(_)}})}var Ur=globalThis.TextDecoder?new TextDecoder("utf-16le"):void 0,ja=(a,l,p)=>{var _=a>>>1,S=Dr(Y,_,l/2,p);if(S-_>16&&Ur)return Ur.decode(Y.subarray(_>>>0,S>>>0));for(var b="",w=_;w<S;++w){var E=Y[w>>>0];b+=String.fromCharCode(E)}return b},Qa=(a,l,p)=>{if(p??=2147483647,p<2)return 0;p-=2;for(var _=l,S=p<a.length*2?p/2:a.length,b=0;b<S;++b){var w=a.charCodeAt(b);G[l>>>1>>>0]=w,l+=2}return G[l>>>1>>>0]=0,l-_},to=a=>a.length*2,eo=(a,l,p)=>{for(var _="",S=a>>>2,b=0;!(b>=l/4);b++){var w=N[S+b>>>0];if(!w&&!p)break;_+=String.fromCodePoint(w)}return _},no=(a,l,p)=>{if(l>>>=0,p??=2147483647,p<4)return 0;for(var _=l,S=_+p-4,b=0;b<a.length;++b){var w=a.codePointAt(b);if(w>65535&&b++,X[l>>>2>>>0]=w,l+=4,l+4>S)break}return X[l>>>2>>>0]=0,l-_},io=a=>{for(var l=0,p=0;p<a.length;++p){var _=a.codePointAt(p);_>65535&&p++,l+=4}return l};function ro(a,l,p){a>>>=0,l>>>=0,p>>>=0,p=_t(p);var _,S,b;l===2?(_=ja,S=Qa,b=to):(_=eo,S=no,b=io),Ft(a,{name:p,fromWireType:w=>{var E=N[w>>>2>>>0],L=_(w+4,E*l,!0);return jt(w),L},toWireType:(w,E)=>{typeof E!="string"&&at(`Cannot pass non-string to C++ string type ${p}`);var L=b(E),B=ii(4+L+l);return N[B>>>2>>>0]=L/l,S(E,B+4,L+l),w!==null&&w.push(jt,B),B},readValueFromPointer:qe,destructorFunction(w){jt(w)}})}function so(a,l,p,_,S,b){a>>>=0,l>>>=0,p>>>=0,_>>>=0,S>>>=0,b>>>=0,un[a]={name:_t(l),rawConstructor:Yt(p,_),rawDestructor:Yt(S,b),fields:[]}}function ao(a,l,p,_,S,b,w,E,L,B){a>>>=0,l>>>=0,p>>>=0,_>>>=0,S>>>=0,b>>>=0,w>>>=0,E>>>=0,L>>>=0,B>>>=0,un[a].fields.push({fieldName:_t(l),getterReturnType:p,getter:Yt(_,S),getterContext:b,setterArgumentType:w,setter:Yt(E,L),setterContext:B})}var oo=function(a,l){a>>>=0,l>>>=0,l=_t(l),Ft(a,{isVoid:!0,name:l,fromWireType:()=>{},toWireType:(p,_)=>{}})};function lo(a,l){a>>>=0,l>>>=0,a=Mt.toValue(a),l=Mt.toValue(l),a.set(l)}var ti=[],co=a=>{var l=ti.length;return ti.push(a),l},ho=(a,l)=>{for(var p=new Array(a),_=0;_<a;++_)p[_]=Ir(N[l+_*4>>>2>>>0],`parameter ${_}`);return p},uo=(a,l,p)=>{var _=[],S=a(_,p);return _.length&&(N[l>>>2>>>0]=Mt.toHandle(_)),S},fo={},Nr=a=>{var l=fo[a];return l===void 0?_t(a):l},po=function(a,l,p){l>>>=0;var _=8,[S,...b]=ho(a,l),w=S.toWireType.bind(S),E=b.map(et=>et.readValueFromPointer.bind(et));a--;var L={toValue:Mt.toValue},B=E.map((et,ft)=>{var bt=`argFromPtr${ft}`;return L[bt]=et,`${bt}(args${ft?"+"+ft*_:""})`}),W;switch(p){case 0:W="toValue(handle)";break;case 2:W="new (toValue(handle))";break;case 3:W="";break;case 1:L.getStringOrSymbol=Nr,W="toValue(handle)[getStringOrSymbol(methodName)]";break}W+=`(${B})`,S.isVoid||(L.toReturnWire=w,L.emval_returnValue=uo,W=`return emval_returnValue(toReturnWire, destructorsRef, ${W})`),W=`return function (handle, methodName, destructorsRef, args) {
${W}
}`;var tt=new Function(Object.keys(L),W)(...Object.values(L)),rt=`methodCaller<(${b.map(et=>et.name)}) => ${S.name}>`;return co(gn(rt,tt))};function mo(a,l){return a>>>=0,l>>>=0,a=Mt.toValue(a),l=Mt.toValue(l),a==l}function go(a,l){return a>>>=0,l>>>=0,a=Mt.toValue(a),l=Mt.toValue(l),Mt.toHandle(a[l])}function vo(a){a>>>=0,a>9&&(pe[a+1]+=1)}function _o(a,l,p,_,S){return a>>>=0,l>>>=0,p>>>=0,_>>>=0,S>>>=0,ti[a](l,p,_,S)}function xo(a){return a>>>=0,Mt.toHandle(Nr(a))}function yo(){return Mt.toHandle({})}function So(a){a>>>=0;var l=Mt.toValue(a);Xn(l),jn(a)}function Mo(a,l,p){a>>>=0,l>>>=0,p>>>=0,a=Mt.toValue(a),l=Mt.toValue(l),p=Mt.toValue(p),a[l]=p}var bo=()=>4294901760,wo=(a,l)=>Math.ceil(a/l)*l,To=a=>{var l=Sn.buffer.byteLength,p=(a-l+65535)/65536|0;try{return Sn.grow(p),lt(),1}catch{}};function Ao(a){a>>>=0;var l=F.length,p=bo();if(a>p)return!1;for(var _=1;_<=4;_*=2){var S=l*(1+.2/_);S=Math.min(S,a+100663296);var b=Math.min(p,wo(Math.max(a,S),65536)),w=To(b);if(w)return!0}return!1}var Eo=(a,l)=>{if(me)for(var p=a;p<a+l;p++){var _=xn(p);_&&me.set(_,p)}},me,Co=a=>(me||(me=new WeakMap,Eo(0,Je.length)),me.get(a)||0),ei=[],Ro=()=>ei.length?ei.pop():Je.grow(1),ni=(a,l)=>Je.set(a,l),Fr=a=>{let l=a.length;return[l%128|128,l>>7,...a]},Po={i:127,p:127,j:126,f:125,d:124,e:111},Or=a=>Fr(Array.from(a,l=>{var p=Po[l];return p})),Io=(a,l)=>{var p=Uint8Array.of(0,97,115,109,1,0,0,0,1,...Fr([1,96,...Or(l.slice(1)),...Or(l[0]==="v"?"":l[0])]),2,7,1,1,101,1,102,0,0,7,5,1,1,102,0,0),_=new WebAssembly.Module(p),S=new WebAssembly.Instance(_,{e:{f:a}}),b=S.exports.f;return b},ge=(a,l)=>{var p=Co(a);if(p)return p;var _=Ro();try{ni(_,a)}catch(b){if(!(b instanceof TypeError))throw b;var S=Io(a,l);ni(_,S)}return me.set(a,_),_},ve=a=>{me.delete(xn(a)),ni(a,null),ei.push(a)};if(da(),Ta(),e.noExitRuntime&&(ta=e.noExitRuntime),e.print&&(C=e.print),e.printErr&&(D=e.printErr),e.wasmBinary&&(I=e.wasmBinary),e.arguments&&(u=e.arguments),e.thisProgram&&(h=e.thisProgram),e.preInit)for(typeof e.preInit=="function"&&(e.preInit=[e.preInit]);e.preInit.length>0;)e.preInit.shift()();e.addFunction=ge,e.removeFunction=ve;var Br,ii,jt,Lo,Do,Sn,Je;function Uo(a){Br=a.K,ii=a.M,jt=a.N,Lo=Sn=a.I,Do=Je=a.L}var No={l:ia,C:ra,q:aa,z:la,G:ca,j:Ra,i:Ia,a:La,E:Da,x:Na,d:Fa,y:Ba,c:za,p:Va,m:Ha,h:Ga,n:Xa,F:Ka,w:ro,r:so,k:ao,H:oo,u:lo,g:po,b:jn,o:mo,B:go,t:vo,f:_o,s:xo,A:yo,e:So,v:Mo,D:Ao};function Fo(a){a=Object.assign({},a);var l=_=>S=>_(S)>>>0,p=_=>()=>_()>>>0;return a.K=l(a.K),a.M=l(a.M),a._emscripten_stack_alloc=l(a._emscripten_stack_alloc),a.emscripten_stack_get_current=p(a.emscripten_stack_get_current),a}function Oo(){ht();function a(){e.calledRun=!0,!V&&(ct(),k?.(e),e.onRuntimeInitialized?.(),Ct())}e.setStatus?(e.setStatus("Running..."),setTimeout(()=>{setTimeout(()=>e.setStatus(""),1),a()},1)):a()}var _e;return _e=await hn(),Oo(),st?t=e:t=new Promise((a,l)=>{k=a,H=l}),t}var Ms=nu;async function ws(c={}){let t=await Ms(c);return t.setup(),t}var bs={size:75,wall:.8,height:12.5,rim:4,base:2.5,relief:4.5,reliefInverted:!1,reliefOut:4.5,reliefIn:1,clearance:.9,detailOffset:0,outlineOffset:0,mode:"integrated",mirror:!1,threshold:160,tolerance:.04,stampBase:2.5,stampInset:0,stampExpansion:0,removeOutline:!1,outlineBand:.8,chamfer:!1,tip:.4,chamferHeight:2,wallEdits:[],cornerRadius:2};function $t(c){return c.reduce((t,e,n)=>{let i=c[(n+1)%c.length];return t+e[0]*i[1]-i[0]*e[1]},0)/2}function iu(c,t){if(c.length<5)return c;let e=(s,o,u)=>{let h=u[0]-o[0],f=u[1]-o[1],d=Math.max(0,Math.min(1,((s[0]-o[0])*h+(s[1]-o[1])*f)/(h*h+f*f||1)));return Math.hypot(s[0]-o[0]-d*h,s[1]-o[1]-d*f)},n=s=>{let o=0,u=0;for(let h=1;h<s.length-1;h++){let f=e(s[h],s[0],s.at(-1));f>o&&(o=f,u=h)}return o>t?[...n(s.slice(0,u+1)).slice(0,-1),...n(s.slice(u))]:[s[0],s.at(-1)]},i=1,r=0;for(let s=1;s<c.length;s++){let o=Math.hypot(c[s][0]-c[0][0],c[s][1]-c[0][1]);o>r&&(r=o,i=s)}return[...n(c.slice(0,i+1)).slice(0,-1),...n([...c.slice(i),c[0]]).slice(0,-1)]}function ru(c){let t=c.flat();if(!t.length)throw Error("Nenhum contorno fechado encontrado.");let e=1/0,n=-1/0,i=1/0,r=-1/0;for(let[o,u]of t)e=Math.min(o,e),n=Math.max(o,n),i=Math.min(u,i),r=Math.max(u,r);let s=Math.max(n-e,r-i);if(!(s>0))throw Error("Arte sem dimens\xE3o.");return c.map(o=>o.map(([u,h])=>[(u-(e+n)/2)/s,(h-(i+r)/2)/s]))}function Ts(c,t,e,n=160){let i=(m,v)=>{if(m<=0||v<=0||m>=t-1||v>=e-1)return 255;let y=(v*t+m)*4,T=c[y+3]/255;return(c[y]*.2126+c[y+1]*.7152+c[y+2]*.0722)*T+255*(1-T)},r=new Map,s=new Map,o=(m,v)=>`h${m},${v}`,u=(m,v)=>`v${m},${v}`,h={1:[[3,0]],2:[[0,1]],3:[[3,1]],4:[[1,2]],6:[[0,2]],7:[[3,2]],8:[[2,3]],9:[[2,0]],11:[[2,1]],12:[[1,3]],13:[[1,0]],14:[[0,3]]};function f(m,v){r.has(m)||r.set(m,[]),r.has(v)||r.set(v,[]),r.get(m).push(v),r.get(v).push(m)}for(let m=0;m<e-1;m++)for(let v=0;v<t-1;v++){let y=[i(v,m),i(v+1,m),i(v+1,m+1),i(v,m+1)],T=y.reduce((P,k,H)=>P+(k<n?1<<H:0),0);if(!T||T===15)continue;let C=[o(v,m),u(v+1,m),o(v,m+1),u(v,m)],D=(P,k)=>(n-P)/(k-P||1),I=[[v+D(y[0],y[1]),m],[v+1,m+D(y[1],y[2])],[v+D(y[3],y[2]),m+1],[v,m+D(y[0],y[3])]],V=h[T];if(T===5||T===10){let P=y.reduce((k,H)=>k+H)/4<n;V=T===5===P?[[0,1],[2,3]]:[[3,0],[1,2]]}for(let[P,k]of V)s.set(C[P],I[P]),s.set(C[k],I[k]),f(C[P],C[k])}let d=new Set,g=[];for(let m of r.keys()){if(d.has(m))continue;let v=m,y=null,T=[];for(;!d.has(v);){d.add(v),T.push(s.get(v));let D=r.get(v).find(I=>I!==y);if(y=v,v=D,!v)break}v===m&&T.length>=8&&Math.abs($t(T))>=3&&g.push(T.map(([C,D])=>[C,-D]))}if(g.sort((m,v)=>Math.abs($t(v))-Math.abs($t(m))),!g.length)throw Error("N\xE3o encontrei linhas escuras. Ajuste o limiar ou use arte preta sobre branco.");return ru(g)}function su(c,t){let e=t.flat(),n=c.triangulate(t,1e-8,!1).map(s=>Array.from(s)),i=(s,o,u)=>(e[o][0]-e[s][0])*(e[u][1]-e[s][1])-(e[o][1]-e[s][1])*(e[u][0]-e[s][0]),r=(s,o)=>(e[s][0]-e[o][0])**2+(e[s][1]-e[o][1])**2;for(let s=0;s<12;s++){let o=0,u=new Map,h=new Set;for(let f=0;f<n.length;f++)for(let d=0;d<3;d++){let g=n[f][d],m=n[f][(d+1)%3],v=n[f][(d+2)%3],y=g<m?g+","+m:m+","+g,T=u.get(y);if(!T){u.set(y,{i:f,a:g,b:m,c:v});continue}if(h.has(f)||h.has(T.i))continue;let C=T.c;r(v,C)+1e-10>=r(g,m)||i(v,C,m)<=1e-12||i(C,v,g)<=1e-12||(n[f]=[v,C,m],n[T.i]=[C,v,g],h.add(f),h.add(T.i),o++)}if(!o)break}return n}function au(c,t,e,n,i,r=n-1,s=[]){let o=y=>$t(y)>0?y.map(T=>T.slice()):y.slice().reverse().map(T=>T.slice()),u=[{poly:t,z:r},{poly:t,z:n},...s,{poly:e,z:i}].map(y=>({...y,poly:o(y.poly)})),h=[],f=[],d=[];for(let y of u){d.push(h.length/3);for(let T of y.poly)h.push(T[0],T[1],y.z)}let g=u[0].poly,m=g.length;for(let y of c.triangulate([g],1e-8,!1))f.push(y[2],y[1],y[0]);for(let y=0;y<m;y++){let T=(y+1)%m;f.push(y,T,m+T,y,m+T,m+y)}for(let y=1;y<u.length-1;y++){let T=u[y].poly,C=u[y+1].poly,D=T.length,I=C.length,V=P=>P<D?d[y]+P:d[y+1]+I-1-(P-D);for(let P of su(c,[T,C.slice().reverse()]))f.push(...P.map(V))}let v=u.length-1;for(let y of c.triangulate([u[v].poly],1e-8,!1))f.push(...y.map(T=>T+d[v]));return new c.Manifold(new c.Mesh({numProp:3,vertProperties:new Float32Array(h),triVerts:new Uint32Array(f)}))}function rr(c={}){let t={...bs,...c,stampBase:c.stampBase??c.base??bs.stampBase};return Number.isFinite(t.reliefOut)||(t.reliefOut=t.reliefInverted?bs.relief:t.relief),Number.isFinite(t.reliefIn)||(t.reliefIn=t.reliefInverted?t.relief:Math.min(1,Math.max(.1,(t.mode==="integrated"?t.base:t.stampBase)*.4))),t}function As(c,t,e,n=null){let i=performance.now(),r=rr(e),s=[],o=d=>(s.push(d),d),u=c.CrossSection,h=c.Manifold,f=["size","wall","height","rim","base","stampBase","stampInset","stampExpansion","outlineBand","tip","chamferHeight","clearance","detailOffset","outlineOffset","tolerance","cornerRadius","relief"];for(let d of f)if(!Number.isFinite(r[d]))throw Error(`Valor inv\xE1lido em ${d}: informe um n\xFAmero finito.`);for(let[d,g]of[["size",.1],["wall",.01],["height",.05],["base",.01],["stampBase",.01],["outlineBand",.001],["tip",.001],["chamferHeight",.001],["tolerance",.0001],["relief",.001]])if(r[d]<g)throw Error(`Valor inv\xE1lido em ${d}: use um valor maior ou igual a ${g}.`);if(r.rim<0||r.cornerRadius<0||r.clearance<0)throw Error("Base de apoio, prote\xE7\xE3o de cantos e folga n\xE3o podem ser negativas.");let _r=r.mode==="integrated"?r.base:r.stampBase;if(r.base>=r.height)throw Error("A base do cortador deve ser menor que a altura total.");if(r.mode==="integrated"&&r.base+r.relief>=r.height)throw Error("Base + relevo precisam ficar abaixo da borda de corte.");if(r.chamfer&&r.mode!=="stamp"&&(r.tip>r.wall||r.chamferHeight>r.height-r.base))throw Error("O chanfro deve caber acima da base; a ponta n\xE3o pode superar a espessura da l\xE2mina.");if(!["integrated","separate","cutter","stamp"].includes(r.mode))throw Error("Modo de pe\xE7a inv\xE1lido.");try{let d=(X,N)=>n?n.memo(X,N):N(),g=r.mode==="separate"||r.mode==="cutter"?n?.get("cutter"):null,m=r.mode==="separate"||r.mode==="stamp"?n?.get("stamp"):null,v=d("source",()=>t.map(X=>iu(X,r.tolerance/r.size).map(([N,Z])=>[N*r.size*(r.mirror?-1:1),Z*r.size])).sort((X,N)=>Math.abs($t(N))-Math.abs($t(X)))),y=X=>{let N=X.toPolygons().sort((Z,q)=>Math.abs($t(q))-Math.abs($t(Z)));if(!N.length)throw Error("O recuo eliminou o contorno. Reduza o valor.");return o(new u([N[0]],"EvenOdd"))},T=r.mode==="separate"?r.stampExpansion:0,C=o(new u([v[0]],"EvenOdd")),D=o(new u(d("outer",()=>y(o(o(C.offset(r.outlineOffset+T,"Round",2,256)).simplify(.002))).toPolygons()),"EvenOdd")),I,V,P,k,H,U,F=[],A=[];if(r.mode!=="stamp"&&!g){let X=d("inner",()=>{if(P=y(o(D.offset(r.clearance,"Round",2,256))),r.cornerRadius>0){let J=r.cornerRadius+r.wall,st=o(o(P.offset(J,"Round",2,256)).offset(-J,"Round",2,256));P=y(o(u.union([P,st])))}return P.toPolygons()});if(P=o(new u(X,"EvenOdd")),!Array.isArray(r.wallEdits)||r.wallEdits.length>100)throw Error("Excesso de ajustes locais na l\xE2mina.");let N=(J=1)=>{let st=r.chamfer?r.tip+(r.wall-r.tip)*J:r.wall,lt=y(o(P.offset(st,"Round",2,256)));for(let ht of r.wallEdits){if(!Number.isFinite(ht.delta)||Math.abs(ht.delta)>2||!Array.isArray(ht.region)||ht.region.length!==4||!ht.region.flat().every(Number.isFinite))throw Error("Ajuste local inv\xE1lido.");let ct=o(new u([ht.region.map(([vt,Rt])=>[vt*r.size*(r.mirror?-1:1),Rt*r.size])],"EvenOdd")),Ct=o(lt.offset(ht.delta*J,"Round",2,256));lt=y(o(u.union([o(lt.subtract(ct)),o(Ct.intersect(ct))])))}if(r.wallEdits.length){let ht=r.chamfer?r.tip+(Math.max(.3,r.tip+.02)-r.tip)*J:.3,ct=r.chamfer?r.tip+(5-r.tip)*J:5;lt=y(o(o(u.union([lt,o(P.offset(ht,"Round",2,256))])).intersect(o(P.offset(ct,"Round",2,256)))))}return lt},Z=d("blade",()=>{let J=N(),st=y(o(P.offset(r.tip,"Round",2,256))),lt=[];if(r.chamfer&&(r.tip<r.wall-1e-6||r.wallEdits.length)){let ht=Math.max(2,Math.min(160,Math.ceil((r.wall-r.tip+r.wallEdits.reduce((Ct,vt)=>Ct+Math.abs(vt.delta),0))/.025))),ct=J;for(let Ct=1;Ct<ht;Ct++){let vt=N(1-Ct/ht);r.wallEdits.length&&(vt=y(o(u.union([o(vt.intersect(ct)),st])))),lt.push({poly:vt.toPolygons()[0],fraction:Ct/ht}),ct=vt}}return{outer:J.toPolygons(),tip:st.toPolygons(),rings:lt}}),q=o(new u(Z.outer,"EvenOdd"));V=o(new u(d("rim",()=>y(o(u.union([o(P.offset(Math.max(r.rim,r.wall),"Round",2,256)),q]))).toPolygons()),"EvenOdd")),F=o(q.subtract(P)).toPolygons();let it=n?.getSolid?.("bladeSolid");if(it)I=o(it.translate([0,0,0]));else{if(r.chamfer&&(r.tip<r.wall-1e-6||r.wallEdits.length)){let J=r.height-r.chamferHeight,st=o(new u(Z.tip,"EvenOdd")),lt=Z.rings.map(ct=>({poly:ct.poly,z:J+r.chamferHeight*ct.fraction})),ht=o(au(c,q.toPolygons()[0],st.toPolygons()[0],J,r.height,r.base-.02,lt));if(ht.status()!=="NoError")throw Error("N\xE3o foi poss\xEDvel fechar o chanfro. Reduza sua altura ou revise o contorno.");I=o(ht.subtract(o(P.extrude(r.height+1))))}else I=o(o(o(q.subtract(P)).extrude(r.height-r.base+.02)).translate([0,0,r.base-.02]));n?.setSolid?.("bladeSolid",I.translate([0,0,0]))}r.mode!=="integrated"&&(k=o(h.union([I,o(o(V.subtract(P)).extrude(r.base))])))}if(r.mode!=="cutter"&&!m){let X=d("art",()=>{let it=o(new u(v,"EvenOdd"));r.detailOffset&&(it=o(it.offset(r.detailOffset,"Round",2,128))),r.removeOutline&&(it=o(it.intersect(o(C.offset(-r.outlineBand,"Round",2,256)))));let J=r.mode==="integrated"?D:y(o(C.offset(-r.stampInset,"Round",2,256))),st=o(it.intersect(J));if(st.isEmpty())throw Error("Nenhum detalhe restou no carimbo. Reduza a remo\xE7\xE3o de borda ou o recuo.");return st.toPolygons()}),N=o(new u(X,"EvenOdd")),Z=r.mode==="integrated"?r.base:r.stampBase,q=o(new u(d("footprint",()=>{let it=r.mode==="integrated"?D:y(o(C.offset(-r.stampInset,"Round",2,256)));return(r.mode!=="integrated"&&r.stampExpansion>0?y(o(C.offset(r.stampExpansion-r.stampInset,"Round",2,256))):it).toPolygons()}),"EvenOdd"));A=X;r.reliefInverted?(()=>{let it=r.mode==="integrated"?P:q,J=o(o(it.extrude(r.relief+.02)).translate([0,0,Z-.02]));H=o(o(N.extrude(r.relief+.02)).translate([0,0,Z]));let st=o(J.subtract(H));r.mode!=="integrated"?U=o(h.union([o(q.extrude(r.stampBase)),st])):U=st})():(H=o(o(N.extrude(r.relief+.02)).translate([0,0,Z-.02])),r.mode!=="integrated"&&(U=o(h.union([o(q.extrude(r.stampBase)),H]))))}let G=[];r.mode==="integrated"?(k=o(V.extrude(r.base)),U=r.reliefInverted?o(h.union([k,U])):o(h.union([k,H])),G=[{name:"Cortador integrado",solid:o(h.union([I,U]))}]):r.mode==="separate"?G=[{name:"Cortador",solid:k},{name:"Carimbo",solid:U}]:G=[r.mode==="cutter"?{name:"Cortador",solid:k}:{name:"Carimbo",solid:U}];let Y={parts:G.map(({name:X,solid:N})=>{if(X==="Cortador"&&g)return g.part;if(X==="Carimbo"&&m)return m.part;if(N=o(N.setTolerance(.001)),N.status()!=="NoError"||N.isEmpty())throw Error(`${X}: falha na constru\xE7\xE3o do s\xF3lido (${N.status()}).`);let Z=ou(N.getMesh()),q=lu(Z);if(q.open||q.nonmanifold||!q.finite)throw Error(`${X}: malha inv\xE1lida (${JSON.stringify(q)}), exporta\xE7\xE3o bloqueada.`);let it=N.decompose(),J=it.length;return it.forEach(st=>st.delete()),{name:X,positions:Float32Array.from(Z.vertProperties),indices:Uint32Array.from(Z.triVerts),stride:Z.numProp,volume:N.volume(),bounds:N.boundingBox(),stats:q,bodies:J}}),outline:D.toPolygons(),reliefOutline:A,cuttingOutline:g?.cuttingOutline||P?.toPolygons()||[],bladeProfile:g?.bladeProfile||F,params:r};for(let X of Y.parts)X.name==="Cortador"&&!g&&n?.set("cutter",{part:X,cuttingOutline:Y.cuttingOutline,bladeProfile:Y.bladeProfile}),X.name==="Carimbo"&&!m&&n?.set("stamp",{part:X});return Y.elapsed=performance.now()-i,Y}finally{s.reverse().forEach(d=>d.delete())}}function Es(c,t,e){let n=[],i=s=>(n.push(s),s),r=c.CrossSection;try{let s=i(new r(t,"EvenOdd")),o;if(e.type==="thickness"){let h=i(s.offset(e.distance/e.size/2,"Round",2,128));if(e.region){let f=i(new r([e.region],"EvenOdd"));o=i(r.union([i(s.subtract(f)),i(h.intersect(f))]))}else o=h}else if(e.type==="offset"){let h=i(new r([t[e.selected]],"EvenOdd")),f=i(h.offset(e.distance/e.size,"Round",2,128)),d=t.filter((g,m)=>m!==e.selected);return d.push(...f.toPolygons()),d.sort((g,m)=>Math.abs($t(m))-Math.abs($t(g)))}else if(e.type==="shape"){let h=i(new r([e.points],"EvenOdd"));o=i(e.subtract?s.subtract(h):r.union([s,h]))}else if(e.type==="stroke"){let h=e.width/e.size/2,f=[];for(let g=0;g<e.points.length;g++)if(f.push(i(i(r.circle(h,16)).translate(e.points[g]))),g){let m=e.points[g-1],v=e.points[g],y=v[0]-m[0],T=v[1]-m[1],C=Math.hypot(y,T);if(C>1e-9){let D=-T/C*h,I=y/C*h;f.push(i(new r([[[m[0]+D,m[1]+I],[m[0]-D,m[1]-I],[v[0]-D,v[1]-I],[v[0]+D,v[1]+I]]],"EvenOdd")))}}let d=i(r.union(f));o=i(e.subtract?s.subtract(d):r.union([s,d]))}if(!o||o.isEmpty())throw Error("A edi\xE7\xE3o apagaria toda a arte.");return o.toPolygons().sort((h,f)=>Math.abs($t(f))-Math.abs($t(h)))}finally{n.reverse().forEach(s=>s.delete())}}function ou(c){let t=new Map,e=[],n=[];for(let r=0;r<c.vertProperties.length;r+=c.numProp){let s=Array.from(c.vertProperties.slice(r,r+3)),o=s.join(",");t.has(o)||(t.set(o,e.length/3),e.push(...s)),n.push(t.get(o))}let i=[];for(let r=0;r<c.triVerts.length;r+=3){let s=n[c.triVerts[r]],o=n[c.triVerts[r+1]],u=n[c.triVerts[r+2]];s!==o&&o!==u&&u!==s&&i.push(s,o,u)}return{numProp:3,vertProperties:new Float32Array(e),triVerts:new Uint32Array(i)}}function lu(c){let t=new Map,e=!0;for(let u of c.vertProperties)Number.isFinite(u)||(e=!1);let n=new Map,i=[],r=c.numProp;for(let u=0;u<c.vertProperties.length;u+=r){let h=[0,1,2].map(f=>String(c.vertProperties[u+f])).join(",");n.has(h)||n.set(h,n.size),i.push(n.get(h))}for(let u=0;u<c.triVerts.length;u+=3)for(let h=0;h<3;h++){let f=i[c.triVerts[u+h]],d=i[c.triVerts[u+(h+1)%3]],g=f<d?`${f}:${d}`:`${d}:${f}`;t.set(g,(t.get(g)||0)+1)}let s=0,o=0;for(let u of t.values())u===1&&s++,u>2&&o++;return{open:s,nonmanifold:o,finite:e,triangles:c.triVerts.length/3}}function Cs(c){let t=c.indices.length/3,e=new ArrayBuffer(84+t*50),n=new DataView(e);n.setUint32(80,t,!0);let i=84;for(let r=0;r<c.indices.length;r+=3){let s=[0,1,2].map(d=>Array.from(c.positions.slice(c.indices[r+d]*c.stride,c.indices[r+d]*c.stride+3))),o=s[1].map((d,g)=>d-s[0][g]),u=s[2].map((d,g)=>d-s[0][g]),h=[o[1]*u[2]-o[2]*u[1],o[2]*u[0]-o[0]*u[2],o[0]*u[1]-o[1]*u[0]],f=Math.hypot(...h)||1;for(let d of[...h.map(g=>g/f),...s.flat()])n.setFloat32(i,d,!0),i+=4;i+=2}return e}function Rs(c,t){let e=!1;for(let n=0,i=c.length-1;n<c.length;i=n++){let r=c[n],s=c[i];r[1]>t[1]!=s[1]>t[1]&&t[0]<(s[0]-r[0])*(t[1]-r[1])/(s[1]-r[1])+r[0]&&(e=!e)}return e}function Ps(c){let t=(p,x)=>!!p?.length&&p.reduce((v,l)=>v!==Rs(l,x),!1),e=(p,x)=>{let ids=x.map(j=>[p.positions[j*p.stride],p.positions[j*p.stride+1],p.positions[j*p.stride+2]]),a=ids[0],u=ids[1].map((v,k)=>v-a[k]),h=ids[2].map((v,k)=>v-a[k]),n=[u[1]*h[2]-u[2]*h[1],u[2]*h[0]-u[0]*h[2],u[0]*h[1]-u[1]*h[0]],z=Math.hypot(...n)||1;return{pts:ids,n:n.map(v=>v/z)}};for(let p of c.parts){if(p.renderData)continue;let x={cutterBase:[],blade:[],stampBase:[],relief:[]},q=c.params;for(let j=0;j<p.indices.length;j+=3){let ids=[p.indices[j],p.indices[j+1],p.indices[j+2]],g=e(p,ids),m=[0,0,0];for(let v of g.pts)for(let k=0;k<3;k++)m[k]+=v[k]/3;let role;if(p.name==="Cortador")role=m[2]<=q.base+.001?"cutterBase":"blade";else{let integrated=p.name!=="Carimbo",top=integrated?q.base:q.stampBase,cavity=!1;if(q.reliefInverted){let ceiling=top+q.relief,eps=Math.max(.001,Math.abs(ceiling)*1e-5);if(m[2]>=top-eps&&m[2]<=ceiling+eps){cavity=t(c.reliefOutline,m);if(!cavity){let l=Math.hypot(g.n[0],g.n[1]);if(l>1e-8){let d=Math.max(.003,(q.size||75)*5e-5),dx=g.n[0]/l*d,dy=g.n[1]/l*d;cavity=t(c.reliefOutline,[m[0]+dx,m[1]+dy])||t(c.reliefOutline,[m[0]-dx,m[1]-dy])}}}if(!integrated)role=cavity?"relief":"stampBase";else if(cavity)role="relief";else{let l=c.cuttingOutline?.length?t(c.cuttingOutline,m):!1;m[2]>q.base+.001&&l&&(role="stampBase")}}if(!role)if(!integrated)role=m[2]<=q.stampBase+.001?"stampBase":"relief";else{let l=c.outline?.[0]?Rs(c.outline[0],m):!0;role=m[2]<=q.base+.001?l?"stampBase":"cutterBase":l?"relief":"blade"}}x[role].push(...ids)}p.renderData={};for(let[role,ids]of Object.entries(x)){if(!ids.length)continue;let g=new be;g.setAttribute("position",new Bt(p.positions,p.stride)),g.setIndex(ids);let m=Ss(g,q);p.renderData[role]={positions:m.attributes.position.array,normals:m.attributes.normal.array,indices:m.index.array},g.dispose(),m.dispose()}}return c}function Is(c){return c.parts.flatMap(t=>[t.positions.buffer,t.indices.buffer,...Object.values(t.renderData||{}).flatMap(e=>[e.positions.buffer,e.normals.buffer,e.indices.buffer])])}var Lt=Uint8Array,Ht=Uint16Array,hr=Int32Array,ur=new Lt([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),fr=new Lt([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Ls=new Lt([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),zs=function(c,t){for(var e=new Ht(31),n=0;n<31;++n)e[n]=t+=1<<c[n-1];for(var i=new hr(e[30]),n=1;n<30;++n)for(var r=e[n];r<e[n+1];++r)i[r]=r-e[n]<<5|n;return{b:e,r:i}},Vs=zs(ur,2),cu=Vs.b,ar=Vs.r;cu[28]=258,ar[258]=28;var ks=zs(fr,0),Ap=ks.b,Ds=ks.r,or=new Ht(32768);for(ot=0;ot<32768;++ot)ne=(ot&43690)>>1|(ot&21845)<<1,ne=(ne&52428)>>2|(ne&13107)<<2,ne=(ne&61680)>>4|(ne&3855)<<4,or[ot]=((ne&65280)>>8|(ne&255)<<8)>>1;var ne,ot,on=(function(c,t,e){for(var n=c.length,i=0,r=new Ht(t);i<n;++i)c[i]&&++r[c[i]-1];var s=new Ht(t);for(i=1;i<t;++i)s[i]=s[i-1]+r[i-1]<<1;var o;if(e){o=new Ht(1<<t);var u=15-t;for(i=0;i<n;++i)if(c[i])for(var h=i<<4|c[i],f=t-c[i],d=s[c[i]-1]++<<f,g=d|(1<<f)-1;d<=g;++d)o[or[d]>>u]=h}else for(o=new Ht(n),i=0;i<n;++i)c[i]&&(o[i]=or[s[c[i]-1]++]>>15-c[i]);return o}),Ee=new Lt(288);for(ot=0;ot<144;++ot)Ee[ot]=8;var ot;for(ot=144;ot<256;++ot)Ee[ot]=9;var ot;for(ot=256;ot<280;++ot)Ee[ot]=7;var ot;for(ot=280;ot<288;++ot)Ee[ot]=8;var ot,zn=new Lt(32);for(ot=0;ot<32;++ot)zn[ot]=5;var ot,hu=on(Ee,9,0);var uu=on(zn,5,0);var Hs=function(c){return(c+7)/8|0},Gs=function(c,t,e){return(t==null||t<0)&&(t=0),(e==null||e>c.length)&&(e=c.length),new Lt(c.subarray(t,e))};var fu=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],Vn=function(c,t,e){var n=new Error(t||fu[c]);if(n.code=c,Error.captureStackTrace&&Error.captureStackTrace(n,Vn),!e)throw n;return n};var ie=function(c,t,e){e<<=t&7;var n=t/8|0;c[n]|=e,c[n+1]|=e>>8},sn=function(c,t,e){e<<=t&7;var n=t/8|0;c[n]|=e,c[n+1]|=e>>8,c[n+2]|=e>>16},sr=function(c,t){for(var e=[],n=0;n<c.length;++n)c[n]&&e.push({s:n,f:c[n]});var i=e.length,r=e.slice();if(!i)return{t:Xs,l:0};if(i==1){var s=new Lt(e[0].s+1);return s[e[0].s]=1,{t:s,l:1}}e.sort(function(P,k){return P.f-k.f}),e.push({s:-1,f:25001});var o=e[0],u=e[1],h=0,f=1,d=2;for(e[0]={s:-1,f:o.f+u.f,l:o,r:u};f!=i-1;)o=e[e[h].f<e[d].f?h++:d++],u=e[h!=f&&e[h].f<e[d].f?h++:d++],e[f++]={s:-1,f:o.f+u.f,l:o,r:u};for(var g=r[0].s,n=1;n<i;++n)r[n].s>g&&(g=r[n].s);var m=new Ht(g+1),v=lr(e[f-1],m,0);if(v>t){var n=0,y=0,T=v-t,C=1<<T;for(r.sort(function(k,H){return m[H.s]-m[k.s]||k.f-H.f});n<i;++n){var D=r[n].s;if(m[D]>t)y+=C-(1<<v-m[D]),m[D]=t;else break}for(y>>=T;y>0;){var I=r[n].s;m[I]<t?y-=1<<t-m[I]++-1:++n}for(;n>=0&&y;--n){var V=r[n].s;m[V]==t&&(--m[V],++y)}v=t}return{t:new Lt(m),l:v}},lr=function(c,t,e){return c.s==-1?Math.max(lr(c.l,t,e+1),lr(c.r,t,e+1)):t[c.s]=e},Us=function(c){for(var t=c.length;t&&!c[--t];);for(var e=new Ht(++t),n=0,i=c[0],r=1,s=function(u){e[n++]=u},o=1;o<=t;++o)if(c[o]==i&&o!=t)++r;else{if(!i&&r>2){for(;r>138;r-=138)s(32754);r>2&&(s(r>10?r-11<<5|28690:r-3<<5|12305),r=0)}else if(r>3){for(s(i),--r;r>6;r-=6)s(8304);r>2&&(s(r-3<<5|8208),r=0)}for(;r--;)s(i);r=1,i=c[o]}return{c:e.subarray(0,n),n:t}},an=function(c,t){for(var e=0,n=0;n<t.length;++n)e+=c[n]*t[n];return e},Ws=function(c,t,e){var n=e.length,i=Hs(t+2);c[i]=n&255,c[i+1]=n>>8,c[i+2]=c[i]^255,c[i+3]=c[i+1]^255;for(var r=0;r<n;++r)c[i+r+4]=e[r];return(i+4+n)*8},Ns=function(c,t,e,n,i,r,s,o,u,h,f){ie(t,f++,e),++i[256];for(var d=sr(i,15),g=d.t,m=d.l,v=sr(r,15),y=v.t,T=v.l,C=Us(g),D=C.c,I=C.n,V=Us(y),P=V.c,k=V.n,H=new Ht(19),U=0;U<D.length;++U)++H[D[U]&31];for(var U=0;U<P.length;++U)++H[P[U]&31];for(var F=sr(H,7),G=F.t,Y=F.l,X=19;X>4&&!G[Ls[X-1]];--X);var N=h+5<<3,Z=an(i,Ee)+an(r,zn)+s,q=an(i,g)+an(r,y)+s+14+3*X+an(H,G)+2*H[16]+3*H[17]+7*H[18];if(u>=0&&N<=Z&&N<=q)return Ws(t,f,c.subarray(u,u+h));var it,J,st,lt;if(ie(t,f,1+(q<Z)),f+=2,q<Z){it=on(g,m,0),J=g,st=on(y,T,0),lt=y;var ht=on(G,Y,0);ie(t,f,I-257),ie(t,f+5,k-1),ie(t,f+10,X-4),f+=14;for(var U=0;U<X;++U)ie(t,f+3*U,G[Ls[U]]);f+=3*X;for(var ct=[D,P],Ct=0;Ct<2;++Ct)for(var vt=ct[Ct],U=0;U<vt.length;++U){var Rt=vt[U]&31;ie(t,f,ht[Rt]),f+=G[Rt],Rt>15&&(ie(t,f,vt[U]>>5&127),f+=vt[U]>>12)}}else it=hu,J=Ee,st=uu,lt=zn;for(var U=0;U<o;++U){var St=n[U];if(St>255){var Rt=St>>18&31;sn(t,f,it[Rt+257]),f+=J[Rt+257],Rt>7&&(ie(t,f,St>>23&31),f+=ur[Rt]);var re=St&31;sn(t,f,st[re]),f+=lt[re],re>3&&(sn(t,f,St>>5&8191),f+=fr[re])}else sn(t,f,it[St]),f+=J[St]}return sn(t,f,it[256]),f+J[256]},du=new hr([65540,131080,131088,131104,262176,1048704,1048832,2114560,2117632]),Xs=new Lt(0),pu=function(c,t,e,n,i,r){var s=r.z||c.length,o=new Lt(n+s+5*(1+Math.ceil(s/7e3))+i),u=o.subarray(n,o.length-i),h=r.l,f=(r.r||0)&7;if(t){f&&(u[0]=r.r>>3);for(var d=du[t-1],g=d>>13,m=d&8191,v=(1<<e)-1,y=r.p||new Ht(32768),T=r.h||new Ht(v+1),C=Math.ceil(e/3),D=2*C,I=function(Re){return(c[Re]^c[Re+1]<<C^c[Re+2]<<D)&v},V=new hr(25e3),P=new Ht(288),k=new Ht(32),H=0,U=0,F=r.i||0,G=0,Y=r.w||0,X=0;F+2<s;++F){var N=I(F),Z=F&32767,q=T[N];if(y[Z]=q,T[N]=Z,Y<=F){var it=s-F;if((H>7e3||G>24576)&&(it>423||!h)){f=Ns(c,u,0,V,P,k,U,G,X,F-X,f),G=H=U=0,X=F;for(var J=0;J<286;++J)P[J]=0;for(var J=0;J<30;++J)k[J]=0}var st=2,lt=0,ht=m,ct=Z-q&32767;if(it>2&&N==I(F-ct))for(var Ct=Math.min(g,it)-1,vt=Math.min(32767,F),Rt=Math.min(258,it);ct<=vt&&--ht&&Z!=q;){if(c[F+st]==c[F+st-ct]){for(var St=0;St<Rt&&c[F+St]==c[F+St-ct];++St);if(St>st){if(st=St,lt=ct,St>Ct)break;for(var re=Math.min(ct,St-2),ln=0,J=0;J<re;++J){var Xe=F-ct+J&32767,Gn=y[Xe],cn=Xe-Gn&32767;cn>ln&&(ln=cn,q=Xe)}}}Z=q,q=y[Z],ct+=Z-q&32767}if(lt){V[G++]=268435456|ar[st]<<18|Ds[lt];var hn=ar[st]&31,Wn=Ds[lt]&31;U+=ur[hn]+fr[Wn],++P[257+hn],++k[Wn],Y=F+st,++H}else V[G++]=c[F],++P[c[F]]}}for(F=Math.max(F,Y);F<s;++F)V[G++]=c[F],++P[c[F]];f=Ns(c,u,h,V,P,k,U,G,X,F-X,f),h||(r.r=f&7|u[f/8|0]<<3,f-=7,r.h=T,r.p=y,r.i=F,r.w=Y)}else{for(var F=r.w||0;F<s+h;F+=65535){var Ce=F+65535;Ce>=s&&(u[f/8|0]=h,Ce=s),f=Ws(u,f+1,c.subarray(F,Ce))}r.i=s}return Gs(o,0,n+Hs(f)+i)},mu=(function(){for(var c=new Int32Array(256),t=0;t<256;++t){for(var e=t,n=9;--n;)e=(e&1&&-306674912)^e>>>1;c[t]=e}return c})(),gu=function(){var c=-1;return{p:function(t){for(var e=c,n=0;n<t.length;++n)e=mu[e&255^t[n]]^e>>>8;c=e},d:function(){return~c}}};var vu=function(c,t,e,n,i){if(!i&&(i={l:1},t.dictionary)){var r=t.dictionary.subarray(-32768),s=new Lt(r.length+c.length);s.set(r),s.set(c,r.length),c=s,i.w=r.length}return pu(c,t.level==null?6:t.level,t.mem==null?i.l?Math.ceil(Math.max(8,Math.min(13,Math.log(c.length)))*1.5):20:12+t.mem,e,n,i)},qs=function(c,t){var e={};for(var n in c)e[n]=c[n];for(var n in t)e[n]=t[n];return e};var Et=function(c,t,e){for(;e;++t)c[t]=e,e>>>=8};function _u(c,t){return vu(c,t||{},0,0)}var $s=function(c,t,e,n){for(var i in c){var r=c[i],s=t+i,o=n;Array.isArray(r)&&(o=qs(n,r[1]),r=r[0]),ArrayBuffer.isView(r)?e[s]=[r,o]:(e[s+="/"]=[new Lt(0),o],$s(r,s,e,n))}},Fs=typeof TextEncoder<"u"&&new TextEncoder,xu=typeof TextDecoder<"u"&&new TextDecoder,yu=0;try{xu.decode(Xs,{stream:!0}),yu=1}catch{}function Os(c,t){if(t){for(var e=new Lt(c.length),n=0;n<c.length;++n)e[n]=c.charCodeAt(n);return e}if(Fs)return Fs.encode(c);for(var i=c.length,r=new Lt(c.length+(c.length>>1)),s=0,o=function(f){r[s++]=f},n=0;n<i;++n){if(s+5>r.length){var u=new Lt(s+8+(i-n<<1));u.set(r),r=u}var h=c.charCodeAt(n);h<128||t?o(h):h<2048?(o(192|h>>6),o(128|h&63)):h>55295&&h<57344?(h=65536+(h&1047552)|c.charCodeAt(++n)&1023,o(240|h>>18),o(128|h>>12&63),o(128|h>>6&63),o(128|h&63)):(o(224|h>>12),o(128|h>>6&63),o(128|h&63))}return Gs(r,0,s)}var cr=function(c){var t=0;if(c)for(var e in c){var n=c[e].length;n>65535&&Vn(9),t+=n+4}return t},Bs=function(c,t,e,n,i,r,s,o){var u=n.length,h=e.extra,f=o&&o.length,d=cr(h);Et(c,t,s!=null?33639248:67324752),t+=4,s!=null&&(c[t++]=20,c[t++]=e.os),c[t]=20,t+=2,c[t++]=e.flag<<1|(r<0&&8),c[t++]=i&&8,c[t++]=e.compression&255,c[t++]=e.compression>>8;var g=new Date(e.mtime==null?Date.now():e.mtime),m=g.getFullYear()-1980;if((m<0||m>119)&&Vn(10),Et(c,t,m<<25|g.getMonth()+1<<21|g.getDate()<<16|g.getHours()<<11|g.getMinutes()<<5|g.getSeconds()>>1),t+=4,r!=-1&&(Et(c,t,e.crc),Et(c,t+4,r<0?-r-2:r),Et(c,t+8,e.size)),Et(c,t+12,u),Et(c,t+14,d),t+=16,s!=null&&(Et(c,t,f),Et(c,t+6,e.attrs),Et(c,t+10,s),t+=14),c.set(n,t),t+=u,d)for(var v in h){var y=h[v],T=y.length;Et(c,t,+v),Et(c,t+2,T),c.set(y,t+4),t+=4+T}return f&&(c.set(o,t),t+=f),t},Su=function(c,t,e,n,i){Et(c,t,101010256),Et(c,t+8,e),Et(c,t+10,e),Et(c,t+12,n),Et(c,t+16,i)};function Ys(c,t){t||(t={});var e={},n=[];$s(c,"",e,t);var i=0,r=0;for(var s in e){var o=e[s],u=o[0],h=o[1],f=h.level==0?0:8,d=Os(s),g=d.length,m=h.comment,v=m&&Os(m),y=v&&v.length,T=cr(h.extra);g>65535&&Vn(11);var C=f?_u(u,h):u,D=C.length,I=gu();I.p(u),n.push(qs(h,{size:u.length,crc:I.d(),c:C,f:d,m:v,u:g!=s.length||v&&m.length!=y,o:i,compression:f})),i+=30+g+T+D,r+=76+2*(g+T)+(y||0)+D}for(var V=new Lt(r+22),P=i,k=r-i,H=0;H<n.length;++H){var d=n[H];Bs(V,d.o,d,d.f,d.u,d.c.length);var U=30+d.f.length+cr(d.extra);V.set(d.c,d.o+U),Bs(V,i,d,d.f,d.u,d.c.length,d.o,d.m),i+=16+U+(d.m?d.m.length:0)}return Su(V,i,n.length,k,P),V}var dr="14.22.0",Zs=["size","mirror","tolerance"],Mu={source:{parents:[],params:Zs},outer:{parents:["source"],params:["outlineOffset","mode","stampExpansion"]},inner:{parents:["outer"],params:["clearance","cornerRadius","wall"]},blade:{parents:["inner"],params:["wall","tip","chamfer","wallEdits"]},rim:{parents:["blade"],params:["rim"]},bladeSolid:{parents:["blade"],params:["base","height","chamferHeight"]},art:{parents:["source"],params:["detailOffset","removeOutline","outlineBand","stampInset","mode","outlineOffset"]},footprint:{parents:["outer"],params:["stampInset","stampExpansion"]},cutter:{parents:["rim","bladeSolid"],params:["base","height","chamferHeight","mode"]},stamp:{parents:["art","footprint"],params:["stampBase","base","relief","reliefInverted","mode"]},integrated:{parents:["cutter","stamp"],params:["base","relief","reliefInverted"]}};function bu(c,t){let e={};for(let[n,i]of Object.entries(Mu)){let r=new Set(i.params);for(let s of i.parents)for(let o of e[s].fields)r.add(o);if(n==="stamp"&&t.mode!=="integrated"){r.clear();for(let s of[...Zs,"mode","stampInset","stampExpansion","detailOffset","removeOutline","outlineBand","stampBase","relief","reliefInverted"])r.add(s)}e[n]={fields:[...r].sort()},e[n].key=dr+":"+c+":"+n+":"+JSON.stringify(e[n].fields.map(s=>[s,t[s]]))}return e}function Js(c){if(ArrayBuffer.isView(c)||c instanceof ArrayBuffer)return c.byteLength;if(typeof c=="string")return c.length*2;if(typeof c=="number")return 8;if(!c||typeof c!="object")return 4;let t=48;for(let e of Object.values(c))t+=Js(e)+8;return t}var kn=class{constructor(t=48*1024*1024){this.limit=t,this.bytes=0,this.entries=new Map,this.hits=0,this.misses=0}get(t){let e=this.entries.get(t);if(!e){this.misses++;return}return this.entries.delete(t),this.entries.set(t,e),this.hits++,e.value}set(t,e){let n=Js(e)+t.length*2,i=this.entries.get(t);if(i&&(this.bytes-=i.bytes,this.entries.delete(t)),n>this.limit)return e;for(;this.bytes+n>this.limit&&this.entries.size;){let[r,s]=this.entries.entries().next().value;this.entries.delete(r),this.bytes-=s.bytes}return this.entries.set(t,{bytes:n,value:e}),this.bytes+=n,e}clear(){this.entries.clear(),this.bytes=0}stats(){return{bytes:this.bytes,limit:this.limit,entries:this.entries.size,hits:this.hits,misses:this.misses}}};function Ks(c,t,e,n=null){let i=bu(t,e),r=[],s=[];return{keys:i,computed:r,reused:s,getSolid(o){let u=n?.get(i[o].key);return u&&s.push(o),u},setSolid(o,u){r.push(o),n?n.set(i[o].key,u):u.delete()},memo(o,u){let h=i[o].key,f=c.get(h);return f!==void 0?(s.push(o),f):(r.push(o),c.set(h,u()))},get(o){let u=c.get(i[o].key);return u!==void 0&&s.push(o),u},set(o,u){return r.push(o),c.set(i[o].key,u)}}}var Hn=class{constructor(t=24*1024*1024){this.limit=t,this.bytes=0,this.entries=new Map}get(t){let e=this.entries.get(t);if(e)return this.entries.delete(t),this.entries.set(t,e),e.solid}set(t,e){let n;try{let r=e.getMesh();n=(r.vertProperties.byteLength+r.triVerts.byteLength)*6}catch(r){throw e.delete(),r}if(n>this.limit){e.delete();return}let i=this.entries.get(t);for(i&&(i.solid.delete(),this.bytes-=i.bytes,this.entries.delete(t));this.entries.size&&(this.bytes+n>this.limit||this.entries.size>=4);){let[r,s]=this.entries.entries().next().value;s.solid.delete(),this.bytes-=s.bytes,this.entries.delete(r)}this.entries.set(t,{solid:e,bytes:n}),this.bytes+=n}clear(){for(let t of this.entries.values())t.solid.delete();this.entries.clear(),this.bytes=0}};var wu,pr=0,mr=new kn(48*1024*1024),Tu=new Hn;self.onmessage=async({data:c})=>{try{if(c.action==="stl"){let o=new Uint8Array(Cs(c.mesh));self.postMessage({id:c.id,result:o},[o.buffer]);return}if(c.action==="zip"){let o=Ys(c.files,{level:3});self.postMessage({id:c.id,result:o},[o.buffer]);return}if(c.action==="trace"){self.postMessage({id:c.id,loops:Ts(c.pixels,c.w,c.h,c.threshold)});return}if(c.action==="stats"){self.postMessage({id:c.id,result:{...mr.stats(),completed:pr}});return}let t=await(wu??=ws({locateFile:()=>new URL("manifold.wasm",self.location.href).href}));if(c.action==="edit"){self.postMessage({id:c.id,loops:Es(t,c.loops,c.op)});return}if(c.action==="svg"){let o=c.shapes.map(h=>new t.CrossSection(h,"EvenOdd")),u;try{u=t.CrossSection.union(o),self.postMessage({id:c.id,loops:u.toPolygons()})}finally{u?.delete(),o.forEach(h=>h.delete())}return}let e=rr(c.params),n=c.sourceHash||JSON.stringify(c.loops),i=Ks(mr,n,e,Tu),r=As(t,c.loops,e,i);pr++;let s=Ps(structuredClone(r));s.calculation={version:dr,computed:i.computed,reused:i.reused,cache:mr.stats(),completed:pr},self.postMessage({id:c.id,result:s},Is(s))}catch(t){self.postMessage({id:c.id,error:t.message})}};
/*! Bundled license information:

three/build/three.core.js:
three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2026 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
