(()=>{var Vi="14.22.0",fu=["size","mirror","tolerance"],Ro={source:{parents:[],params:fu},outer:{parents:["source"],params:["outlineOffset","mode","stampExpansion"]},inner:{parents:["outer"],params:["clearance","cornerRadius","wall"]},blade:{parents:["inner"],params:["wall","tip","chamfer","wallEdits"]},rim:{parents:["blade"],params:["rim"]},bladeSolid:{parents:["blade"],params:["base","height","chamferHeight"]},art:{parents:["source"],params:["detailOffset","removeOutline","outlineBand","stampInset","mode","outlineOffset"]},footprint:{parents:["outer"],params:["stampInset","stampExpansion"]},cutter:{parents:["rim","bladeSolid"],params:["base","height","chamferHeight","mode"]},stamp:{parents:["art","footprint"],params:["stampBase","base","relief","reliefInverted","mode"]},integrated:{parents:["cutter","stamp"],params:["base","relief","reliefInverted"]}};function pu(n,e){let t={};for(let[i,r]of Object.entries(Ro)){let s=new Set(r.params);for(let o of r.parents)for(let a of t[o].fields)s.add(a);if(i==="stamp"&&e.mode!=="integrated"){s.clear();for(let o of[...fu,"mode","stampInset","stampExpansion","detailOffset","removeOutline","outlineBand","stampBase","relief","reliefInverted"])s.add(o)}t[i]={fields:[...s].sort()},t[i].key=Vi+":"+n+":"+i+":"+JSON.stringify(t[i].fields.map(o=>[o,e[o]]))}return t}var oc=256*1024*1024,mu;function ac(){return mu??=new Promise((n,e)=>{let t=indexedDB.open("rv-geometry-cache",1);t.onupgradeneeded=()=>{t.result.createObjectStore("meshes"),t.result.createObjectStore("meta",{keyPath:"key"})},t.onsuccess=()=>n(t.result),t.onerror=()=>{mu=null,e(t.error)}})}var lc=n=>new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error)});async function Po(n){let e=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(n));return Array.from(new Uint8Array(e),t=>t.toString(16).padStart(2,"0")).join("")}async function gu(n){try{let e=await ac(),t=e.transaction("meshes"),i=await lc(t.objectStore("meshes").get(n));return i?.calculation?.version!==Vi||!i.parts?.length||i.parts.some(r=>!(r.positions instanceof Float32Array)||!(r.indices instanceof Uint32Array)||!r.positions.length||r.indices.length!==r.stats?.triangles*3||r.stats.open||r.stats.nonmanifold||!r.stats.finite)?null:i}catch{return null}}async function _u(n,e){try{let t=e.parts.reduce((c,l)=>c+l.positions.byteLength+l.indices.byteLength+Object.values(l.renderData||{}).reduce((u,d)=>u+d.positions.byteLength+d.normals.byteLength+d.indices.byteLength,0),0)+JSON.stringify([e.outline,e.cuttingOutline,e.bladeProfile]).length*2;if(t>oc/4)return!1;let i=await ac(),r=await lc(i.transaction("meta").objectStore("meta").getAll()),s=r.reduce((c,l)=>c+(l.key===n?0:l.bytes),0),o=r.filter(c=>c.key!==n).sort((c,l)=>c.used-l.used),a=i.transaction(["meshes","meta"],"readwrite");for(let c of o){if(s+t<=oc)break;a.objectStore("meshes").delete(c.key),a.objectStore("meta").delete(c.key),s-=c.bytes}return a.objectStore("meshes").put(e,n),a.objectStore("meta").put({key:n,bytes:t,used:Date.now()}),await new Promise((c,l)=>{a.oncomplete=c,a.onabort=()=>l(a.error)}),!0}catch{return!1}}async function yu(){let n=await ac(),e=await lc(n.transaction("meta").objectStore("meta").getAll());return{entries:e.length,bytes:e.reduce((t,i)=>t+i.bytes,0),limit:oc}}var Ai={LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},Ci={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},nd=0,$c=1,id=2;var nr=1,rd=2,Jr=3,Ri=0,Gt=1,nn=2,$n=0,Kr=1,Yc=2,Zc=3,Jc=4,sd=5;var ir=100,od=101,ad=102,ld=103,cd=104,hd=200,ud=201,dd=202,fd=203,Kc=204,Qc=205,pd=206,md=207,gd=208,_d=209,yd=210,vd=211,xd=212,bd=213,Md=214,la=0,ca=1,ha=2,Fr=3,ua=4,da=5,fa=6,pa=7,eh=0,Sd=1,wd=2,Ln=0,th=1,nh=2,ih=3,rh=4,sh=5,oh=6,ah=7;var lh=300,Pi=301,rr=302,ja=303,qa=304,no=306,Or=1e3,xn=1001,Br=1002,Dt=1003,Td=1004;var io=1005;var Nt=1006,$a=1007;var Ii=1008;var an=1009,ch=1010,hh=1011,Qr=1012,Ya=1013,Nn=1014,Un=1015,Fn=1016,Za=1017,Ja=1018,es=1020,uh=35902,dh=35899,fh=1021,ph=1022,Mn=1023,Xn=1026,Di=1027,ts=1028,Ka=1029,Li=1030,Qa=1031;var el=1033,ro=33776,so=33777,oo=33778,ao=33779,tl=35840,nl=35841,il=35842,rl=35843,sl=36196,ol=37492,al=37496,ll=37488,cl=37489,lo=37490,hl=37491,ul=37808,dl=37809,fl=37810,pl=37811,ml=37812,gl=37813,_l=37814,yl=37815,vl=37816,xl=37817,bl=37818,Ml=37819,Sl=37820,wl=37821,Tl=36492,El=36494,Al=36495,Cl=36283,Rl=36284,co=36285,Pl=36286;var Ts=2300,ma=2301,oa=2302,Fc=2303,Oc=2400,Bc=2401,kc=2402;var Ed=3200;var ho=0,Ad=1,ai="",Qt="srgb",Es="srgb-linear",As="linear",ct="srgb";var aa=7680;var Cd=519,Rd=512,Pd=513,Id=514,Il=515,Dd=516,Ld=517,Dl=518,Nd=519,mh=35044;var gh="300 es",Pn=2e3,kr=2001;function Mp(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function Sp(n){return ArrayBuffer.isView(n)&&!(n instanceof DataView)}function Cs(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function Ud(){let n=Cs("canvas");return n.style.display="block",n}var vu={},zr=null;function Rs(...n){let e="THREE."+n.shift();zr?zr("log",e,...n):console.log(e,...n)}function Fd(n){let e=n[0];if(typeof e=="string"&&e.startsWith("TSL:")){let t=n[1];t&&t.isStackTrace?n[0]+=" "+t.getLocation():n[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return n}function qe(...n){n=Fd(n);let e="THREE."+n.shift();if(zr)zr("warn",e,...n);else{let t=n[0];t&&t.isStackTrace?console.warn(t.getError(e)):console.warn(e,...n)}}function Ye(...n){n=Fd(n);let e="THREE."+n.shift();if(zr)zr("error",e,...n);else{let t=n[0];t&&t.isStackTrace?console.error(t.getError(e)):console.error(e,...n)}}function ji(...n){let e=n.join(" ");e in vu||(vu[e]=!0,qe(...n))}function Od(n,e,t){return new Promise(function(i,r){function s(){switch(n.clientWaitSync(e,n.SYNC_FLUSH_COMMANDS_BIT,0)){case n.WAIT_FAILED:r();break;case n.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:i()}}setTimeout(s,t)})}var Bd={[la]:ca,[ha]:fa,[ua]:pa,[Fr]:da,[ca]:la,[fa]:ha,[pa]:ua,[da]:Fr},In=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){let i=this._listeners;return i===void 0?!1:i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){let i=this._listeners;if(i===void 0)return;let r=i[e];if(r!==void 0){let s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let i=t[e.type];if(i!==void 0){e.target=this;let r=i.slice(0);for(let s=0,o=r.length;s<o;s++)r[s].call(this,e);e.target=null}}},Xt=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],xu=1234567,Nr=Math.PI/180,Vr=180/Math.PI;function Wn(){let n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Xt[n&255]+Xt[n>>8&255]+Xt[n>>16&255]+Xt[n>>24&255]+"-"+Xt[e&255]+Xt[e>>8&255]+"-"+Xt[e>>16&15|64]+Xt[e>>24&255]+"-"+Xt[t&63|128]+Xt[t>>8&255]+"-"+Xt[t>>16&255]+Xt[t>>24&255]+Xt[i&255]+Xt[i>>8&255]+Xt[i>>16&255]+Xt[i>>24&255]).toLowerCase()}function et(n,e,t){return Math.max(e,Math.min(t,n))}function _h(n,e){return(n%e+e)%e}function wp(n,e,t,i,r){return i+(n-e)*(r-i)/(t-e)}function Tp(n,e,t){return n!==e?(t-n)/(e-n):0}function Ms(n,e,t){return(1-t)*n+t*e}function Ep(n,e,t,i){return Ms(n,e,1-Math.exp(-t*i))}function Ap(n,e=1){return e-Math.abs(_h(n,e*2)-e)}function Cp(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*(3-2*n))}function Rp(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*n*(n*(n*6-15)+10))}function Pp(n,e){return n+Math.floor(Math.random()*(e-n+1))}function Ip(n,e){return n+Math.random()*(e-n)}function Dp(n){return n*(.5-Math.random())}function Lp(n){n!==void 0&&(xu=n);let e=xu+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Np(n){return n*Nr}function Up(n){return n*Vr}function Fp(n){return n>0&&Number.isInteger(n)&&2**Math.round(Math.log2(n))===n}function Op(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function Bp(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function kp(n,e,t,i,r){let s=Math.cos,o=Math.sin,a=s(t/2),c=o(t/2),l=s((e+i)/2),u=o((e+i)/2),d=s((e-i)/2),h=o((e-i)/2),f=s((i-e)/2),g=o((i-e)/2);switch(r){case"XYX":n.set(a*u,c*d,c*h,a*l);break;case"YZY":n.set(c*h,a*u,c*d,a*l);break;case"ZXZ":n.set(c*d,c*h,a*u,a*l);break;case"XZX":n.set(a*u,c*g,c*f,a*l);break;case"YXY":n.set(c*f,a*u,c*g,a*l);break;case"ZYZ":n.set(c*g,c*f,a*u,a*l);break;default:qe("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function Rn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:case Uint8ClampedArray:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("THREE.MathUtils: Invalid component type.")}}function ht(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("THREE.MathUtils: Invalid component type.")}}var On={DEG2RAD:Nr,RAD2DEG:Vr,generateUUID:Wn,clamp:et,euclideanModulo:_h,mapLinear:wp,inverseLerp:Tp,lerp:Ms,damp:Ep,pingpong:Ap,smoothstep:Cp,smootherstep:Rp,randInt:Pp,randFloat:Ip,randFloatSpread:Dp,seededRandom:Lp,degToRad:Np,radToDeg:Up,isPowerOfTwo:Fp,ceilPowerOfTwo:Op,floorPowerOfTwo:Bp,setQuaternionFromProperEuler:kp,normalize:ht,denormalize:Rn},be=class n{static{n.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("THREE.Vector2: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("THREE.Vector2: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*i-o*r+e.x,this.y=s*r+o*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},pn=class{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,o,a){let c=i[r+0],l=i[r+1],u=i[r+2],d=i[r+3],h=s[o+0],f=s[o+1],g=s[o+2],b=s[o+3];if(d!==b||c!==h||l!==f||u!==g){let m=c*h+l*f+u*g+d*b;m<0&&(h=-h,f=-f,g=-g,b=-b,m=-m);let p=1-a;if(m<.9995){let S=Math.acos(m),T=Math.sin(S);p=Math.sin(p*S)/T,a=Math.sin(a*S)/T,c=c*p+h*a,l=l*p+f*a,u=u*p+g*a,d=d*p+b*a}else{c=c*p+h*a,l=l*p+f*a,u=u*p+g*a,d=d*p+b*a;let S=1/Math.sqrt(c*c+l*l+u*u+d*d);c*=S,l*=S,u*=S,d*=S}}e[t]=c,e[t+1]=l,e[t+2]=u,e[t+3]=d}static multiplyQuaternionsFlat(e,t,i,r,s,o){let a=i[r],c=i[r+1],l=i[r+2],u=i[r+3],d=s[o],h=s[o+1],f=s[o+2],g=s[o+3];return e[t]=a*g+u*d+c*f-l*h,e[t+1]=c*g+u*h+l*d-a*f,e[t+2]=l*g+u*f+a*h-c*d,e[t+3]=u*g-a*d-c*h-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let i=e._x,r=e._y,s=e._z,o=e._order,a=Math.cos,c=Math.sin,l=a(i/2),u=a(r/2),d=a(s/2),h=c(i/2),f=c(r/2),g=c(s/2);switch(o){case"XYZ":this._x=h*u*d+l*f*g,this._y=l*f*d-h*u*g,this._z=l*u*g+h*f*d,this._w=l*u*d-h*f*g;break;case"YXZ":this._x=h*u*d+l*f*g,this._y=l*f*d-h*u*g,this._z=l*u*g-h*f*d,this._w=l*u*d+h*f*g;break;case"ZXY":this._x=h*u*d-l*f*g,this._y=l*f*d+h*u*g,this._z=l*u*g+h*f*d,this._w=l*u*d-h*f*g;break;case"ZYX":this._x=h*u*d-l*f*g,this._y=l*f*d+h*u*g,this._z=l*u*g-h*f*d,this._w=l*u*d+h*f*g;break;case"YZX":this._x=h*u*d+l*f*g,this._y=l*f*d+h*u*g,this._z=l*u*g-h*f*d,this._w=l*u*d-h*f*g;break;case"XZY":this._x=h*u*d-l*f*g,this._y=l*f*d-h*u*g,this._z=l*u*g+h*f*d,this._w=l*u*d+h*f*g;break;default:qe("Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,i=t[0],r=t[4],s=t[8],o=t[1],a=t[5],c=t[9],l=t[2],u=t[6],d=t[10],h=i+a+d;if(h>0){let f=.5/Math.sqrt(h+1);this._w=.25/f,this._x=(u-c)*f,this._y=(s-l)*f,this._z=(o-r)*f}else if(i>a&&i>d){let f=2*Math.sqrt(1+i-a-d);this._w=(u-c)/f,this._x=.25*f,this._y=(r+o)/f,this._z=(s+l)/f}else if(a>d){let f=2*Math.sqrt(1+a-i-d);this._w=(s-l)/f,this._x=(r+o)/f,this._y=.25*f,this._z=(c+u)/f}else{let f=2*Math.sqrt(1+d-i-a);this._w=(o-r)/f,this._x=(s+l)/f,this._y=(c+u)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<1e-8?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(et(this.dot(e),-1,1)))}rotateTowards(e,t){let i=this.angleTo(e);if(i===0)return this;let r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let i=e._x,r=e._y,s=e._z,o=e._w,a=t._x,c=t._y,l=t._z,u=t._w;return this._x=i*u+o*a+r*l-s*c,this._y=r*u+o*c+s*a-i*l,this._z=s*u+o*l+i*c-r*a,this._w=o*u-i*a-r*c-s*l,this._onChangeCallback(),this}slerp(e,t){let i=e._x,r=e._y,s=e._z,o=e._w,a=this.dot(e);a<0&&(i=-i,r=-r,s=-s,o=-o,a=-a);let c=1-t;if(a<.9995){let l=Math.acos(a),u=Math.sin(l);c=Math.sin(c*l)/u,t=Math.sin(t*l)/u,this._x=this._x*c+i*t,this._y=this._y*c+r*t,this._z=this._z*c+s*t,this._w=this._w*c+o*t,this._onChangeCallback()}else this._x=this._x*c+i*t,this._y=this._y*c+r*t,this._z=this._z*c+s*t,this._w=this._w*c+o*t,this.normalize();return this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),r=Math.sqrt(1-i),s=Math.sqrt(i);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},O=class n{static{n.prototype.isVector3=!0}constructor(e=0,t=0,i=0){this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("THREE.Vector3: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("THREE.Vector3: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(bu.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(bu.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,i=this.y,r=this.z,s=e.elements,o=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*o,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*o,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*o,this}applyQuaternion(e){let t=this.x,i=this.y,r=this.z,s=e.x,o=e.y,a=e.z,c=e.w,l=2*(o*r-a*i),u=2*(a*t-s*r),d=2*(s*i-o*t);return this.x=t+c*l+o*d-a*u,this.y=i+c*u+a*l-s*d,this.z=r+c*d+s*u-o*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this.z=et(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this.z=et(this.z,e,t),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let i=e.x,r=e.y,s=e.z,o=t.x,a=t.y,c=t.z;return this.x=r*c-s*a,this.y=s*o-i*c,this.z=i*a-r*o,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return cc.copy(this).projectOnVector(e),this.sub(cc)}reflect(e){return this.sub(cc.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(et(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){let r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},cc=new O,bu=new pn,je=class n{static{n.prototype.isMatrix3=!0}constructor(e,t,i,r,s,o,a,c,l){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,o,a,c,l)}set(e,t,i,r,s,o,a,c,l){let u=this.elements;return u[0]=e,u[1]=r,u[2]=a,u[3]=t,u[4]=s,u[5]=c,u[6]=i,u[7]=o,u[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,r=t.elements,s=this.elements,o=i[0],a=i[3],c=i[6],l=i[1],u=i[4],d=i[7],h=i[2],f=i[5],g=i[8],b=r[0],m=r[3],p=r[6],S=r[1],T=r[4],y=r[7],E=r[2],A=r[5],U=r[8];return s[0]=o*b+a*S+c*E,s[3]=o*m+a*T+c*A,s[6]=o*p+a*y+c*U,s[1]=l*b+u*S+d*E,s[4]=l*m+u*T+d*A,s[7]=l*p+u*y+d*U,s[2]=h*b+f*S+g*E,s[5]=h*m+f*T+g*A,s[8]=h*p+f*y+g*U,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8];return t*o*u-t*a*l-i*s*u+i*a*c+r*s*l-r*o*c}invert(){let e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],d=u*o-a*l,h=a*c-u*s,f=l*s-o*c,g=t*d+i*h+r*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);let b=1/g;return e[0]=d*b,e[1]=(r*l-u*i)*b,e[2]=(a*i-r*o)*b,e[3]=h*b,e[4]=(u*t-r*c)*b,e[5]=(r*s-a*t)*b,e[6]=f*b,e[7]=(i*c-l*t)*b,e[8]=(o*t-i*s)*b,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,o,a){let c=Math.cos(s),l=Math.sin(s);return this.set(i*c,i*l,-i*(c*o+l*a)+o+e,-r*l,r*c,-r*(-l*o+c*a)+a+t,0,0,1),this}scale(e,t){return ji("Matrix3: .scale() is deprecated. Use .makeScale() instead."),this.premultiply(hc.makeScale(e,t)),this}rotate(e){return ji("Matrix3: .rotate() is deprecated. Use .makeRotation() instead."),this.premultiply(hc.makeRotation(-e)),this}translate(e,t){return ji("Matrix3: .translate() is deprecated. Use .makeTranslation() instead."),this.premultiply(hc.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}},hc=new je,Mu=new je().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Su=new je().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function zp(){let n={enabled:!0,workingColorSpace:Es,spaces:{},convert:function(r,s,o){return this.enabled===!1||s===o||!s||!o||(this.spaces[s].transfer===ct&&(r.r=ri(r.r),r.g=ri(r.g),r.b=ri(r.b)),this.spaces[s].primaries!==this.spaces[o].primaries&&(r.applyMatrix3(this.spaces[s].toXYZ),r.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===ct&&(r.r=Ur(r.r),r.g=Ur(r.g),r.b=Ur(r.b))),r},workingToColorSpace:function(r,s){return this.convert(r,this.workingColorSpace,s)},colorSpaceToWorking:function(r,s){return this.convert(r,s,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===ai?As:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,s=this.workingColorSpace){return r.fromArray(this.spaces[s].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,s,o){return r.copy(this.spaces[s].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,s){return ji("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),n.workingToColorSpace(r,s)},toWorkingColorSpace:function(r,s){return ji("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),n.colorSpaceToWorking(r,s)}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],i=[.3127,.329];return n.define({[Es]:{primaries:e,whitePoint:i,transfer:As,toXYZ:Mu,fromXYZ:Su,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:Qt},outputColorSpaceConfig:{drawingBufferColorSpace:Qt}},[Qt]:{primaries:e,whitePoint:i,transfer:ct,toXYZ:Mu,fromXYZ:Su,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:Qt}}}),n}var rt=zp();function ri(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Ur(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}var _r,ga=class{static getDataURL(e,t="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let i;if(e instanceof HTMLCanvasElement)i=e;else{_r===void 0&&(_r=Cs("canvas")),_r.width=e.width,_r.height=e.height;let r=_r.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),i=_r}return i.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=Cs("canvas");t.width=e.width,t.height=e.height;let i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);let r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let o=0;o<s.length;o++)s[o]=ri(s[o]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){let t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(ri(t[i]/255)*255):t[i]=ri(t[i]);return{data:t,width:e.width,height:e.height}}else return qe("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Vp=0,Hr=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Vp++}),this.uuid=Wn(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<"u"&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<"u"&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t!==null?e.set(t.width,t.height,t.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let o=0,a=r.length;o<a;o++)r[o].isDataTexture?s.push(uc(r[o].image)):s.push(uc(r[o]))}else s=uc(r);i.url=s}return t||(e.images[this.uuid]=i),i}};function uc(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?ga.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(qe("Texture: Unable to serialize Texture."),{})}var Hp=0,dc=new O,tn=class n extends In{constructor(e=n.DEFAULT_IMAGE,t=n.DEFAULT_MAPPING,i=xn,r=xn,s=Nt,o=Ii,a=Mn,c=an,l=n.DEFAULT_ANISOTROPY,u=ai){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Hp++}),this.uuid=Wn(),this.name="",this.source=new Hr(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=o,this.anisotropy=l,this.format=a,this.internalFormat=null,this.type=c,this.offset=new be(0,0),this.repeat=new be(1,1),this.center=new be(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new je,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(dc).x}get height(){return this.source.getSize(dc).y}get depth(){return this.source.getSize(dc).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let i=e[t];if(i===void 0){qe(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){qe(`Texture.setValues(): property '${t}' does not exist.`);continue}r&&i&&r.isVector2&&i.isVector2||r&&i&&r.isVector3&&i.isVector3||r&&i&&r.isMatrix3&&i.isMatrix3?r.copy(i):this[t]=i}}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==lh)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Or:e.x=e.x-Math.floor(e.x);break;case xn:e.x=e.x<0?0:1;break;case Br:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Or:e.y=e.y-Math.floor(e.y);break;case xn:e.y=e.y<0?0:1;break;case Br:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};tn.DEFAULT_IMAGE=null;tn.DEFAULT_MAPPING=lh;tn.DEFAULT_ANISOTROPY=1;var St=class n{static{n.prototype.isVector4=!0}constructor(e=0,t=0,i=0,r=1){this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("THREE.Vector4: index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("THREE.Vector4: index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,i=this.y,r=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*i+o[8]*r+o[12]*s,this.y=o[1]*t+o[5]*i+o[9]*r+o[13]*s,this.z=o[2]*t+o[6]*i+o[10]*r+o[14]*s,this.w=o[3]*t+o[7]*i+o[11]*r+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s,c=e.elements,l=c[0],u=c[4],d=c[8],h=c[1],f=c[5],g=c[9],b=c[2],m=c[6],p=c[10];if(Math.abs(u-h)<.01&&Math.abs(d-b)<.01&&Math.abs(g-m)<.01){if(Math.abs(u+h)<.1&&Math.abs(d+b)<.1&&Math.abs(g+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let T=(l+1)/2,y=(f+1)/2,E=(p+1)/2,A=(u+h)/4,U=(d+b)/4,v=(g+m)/4;return T>y&&T>E?T<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(T),r=A/i,s=U/i):y>E?y<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(y),i=A/r,s=v/r):E<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(E),i=U/s,r=v/s),this.set(i,r,s,t),this}let S=Math.sqrt((m-g)*(m-g)+(d-b)*(d-b)+(h-u)*(h-u));return Math.abs(S)<.001&&(S=1),this.x=(m-g)/S,this.y=(d-b)/S,this.z=(h-u)/S,this.w=Math.acos((l+f+p-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=et(this.x,e.x,t.x),this.y=et(this.y,e.y,t.y),this.z=et(this.z,e.z,t.z),this.w=et(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=et(this.x,e,t),this.y=et(this.y,e,t),this.z=et(this.z,e,t),this.w=et(this.w,e,t),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(et(i,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},_a=class extends In{constructor(e=1,t=1,i={}){super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Nt,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},i),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=i.depth,this.scissor=new St(0,0,e,t),this.scissorTest=!1,this.viewport=new St(0,0,e,t),this.textures=[];let r={width:e,height:t,depth:i.depth},s=new tn(r),o=i.count;for(let a=0;a<o;a++)this.textures[a]=s.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveColorBuffer=i.resolveColorBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.storeMultisampledColorBuffer=i.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=i.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=i.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview,this.useArrayDepthTexture=i.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:Nt,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let i=0;i<this.textures.length;i++)this.textures[i].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=i,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,i=e.textures.length;t<i;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let r=Object.assign({},e.textures[t].image);this.textures[t].source=new Hr(r)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null)if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture;return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:"dispose"})}},sn=class extends _a{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}},Ps=class extends tn{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Dt,this.minFilter=Dt,this.wrapR=xn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}};var ya=class extends tn{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Dt,this.minFilter=Dt,this.wrapR=xn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}};var vt=class n{static{n.prototype.isMatrix4=!0}constructor(e,t,i,r,s,o,a,c,l,u,d,h,f,g,b,m){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,o,a,c,l,u,d,h,f,g,b,m)}set(e,t,i,r,s,o,a,c,l,u,d,h,f,g,b,m){let p=this.elements;return p[0]=e,p[4]=t,p[8]=i,p[12]=r,p[1]=s,p[5]=o,p[9]=a,p[13]=c,p[2]=l,p[6]=u,p[10]=d,p[14]=h,p[3]=f,p[7]=g,p[11]=b,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new n().fromArray(this.elements)}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){let t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),i.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this)}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,i=e.elements,r=1/yr.setFromMatrixColumn(e,0).length(),s=1/yr.setFromMatrixColumn(e,1).length(),o=1/yr.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*o,t[9]=i[9]*o,t[10]=i[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,i=e.x,r=e.y,s=e.z,o=Math.cos(i),a=Math.sin(i),c=Math.cos(r),l=Math.sin(r),u=Math.cos(s),d=Math.sin(s);if(e.order==="XYZ"){let h=o*u,f=o*d,g=a*u,b=a*d;t[0]=c*u,t[4]=-c*d,t[8]=l,t[1]=f+g*l,t[5]=h-b*l,t[9]=-a*c,t[2]=b-h*l,t[6]=g+f*l,t[10]=o*c}else if(e.order==="YXZ"){let h=c*u,f=c*d,g=l*u,b=l*d;t[0]=h+b*a,t[4]=g*a-f,t[8]=o*l,t[1]=o*d,t[5]=o*u,t[9]=-a,t[2]=f*a-g,t[6]=b+h*a,t[10]=o*c}else if(e.order==="ZXY"){let h=c*u,f=c*d,g=l*u,b=l*d;t[0]=h-b*a,t[4]=-o*d,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*u,t[9]=b-h*a,t[2]=-o*l,t[6]=a,t[10]=o*c}else if(e.order==="ZYX"){let h=o*u,f=o*d,g=a*u,b=a*d;t[0]=c*u,t[4]=g*l-f,t[8]=h*l+b,t[1]=c*d,t[5]=b*l+h,t[9]=f*l-g,t[2]=-l,t[6]=a*c,t[10]=o*c}else if(e.order==="YZX"){let h=o*c,f=o*l,g=a*c,b=a*l;t[0]=c*u,t[4]=b-h*d,t[8]=g*d+f,t[1]=d,t[5]=o*u,t[9]=-a*u,t[2]=-l*u,t[6]=f*d+g,t[10]=h-b*d}else if(e.order==="XZY"){let h=o*c,f=o*l,g=a*c,b=a*l;t[0]=c*u,t[4]=-d,t[8]=l*u,t[1]=h*d+b,t[5]=o*u,t[9]=f*d-g,t[2]=g*d-f,t[6]=a*u,t[10]=b*d+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Gp,e,Wp)}lookAt(e,t,i){let r=this.elements;return dn.subVectors(e,t),dn.lengthSq()===0&&(dn.z=1),dn.normalize(),pi.crossVectors(i,dn),pi.lengthSq()===0&&(Math.abs(i.z)===1?dn.x+=1e-4:dn.z+=1e-4,dn.normalize(),pi.crossVectors(i,dn)),pi.normalize(),Io.crossVectors(dn,pi),r[0]=pi.x,r[4]=Io.x,r[8]=dn.x,r[1]=pi.y,r[5]=Io.y,r[9]=dn.y,r[2]=pi.z,r[6]=Io.z,r[10]=dn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,r=t.elements,s=this.elements,o=i[0],a=i[4],c=i[8],l=i[12],u=i[1],d=i[5],h=i[9],f=i[13],g=i[2],b=i[6],m=i[10],p=i[14],S=i[3],T=i[7],y=i[11],E=i[15],A=r[0],U=r[4],v=r[8],C=r[12],z=r[1],X=r[5],W=r[9],re=r[13],G=r[2],se=r[6],_e=r[10],ee=r[14],Y=r[3],he=r[7],de=r[11],ye=r[15];return s[0]=o*A+a*z+c*G+l*Y,s[4]=o*U+a*X+c*se+l*he,s[8]=o*v+a*W+c*_e+l*de,s[12]=o*C+a*re+c*ee+l*ye,s[1]=u*A+d*z+h*G+f*Y,s[5]=u*U+d*X+h*se+f*he,s[9]=u*v+d*W+h*_e+f*de,s[13]=u*C+d*re+h*ee+f*ye,s[2]=g*A+b*z+m*G+p*Y,s[6]=g*U+b*X+m*se+p*he,s[10]=g*v+b*W+m*_e+p*de,s[14]=g*C+b*re+m*ee+p*ye,s[3]=S*A+T*z+y*G+E*Y,s[7]=S*U+T*X+y*se+E*he,s[11]=S*v+T*W+y*_e+E*de,s[15]=S*C+T*re+y*ee+E*ye,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],o=e[1],a=e[5],c=e[9],l=e[13],u=e[2],d=e[6],h=e[10],f=e[14],g=e[3],b=e[7],m=e[11],p=e[15],S=c*f-l*h,T=a*f-l*d,y=a*h-c*d,E=o*f-l*u,A=o*h-c*u,U=o*d-a*u;return t*(b*S-m*T+p*y)-i*(g*S-m*E+p*A)+r*(g*T-b*E+p*U)-s*(g*y-b*A+m*U)}determinantAffine(){let e=this.elements,t=e[0],i=e[4],r=e[8],s=e[1],o=e[5],a=e[9],c=e[2],l=e[6],u=e[10];return t*(o*u-a*l)-i*(s*u-a*c)+r*(s*l-o*c)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){let e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],o=e[4],a=e[5],c=e[6],l=e[7],u=e[8],d=e[9],h=e[10],f=e[11],g=e[12],b=e[13],m=e[14],p=e[15],S=t*a-i*o,T=t*c-r*o,y=t*l-s*o,E=i*c-r*a,A=i*l-s*a,U=r*l-s*c,v=u*b-d*g,C=u*m-h*g,z=u*p-f*g,X=d*m-h*b,W=d*p-f*b,re=h*p-f*m,G=S*re-T*W+y*X+E*z-A*C+U*v;if(G===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let se=1/G;return e[0]=(a*re-c*W+l*X)*se,e[1]=(r*W-i*re-s*X)*se,e[2]=(b*U-m*A+p*E)*se,e[3]=(h*A-d*U-f*E)*se,e[4]=(c*z-o*re-l*C)*se,e[5]=(t*re-r*z+s*C)*se,e[6]=(m*y-g*U-p*T)*se,e[7]=(u*U-h*y+f*T)*se,e[8]=(o*W-a*z+l*v)*se,e[9]=(i*z-t*W-s*v)*se,e[10]=(g*A-b*y+p*S)*se,e[11]=(d*y-u*A-f*S)*se,e[12]=(a*C-o*X-c*v)*se,e[13]=(t*X-i*C+r*v)*se,e[14]=(b*T-g*E-m*S)*se,e[15]=(u*E-d*T+h*S)*se,this}scale(e){let t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let i=Math.cos(t),r=Math.sin(t),s=1-i,o=e.x,a=e.y,c=e.z,l=s*o,u=s*a;return this.set(l*o+i,l*a-r*c,l*c+r*a,0,l*a+r*c,u*a+i,u*c-r*o,0,l*c-r*a,u*c+r*o,s*c*c+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,o){return this.set(1,i,s,0,e,1,o,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){let r=this.elements,s=t._x,o=t._y,a=t._z,c=t._w,l=s+s,u=o+o,d=a+a,h=s*l,f=s*u,g=s*d,b=o*u,m=o*d,p=a*d,S=c*l,T=c*u,y=c*d,E=i.x,A=i.y,U=i.z;return r[0]=(1-(b+p))*E,r[1]=(f+y)*E,r[2]=(g-T)*E,r[3]=0,r[4]=(f-y)*A,r[5]=(1-(h+p))*A,r[6]=(m+S)*A,r[7]=0,r[8]=(g+T)*U,r[9]=(m-S)*U,r[10]=(1-(h+b))*U,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let s=this.determinantAffine();if(s===0)return i.set(1,1,1),t.identity(),this;let o=yr.set(r[0],r[1],r[2]).length(),a=yr.set(r[4],r[5],r[6]).length(),c=yr.set(r[8],r[9],r[10]).length();s<0&&(o=-o),En.copy(this);let l=1/o,u=1/a,d=1/c;return En.elements[0]*=l,En.elements[1]*=l,En.elements[2]*=l,En.elements[4]*=u,En.elements[5]*=u,En.elements[6]*=u,En.elements[8]*=d,En.elements[9]*=d,En.elements[10]*=d,t.setFromRotationMatrix(En),i.x=o,i.y=a,i.z=c,this}makePerspective(e,t,i,r,s,o,a=Pn,c=!1){let l=this.elements,u=2*s/(t-e),d=2*s/(i-r),h=(t+e)/(t-e),f=(i+r)/(i-r),g,b;if(c)g=s/(o-s),b=o*s/(o-s);else if(a===Pn)g=-(o+s)/(o-s),b=-2*o*s/(o-s);else if(a===kr)g=-o/(o-s),b=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=u,l[4]=0,l[8]=h,l[12]=0,l[1]=0,l[5]=d,l[9]=f,l[13]=0,l[2]=0,l[6]=0,l[10]=g,l[14]=b,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,r,s,o,a=Pn,c=!1){let l=this.elements,u=2/(t-e),d=2/(i-r),h=-(t+e)/(t-e),f=-(i+r)/(i-r),g,b;if(c)g=1/(o-s),b=o/(o-s);else if(a===Pn)g=-2/(o-s),b=-(o+s)/(o-s);else if(a===kr)g=-1/(o-s),b=-s/(o-s);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=u,l[4]=0,l[8]=0,l[12]=h,l[1]=0,l[5]=d,l[9]=0,l[13]=f,l[2]=0,l[6]=0,l[10]=g,l[14]=b,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}},yr=new O,En=new vt,Gp=new O(0,0,0),Wp=new O(1,1,1),pi=new O,Io=new O,dn=new O,wu=new vt,Tu=new pn,si=class n{constructor(e=0,t=0,i=0,r=n.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){let r=e.elements,s=r[0],o=r[4],a=r[8],c=r[1],l=r[5],u=r[9],d=r[2],h=r[6],f=r[10];switch(t){case"XYZ":this._y=Math.asin(et(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-u,f),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(h,l),this._z=0);break;case"YXZ":this._x=Math.asin(-et(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(et(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-d,f),this._z=Math.atan2(-o,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-et(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(h,f),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-o,l));break;case"YZX":this._z=Math.asin(et(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-u,l),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-et(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(h,l),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-u,f),this._y=0);break;default:qe("Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return wu.makeRotationFromQuaternion(e),this.setFromRotationMatrix(wu,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Tu.setFromEuler(this),this.setFromQuaternion(Tu,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};si.DEFAULT_ORDER="XYZ";var Is=class{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}},Xp=0,Eu=new O,vr=new pn,Kn=new vt,Do=new O,fs=new O,jp=new O,qp=new pn,Au=new O(1,0,0),Cu=new O(0,1,0),Ru=new O(0,0,1),Pu={type:"added"},$p={type:"removed"},xr={type:"childadded",child:null},fc={type:"childremoved",child:null},kt=class n extends In{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Xp++}),this.uuid=Wn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=n.DEFAULT_UP.clone();let e=new O,t=new si,i=new pn,r=new O(1,1,1);function s(){i.setFromEuler(t,!1)}function o(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new vt},normalMatrix:{value:new je}}),this.matrix=new vt,this.matrixWorld=new vt,this.matrixAutoUpdate=n.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=n.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Is,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return vr.setFromAxisAngle(e,t),this.quaternion.multiply(vr),this}rotateOnWorldAxis(e,t){return vr.setFromAxisAngle(e,t),this.quaternion.premultiply(vr),this}rotateX(e){return this.rotateOnAxis(Au,e)}rotateY(e){return this.rotateOnAxis(Cu,e)}rotateZ(e){return this.rotateOnAxis(Ru,e)}translateOnAxis(e,t){return Eu.copy(e).applyQuaternion(this.quaternion),this.position.add(Eu.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Au,e)}translateY(e){return this.translateOnAxis(Cu,e)}translateZ(e){return this.translateOnAxis(Ru,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Kn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Do.copy(e):Do.set(e,t,i);let r=this.parent;this.updateWorldMatrix(!0,!1),fs.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Kn.lookAt(fs,Do,this.up):Kn.lookAt(Do,fs,this.up),this.quaternion.setFromRotationMatrix(Kn),r&&(Kn.extractRotation(r.matrixWorld),vr.setFromRotationMatrix(Kn),this.quaternion.premultiply(vr.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(Ye("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Pu),xr.child=e,this.dispatchEvent(xr),xr.child=null):Ye("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent($p),fc.child=e,this.dispatchEvent(fc),fc.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Kn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Kn.multiply(e.parent.matrixWorld)),e.applyMatrix4(Kn),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Pu),xr.child=e,this.dispatchEvent(xr),xr.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){let o=this.children[i].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);let r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fs,e,jp),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(fs,qp,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,i=e.y,r=e.z,s=this.matrix.elements;s[12]+=t-s[0]*t-s[4]*i-s[8]*r,s[13]+=i-s[1]*t-s[5]*i-s[9]*r,s[14]+=r-s[2]*t-s[6]*i-s[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t,i=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||i)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,i=!0),t===!0){let s=this.children;for(let o=0,a=s.length;o<a;o++)s[o].updateWorldMatrix(!1,!0,i)}}toJSON(e){let t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(a=>({...a,boundingBox:a.boundingBox?a.boundingBox.toJSON():void 0,boundingSphere:a.boundingSphere?a.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(a=>({...a})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function s(a,c){return a[c.uuid]===void 0&&(a[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);let a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){let c=a.shapes;if(Array.isArray(c))for(let l=0,u=c.length;l<u;l++){let d=c[l];s(e.shapes,d)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let a=[];for(let c=0,l=this.material.length;c<l;c++)a.push(s(e.materials,this.material[c]));r.material=a}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let a=0;a<this.children.length;a++)r.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let a=0;a<this.animations.length;a++){let c=this.animations[a];r.animations.push(s(e.animations,c))}}if(t){let a=o(e.geometries),c=o(e.materials),l=o(e.textures),u=o(e.images),d=o(e.shapes),h=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(i.geometries=a),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),u.length>0&&(i.images=u),d.length>0&&(i.shapes=d),h.length>0&&(i.skeletons=h),f.length>0&&(i.animations=f),g.length>0&&(i.nodes=g)}return i.object=r,i;function o(a){let c=[];for(let l in a){let u=a[l];delete u.metadata,c.push(u)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){let r=e.children[i];this.add(r.clone())}return this}dispose(){this.dispatchEvent({type:"dispose"})}};kt.DEFAULT_UP=new O(0,1,0);kt.DEFAULT_MATRIX_AUTO_UPDATE=!0;kt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var en=class extends kt{constructor(){super(),this.isGroup=!0,this.type="Group"}},Yp={type:"move"},Gr=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new en,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new en,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new O,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new O),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new en,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new O,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new O,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,o=null,a=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){o=!0;for(let b of e.hand.values()){let m=t.getJointPose(b,i),p=this._getHandJoint(l,b);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}let u=l.joints["index-finger-tip"],d=l.joints["thumb-tip"],h=u.position.distanceTo(d.position),f=.02,g=.005;l.inputState.pinching&&h>f+g?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&h<=f-g&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1,c.eventsEnabled&&c.dispatchEvent({type:"gripUpdated",data:e,target:this})));a!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(a.matrix.fromArray(r.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,r.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(r.linearVelocity)):a.hasLinearVelocity=!1,r.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(r.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Yp)))}return a!==null&&(a.visible=r!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let i=new en;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}},kd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},mi={h:0,s:0,l:0},Lo={h:0,s:0,l:0};function pc(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}var He=class{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){let r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=Qt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,rt.colorSpaceToWorking(this,t),this}setRGB(e,t,i,r=rt.workingColorSpace){return this.r=e,this.g=t,this.b=i,rt.colorSpaceToWorking(this,r),this}setHSL(e,t,i,r=rt.workingColorSpace){if(e=_h(e,1),t=et(t,0,1),i=et(i,0,1),t===0)this.r=this.g=this.b=i;else{let s=i<=.5?i*(1+t):i+t-i*t,o=2*i-s;this.r=pc(o,s,e+1/3),this.g=pc(o,s,e),this.b=pc(o,s,e-1/3)}return rt.colorSpaceToWorking(this,r),this}setStyle(e,t=Qt){function i(s){s!==void 0&&parseFloat(s)<1&&qe("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s,o=r[1],a=r[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:qe("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let s=r[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);qe("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=Qt){let i=kd[e.toLowerCase()];return i!==void 0?this.setHex(i,t):qe("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=ri(e.r),this.g=ri(e.g),this.b=ri(e.b),this}copyLinearToSRGB(e){return this.r=Ur(e.r),this.g=Ur(e.g),this.b=Ur(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Qt){return rt.workingToColorSpace(jt.copy(this),e),Math.round(et(jt.r*255,0,255))*65536+Math.round(et(jt.g*255,0,255))*256+Math.round(et(jt.b*255,0,255))}getHexString(e=Qt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=rt.workingColorSpace){rt.workingToColorSpace(jt.copy(this),t);let i=jt.r,r=jt.g,s=jt.b,o=Math.max(i,r,s),a=Math.min(i,r,s),c,l,u=(a+o)/2;if(a===o)c=0,l=0;else{let d=o-a;switch(l=u<=.5?d/(o+a):d/(2-o-a),o){case i:c=(r-s)/d+(r<s?6:0);break;case r:c=(s-i)/d+2;break;case s:c=(i-r)/d+4;break}c/=6}return e.h=c,e.s=l,e.l=u,e}getRGB(e,t=rt.workingColorSpace){return rt.workingToColorSpace(jt.copy(this),t),e.r=jt.r,e.g=jt.g,e.b=jt.b,e}getStyle(e=Qt){rt.workingToColorSpace(jt.copy(this),e);let t=jt.r,i=jt.g,r=jt.b;return e!==Qt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(mi),this.setHSL(mi.h+e,mi.s+t,mi.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(mi),e.getHSL(Lo);let i=Ms(mi.h,Lo.h,t),r=Ms(mi.s,Lo.s,t),s=Ms(mi.l,Lo.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},jt=new He;He.NAMES=kd;var Ds=class extends kt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new si,this.environmentIntensity=1,this.environmentRotation=new si,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},An=new O,Qn=new O,mc=new O,ei=new O,br=new O,Mr=new O,Iu=new O,gc=new O,_c=new O,yc=new O,vc=new St,xc=new St,bc=new St,Gn=class n{constructor(e=new O,t=new O,i=new O){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),An.subVectors(e,t),r.cross(An);let s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){An.subVectors(r,t),Qn.subVectors(i,t),mc.subVectors(e,t);let o=An.dot(An),a=An.dot(Qn),c=An.dot(mc),l=Qn.dot(Qn),u=Qn.dot(mc),d=o*l-a*a;if(d===0)return s.set(0,0,0),null;let h=1/d,f=(l*c-a*u)*h,g=(o*u-a*c)*h;return s.set(1-f-g,g,f)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,ei)===null?!1:ei.x>=0&&ei.y>=0&&ei.x+ei.y<=1}static getInterpolation(e,t,i,r,s,o,a,c){return this.getBarycoord(e,t,i,r,ei)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,ei.x),c.addScaledVector(o,ei.y),c.addScaledVector(a,ei.z),c)}static getInterpolatedAttribute(e,t,i,r,s,o){return vc.setScalar(0),xc.setScalar(0),bc.setScalar(0),vc.fromBufferAttribute(e,t),xc.fromBufferAttribute(e,i),bc.fromBufferAttribute(e,r),o.setScalar(0),o.addScaledVector(vc,s.x),o.addScaledVector(xc,s.y),o.addScaledVector(bc,s.z),o}static isFrontFacing(e,t,i,r){return An.subVectors(i,t),Qn.subVectors(e,t),An.cross(Qn).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return An.subVectors(this.c,this.b),Qn.subVectors(this.a,this.b),An.cross(Qn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return n.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return n.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,r,s){return n.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return n.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return n.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let i=this.a,r=this.b,s=this.c,o,a;br.subVectors(r,i),Mr.subVectors(s,i),gc.subVectors(e,i);let c=br.dot(gc),l=Mr.dot(gc);if(c<=0&&l<=0)return t.copy(i);_c.subVectors(e,r);let u=br.dot(_c),d=Mr.dot(_c);if(u>=0&&d<=u)return t.copy(r);let h=c*d-u*l;if(h<=0&&c>=0&&u<=0)return o=c/(c-u),t.copy(i).addScaledVector(br,o);yc.subVectors(e,s);let f=br.dot(yc),g=Mr.dot(yc);if(g>=0&&f<=g)return t.copy(s);let b=f*l-c*g;if(b<=0&&l>=0&&g<=0)return a=l/(l-g),t.copy(i).addScaledVector(Mr,a);let m=u*g-f*d;if(m<=0&&d-u>=0&&f-g>=0)return Iu.subVectors(s,r),a=(d-u)/(d-u+(f-g)),t.copy(r).addScaledVector(Iu,a);let p=1/(m+b+h);return o=b*p,a=h*p,t.copy(i).addScaledVector(br,o).addScaledVector(Mr,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},on=class{constructor(e=new O(1/0,1/0,1/0),t=new O(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Cn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Cn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=Cn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let i=e.geometry;if(i!==void 0){let s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=s.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Cn):Cn.fromBufferAttribute(s,o),Cn.applyMatrix4(e.matrixWorld),this.expandByPoint(Cn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),No.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),No.copy(i.boundingBox)),No.applyMatrix4(e.matrixWorld),this.union(No)}let r=e.children;for(let s=0,o=r.length;s<o;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Cn),Cn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ps),Uo.subVectors(this.max,ps),Sr.subVectors(e.a,ps),wr.subVectors(e.b,ps),Tr.subVectors(e.c,ps),gi.subVectors(wr,Sr),_i.subVectors(Tr,wr),Hi.subVectors(Sr,Tr);let t=[0,-gi.z,gi.y,0,-_i.z,_i.y,0,-Hi.z,Hi.y,gi.z,0,-gi.x,_i.z,0,-_i.x,Hi.z,0,-Hi.x,-gi.y,gi.x,0,-_i.y,_i.x,0,-Hi.y,Hi.x,0];return!Mc(t,Sr,wr,Tr,Uo)||(t=[1,0,0,0,1,0,0,0,1],!Mc(t,Sr,wr,Tr,Uo))?!1:(Fo.crossVectors(gi,_i),t=[Fo.x,Fo.y,Fo.z],Mc(t,Sr,wr,Tr,Uo))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Cn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Cn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ti[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ti[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ti[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ti[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ti[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ti[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ti[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ti[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ti),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},ti=[new O,new O,new O,new O,new O,new O,new O,new O],Cn=new O,No=new on,Sr=new O,wr=new O,Tr=new O,gi=new O,_i=new O,Hi=new O,ps=new O,Uo=new O,Fo=new O,Gi=new O;function Mc(n,e,t,i,r){for(let s=0,o=n.length-3;s<=o;s+=3){Gi.fromArray(n,s);let a=r.x*Math.abs(Gi.x)+r.y*Math.abs(Gi.y)+r.z*Math.abs(Gi.z),c=e.dot(Gi),l=t.dot(Gi),u=i.dot(Gi);if(Math.max(-Math.max(c,l,u),Math.min(c,l,u))>a)return!1}return!0}var It=new O,Oo=new be,Zp=0,Ct=class extends In{constructor(e,t,i=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:Zp++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=mh,this.updateRanges=[],this.gpuType=Un,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Oo.fromBufferAttribute(this,t),Oo.applyMatrix3(e),this.setXY(t,Oo.x,Oo.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.applyMatrix3(e),this.setXYZ(t,It.x,It.y,It.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.applyMatrix4(e),this.setXYZ(t,It.x,It.y,It.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.applyNormalMatrix(e),this.setXYZ(t,It.x,It.y,It.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.transformDirection(e),this.setXYZ(t,It.x,It.y,It.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=Rn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=ht(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=Rn(t,this.array)),t}setX(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=Rn(t,this.array)),t}setY(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=Rn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=Rn(t,this.array)),t}setW(e,t){return this.normalized&&(t=ht(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array),r=ht(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array),r=ht(r,this.array),s=ht(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:"dispose"})}};var Ls=class extends Ct{constructor(e,t,i){super(new Uint16Array(e),t,i)}};var Ns=class extends Ct{constructor(e,t,i){super(new Uint32Array(e),t,i)}};var _t=class extends Ct{constructor(e,t,i){super(new Float32Array(e),t,i)}},Jp=new on,ms=new O,Sc=new O,qi=class{constructor(e=new O,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let i=this.center;t!==void 0?i.copy(t):Jp.setFromPoints(e).getCenter(i);let r=0;for(let s=0,o=e.length;s<o;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ms.subVectors(e,this.center);let t=ms.lengthSq();if(t>this.radius*this.radius){let i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(ms,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Sc.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ms.copy(e.center).add(Sc)),this.expandByPoint(ms.copy(e.center).sub(Sc))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},Kp=0,vn=new vt,wc=new kt,Er=new O,fn=new on,gs=new on,Bt=new O,wt=class n extends In{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Kp++}),this.uuid=Wn(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Mp(e)?Ns:Ls)(e,1):this.index=e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let s=new je().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return vn.makeRotationFromQuaternion(e),this.applyMatrix4(vn),this}rotateX(e){return vn.makeRotationX(e),this.applyMatrix4(vn),this}rotateY(e){return vn.makeRotationY(e),this.applyMatrix4(vn),this}rotateZ(e){return vn.makeRotationZ(e),this.applyMatrix4(vn),this}translate(e,t,i){return vn.makeTranslation(e,t,i),this.applyMatrix4(vn),this}scale(e,t,i){return vn.makeScale(e,t,i),this.applyMatrix4(vn),this}lookAt(e){return wc.lookAt(e),wc.updateMatrix(),this.applyMatrix4(wc.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Er).negate(),this.translate(Er.x,Er.y,Er.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let i=[];for(let r=0,s=e.length;r<s;r++){let o=e[r];i.push(o.x,o.y,o.z||0)}this.setAttribute("position",new _t(i,3))}else{let i=Math.min(e.length,t.count);for(let r=0;r<i;r++){let s=e[r];t.setXYZ(r,s.x,s.y,s.z||0)}e.length>t.count&&qe("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new on);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ye("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new O(-1/0,-1/0,-1/0),new O(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){let s=t[i];fn.setFromBufferAttribute(s),this.morphTargetsRelative?(Bt.addVectors(this.boundingBox.min,fn.min),this.boundingBox.expandByPoint(Bt),Bt.addVectors(this.boundingBox.max,fn.max),this.boundingBox.expandByPoint(Bt)):(this.boundingBox.expandByPoint(fn.min),this.boundingBox.expandByPoint(fn.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ye('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new qi);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Ye("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new O,1/0);return}if(e){let i=this.boundingSphere.center;if(fn.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){let a=t[s];gs.setFromBufferAttribute(a),this.morphTargetsRelative?(Bt.addVectors(fn.min,gs.min),fn.expandByPoint(Bt),Bt.addVectors(fn.max,gs.max),fn.expandByPoint(Bt)):(fn.expandByPoint(gs.min),fn.expandByPoint(gs.max))}fn.getCenter(i);let r=0;for(let s=0,o=e.count;s<o;s++)Bt.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(Bt));if(t)for(let s=0,o=t.length;s<o;s++){let a=t[s],c=this.morphTargetsRelative;for(let l=0,u=a.count;l<u;l++)Bt.fromBufferAttribute(a,l),c&&(Er.fromBufferAttribute(e,l),Bt.add(Er)),r=Math.max(r,i.distanceToSquared(Bt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&Ye('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){Ye("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}let i=t.position,r=t.normal,s=t.uv,o=this.getAttribute("tangent");(o===void 0||o.count!==i.count)&&(o=new Ct(new Float32Array(4*i.count),4),this.setAttribute("tangent",o));let a=[],c=[];for(let v=0;v<i.count;v++)a[v]=new O,c[v]=new O;let l=new O,u=new O,d=new O,h=new be,f=new be,g=new be,b=new O,m=new O;function p(v,C,z){l.fromBufferAttribute(i,v),u.fromBufferAttribute(i,C),d.fromBufferAttribute(i,z),h.fromBufferAttribute(s,v),f.fromBufferAttribute(s,C),g.fromBufferAttribute(s,z),u.sub(l),d.sub(l),f.sub(h),g.sub(h);let X=1/(f.x*g.y-g.x*f.y);isFinite(X)&&(b.copy(u).multiplyScalar(g.y).addScaledVector(d,-f.y).multiplyScalar(X),m.copy(d).multiplyScalar(f.x).addScaledVector(u,-g.x).multiplyScalar(X),a[v].add(b),a[C].add(b),a[z].add(b),c[v].add(m),c[C].add(m),c[z].add(m))}let S=this.groups;S.length===0&&(S=[{start:0,count:e.count}]);for(let v=0,C=S.length;v<C;++v){let z=S[v],X=z.start,W=z.count;for(let re=X,G=X+W;re<G;re+=3)p(e.getX(re+0),e.getX(re+1),e.getX(re+2))}let T=new O,y=new O,E=new O,A=new O;function U(v){E.fromBufferAttribute(r,v),A.copy(E);let C=a[v];T.copy(C),T.sub(E.multiplyScalar(E.dot(C))).normalize(),y.crossVectors(A,C);let X=y.dot(c[v])<0?-1:1;o.setXYZW(v,T.x,T.y,T.z,X)}for(let v=0,C=S.length;v<C;++v){let z=S[v],X=z.start,W=z.count;for(let re=X,G=X+W;re<G;re+=3)U(e.getX(re+0)),U(e.getX(re+1)),U(e.getX(re+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0||i.count!==t.count)i=new Ct(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let h=0,f=i.count;h<f;h++)i.setXYZ(h,0,0,0);let r=new O,s=new O,o=new O,a=new O,c=new O,l=new O,u=new O,d=new O;if(e)for(let h=0,f=e.count;h<f;h+=3){let g=e.getX(h+0),b=e.getX(h+1),m=e.getX(h+2);r.fromBufferAttribute(t,g),s.fromBufferAttribute(t,b),o.fromBufferAttribute(t,m),u.subVectors(o,s),d.subVectors(r,s),u.cross(d),a.fromBufferAttribute(i,g),c.fromBufferAttribute(i,b),l.fromBufferAttribute(i,m),a.add(u),c.add(u),l.add(u),i.setXYZ(g,a.x,a.y,a.z),i.setXYZ(b,c.x,c.y,c.z),i.setXYZ(m,l.x,l.y,l.z)}else for(let h=0,f=t.count;h<f;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),o.fromBufferAttribute(t,h+2),u.subVectors(o,s),d.subVectors(r,s),u.cross(d),i.setXYZ(h+0,u.x,u.y,u.z),i.setXYZ(h+1,u.x,u.y,u.z),i.setXYZ(h+2,u.x,u.y,u.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Bt.fromBufferAttribute(e,t),Bt.normalize(),e.setXYZ(t,Bt.x,Bt.y,Bt.z)}toNonIndexed(){function e(a,c){let l=a.array,u=a.itemSize,d=a.normalized,h=new l.constructor(c.length*u),f=0,g=0;for(let b=0,m=c.length;b<m;b++){a.isInterleavedBufferAttribute?f=c[b]*a.data.stride+a.offset:f=c[b]*u;for(let p=0;p<u;p++)h[g++]=l[f++]}return new Ct(h,u,d)}if(this.index===null)return qe("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new n,i=this.index.array,r=this.attributes;for(let a in r){let c=r[a],l=e(c,i);t.setAttribute(a,l)}let s=this.morphAttributes;for(let a in s){let c=[],l=s[a];for(let u=0,d=l.length;u<d;u++){let h=l[u],f=e(h,i);c.push(f)}t.morphAttributes[a]=c}t.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let a=0,c=o.length;a<c;a++){let l=o[a];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){let e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?"BufferGeometry":this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let c=this.parameters;for(let l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let i=this.attributes;for(let c in i){let l=i[c];e.data.attributes[c]=l.toJSON(e.data)}let r={},s=!1;for(let c in this.morphAttributes){let l=this.morphAttributes[c],u=[];for(let d=0,h=l.length;d<h;d++){let f=l[d];u.push(f.toJSON(e.data))}u.length>0&&(r[c]=u,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));let a=this.boundingSphere;return a!==null&&(e.data.boundingSphere=a.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let i=e.index;i!==null&&this.setIndex(i.clone());let r=e.attributes;for(let l in r){let u=r[l];this.setAttribute(l,u.clone(t))}let s=e.morphAttributes;for(let l in s){let u=[],d=s[l];for(let h=0,f=d.length;h<f;h++)u.push(d[h].clone(t));this.morphAttributes[l]=u}this.morphTargetsRelative=e.morphTargetsRelative;let o=e.groups;for(let l=0,u=o.length;l<u;l++){let d=o[l];this.addGroup(d.start,d.count,d.materialIndex)}let a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());let c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:"dispose"})}},va=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=mh,this.updateRanges=[],this.version=0,this.uuid=Wn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Wn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Wn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer)));let t={uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride};return t.usage=this.usage,t}},Kt=new O,Us=class n{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Kt.fromBufferAttribute(this,t),Kt.applyMatrix4(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Kt.fromBufferAttribute(this,t),Kt.applyNormalMatrix(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Kt.fromBufferAttribute(this,t),Kt.transformDirection(e),this.setXYZ(t,Kt.x,Kt.y,Kt.z);return this}getComponent(e,t){let i=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(i=Rn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=ht(i,this.array)),this.data.array[e*this.data.stride+this.offset+t]=i,this}setX(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=ht(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=Rn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=Rn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=Rn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=Rn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array),r=ht(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=ht(t,this.array),i=ht(i,this.array),r=ht(r,this.array),s=ht(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){Rs("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new Ct(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new n(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){Rs("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Tc=new O,Qp=new O,em=new je,qt=class{constructor(e=new O(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){let r=Tc.subVectors(i,t).cross(Qp.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,i=!0){let r=e.delta(Tc),s=this.normal.dot(r);if(s===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let o=-(e.start.dot(this.normal)+this.constant)/s;return i===!0&&(o<0||o>1)?null:t.copy(e.start).addScaledVector(r,o)}intersectsLine(e){let t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let i=t||em.getNormalMatrix(e),r=this.coplanarPoint(Tc).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},tm=0,bn=class extends In{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tm++}),this.uuid=Wn(),this.name="",this.type="Material",this.blending=Kr,this.side=Ri,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Kc,this.blendDst=Qc,this.blendEquation=ir,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new He(0,0,0),this.blendAlpha=0,this.depthFunc=Fr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Cd,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=aa,this.stencilZFail=aa,this.stencilZPass=aa,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let i=e[t];if(i===void 0){qe(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];if(r===void 0){qe(`Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector2&&i&&i.isVector2||r&&r.isEuler&&i&&i.isEuler||r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,i.blending=this.blending,i.side=this.side,i.shadowSide=this.shadowSide,i.vertexColors=this.vertexColors,i.opacity=this.opacity,i.transparent=this.transparent,i.blendSrc=this.blendSrc,i.blendDst=this.blendDst,i.blendEquation=this.blendEquation,i.blendSrcAlpha=this.blendSrcAlpha,i.blendDstAlpha=this.blendDstAlpha,i.blendEquationAlpha=this.blendEquationAlpha,i.blendColor=this.blendColor.getHex(),i.blendAlpha=this.blendAlpha,i.depthFunc=this.depthFunc,i.depthTest=this.depthTest,i.depthWrite=this.depthWrite,i.colorWrite=this.colorWrite,i.clipIntersection=this.clipIntersection,i.clipShadows=this.clipShadows,i.stencilWriteMask=this.stencilWriteMask,i.stencilFunc=this.stencilFunc,i.stencilRef=this.stencilRef,i.stencilFuncMask=this.stencilFuncMask,i.stencilFail=this.stencilFail,i.stencilZFail=this.stencilZFail,i.stencilZPass=this.stencilZPass,i.stencilWrite=this.stencilWrite,i.polygonOffset=this.polygonOffset,i.polygonOffsetFactor=this.polygonOffsetFactor,i.polygonOffsetUnits=this.polygonOffsetUnits,i.dithering=this.dithering,i.alphaTest=this.alphaTest,i.alphaHash=this.alphaHash,i.alphaToCoverage=this.alphaToCoverage,i.premultipliedAlpha=this.premultipliedAlpha,i.forceSinglePass=this.forceSinglePass,i.allowOverride=this.allowOverride,i.visible=this.visible,i.toneMapped=this.toneMapped,i.name=this.name,this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(i.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(i.clippingPlanes=this.clippingPlanes.map(s=>s.toJSON())),this.rotation!==void 0&&(i.rotation=this.rotation),this.depthPacking!==void 0&&(i.depthPacking=this.depthPacking),this.linewidth!==void 0&&(i.linewidth=this.linewidth),this.linecap!==void 0&&(i.linecap=this.linecap),this.linejoin!==void 0&&(i.linejoin=this.linejoin),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.wireframe!==void 0&&(i.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(i.flatShading=this.flatShading),this.fog!==void 0&&(i.fog=this.fog),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){let o=[];for(let a in s){let c=s[a];delete c.metadata,o.push(c)}return o}if(t){let s=r(e.textures),o=r(e.images);s.length>0&&(i.textures=s),o.length>0&&(i.images=o)}return i}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new He().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(i=>new qt().fromJSON(i))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(typeof e.vertexColors=="number"?this.vertexColors=e.vertexColors>0:this.vertexColors=e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let i=e.normalScale;Array.isArray(i)===!1&&(i=[i,i]),this.normalScale=new be().fromArray(i)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new be().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,i=null;if(t!==null){let r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}},Wr=class extends bn{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new He(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Ar,_s=new O,Cr=new O,Rr=new O,Pr=new be,ys=new be,zd=new vt,Bo=new O,vs=new O,ko=new O,Du=new be,Ec=new be,Lu=new be,Fs=class extends kt{constructor(e=new Wr){if(super(),this.isSprite=!0,this.type="Sprite",Ar===void 0){Ar=new wt;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new va(t,5);Ar.setIndex([0,1,2,0,2,3]),Ar.setAttribute("position",new Us(i,3,0,!1)),Ar.setAttribute("uv",new Us(i,2,3,!1))}this.geometry=Ar,this.material=e,this.center=new be(.5,.5),this.count=1}intersectsFrustum(e){return e.intersectsSprite(this)}raycast(e,t){e.camera===null&&Ye('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Cr.setFromMatrixScale(this.matrixWorld),zd.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Rr.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Cr.multiplyScalar(-Rr.z);let i=this.material.rotation,r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));let o=this.center;zo(Bo.set(-.5,-.5,0),Rr,o,Cr,r,s),zo(vs.set(.5,-.5,0),Rr,o,Cr,r,s),zo(ko.set(.5,.5,0),Rr,o,Cr,r,s),Du.set(0,0),Ec.set(1,0),Lu.set(1,1);let a=e.ray.intersectTriangle(Bo,vs,ko,!1,_s);if(a===null&&(zo(vs.set(-.5,.5,0),Rr,o,Cr,r,s),Ec.set(0,1),a=e.ray.intersectTriangle(Bo,ko,vs,!1,_s),a===null))return;let c=e.ray.origin.distanceTo(_s);c<e.near||c>e.far||t.push({distance:c,point:_s.clone(),uv:Gn.getInterpolation(_s,Bo,vs,ko,Du,Ec,Lu,new be),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function zo(n,e,t,i,r,s){Pr.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(ys.x=s*Pr.x-r*Pr.y,ys.y=r*Pr.x+s*Pr.y):ys.copy(Pr),n.copy(e),n.x+=ys.x,n.y+=ys.y,n.applyMatrix4(zd)}var ni=new O,Ac=new O,Vo=new O,Ho=new O,oi=class{constructor(e=new O,t=new O(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,ni)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=ni.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(ni.copy(this.origin).addScaledVector(this.direction,t),ni.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){Ac.copy(e).add(t).multiplyScalar(.5),Vo.copy(t).sub(e).normalize(),Ho.copy(this.origin).sub(Ac);let s=e.distanceTo(t)*.5,o=-this.direction.dot(Vo),a=Ho.dot(this.direction),c=-Ho.dot(Vo),l=Ho.lengthSq(),u=Math.abs(1-o*o),d,h,f,g;if(u>0)if(d=o*c-a,h=o*a-c,g=s*u,d>=0)if(h>=-g)if(h<=g){let b=1/u;d*=b,h*=b,f=d*(d+o*h+2*a)+h*(o*d+h+2*c)+l}else h=s,d=Math.max(0,-(o*h+a)),f=-d*d+h*(h+2*c)+l;else h=-s,d=Math.max(0,-(o*h+a)),f=-d*d+h*(h+2*c)+l;else h<=-g?(d=Math.max(0,-(-o*s+a)),h=d>0?-s:Math.min(Math.max(-s,-c),s),f=-d*d+h*(h+2*c)+l):h<=g?(d=0,h=Math.min(Math.max(-s,-c),s),f=h*(h+2*c)+l):(d=Math.max(0,-(o*s+a)),h=d>0?s:Math.min(Math.max(-s,-c),s),f=-d*d+h*(h+2*c)+l);else h=o>0?-s:s,d=Math.max(0,-(o*h+a)),f=-d*d+h*(h+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,d),r&&r.copy(Ac).addScaledVector(Vo,h),f}intersectSphere(e,t){if(e.radius<0)return null;ni.subVectors(e.center,this.origin);let i=ni.dot(this.direction),r=ni.dot(ni)-i*i,s=e.radius*e.radius;if(r>s)return null;let o=Math.sqrt(s-r),a=i-o,c=i+o;return c<0?null:a<0?this.at(c,t):this.at(a,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){let i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,o,a,c,l=1/this.direction.x,u=1/this.direction.y,d=1/this.direction.z,h=this.origin;return l>=0?(i=(e.min.x-h.x)*l,r=(e.max.x-h.x)*l):(i=(e.max.x-h.x)*l,r=(e.min.x-h.x)*l),u>=0?(s=(e.min.y-h.y)*u,o=(e.max.y-h.y)*u):(s=(e.max.y-h.y)*u,o=(e.min.y-h.y)*u),i>o||s>r||((s>i||isNaN(i))&&(i=s),(o<r||isNaN(r))&&(r=o),d>=0?(a=(e.min.z-h.z)*d,c=(e.max.z-h.z)*d):(a=(e.max.z-h.z)*d,c=(e.min.z-h.z)*d),i>c||a>r)||((a>i||i!==i)&&(i=a),(c<r||r!==r)&&(r=c),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,ni)!==null}intersectTriangle(e,t,i,r,s){let o=this.origin,a=this.direction,c=a.x,l=a.y,u=a.z,d=e.x-o.x,h=e.y-o.y,f=e.z-o.z,g=t.x-o.x,b=t.y-o.y,m=t.z-o.z,p=i.x-o.x,S=i.y-o.y,T=i.z-o.z,y=Math.abs(c),E=Math.abs(l),A=Math.abs(u),U,v,C,z,X,W,re,G,se,_e,ee,Y;if(y>=E&&y>=A?(C=c,W=d,se=g,Y=p,c>=0?(U=l,v=u,z=h,X=f,re=b,G=m,_e=S,ee=T):(U=u,v=l,z=f,X=h,re=m,G=b,_e=T,ee=S)):E>=A?(C=l,W=h,se=b,Y=S,l>=0?(U=u,v=c,z=f,X=d,re=m,G=g,_e=T,ee=p):(U=c,v=u,z=d,X=f,re=g,G=m,_e=p,ee=T)):(C=u,W=f,se=m,Y=T,u>=0?(U=c,v=l,z=d,X=h,re=g,G=b,_e=p,ee=S):(U=l,v=c,z=h,X=d,re=b,G=g,_e=S,ee=p)),C===0)return null;let he=U/C,de=v/C,ye=1/C,Oe=z-he*W,Ne=X-de*W,Ke=re-he*se,Ze=G-de*se,Je=_e-he*Y,F=ee-de*Y,D=Je*Ze-F*Ke,L=Oe*F-Ne*Je,R=Ke*Ne-Ze*Oe;if(r){if(D<0||L<0||R<0)return null}else if((D<0||L<0||R<0)&&(D>0||L>0||R>0))return null;let k=D+L+R;if(k===0)return null;let le=ye*(D*W+L*se+R*Y);return(k>0?le<0:le>0)?null:this.at(le/k,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},jn=class extends bn{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new He(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new si,this.combine=eh,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Nu=new vt,Wi=new oi,Go=new qi,Uu=new O,Wo=new O,Xo=new O,jo=new O,Cc=new O,qo=new O,Fu=new O,$o=new O,zt=class extends kt{constructor(e=new wt,t=new jn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){let r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){let a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(e,t){let i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,o=i.morphTargetsRelative;t.fromBufferAttribute(r,e);let a=this.morphTargetInfluences;if(s&&a){qo.set(0,0,0);for(let c=0,l=s.length;c<l;c++){let u=a[c],d=s[c];u!==0&&(Cc.fromBufferAttribute(d,e),o?qo.addScaledVector(Cc,u):qo.addScaledVector(Cc.sub(t),u))}t.add(qo)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Go.copy(i.boundingSphere),Go.applyMatrix4(s),Wi.copy(e.ray).recast(e.near),!(Go.containsPoint(Wi.origin)===!1&&(Wi.intersectSphere(Go,Uu)===null||Wi.origin.distanceToSquared(Uu)>(e.far-e.near)**2))&&(Nu.copy(s).invert(),Wi.copy(e.ray).applyMatrix4(Nu),!(i.boundingBox!==null&&Wi.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Wi)))}_computeIntersections(e,t,i){let r,s=this.geometry,o=this.material,a=s.index,c=s.attributes.position,l=s.attributes.uv,u=s.attributes.uv1,d=s.attributes.normal,h=s.groups,f=s.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,b=h.length;g<b;g++){let m=h[g],p=o[m.materialIndex],S=Math.max(m.start,f.start),T=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let y=S,E=T;y<E;y+=3){let A=a.getX(y),U=a.getX(y+1),v=a.getX(y+2);r=Yo(this,p,e,i,l,u,d,A,U,v),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{let g=Math.max(0,f.start),b=Math.min(a.count,f.start+f.count);for(let m=g,p=b;m<p;m+=3){let S=a.getX(m),T=a.getX(m+1),y=a.getX(m+2);r=Yo(this,o,e,i,l,u,d,S,T,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(c!==void 0)if(Array.isArray(o))for(let g=0,b=h.length;g<b;g++){let m=h[g],p=o[m.materialIndex],S=Math.max(m.start,f.start),T=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let y=S,E=T;y<E;y+=3){let A=y,U=y+1,v=y+2;r=Yo(this,p,e,i,l,u,d,A,U,v),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{let g=Math.max(0,f.start),b=Math.min(c.count,f.start+f.count);for(let m=g,p=b;m<p;m+=3){let S=m,T=m+1,y=m+2;r=Yo(this,o,e,i,l,u,d,S,T,y),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}};function nm(n,e,t,i,r,s,o,a){let c;if(e.side===Gt?c=i.intersectTriangle(o,s,r,!0,a):c=i.intersectTriangle(r,s,o,e.side===Ri,a),c===null)return null;$o.copy(a),$o.applyMatrix4(n.matrixWorld);let l=t.ray.origin.distanceTo($o);return l<t.near||l>t.far?null:{distance:l,point:$o.clone(),object:n}}function Yo(n,e,t,i,r,s,o,a,c,l){n.getVertexPosition(a,Wo),n.getVertexPosition(c,Xo),n.getVertexPosition(l,jo);let u=nm(n,e,t,i,Wo,Xo,jo,Fu);if(u){let d=new O;Gn.getBarycoord(Fu,Wo,Xo,jo,d),r&&(u.uv=Gn.getInterpolatedAttribute(r,a,c,l,d,new be)),s&&(u.uv1=Gn.getInterpolatedAttribute(s,a,c,l,d,new be)),o&&(u.normal=Gn.getInterpolatedAttribute(o,a,c,l,d,new O),u.normal.dot(i.direction)>0&&u.normal.multiplyScalar(-1));let h={a,b:c,c:l,normal:new O,materialIndex:0};Gn.getNormal(Wo,Xo,jo,h.normal),u.face=h,u.barycoord=d}return u}var $i=class extends tn{constructor(e=null,t=1,i=1,r,s,o,a,c,l=Dt,u=Dt,d,h){super(null,o,a,c,l,u,r,s,d,h),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var Xi=new qi,im=new be(.5,.5),Zo=new O,Xr=class{constructor(e=new qt,t=new qt,i=new qt,r=new qt,s=new qt,o=new qt){this.planes=[e,t,i,r,s,o]}set(e,t,i,r,s,o){let a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(i),a[3].copy(r),a[4].copy(s),a[5].copy(o),this}copy(e){let t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=Pn,i=!1){let r=this.planes,s=e.elements,o=s[0],a=s[1],c=s[2],l=s[3],u=s[4],d=s[5],h=s[6],f=s[7],g=s[8],b=s[9],m=s[10],p=s[11],S=s[12],T=s[13],y=s[14],E=s[15];if(r[0].setComponents(l-o,f-u,p-g,E-S).normalize(),r[1].setComponents(l+o,f+u,p+g,E+S).normalize(),r[2].setComponents(l+a,f+d,p+b,E+T).normalize(),r[3].setComponents(l-a,f-d,p-b,E-T).normalize(),i)r[4].setComponents(c,h,m,y).normalize(),r[5].setComponents(l-c,f-h,p-m,E-y).normalize();else if(r[4].setComponents(l-c,f-h,p-m,E-y).normalize(),t===Pn)r[5].setComponents(l+c,f+h,p+m,E+y).normalize();else if(t===kr)r[5].setComponents(c,h,m,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Xi.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Xi.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Xi)}intersectsSprite(e){Xi.center.set(0,0,0);let t=im.distanceTo(e.center);return Xi.radius=.7071067811865476+t,Xi.applyMatrix4(e.matrixWorld),this.intersectsSphere(Xi)}intersectsSphere(e){let t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let i=0;i<6;i++){let r=t[i];if(Zo.x=r.normal.x>0?e.max.x:e.min.x,Zo.y=r.normal.y>0?e.max.y:e.min.y,Zo.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Zo)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};var vi=class extends bn{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new He(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},xa=new O,ba=new O,Ou=new vt,xs=new oi,Jo=new qi,Rc=new O,Bu=new O,Yi=class extends kt{constructor(e=new wt,t=new vi){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[0];for(let r=1,s=t.count;r<s;r++)xa.fromBufferAttribute(t,r-1),ba.fromBufferAttribute(t,r),i[r]=i[r-1],i[r]+=xa.distanceTo(ba);e.setAttribute("lineDistance",new _t(i,1))}else qe("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let i=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,o=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Jo.copy(i.boundingSphere),Jo.applyMatrix4(r),Jo.radius+=s,e.ray.intersectsSphere(Jo)===!1)return;Ou.copy(r).invert(),xs.copy(e.ray).applyMatrix4(Ou);let a=s/((this.scale.x+this.scale.y+this.scale.z)/3),c=a*a,l=this.isLineSegments?2:1,u=i.index,h=i.attributes.position;if(u!==null){let f=Math.max(0,o.start),g=Math.min(u.count,o.start+o.count);for(let b=f,m=g-1;b<m;b+=l){let p=u.getX(b),S=u.getX(b+1),T=Ko(this,e,xs,c,p,S,b);T&&t.push(T)}if(this.isLineLoop){let b=u.getX(g-1),m=u.getX(f),p=Ko(this,e,xs,c,b,m,g-1);p&&t.push(p)}}else{let f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let b=f,m=g-1;b<m;b+=l){let p=Ko(this,e,xs,c,b,b+1,b);p&&t.push(p)}if(this.isLineLoop){let b=Ko(this,e,xs,c,g-1,f,g-1);b&&t.push(b)}}}updateMorphTargets(){let t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){let r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){let a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}};function Ko(n,e,t,i,r,s,o){let a=n.geometry.attributes.position;if(xa.fromBufferAttribute(a,r),ba.fromBufferAttribute(a,s),t.distanceSqToSegment(xa,ba,Rc,Bu)>i)return;Rc.applyMatrix4(n.matrixWorld);let l=e.ray.origin.distanceTo(Rc);if(!(l<e.near||l>e.far))return{distance:l,point:Bu.clone().applyMatrix4(n.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:n}}var ku=new O,zu=new O,Ma=class extends Yi{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[];for(let r=0,s=t.count;r<s;r+=2)ku.fromBufferAttribute(t,r),zu.fromBufferAttribute(t,r+1),i[r]=r===0?0:i[r-1],i[r+1]=i[r]+ku.distanceTo(zu);e.setAttribute("lineDistance",new _t(i,1))}else qe("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}},Os=class extends Yi{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}};var Bs=class extends tn{constructor(e=[],t=Pi,i,r,s,o,a,c,l,u){super(e,t,i,r,s,o,a,c,l,u),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Zi=class extends tn{constructor(e,t,i,r,s,o,a,c,l){super(e,t,i,r,s,o,a,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}};var xi=class extends tn{constructor(e,t,i=Nn,r,s,o,a=Dt,c=Dt,l,u=Xn,d=1){if(u!==Xn&&u!==Di)throw new Error("THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat");let h={width:e,height:t,depth:d};super(h,r,s,o,a,c,u,i,l),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Hr(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},Sa=class extends xi{constructor(e,t=Nn,i=Pi,r,s,o=Dt,a=Dt,c,l=Xn){let u={width:e,height:e,depth:1},d=[u,u,u,u,u,u];super(e,e,t,i,r,s,o,a,c,l),this.image=d,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},ks=class extends tn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},bi=class n extends wt{constructor(e=1,t=1,i=1,r=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:o};let a=this;r=Math.floor(r),s=Math.floor(s),o=Math.floor(o);let c=[],l=[],u=[],d=[],h=0,f=0;g("z","y","x",-1,-1,i,t,e,o,s,0),g("z","y","x",1,-1,i,t,-e,o,s,1),g("x","z","y",1,1,e,i,t,r,o,2),g("x","z","y",1,-1,e,i,-t,r,o,3),g("x","y","z",1,-1,e,t,i,r,s,4),g("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(c),this.setAttribute("position",new _t(l,3)),this.setAttribute("normal",new _t(u,3)),this.setAttribute("uv",new _t(d,2));function g(b,m,p,S,T,y,E,A,U,v,C){let z=y/U,X=E/v,W=y/2,re=E/2,G=A/2,se=U+1,_e=v+1,ee=0,Y=0,he=new O;for(let de=0;de<_e;de++){let ye=de*X-re;for(let Oe=0;Oe<se;Oe++){let Ne=Oe*z-W;he[b]=Ne*S,he[m]=ye*T,he[p]=G,l.push(he.x,he.y,he.z),he[b]=0,he[m]=0,he[p]=A>0?1:-1,u.push(he.x,he.y,he.z),d.push(Oe/U),d.push(1-de/v),ee+=1}}for(let de=0;de<v;de++)for(let ye=0;ye<U;ye++){let Oe=h+ye+se*de,Ne=h+ye+se*(de+1),Ke=h+(ye+1)+se*(de+1),Ze=h+(ye+1)+se*de;c.push(Oe,Ne,Ze),c.push(Ne,Ke,Ze),Y+=6}a.addGroup(f,Y,C),f+=Y,h+=ee}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new n(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};var Qo=new O,ea=new O,Pc=new O,ta=new Gn,zs=class extends wt{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let r=Math.pow(10,4),s=Math.cos(Nr*t),o=e.getIndex(),a=e.getAttribute("position"),c=o?o.count:a.count,l=[0,0,0],u=["a","b","c"],d=new Array(3),h={},f=[];for(let g=0;g<c;g+=3){o?(l[0]=o.getX(g),l[1]=o.getX(g+1),l[2]=o.getX(g+2)):(l[0]=g,l[1]=g+1,l[2]=g+2);let{a:b,b:m,c:p}=ta;if(b.fromBufferAttribute(a,l[0]),m.fromBufferAttribute(a,l[1]),p.fromBufferAttribute(a,l[2]),ta.getNormal(Pc),d[0]=`${Math.round(b.x*r)},${Math.round(b.y*r)},${Math.round(b.z*r)}`,d[1]=`${Math.round(m.x*r)},${Math.round(m.y*r)},${Math.round(m.z*r)}`,d[2]=`${Math.round(p.x*r)},${Math.round(p.y*r)},${Math.round(p.z*r)}`,!(d[0]===d[1]||d[1]===d[2]||d[2]===d[0]))for(let S=0;S<3;S++){let T=(S+1)%3,y=d[S],E=d[T],A=ta[u[S]],U=ta[u[T]],v=`${y}_${E}`,C=`${E}_${y}`;C in h&&h[C]?(Pc.dot(h[C].normal)<=s&&(f.push(A.x,A.y,A.z),f.push(U.x,U.y,U.z)),h[C]=null):v in h||(h[v]={index0:l[S],index1:l[T],normal:Pc.clone()})}}for(let g in h)if(h[g]){let{index0:b,index1:m}=h[g];Qo.fromBufferAttribute(a,b),ea.fromBufferAttribute(a,m),f.push(Qo.x,Qo.y,Qo.z),f.push(ea.x,ea.y,ea.z)}this.setAttribute("position",new _t(f,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},mn=class{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){qe("Curve: .getPoint() not implemented.")}getPointAt(e,t){let i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],i,r=this.getPoint(0),s=0;t.push(0);for(let o=1;o<=e;o++)i=this.getPoint(o/e),s+=i.distanceTo(r),t.push(s),r=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){let i=this.getLengths(),r=0,s=i.length,o;t?o=t:o=e*i[s-1];let a=0,c=s-1,l;for(;a<=c;)if(r=Math.floor(a+(c-a)/2),l=i[r]-o,l<0)a=r+1;else if(l>0)c=r-1;else{c=r;break}if(r=c,i[r]===o)return r/(s-1);let u=i[r],h=i[r+1]-u,f=(o-u)/h;return(r+f)/(s-1)}getTangent(e,t){let r=e-1e-4,s=e+1e-4;r<0&&(r=0),s>1&&(s=1);let o=this.getPoint(r),a=this.getPoint(s),c=t||(o.isVector2?new be:new O);return c.copy(a).sub(o).normalize(),c}getTangentAt(e,t){let i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t=!1){let i=new O,r=[],s=[],o=[],a=new O,c=new vt;for(let f=0;f<=e;f++){let g=f/e;r[f]=this.getTangentAt(g,new O)}s[0]=new O,o[0]=new O;let l=Number.MAX_VALUE,u=Math.abs(r[0].x),d=Math.abs(r[0].y),h=Math.abs(r[0].z);u<=l&&(l=u,i.set(1,0,0)),d<=l&&(l=d,i.set(0,1,0)),h<=l&&i.set(0,0,1),a.crossVectors(r[0],i).normalize(),s[0].crossVectors(r[0],a),o[0].crossVectors(r[0],s[0]);for(let f=1;f<=e;f++){if(s[f]=s[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(r[f-1],r[f]),a.length()>Number.EPSILON){a.normalize();let g=Math.acos(et(r[f-1].dot(r[f]),-1,1));s[f].applyMatrix4(c.makeRotationAxis(a,g))}o[f].crossVectors(r[f],s[f])}if(t===!0){let f=Math.acos(et(s[0].dot(s[e]),-1,1));f/=e,r[0].dot(a.crossVectors(s[0],s[e]))>0&&(f=-f);for(let g=1;g<=e;g++)s[g].applyMatrix4(c.makeRotationAxis(r[g],f*g)),o[g].crossVectors(r[g],s[g])}return{tangents:r,normals:s,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},jr=class extends mn{constructor(e=0,t=0,i=1,r=1,s=0,o=Math.PI*2,a=!1,c=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=r,this.aStartAngle=s,this.aEndAngle=o,this.aClockwise=a,this.aRotation=c}getPoint(e,t=new be){let i=t,r=Math.PI*2,s=this.aEndAngle-this.aStartAngle,o=Math.abs(s)<Number.EPSILON;for(;s<0;)s+=r;for(;s>r;)s-=r;s<Number.EPSILON&&(o?s=0:s=r),this.aClockwise===!0&&!o&&(s===r?s=-r:s=s-r);let a=this.aStartAngle+e*s,c=this.aX+this.xRadius*Math.cos(a),l=this.aY+this.yRadius*Math.sin(a);if(this.aRotation!==0){let u=Math.cos(this.aRotation),d=Math.sin(this.aRotation),h=c-this.aX,f=l-this.aY;c=h*u-f*d+this.aX,l=h*d+f*u+this.aY}return i.set(c,l)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},wa=class extends jr{constructor(e,t,i,r,s,o){super(e,t,i,i,r,s,o),this.isArcCurve=!0,this.type="ArcCurve"}};function yh(){let n=0,e=0,t=0,i=0;function r(s,o,a,c){n=s,e=a,t=-3*s+3*o-2*a-c,i=2*s-2*o+a+c}return{initCatmullRom:function(s,o,a,c,l){r(o,a,l*(a-s),l*(c-o))},initNonuniformCatmullRom:function(s,o,a,c,l,u,d){let h=(o-s)/l-(a-s)/(l+u)+(a-o)/u,f=(a-o)/u-(c-o)/(u+d)+(c-a)/d;h*=u,f*=u,r(o,a,h,f)},calc:function(s){let o=s*s,a=o*s;return n+e*s+t*o+i*a}}}var Vu=new O,Hu=new O,Ic=new yh,Dc=new yh,Lc=new yh,Ta=class extends mn{constructor(e=[],t=!1,i="centripetal",r=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=r}getPoint(e,t=new O){let i=t,r=this.points,s=r.length,o=(s-(this.closed?0:1))*e,a=Math.floor(o),c=o-a;this.closed?a+=a>0?0:(Math.floor(Math.abs(a)/s)+1)*s:c===0&&a===s-1&&(a=s-2,c=1);let l,u;this.closed||a>0?l=r[(a-1)%s]:(Hu.subVectors(r[0],r[1]).add(r[0]),l=Hu);let d=r[a%s],h=r[(a+1)%s];if(this.closed||a+2<s?u=r[(a+2)%s]:(Vu.subVectors(r[s-1],r[s-2]).add(r[s-1]),u=Vu),this.curveType==="centripetal"||this.curveType==="chordal"){let f=this.curveType==="chordal"?.5:.25,g=Math.pow(l.distanceToSquared(d),f),b=Math.pow(d.distanceToSquared(h),f),m=Math.pow(h.distanceToSquared(u),f);b<1e-4&&(b=1),g<1e-4&&(g=b),m<1e-4&&(m=b),Ic.initNonuniformCatmullRom(l.x,d.x,h.x,u.x,g,b,m),Dc.initNonuniformCatmullRom(l.y,d.y,h.y,u.y,g,b,m),Lc.initNonuniformCatmullRom(l.z,d.z,h.z,u.z,g,b,m)}else this.curveType==="catmullrom"&&(Ic.initCatmullRom(l.x,d.x,h.x,u.x,this.tension),Dc.initCatmullRom(l.y,d.y,h.y,u.y,this.tension),Lc.initCatmullRom(l.z,d.z,h.z,u.z,this.tension));return i.set(Ic.calc(c),Dc.calc(c),Lc.calc(c)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let r=e.points[t];this.points.push(r.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let r=this.points[t];e.points.push(r.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let r=e.points[t];this.points.push(new O().fromArray(r))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function Gu(n,e,t,i,r){let s=(i-e)*.5,o=(r-t)*.5,a=n*n,c=n*a;return(2*t-2*i+s+o)*c+(-3*t+3*i-2*s-o)*a+s*n+t}function rm(n,e){let t=1-n;return t*t*e}function sm(n,e){return 2*(1-n)*n*e}function om(n,e){return n*n*e}function Ss(n,e,t,i){return rm(n,e)+sm(n,t)+om(n,i)}function am(n,e){let t=1-n;return t*t*t*e}function lm(n,e){let t=1-n;return 3*t*t*n*e}function cm(n,e){return 3*(1-n)*n*n*e}function hm(n,e){return n*n*n*e}function ws(n,e,t,i,r){return am(n,e)+lm(n,t)+cm(n,i)+hm(n,r)}var Vs=class extends mn{constructor(e=new be,t=new be,i=new be,r=new be){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=r}getPoint(e,t=new be){let i=t,r=this.v0,s=this.v1,o=this.v2,a=this.v3;return i.set(ws(e,r.x,s.x,o.x,a.x),ws(e,r.y,s.y,o.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Ea=class extends mn{constructor(e=new O,t=new O,i=new O,r=new O){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=r}getPoint(e,t=new O){let i=t,r=this.v0,s=this.v1,o=this.v2,a=this.v3;return i.set(ws(e,r.x,s.x,o.x,a.x),ws(e,r.y,s.y,o.y,a.y),ws(e,r.z,s.z,o.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Hs=class extends mn{constructor(e=new be,t=new be){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new be){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new be){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Aa=class extends mn{constructor(e=new O,t=new O){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new O){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new O){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Gs=class extends mn{constructor(e=new be,t=new be,i=new be){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new be){let i=t,r=this.v0,s=this.v1,o=this.v2;return i.set(Ss(e,r.x,s.x,o.x),Ss(e,r.y,s.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ca=class extends mn{constructor(e=new O,t=new O,i=new O){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new O){let i=t,r=this.v0,s=this.v1,o=this.v2;return i.set(Ss(e,r.x,s.x,o.x),Ss(e,r.y,s.y,o.y),Ss(e,r.z,s.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ws=class extends mn{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new be){let i=t,r=this.points,s=(r.length-1)*e,o=Math.floor(s),a=s-o,c=r[o===0?o:o-1],l=r[o],u=r[o>r.length-2?r.length-1:o+1],d=r[o>r.length-3?r.length-1:o+2];return i.set(Gu(a,c.x,l.x,u.x,d.x),Gu(a,c.y,l.y,u.y,d.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let r=e.points[t];this.points.push(r.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let r=this.points[t];e.points.push(r.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let r=e.points[t];this.points.push(new be().fromArray(r))}return this}},Wu=Object.freeze({__proto__:null,ArcCurve:wa,CatmullRomCurve3:Ta,CubicBezierCurve:Vs,CubicBezierCurve3:Ea,EllipseCurve:jr,LineCurve:Hs,LineCurve3:Aa,QuadraticBezierCurve:Gs,QuadraticBezierCurve3:Ca,SplineCurve:Ws}),Ra=class extends mn{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Wu[i](t,e))}return this}getPoint(e,t){let i=e*this.getLength(),r=this.getCurveLengths(),s=0;for(;s<r.length;){if(r[s]>=i){let o=r[s]-i,a=this.curves[s],c=a.getLength(),l=c===0?0:1-o/c;return a.getPointAt(l,t)}s++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let i=0,r=this.curves.length;i<r;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],i;for(let r=0,s=this.curves;r<s.length;r++){let o=s[r],a=o.isEllipseCurve?e*2:o.isLineCurve||o.isLineCurve3?1:o.isSplineCurve?e*o.points.length:e,c=o.getPoints(a);for(let l=0;l<c.length;l++){let u=c[l];i&&i.equals(u)||(t.push(u),i=u)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let r=e.curves[t];this.curves.push(r.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){let r=this.curves[t];e.curves.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let r=e.curves[t];this.curves.push(new Wu[r.type]().fromJSON(r))}return this}},qn=class extends Ra{constructor(e){super(),this.type="Path",this.currentPoint=new be,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let i=new Hs(this.currentPoint.clone(),new be(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,r){let s=new Gs(this.currentPoint.clone(),new be(e,t),new be(i,r));return this.curves.push(s),this.currentPoint.set(i,r),this}bezierCurveTo(e,t,i,r,s,o){let a=new Vs(this.currentPoint.clone(),new be(e,t),new be(i,r),new be(s,o));return this.curves.push(a),this.currentPoint.set(s,o),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),i=new Ws(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,r,s,o){let a=this.currentPoint.x,c=this.currentPoint.y;return this.absarc(e+a,t+c,i,r,s,o),this}absarc(e,t,i,r,s,o){return this.absellipse(e,t,i,i,r,s,o),this}ellipse(e,t,i,r,s,o,a,c){let l=this.currentPoint.x,u=this.currentPoint.y;return this.absellipse(e+l,t+u,i,r,s,o,a,c),this}absellipse(e,t,i,r,s,o,a,c){let l=new jr(e,t,i,r,s,o,a,c);if(this.curves.length>0){let d=l.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(l);let u=l.getPoint(1);return this.currentPoint.copy(u),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},Pa=class extends qn{constructor(e){super(e),this.uuid=Wn(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let i=0,r=this.holes.length;i<r;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let r=e.holes[t];this.holes.push(r.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){let r=this.holes[t];e.holes.push(r.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let r=e.holes[t];this.holes.push(new qn().fromJSON(r))}return this}};function um(n,e,t=2){let i=e&&e.length,r=i?e[0]*t:n.length,s=Vd(n,0,r,t,!0),o=[];if(!s||s.next===s.prev)return o;let a,c,l;if(i&&(s=gm(n,e,s,t)),n.length>80*t){a=n[0],c=n[1];let u=a,d=c;for(let h=t;h<r;h+=t){let f=n[h],g=n[h+1];f<a&&(a=f),g<c&&(c=g),f>u&&(u=f),g>d&&(d=g)}l=Math.max(u-a,d-c),l=l!==0?32767/l:0}return Xs(s,o,t,a,c,l,0),o}function Vd(n,e,t,i,r){let s;if(r===Am(n,e,t,i)>0)for(let o=e;o<t;o+=i)s=Xu(o/i|0,n[o],n[o+1],s);else for(let o=t-i;o>=e;o-=i)s=Xu(o/i|0,n[o],n[o+1],s);return s&&qr(s,s.next)&&(qs(s),s=s.next),s}function Ji(n,e){if(!n)return n;e||(e=n);let t=n,i;do if(i=!1,!t.steiner&&(qr(t,t.next)||Tt(t.prev,t,t.next)===0)){if(qs(t),t=e=t.prev,t===t.next)break;i=!0}else t=t.next;while(i||t!==e);return e}function Xs(n,e,t,i,r,s,o){if(!n)return;!o&&s&&bm(n,i,r,s);let a=n;for(;n.prev!==n.next;){let c=n.prev,l=n.next;if(s?fm(n,i,r,s):dm(n)){e.push(c.i,n.i,l.i),qs(n),n=l.next,a=l.next;continue}if(n=l,n===a){o?o===1?(n=pm(Ji(n),e),Xs(n,e,t,i,r,s,2)):o===2&&mm(n,e,t,i,r,s):Xs(Ji(n),e,t,i,r,s,1);break}}}function dm(n){let e=n.prev,t=n,i=n.next;if(Tt(e,t,i)>=0)return!1;let r=e.x,s=t.x,o=i.x,a=e.y,c=t.y,l=i.y,u=Math.min(r,s,o),d=Math.min(a,c,l),h=Math.max(r,s,o),f=Math.max(a,c,l),g=i.next;for(;g!==e;){if(g.x>=u&&g.x<=h&&g.y>=d&&g.y<=f&&bs(r,a,s,c,o,l,g.x,g.y)&&Tt(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function fm(n,e,t,i){let r=n.prev,s=n,o=n.next;if(Tt(r,s,o)>=0)return!1;let a=r.x,c=s.x,l=o.x,u=r.y,d=s.y,h=o.y,f=Math.min(a,c,l),g=Math.min(u,d,h),b=Math.max(a,c,l),m=Math.max(u,d,h),p=zc(f,g,e,t,i),S=zc(b,m,e,t,i),T=n.prevZ,y=n.nextZ;for(;T&&T.z>=p&&y&&y.z<=S;){if(T.x>=f&&T.x<=b&&T.y>=g&&T.y<=m&&T!==r&&T!==o&&bs(a,u,c,d,l,h,T.x,T.y)&&Tt(T.prev,T,T.next)>=0||(T=T.prevZ,y.x>=f&&y.x<=b&&y.y>=g&&y.y<=m&&y!==r&&y!==o&&bs(a,u,c,d,l,h,y.x,y.y)&&Tt(y.prev,y,y.next)>=0))return!1;y=y.nextZ}for(;T&&T.z>=p;){if(T.x>=f&&T.x<=b&&T.y>=g&&T.y<=m&&T!==r&&T!==o&&bs(a,u,c,d,l,h,T.x,T.y)&&Tt(T.prev,T,T.next)>=0)return!1;T=T.prevZ}for(;y&&y.z<=S;){if(y.x>=f&&y.x<=b&&y.y>=g&&y.y<=m&&y!==r&&y!==o&&bs(a,u,c,d,l,h,y.x,y.y)&&Tt(y.prev,y,y.next)>=0)return!1;y=y.nextZ}return!0}function pm(n,e){let t=n;do{let i=t.prev,r=t.next.next;!qr(i,r)&&Gd(i,t,t.next,r)&&js(i,r)&&js(r,i)&&(e.push(i.i,t.i,r.i),qs(t),qs(t.next),t=n=r),t=t.next}while(t!==n);return Ji(t)}function mm(n,e,t,i,r,s){let o=n;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&wm(o,a)){let c=Wd(o,a);o=Ji(o,o.next),c=Ji(c,c.next),Xs(o,e,t,i,r,s,0),Xs(c,e,t,i,r,s,0);return}a=a.next}o=o.next}while(o!==n)}function gm(n,e,t,i){let r=[];for(let s=0,o=e.length;s<o;s++){let a=e[s]*i,c=s<o-1?e[s+1]*i:n.length,l=Vd(n,a,c,i,!1);l===l.next&&(l.steiner=!0),r.push(Sm(l))}r.sort(_m);for(let s=0;s<r.length;s++)t=ym(r[s],t);return t}function _m(n,e){let t=n.x-e.x;if(t===0&&(t=n.y-e.y,t===0)){let i=(n.next.y-n.y)/(n.next.x-n.x),r=(e.next.y-e.y)/(e.next.x-e.x);t=i-r}return t}function ym(n,e){let t=vm(n,e);if(!t)return e;let i=Wd(t,n);return Ji(i,i.next),Ji(t,t.next)}function vm(n,e){let t=e,i=n.x,r=n.y,s=-1/0,o;if(qr(n,t))return t;do{if(qr(n,t.next))return t.next;if(r<=t.y&&r>=t.next.y&&t.next.y!==t.y){let d=t.x+(r-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=i&&d>s&&(s=d,o=t.x<t.next.x?t:t.next,d===i))return o}t=t.next}while(t!==e);if(!o)return null;let a=o,c=o.x,l=o.y,u=1/0;t=o;do{if(i>=t.x&&t.x>=c&&i!==t.x&&Hd(r<l?i:s,r,c,l,r<l?s:i,r,t.x,t.y)){let d=Math.abs(r-t.y)/(i-t.x);js(t,n)&&(d<u||d===u&&(t.x>o.x||t.x===o.x&&xm(o,t)))&&(o=t,u=d)}t=t.next}while(t!==a);return o}function xm(n,e){return Tt(n.prev,n,e.prev)<0&&Tt(e.next,n,n.next)<0}function bm(n,e,t,i){let r=n;do r.z===0&&(r.z=zc(r.x,r.y,e,t,i)),r.prevZ=r.prev,r.nextZ=r.next,r=r.next;while(r!==n);r.prevZ.nextZ=null,r.prevZ=null,Mm(r)}function Mm(n){let e,t=1;do{let i=n,r;n=null;let s=null;for(e=0;i;){e++;let o=i,a=0;for(let l=0;l<t&&(a++,o=o.nextZ,!!o);l++);let c=t;for(;a>0||c>0&&o;)a!==0&&(c===0||!o||i.z<=o.z)?(r=i,i=i.nextZ,a--):(r=o,o=o.nextZ,c--),s?s.nextZ=r:n=r,r.prevZ=s,s=r;i=o}s.nextZ=null,t*=2}while(e>1);return n}function zc(n,e,t,i,r){return n=(n-t)*r|0,e=(e-i)*r|0,n=(n|n<<8)&16711935,n=(n|n<<4)&252645135,n=(n|n<<2)&858993459,n=(n|n<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,n|e<<1}function Sm(n){let e=n,t=n;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==n);return t}function Hd(n,e,t,i,r,s,o,a){return(r-o)*(e-a)>=(n-o)*(s-a)&&(n-o)*(i-a)>=(t-o)*(e-a)&&(t-o)*(s-a)>=(r-o)*(i-a)}function bs(n,e,t,i,r,s,o,a){return!(n===o&&e===a)&&Hd(n,e,t,i,r,s,o,a)}function wm(n,e){return n.next.i!==e.i&&n.prev.i!==e.i&&!Tm(n,e)&&(js(n,e)&&js(e,n)&&Em(n,e)&&(Tt(n.prev,n,e.prev)||Tt(n,e.prev,e))||qr(n,e)&&Tt(n.prev,n,n.next)>0&&Tt(e.prev,e,e.next)>0)}function Tt(n,e,t){return(e.y-n.y)*(t.x-e.x)-(e.x-n.x)*(t.y-e.y)}function qr(n,e){return n.x===e.x&&n.y===e.y}function Gd(n,e,t,i){let r=ia(Tt(n,e,t)),s=ia(Tt(n,e,i)),o=ia(Tt(t,i,n)),a=ia(Tt(t,i,e));return!!(r!==s&&o!==a||r===0&&na(n,t,e)||s===0&&na(n,i,e)||o===0&&na(t,n,i)||a===0&&na(t,e,i))}function na(n,e,t){return e.x<=Math.max(n.x,t.x)&&e.x>=Math.min(n.x,t.x)&&e.y<=Math.max(n.y,t.y)&&e.y>=Math.min(n.y,t.y)}function ia(n){return n>0?1:n<0?-1:0}function Tm(n,e){let t=n;do{if(t.i!==n.i&&t.next.i!==n.i&&t.i!==e.i&&t.next.i!==e.i&&Gd(t,t.next,n,e))return!0;t=t.next}while(t!==n);return!1}function js(n,e){return Tt(n.prev,n,n.next)<0?Tt(n,e,n.next)>=0&&Tt(n,n.prev,e)>=0:Tt(n,e,n.prev)<0||Tt(n,n.next,e)<0}function Em(n,e){let t=n,i=!1,r=(n.x+e.x)/2,s=(n.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&r<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(i=!i),t=t.next;while(t!==n);return i}function Wd(n,e){let t=Vc(n.i,n.x,n.y),i=Vc(e.i,e.x,e.y),r=n.next,s=e.prev;return n.next=e,e.prev=n,t.next=r,r.prev=t,i.next=t,t.prev=i,s.next=i,i.prev=s,i}function Xu(n,e,t,i){let r=Vc(n,e,t);return i?(r.next=i.next,r.prev=i,i.next.prev=r,i.next=r):(r.prev=r,r.next=r),r}function qs(n){n.next.prev=n.prev,n.prev.next=n.next,n.prevZ&&(n.prevZ.nextZ=n.nextZ),n.nextZ&&(n.nextZ.prevZ=n.prevZ)}function Vc(n,e,t){return{i:n,x:e,y:t,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}}function Am(n,e,t,i){let r=0;for(let s=e,o=t-i;s<t;s+=i)r+=(n[o]-n[s])*(n[s+1]+n[o+1]),o=s;return r}var Hc=class{static triangulate(e,t,i=2){return um(e,t,i)}},$r=class n{static area(e){let t=e.length,i=0;for(let r=t-1,s=0;s<t;r=s++)i+=e[r].x*e[s].y-e[s].x*e[r].y;return i*.5}static isClockWise(e){return n.area(e)<0}static triangulateShape(e,t){let i=[],r=[],s=[];ju(e),qu(i,e);let o=e.length;t.forEach(ju);for(let c=0;c<t.length;c++)r.push(o),o+=t[c].length,qu(i,t[c]);let a=Hc.triangulate(i,r);for(let c=0;c<a.length;c+=3)s.push(a.slice(c,c+3));return s}};function ju(n){let e=n.length;e>2&&n[e-1].equals(n[0])&&n.pop()}function qu(n,e){for(let t=0;t<e.length;t++)n.push(e[t].x),n.push(e[t].y)}var Ki=class n extends wt{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};let s=e/2,o=t/2,a=Math.floor(i),c=Math.floor(r),l=a+1,u=c+1,d=e/a,h=t/c,f=[],g=[],b=[],m=[];for(let p=0;p<u;p++){let S=p*h-o;for(let T=0;T<l;T++){let y=T*d-s;g.push(y,-S,0),b.push(0,0,1),m.push(T/a),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let S=0;S<a;S++){let T=S+l*p,y=S+l*(p+1),E=S+1+l*(p+1),A=S+1+l*p;f.push(T,y,A),f.push(y,E,A)}this.setIndex(f),this.setAttribute("position",new _t(g,3)),this.setAttribute("normal",new _t(b,3)),this.setAttribute("uv",new _t(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new n(e.width,e.height,e.widthSegments,e.heightSegments)}};var $s=class extends bn{constructor(e){super(),this.isShadowMaterial=!0,this.type="ShadowMaterial",this.color=new He(0),this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.fog=e.fog,this}};function sr(n){let e={};for(let t in n){e[t]={};for(let i in n[t]){let r=n[t][i];if($u(r))r.isRenderTargetTexture?(qe("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone();else if(Array.isArray(r))if($u(r[0])){let s=[];for(let o=0,a=r.length;o<a;o++)s[o]=r[o].clone();e[t][i]=s}else e[t][i]=r.slice();else e[t][i]=r}}return e}function Yt(n){let e={};for(let t=0;t<n.length;t++){let i=sr(n[t]);for(let r in i)e[r]=i[r]}return e}function $u(n){return n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)}function Cm(n){let e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function vh(n){let e=n.getRenderTarget();return e===null?n.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:rt.workingColorSpace}var Xd={clone:sr,merge:Yt},Rm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Pm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Ht=class extends bn{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Rm,this.fragmentShader=Pm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=sr(e.uniforms),this.uniformsGroups=Cm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let r in this.uniforms){let o=this.uniforms[r].value;o&&o.isTexture?t.uniforms[r]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[r]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[r]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[r]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[r]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[r]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[r]={type:"m4",value:o.toArray()}:t.uniforms[r]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let i={};for(let r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let i in e.uniforms){let r=e.uniforms[i];switch(this.uniforms[i]={},r.type){case"t":this.uniforms[i].value=t[r.value]||null;break;case"c":this.uniforms[i].value=new He().setHex(r.value);break;case"v2":this.uniforms[i].value=new be().fromArray(r.value);break;case"v3":this.uniforms[i].value=new O().fromArray(r.value);break;case"v4":this.uniforms[i].value=new St().fromArray(r.value);break;case"m3":this.uniforms[i].value=new je().fromArray(r.value);break;case"m4":this.uniforms[i].value=new vt().fromArray(r.value);break;default:this.uniforms[i].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let i in e.extensions)this.extensions[i]=e.extensions[i];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Ia=class extends Ht{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}},Qi=class extends bn{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new He(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new He(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ho,this.normalScale=new be(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new si,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};var er=class extends bn{constructor(e){super(),this.isMeshToonMaterial=!0,this.defines={TOON:""},this.type="MeshToonMaterial",this.color=new He(16777215),this.map=null,this.gradientMap=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new He(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=ho,this.normalScale=new be(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.gradientMap=e.gradientMap,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.alphaMap=e.alphaMap,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}};var Da=class extends bn{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Ed,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},La=class extends bn{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Ir(n,e){return!n||n.constructor===e?n:typeof e.BYTES_PER_ELEMENT=="number"?new e(n):Array.prototype.slice.call(n)}function Nc(n){return n!==void 0&&n.inTangents!==void 0&&n.outTangents!==void 0}var Mi=class{constructor(e,t,i,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r!==void 0?r:new t.constructor(i),this.sampleValues=t,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,i=this._cachedIndex,r=t[i],s=t[i-1];n:{e:{let o;t:{i:if(!(e<r)){for(let a=i+2;;){if(r===void 0){if(e<s)break i;return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===a)break;if(s=r,r=t[++i],e<r)break e}o=t.length;break t}if(!(e>=s)){let a=t[1];e<a&&(i=2,s=a);for(let c=i-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===c)break;if(r=s,s=t[--i-1],e>=s)break e}o=i,i=0;break t}break n}for(;i<o;){let a=i+o>>>1;e<t[a]?o=a:i=a+1}if(r=t[i],s=t[i-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,s,r)}return this.interpolate_(i,s,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,r=this.valueSize,s=e*r;for(let o=0;o!==r;++o)t[o]=i[s+o];return t}interpolate_(){throw new Error("THREE.Interpolant: Call to abstract method.")}intervalChanged_(){}},Na=class extends Mi{constructor(e,t,i,r){super(e,t,i,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Oc,endingEnd:Oc}}intervalChanged_(e,t,i){let r=this.parameterPositions,s=e-2,o=e+1,a=r[s],c=r[o];if(a===void 0)switch(this.getSettings_().endingStart){case Bc:s=e,a=2*t-i;break;case kc:s=r.length-2,a=t+r[s]-r[s+1];break;default:s=e,a=i}if(c===void 0)switch(this.getSettings_().endingEnd){case Bc:o=e,c=2*i-t;break;case kc:o=1,c=i+r[1]-r[0];break;default:o=e-1,c=t}let l=(i-t)*.5,u=this.valueSize;this._weightPrev=l/(t-a),this._weightNext=l/(c-i),this._offsetPrev=s*u,this._offsetNext=o*u}interpolate_(e,t,i,r){let s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=this._offsetPrev,d=this._offsetNext,h=this._weightPrev,f=this._weightNext,g=(i-t)/(r-t),b=g*g,m=b*g,p=-h*m+2*h*b-h*g,S=(1+h)*m+(-1.5-2*h)*b+(-.5+h)*g+1,T=(-1-f)*m+(1.5+f)*b+.5*g,y=f*m-f*b;for(let E=0;E!==a;++E)s[E]=p*o[u+E]+S*o[l+E]+T*o[c+E]+y*o[d+E];return s}},Ua=class extends Mi{constructor(e,t,i,r){super(e,t,i,r)}interpolate_(e,t,i,r){let s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=(i-t)/(r-t),d=1-u;for(let h=0;h!==a;++h)s[h]=o[l+h]*d+o[c+h]*u;return s}},Fa=class extends Mi{constructor(e,t,i,r){super(e,t,i,r)}interpolate_(e){return this.copySampleValue_(e-1)}},Oa=class extends Mi{interpolate_(e,t,i,r){let s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=e*a,l=c-a,u=this.inTangents,d=this.outTangents;if(!u||!d){let g=(i-t)/(r-t),b=1-g;for(let m=0;m!==a;++m)s[m]=o[l+m]*b+o[c+m]*g;return s}let h=a*2,f=e-1;for(let g=0;g!==a;++g){let b=o[l+g],m=o[c+g],p=f*h+g*2,S=d[p],T=d[p+1],y=e*h+g*2,E=u[y],A=u[y+1],U=Dm(i,t,S,E,r);s[g]=jd(U,b,T,A,m)}return s}};function jd(n,e,t,i,r){let s=1-n;return s*s*s*e+3*s*s*n*t+3*s*n*n*i+n*n*n*r}function Im(n,e,t,i,r){let s=1-n;return 3*s*s*(t-e)+6*s*n*(i-t)+3*n*n*(r-i)}function Dm(n,e,t,i,r){let s=(n-e)/(r-e);for(let o=0;o<8;o++){let a=jd(s,e,t,i,r)-n;if(Math.abs(a)<1e-10)break;let c=Im(s,e,t,i,r);if(Math.abs(c)<1e-10)break;s=Math.max(0,Math.min(1,s-a/c))}return s}var gn=class{constructor(e,t,i,r){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ir(t,this.TimeBufferType),this.values=Ir(i,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,i;if(t.toJSON!==this.toJSON)i=t.toJSON(e);else{i={name:e.name,times:Ir(e.times,Array),values:Ir(e.values,Array)};let r=e.getInterpolation();r!==e.DefaultInterpolation&&(i.interpolation=r),Nc(e.settings)&&(i.settings={inTangents:Ir(e.settings.inTangents,Array),outTangents:Ir(e.settings.outTangents,Array)})}return i.type=e.ValueTypeName,i}InterpolantFactoryMethodDiscrete(e){return new Fa(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Ua(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Na(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new Oa(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case Ts:t=this.InterpolantFactoryMethodDiscrete;break;case ma:t=this.InterpolantFactoryMethodLinear;break;case oa:t=this.InterpolantFactoryMethodSmooth;break;case Fc:t=this.InterpolantFactoryMethodBezier;break}if(t===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(i);return qe("KeyframeTrack:",i),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Ts;case this.InterpolantFactoryMethodLinear:return ma;case this.InterpolantFactoryMethodSmooth:return oa;case this.InterpolantFactoryMethodBezier:return Fc}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let i=0,r=t.length;i!==r;++i)t[i]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let i=0,r=t.length;i!==r;++i)t[i]*=e;Nc(this.settings)&&(Yu(this.settings.inTangents,e),Yu(this.settings.outTangents,e))}return this}trim(e,t){let i=this.times,r=i.length,s=0,o=r-1;for(;s!==r&&i[s]<e;)++s;for(;o!==-1&&i[o]>t;)--o;if(++o,s!==0||o!==r){s>=o&&(o=Math.max(o,1),s=o-1);let a=this.getValueSize();this.times=i.slice(s,o),this.values=this.values.slice(s*a,o*a)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(Ye("KeyframeTrack: Invalid value size in track.",this),e=!1);let i=this.times,r=this.values,s=i.length;s===0&&(Ye("KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==s;a++){let c=i[a];if(typeof c=="number"&&isNaN(c)){Ye("KeyframeTrack: Time is not a valid number.",this,a,c),e=!1;break}if(o!==null&&o>c){Ye("KeyframeTrack: Out of order keys.",this,a,c,o),e=!1;break}o=c}if(r!==void 0&&Sp(r))for(let a=0,c=r.length;a!==c;++a){let l=r[a];if(isNaN(l)){Ye("KeyframeTrack: Value is not a valid number.",this,a,l),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),i=this.getValueSize(),r=this.getInterpolation()===oa,s=e.length-1,o=1;for(let a=1;a<s;++a){let c=!1,l=e[a],u=e[a+1];if(l!==u&&(a!==1||l!==e[0]))if(r)c=!0;else{let d=a*i,h=d-i,f=d+i;for(let g=0;g!==i;++g){let b=t[d+g];if(b!==t[h+g]||b!==t[f+g]){c=!0;break}}}if(c){if(a!==o){e[o]=e[a];let d=a*i,h=o*i;for(let f=0;f!==i;++f)t[h+f]=t[d+f]}++o}}if(s>0){e[o]=e[s];for(let a=s*i,c=o*i,l=0;l!==i;++l)t[c+l]=t[a+l];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*i)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),i=this.constructor,r=new i(this.name,e,t);return r.createInterpolant=this.createInterpolant,Nc(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function Yu(n,e){for(let t=0,i=n.length;t!==i;t+=2)n[t]*=e}gn.prototype.ValueTypeName="";gn.prototype.TimeBufferType=Float32Array;gn.prototype.ValueBufferType=Float32Array;gn.prototype.DefaultInterpolation=ma;var Si=class extends gn{constructor(e,t,i){super(e,t,i)}};Si.prototype.ValueTypeName="bool";Si.prototype.ValueBufferType=Array;Si.prototype.DefaultInterpolation=Ts;Si.prototype.InterpolantFactoryMethodLinear=void 0;Si.prototype.InterpolantFactoryMethodSmooth=void 0;var Ba=class extends gn{constructor(e,t,i,r){super(e,t,i,r)}};Ba.prototype.ValueTypeName="color";var ka=class extends gn{constructor(e,t,i,r){super(e,t,i,r)}};ka.prototype.ValueTypeName="number";var za=class extends Mi{constructor(e,t,i,r){super(e,t,i,r)}interpolate_(e,t,i,r){let s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,c=(i-t)/(r-t),l=e*a;for(let u=l+a;l!==u;l+=4)pn.slerpFlat(s,0,o,l-a,o,l,c);return s}},Ys=class extends gn{constructor(e,t,i,r){super(e,t,i,r)}InterpolantFactoryMethodLinear(e){return new za(this.times,this.values,this.getValueSize(),e)}};Ys.prototype.ValueTypeName="quaternion";Ys.prototype.InterpolantFactoryMethodSmooth=void 0;var wi=class extends gn{constructor(e,t,i){super(e,t,i)}};wi.prototype.ValueTypeName="string";wi.prototype.ValueBufferType=Array;wi.prototype.DefaultInterpolation=Ts;wi.prototype.InterpolantFactoryMethodLinear=void 0;wi.prototype.InterpolantFactoryMethodSmooth=void 0;var Va=class extends gn{constructor(e,t,i,r){super(e,t,i,r)}};Va.prototype.ValueTypeName="vector";var Gc={enabled:!1,files:{},add:function(n,e){this.enabled!==!1&&(Zu(n)||(this.files[n]=e))},get:function(n){if(this.enabled!==!1&&!Zu(n))return this.files[n]},remove:function(n){delete this.files[n]},clear:function(){this.files={}}};function Zu(n){try{let e=n.slice(n.indexOf(":")+1);return new URL(e).protocol==="blob:"}catch{return!1}}var Ha=class{constructor(e,t,i){let r=this,s=!1,o=0,a=0,c,l=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this._abortController=null,this.itemStart=function(u){a++,s===!1&&r.onStart!==void 0&&r.onStart(u,o,a),s=!0},this.itemEnd=function(u){o++,r.onProgress!==void 0&&r.onProgress(u,o,a),o===a&&(s=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(u){r.onError!==void 0&&r.onError(u)},this.resolveURL=function(u){return u=u.normalize("NFC"),c?c(u):u},this.setURLModifier=function(u){return c=u,this},this.addHandler=function(u,d){return l.push(u,d),this},this.removeHandler=function(u){let d=l.indexOf(u);return d!==-1&&l.splice(d,2),this},this.getHandler=function(u){for(let d=0,h=l.length;d<h;d+=2){let f=l[d],g=l[d+1];if(f.global&&(f.lastIndex=0),f.test(u))return g}return null},this.abort=function(){return this.abortController.abort(),this._abortController=null,this}}get abortController(){return this._abortController||(this._abortController=new AbortController),this._abortController}},qd=new Ha,tr=class{constructor(e){this.manager=e!==void 0?e:qd,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}load(){}loadAsync(e,t){let i=this;return new Promise(function(r,s){i.load(e,r,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}abort(){return this}};tr.DEFAULT_MATERIAL_NAME="__DEFAULT";var ii={},Wc=class extends Error{constructor(e,t){super(e),this.response=t}},Zs=class extends tr{constructor(e){super(e),this.mimeType="",this.responseType="",this._abortController=new AbortController}load(e,t,i,r){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);let s=Gc.get(`file:${e}`);if(s!==void 0){this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0);return}if(ii[e]!==void 0){ii[e].push({onLoad:t,onProgress:i,onError:r});return}ii[e]=[],ii[e].push({onLoad:t,onProgress:i,onError:r});let o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:typeof AbortSignal.any=="function"?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),a=this.mimeType,c=this.responseType;fetch(o).then(l=>{if(l.status===200||l.status===0){if(l.status===0&&qe("FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||l.body===void 0||l.body.getReader===void 0)return l;let u=ii[e],d=l.body.getReader(),h=l.headers.get("X-File-Size")||l.headers.get("Content-Length"),f=h?parseInt(h):0,g=f!==0,b=0,m=new ReadableStream({start(p){S();function S(){d.read().then(({done:T,value:y})=>{if(T)p.close();else{b+=y.byteLength;let E=new ProgressEvent("progress",{lengthComputable:g,loaded:b,total:f});for(let A=0,U=u.length;A<U;A++){let v=u[A];v.onProgress&&v.onProgress(E)}p.enqueue(y),S()}},T=>{p.error(T)})}}});return new Response(m)}else throw new Wc(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`,l)}).then(l=>{switch(c){case"arraybuffer":return l.arrayBuffer();case"blob":return l.blob();case"document":return l.text().then(u=>new DOMParser().parseFromString(u,a));case"json":return l.json();default:if(a==="")return l.text();{let d=/charset="?([^;"\s]*)"?/i.exec(a),h=d&&d[1]?d[1].toLowerCase():void 0,f=new TextDecoder(h);return l.arrayBuffer().then(g=>f.decode(g))}}}).then(l=>{Gc.add(`file:${e}`,l);let u=ii[e];delete ii[e];for(let d=0,h=u.length;d<h;d++){let f=u[d];f.onLoad&&f.onLoad(l)}}).catch(l=>{let u=ii[e];if(u===void 0)throw this.manager.itemError(e),l;delete ii[e];for(let d=0,h=u.length;d<h;d++){let f=u[d];f.onError&&f.onError(l)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}abort(){return this._abortController.abort(),this._abortController=new AbortController,this}};var Js=class extends kt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new He(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},Ks=class extends Js{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(kt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new He(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}toJSON(e){let t=super.toJSON(e);return t.object.groundColor=this.groundColor.getHex(),t}},Uc=new vt,Ju=new O,Ku=new O,Ga=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new be(512,512),this.mapType=an,this.map=null,this.mapPass=null,this.matrix=new vt,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Xr,this._frameExtents=new be(1,1),this._viewportCount=1,this._viewports=[new St(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;Ju.setFromMatrixPosition(e.matrixWorld),t.position.copy(Ju),Ku.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ku),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,i,r){Uc.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),i.setFromProjectionMatrix(Uc,e.coordinateSystem,e.reversedDepth);let s=this._frameExtents,o=r?r.z/s.x:1,a=r?r.w/s.y:1,c=r?r.x/s.x:0,l=r?r.y/s.y:0;e.coordinateSystem===kr||e.reversedDepth?t.set(.5*o,0,0,.5*o+c,0,.5*a,0,.5*a+l,0,0,1,0,0,0,0,1):t.set(.5*o,0,0,.5*o+c,0,.5*a,0,.5*a+l,0,0,.5,.5,0,0,0,1),t.multiply(Uc)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},ra=new O,sa=new pn,Hn=new O,Qs=class extends kt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new vt,this.projectionMatrix=new vt,this.projectionMatrixInverse=new vt,this.coordinateSystem=Pn,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(ra,sa,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ra,sa,Hn.set(1,1,1)).invert()}updateWorldMatrix(e,t,i=!1){super.updateWorldMatrix(e,t,i),this.matrixWorld.decompose(ra,sa,Hn),Hn.x===1&&Hn.y===1&&Hn.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(ra,sa,Hn.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},yi=new O,Qu=new be,ed=new be,$t=class extends Qs{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=Vr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(Nr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Vr*2*Math.atan(Math.tan(Nr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){yi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(yi.x,yi.y).multiplyScalar(-e/yi.z),yi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(yi.x,yi.y).multiplyScalar(-e/yi.z)}getViewSize(e,t){return this.getViewBounds(e,Qu,ed),t.subVectors(ed,Qu)}setViewOffset(e,t,i,r,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(Nr*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r,o=this.view;if(this.view!==null&&this.view.enabled){let c=o.fullWidth,l=o.fullHeight;s+=o.offsetX*r/c,t-=o.offsetY*i/l,r*=o.width/c,i*=o.height/l}let a=this.filmOffset;a!==0&&(s+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}};var Ti=class extends Qs{constructor(e=-1,t=1,i=1,r=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2,s=i-e,o=i+e,a=r+t,c=r-t;if(this.view!==null&&this.view.enabled){let l=(this.right-this.left)/this.view.fullWidth/this.zoom,u=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,o=s+l*this.view.width,a-=u*this.view.offsetY,c=a-u*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,c,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Xc=class extends Ga{constructor(){super(new Ti(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Yr=class extends Js{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(kt.DEFAULT_UP),this.updateMatrix(),this.target=new kt,this.shadow=new Xc}dispose(){super.dispose(),this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.shadow=this.shadow.toJSON(),t.object.target=this.target.uuid,t}};var Dr=-90,Lr=1,Wa=class extends kt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new $t(Dr,Lr,e,t);r.layers=this.layers,this.add(r);let s=new $t(Dr,Lr,e,t);s.layers=this.layers,this.add(s);let o=new $t(Dr,Lr,e,t);o.layers=this.layers,this.add(o);let a=new $t(Dr,Lr,e,t);a.layers=this.layers,this.add(a);let c=new $t(Dr,Lr,e,t);c.layers=this.layers,this.add(c);let l=new $t(Dr,Lr,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[i,r,s,o,a,c]=t;for(let l of t)this.remove(l);if(e===Pn)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===kr)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(let l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[s,o,a,c,l,u]=this.children,d=e.getRenderTarget(),h=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;let b=i.texture.generateMipmaps;i.texture.generateMipmaps=!1;let m=!1;e.isWebGLRenderer===!0?m=e.state.buffers.depth.getReversed():m=e.reversedDepthBuffer,e.setRenderTarget(i,0,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(i,1,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(i,2,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(i,3,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),e.setRenderTarget(i,4,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),i.texture.generateMipmaps=b,e.setRenderTarget(i,5,r),m&&e.autoClear===!1&&e.clearDepth(),e.render(t,u),e.setRenderTarget(d,h,f),e.xr.enabled=g,i.texture.needsPMREMUpdate=!0}},Xa=class extends $t{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}};var xh="\\[\\]\\.:\\/",Lm=new RegExp("["+xh+"]","g"),bh="[^"+xh+"]",Nm="[^"+xh.replace("\\.","")+"]",Um=/((?:WC+[\/:])*)/.source.replace("WC",bh),Fm=/(WCOD+)?/.source.replace("WCOD",Nm),Om=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",bh),Bm=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",bh),km=new RegExp("^"+Um+Fm+Om+Bm+"$"),zm=["material","materials","bones","map"],jc=class{constructor(e,t,i){let r=i||Mt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let i=this._targetGroup.nCachedObjects_,r=this._bindings[i];r!==void 0&&r.getValue(e,t)}setValue(e,t){let i=this._bindings;for(let r=this._targetGroup.nCachedObjects_,s=i.length;r!==s;++r)i[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,i=e.length;t!==i;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,i=e.length;t!==i;++t)e[t].unbind()}},Mt=class n{constructor(e,t,i){this.path=t,this.parsedPath=i||n.parseTrackName(t),this.node=n.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,i){return e&&e.isAnimationObjectGroup?new n.Composite(e,t,i):new n(e,t,i)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(Lm,"")}static parseTrackName(e){let t=km.exec(e);if(t===null)throw new Error("THREE.PropertyBinding: Cannot parse trackName: "+e);let i={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=i.nodeName&&i.nodeName.lastIndexOf(".");if(r!==void 0&&r!==-1){let s=i.nodeName.substring(r+1);zm.indexOf(s)!==-1&&(i.nodeName=i.nodeName.substring(0,r),i.objectName=s)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("THREE.PropertyBinding: can not parse propertyName from trackName: "+e);return i}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let i=e.skeleton.getBoneByName(t);if(i!==void 0)return i}if(e.children){let i=function(s){for(let o=0;o<s.length;o++){let a=s[o];if(a.name===t||a.uuid===t)return a;let c=i(a.children);if(c)return c}return null},r=i(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let i=this.resolvedProperty;for(let r=0,s=i.length;r!==s;++r)e[t++]=i[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let i=this.resolvedProperty;for(let r=0,s=i.length;r!==s;++r)i[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let i=this.resolvedProperty;for(let r=0,s=i.length;r!==s;++r)i[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let i=this.resolvedProperty;for(let r=0,s=i.length;r!==s;++r)i[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,i=t.objectName,r=t.propertyName,s=t.propertyIndex;if(e||(e=n.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){qe("PropertyBinding: No target node found for track: "+this.path+".");return}if(i){let l=t.objectIndex;switch(i){case"materials":if(!e.material){Ye("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){Ye("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){Ye("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let u=0;u<e.length;u++)if(e[u].name===l){l=u;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){Ye("PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){Ye("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[i]===void 0){Ye("PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[i]}if(l!==void 0){if(e[l]===void 0){Ye("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[l]}}let o=e[r];if(o===void 0){let l=t.nodeName;Ye("PropertyBinding: Trying to update property for track: "+l+"."+r+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?a=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(s!==void 0){if(r==="morphTargetInfluences"){if(!e.geometry){Ye("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){Ye("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=s}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=r;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Mt.Composite=jc;Mt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Mt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Mt.prototype.GetterByBindingType=[Mt.prototype._getValue_direct,Mt.prototype._getValue_array,Mt.prototype._getValue_arrayElement,Mt.prototype._getValue_toArray];Mt.prototype.SetterByBindingTypeAndVersioning=[[Mt.prototype._setValue_direct,Mt.prototype._setValue_direct_setNeedsUpdate,Mt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Mt.prototype._setValue_array,Mt.prototype._setValue_array_setNeedsUpdate,Mt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Mt.prototype._setValue_arrayElement,Mt.prototype._setValue_arrayElement_setNeedsUpdate,Mt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Mt.prototype._setValue_fromArray,Mt.prototype._setValue_fromArray_setNeedsUpdate,Mt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var Ex=new Float32Array(1);var Zr=class{constructor(e=1,t=0,i=0){this.radius=e,this.phi=t,this.theta=i}set(e,t,i){return this.radius=e,this.phi=t,this.theta=i,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=et(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,i){return this.radius=Math.sqrt(e*e+t*t+i*i),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,i),this.phi=Math.acos(et(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}};var qc=class n{static{n.prototype.isMatrix2=!0}constructor(e,t,i,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,i,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let i=0;i<4;i++)this.elements[i]=e[i+t];return this}set(e,t,i,r){let s=this.elements;return s[0]=e,s[2]=t,s[1]=i,s[3]=r,this}},td=new be,Ei=class{constructor(e=new be(1/0,1/0),t=new be(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=td.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,td).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}};var eo=class extends Ma{constructor(e=10,t=10,i=4473924,r=8947848){i=new He(i),r=new He(r);let s=t/2,o=e/t,a=e/2,c=[],l=[];for(let h=0,f=0,g=-a;h<=t;h++,g+=o){c.push(-a,0,g,a,0,g),c.push(g,0,-a,g,0,a);let b=h===s?i:r;b.toArray(l,f),f+=3,b.toArray(l,f),f+=3,b.toArray(l,f),f+=3,b.toArray(l,f),f+=3}let u=new wt;u.setAttribute("position",new _t(c,3)),u.setAttribute("color",new _t(l,3));let d=new vi({vertexColors:!0,toneMapped:!1});super(u,d),this.type="GridHelper"}dispose(){super.dispose(),this.geometry.dispose(),this.material.dispose()}};var Dn=class{constructor(){this.type="ShapePath",this.color=new He,this.subPaths=[],this.currentPath=null,this.userData={}}moveTo(e,t){return this.currentPath=new qn,this.subPaths.push(this.currentPath),this.currentPath.moveTo(e,t),this}lineTo(e,t){return this.currentPath.lineTo(e,t),this}quadraticCurveTo(e,t,i,r){return this.currentPath.quadraticCurveTo(e,t,i,r),this}bezierCurveTo(e,t,i,r,s,o){return this.currentPath.bezierCurveTo(e,t,i,r,s,o),this}splineThru(e){return this.currentPath.splineThru(e),this}toShapes(){function e(c,l){let u=!1,d=l.length;for(let h=0,f=d-1;h<d;f=h++){let g=l[h],b=l[f];g.y>c.y!=b.y>c.y&&c.x<(b.x-g.x)*(c.y-g.y)/(b.y-g.y)+g.x&&(u=!u)}return u}function t(c,l){let u=l.getCenter(new be);if(e(u,c))return u;let d=u.y,h=[],f=c.length;for(let g=0;g<f;g++){let b=c[g],m=c[(g+1)%f];if(b.y>d!=m.y>d){let p=b.x+(d-b.y)*(m.x-b.x)/(m.y-b.y);h.push(p)}}return h.length>1&&(h.sort((g,b)=>g-b),u.x=(h[0]+h[1])/2),u}let i=this.userData.style&&this.userData.style.fillRule||"nonzero";i!=="nonzero"&&i!=="evenodd"&&(qe('Fill-rule "'+i+'" is not supported, falling back to "nonzero".'),i="nonzero");let r=i==="nonzero"?(c=>c!==0):(c=>(c&1)!==0),s=[];for(let c of this.subPaths){let l=c.getPoints();if(l.length<3)continue;let u=$r.area(l);if(u===0)continue;let d=new Ei;for(let h=0;h<l.length;h++)d.expandByPoint(l[h]);s.push({subPath:c,points:l,boundingBox:d,interiorPoint:t(l,d),absArea:Math.abs(u),winding:u<0?-1:1,container:null,exclude:!1,role:null})}s.sort((c,l)=>l.absArea-c.absArea);for(let c=0;c<s.length;c++){let l=s[c],u=0;for(let d=c-1;d>=0;d--){let h=s[d];if(h.boundingBox.containsBox(l.boundingBox)&&e(l.interiorPoint,h.points)){l.container=h.exclude?h.container:h,u=h.winding,l.winding+=u;break}}r(l.winding)===r(u)&&(l.exclude=!0)}for(let c of s)c.exclude||(c.role=c.container===null||c.container.role==="hole"?"outer":"hole");let o=[],a=new Map;for(let c of s){if(c.exclude||c.role!=="outer")continue;let l=new Pa;l.curves=c.subPath.curves,o.push(l),a.set(c,l)}for(let c of s){if(c.exclude||c.role!=="hole")continue;let l=a.get(c.container);if(!l)continue;let u=new qn;u.curves=c.subPath.curves,l.holes.push(u)}return o}},to=class extends In{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(e){this.domElement!==null&&this.disconnect(),this.domElement=e}disconnect(){}dispose(){}update(){}};function Mh(n,e,t,i){let r=Vm(i);switch(t){case fh:return n*e;case ts:return n*e/r.components*r.byteLength;case Ka:return n*e/r.components*r.byteLength;case Li:return n*e*2/r.components*r.byteLength;case Qa:return n*e*2/r.components*r.byteLength;case ph:return n*e*3/r.components*r.byteLength;case Mn:return n*e*4/r.components*r.byteLength;case el:return n*e*4/r.components*r.byteLength;case ro:case so:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case oo:case ao:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case nl:case rl:return Math.max(n,16)*Math.max(e,8)/4;case tl:case il:return Math.max(n,8)*Math.max(e,8)/2;case sl:case ol:case ll:case cl:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*8;case al:case lo:case hl:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case ul:return Math.floor((n+3)/4)*Math.floor((e+3)/4)*16;case dl:return Math.floor((n+4)/5)*Math.floor((e+3)/4)*16;case fl:return Math.floor((n+4)/5)*Math.floor((e+4)/5)*16;case pl:return Math.floor((n+5)/6)*Math.floor((e+4)/5)*16;case ml:return Math.floor((n+5)/6)*Math.floor((e+5)/6)*16;case gl:return Math.floor((n+7)/8)*Math.floor((e+4)/5)*16;case _l:return Math.floor((n+7)/8)*Math.floor((e+5)/6)*16;case yl:return Math.floor((n+7)/8)*Math.floor((e+7)/8)*16;case vl:return Math.floor((n+9)/10)*Math.floor((e+4)/5)*16;case xl:return Math.floor((n+9)/10)*Math.floor((e+5)/6)*16;case bl:return Math.floor((n+9)/10)*Math.floor((e+7)/8)*16;case Ml:return Math.floor((n+9)/10)*Math.floor((e+9)/10)*16;case Sl:return Math.floor((n+11)/12)*Math.floor((e+9)/10)*16;case wl:return Math.floor((n+11)/12)*Math.floor((e+11)/12)*16;case Tl:case El:case Al:return Math.ceil(n/4)*Math.ceil(e/4)*16;case Cl:case Rl:return Math.ceil(n/4)*Math.ceil(e/4)*8;case co:case Pl:return Math.ceil(n/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Vm(n){switch(n){case an:case ch:return{byteLength:1,components:1};case Qr:case hh:case Fn:return{byteLength:2,components:1};case Za:case Ja:return{byteLength:2,components:4};case Nn:case Ya:case Un:return{byteLength:4,components:1};case uh:case dh:return{byteLength:4,components:3}}throw new Error(`THREE.TextureUtils: Unknown texture type ${n}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"186"}}));typeof window<"u"&&(window.__THREE__?qe("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="186");function gf(){let n=null,e=!1,t=null,i=null;function r(s,o){i=n.requestAnimationFrame(r),t(s,o)}return{start:function(){e!==!0&&t!==null&&n!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n!==null&&n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function Gm(n){let e=new WeakMap;function t(a,c){let l=a.array,u=a.usage,d=l.byteLength,h=n.createBuffer();n.bindBuffer(c,h),n.bufferData(c,l,u),a.onUploadCallback();let f;if(l instanceof Float32Array)f=n.FLOAT;else if(typeof Float16Array<"u"&&l instanceof Float16Array)f=n.HALF_FLOAT;else if(l instanceof Uint16Array)a.isFloat16BufferAttribute?f=n.HALF_FLOAT:f=n.UNSIGNED_SHORT;else if(l instanceof Int16Array)f=n.SHORT;else if(l instanceof Uint32Array)f=n.UNSIGNED_INT;else if(l instanceof Int32Array)f=n.INT;else if(l instanceof Int8Array)f=n.BYTE;else if(l instanceof Uint8Array)f=n.UNSIGNED_BYTE;else if(l instanceof Uint8ClampedArray)f=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+l);return{buffer:h,type:f,bytesPerElement:l.BYTES_PER_ELEMENT,version:a.version,size:d}}function i(a,c,l){let u=c.array,d=c.updateRanges;if(n.bindBuffer(l,a),d.length===0)n.bufferSubData(l,0,u);else{d.sort((f,g)=>f.start-g.start);let h=0;for(let f=1;f<d.length;f++){let g=d[h],b=d[f];b.start<=g.start+g.count+1?g.count=Math.max(g.count,b.start+b.count-g.start):(++h,d[h]=b)}d.length=h+1;for(let f=0,g=d.length;f<g;f++){let b=d[f];n.bufferSubData(l,b.start*u.BYTES_PER_ELEMENT,u,b.start,b.count)}c.clearUpdateRanges()}c.onUploadCallback()}function r(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);let c=e.get(a);c&&(n.deleteBuffer(c.buffer),e.delete(a))}function o(a,c){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){let u=e.get(a);(!u||u.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}let l=e.get(a);if(l===void 0)e.set(a,t(a,c));else if(l.version<a.version){if(l.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(l.buffer,a,c),l.version=a.version}}return{get:r,remove:s,update:o}}var Wm=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Xm=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,jm=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,qm=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,$m=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Ym=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Zm=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Jm=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Km=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,Qm=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,eg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,tg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,ng=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ig=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,rg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,sg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,og=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,ag=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,lg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,cg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,hg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,ug=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,dg=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,fg=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,pg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,mg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,gg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,_g=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,yg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,vg=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,xg="gl_FragColor = linearToOutputTexel( gl_FragColor );",bg=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Mg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Sg=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,wg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Tg=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Eg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Ag=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Cg=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Rg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Pg=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Ig=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Dg=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Lg=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Ng=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Ug=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Fg=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,Og=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Bg=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,kg=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,zg=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Vg=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Hg=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Gg=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Wg=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Xg=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,jg=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,qg=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,$g=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Yg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Zg=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Jg=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Kg=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Qg=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,e0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,t0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,n0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,i0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,r0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,s0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,o0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,a0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,l0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,c0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,h0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,u0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,d0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,f0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,p0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,m0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,g0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,_0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,y0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,v0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,x0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,b0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,M0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,S0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,w0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,T0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,E0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,A0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,C0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,R0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,P0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,I0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,D0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,L0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,N0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,U0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,F0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,O0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,B0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,k0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,z0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,V0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,H0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,G0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,W0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,X0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,j0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,q0=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Y0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Z0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,J0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,K0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Q0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,e_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,t_=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,n_=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,i_=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,r_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,s_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,o_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,a_=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,l_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,c_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,h_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,u_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,d_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,f_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,p_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,m_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,g_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,__=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,y_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,v_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,x_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,b_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,M_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,S_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,tt={alphahash_fragment:Wm,alphahash_pars_fragment:Xm,alphamap_fragment:jm,alphamap_pars_fragment:qm,alphatest_fragment:$m,alphatest_pars_fragment:Ym,aomap_fragment:Zm,aomap_pars_fragment:Jm,batching_pars_vertex:Km,batching_vertex:Qm,begin_vertex:eg,beginnormal_vertex:tg,bsdfs:ng,iridescence_fragment:ig,bumpmap_pars_fragment:rg,clipping_planes_fragment:sg,clipping_planes_pars_fragment:og,clipping_planes_pars_vertex:ag,clipping_planes_vertex:lg,color_fragment:cg,color_pars_fragment:hg,color_pars_vertex:ug,color_vertex:dg,common:fg,cube_uv_reflection_fragment:pg,defaultnormal_vertex:mg,displacementmap_pars_vertex:gg,displacementmap_vertex:_g,emissivemap_fragment:yg,emissivemap_pars_fragment:vg,colorspace_fragment:xg,colorspace_pars_fragment:bg,envmap_fragment:Mg,envmap_common_pars_fragment:Sg,envmap_pars_fragment:wg,envmap_pars_vertex:Tg,envmap_physical_pars_fragment:Fg,envmap_vertex:Eg,fog_vertex:Ag,fog_pars_vertex:Cg,fog_fragment:Rg,fog_pars_fragment:Pg,gradientmap_pars_fragment:Ig,lightmap_pars_fragment:Dg,lights_lambert_fragment:Lg,lights_lambert_pars_fragment:Ng,lights_pars_begin:Ug,lights_toon_fragment:Og,lights_toon_pars_fragment:Bg,lights_phong_fragment:kg,lights_phong_pars_fragment:zg,lights_physical_fragment:Vg,lights_physical_pars_fragment:Hg,lights_fragment_begin:Gg,lights_fragment_maps:Wg,lights_fragment_end:Xg,lightprobes_pars_fragment:jg,logdepthbuf_fragment:qg,logdepthbuf_pars_fragment:$g,logdepthbuf_pars_vertex:Yg,logdepthbuf_vertex:Zg,map_fragment:Jg,map_pars_fragment:Kg,map_particle_fragment:Qg,map_particle_pars_fragment:e0,metalnessmap_fragment:t0,metalnessmap_pars_fragment:n0,morphinstance_vertex:i0,morphcolor_vertex:r0,morphnormal_vertex:s0,morphtarget_pars_vertex:o0,morphtarget_vertex:a0,normal_fragment_begin:l0,normal_fragment_maps:c0,normal_pars_fragment:h0,normal_pars_vertex:u0,normal_vertex:d0,normalmap_pars_fragment:f0,clearcoat_normal_fragment_begin:p0,clearcoat_normal_fragment_maps:m0,clearcoat_pars_fragment:g0,iridescence_pars_fragment:_0,opaque_fragment:y0,packing:v0,premultiplied_alpha_fragment:x0,project_vertex:b0,dithering_fragment:M0,dithering_pars_fragment:S0,roughnessmap_fragment:w0,roughnessmap_pars_fragment:T0,shadowmap_pars_fragment:E0,shadowmap_pars_vertex:A0,shadowmap_vertex:C0,shadowmask_pars_fragment:R0,skinbase_vertex:P0,skinning_pars_vertex:I0,skinning_vertex:D0,skinnormal_vertex:L0,specularmap_fragment:N0,specularmap_pars_fragment:U0,tonemapping_fragment:F0,tonemapping_pars_fragment:O0,transmission_fragment:B0,transmission_pars_fragment:k0,uv_pars_fragment:z0,uv_pars_vertex:V0,uv_vertex:H0,worldpos_vertex:G0,background_vert:W0,background_frag:X0,backgroundCube_vert:j0,backgroundCube_frag:q0,cube_vert:$0,cube_frag:Y0,depth_vert:Z0,depth_frag:J0,distance_vert:K0,distance_frag:Q0,equirect_vert:e_,equirect_frag:t_,linedashed_vert:n_,linedashed_frag:i_,meshbasic_vert:r_,meshbasic_frag:s_,meshlambert_vert:o_,meshlambert_frag:a_,meshmatcap_vert:l_,meshmatcap_frag:c_,meshnormal_vert:h_,meshnormal_frag:u_,meshphong_vert:d_,meshphong_frag:f_,meshphysical_vert:p_,meshphysical_frag:m_,meshtoon_vert:g_,meshtoon_frag:__,points_vert:y_,points_frag:v_,shadow_vert:x_,shadow_frag:b_,sprite_vert:M_,sprite_frag:S_},Re={common:{diffuse:{value:new He(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new je}},envmap:{envMap:{value:null},envMapRotation:{value:new je},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new je}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new je}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new je},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new je},normalScale:{value:new be(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new je},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new je}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new je}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new je}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new He(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new O},probesMax:{value:new O},probesResolution:{value:new O}},points:{diffuse:{value:new He(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0},uvTransform:{value:new je}},sprite:{diffuse:{value:new He(16777215)},opacity:{value:1},center:{value:new be(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new je},alphaMap:{value:null},alphaMapTransform:{value:new je},alphaTest:{value:0}}},Zn={basic:{uniforms:Yt([Re.common,Re.specularmap,Re.envmap,Re.aomap,Re.lightmap,Re.fog]),vertexShader:tt.meshbasic_vert,fragmentShader:tt.meshbasic_frag},lambert:{uniforms:Yt([Re.common,Re.specularmap,Re.envmap,Re.aomap,Re.lightmap,Re.emissivemap,Re.bumpmap,Re.normalmap,Re.displacementmap,Re.fog,Re.lights,{emissive:{value:new He(0)},envMapIntensity:{value:1}}]),vertexShader:tt.meshlambert_vert,fragmentShader:tt.meshlambert_frag},phong:{uniforms:Yt([Re.common,Re.specularmap,Re.envmap,Re.aomap,Re.lightmap,Re.emissivemap,Re.bumpmap,Re.normalmap,Re.displacementmap,Re.fog,Re.lights,{emissive:{value:new He(0)},specular:{value:new He(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:tt.meshphong_vert,fragmentShader:tt.meshphong_frag},standard:{uniforms:Yt([Re.common,Re.envmap,Re.aomap,Re.lightmap,Re.emissivemap,Re.bumpmap,Re.normalmap,Re.displacementmap,Re.roughnessmap,Re.metalnessmap,Re.fog,Re.lights,{emissive:{value:new He(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:tt.meshphysical_vert,fragmentShader:tt.meshphysical_frag},toon:{uniforms:Yt([Re.common,Re.aomap,Re.lightmap,Re.emissivemap,Re.bumpmap,Re.normalmap,Re.displacementmap,Re.gradientmap,Re.fog,Re.lights,{emissive:{value:new He(0)}}]),vertexShader:tt.meshtoon_vert,fragmentShader:tt.meshtoon_frag},matcap:{uniforms:Yt([Re.common,Re.bumpmap,Re.normalmap,Re.displacementmap,Re.fog,{matcap:{value:null}}]),vertexShader:tt.meshmatcap_vert,fragmentShader:tt.meshmatcap_frag},points:{uniforms:Yt([Re.points,Re.fog]),vertexShader:tt.points_vert,fragmentShader:tt.points_frag},dashed:{uniforms:Yt([Re.common,Re.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:tt.linedashed_vert,fragmentShader:tt.linedashed_frag},depth:{uniforms:Yt([Re.common,Re.displacementmap]),vertexShader:tt.depth_vert,fragmentShader:tt.depth_frag},normal:{uniforms:Yt([Re.common,Re.bumpmap,Re.normalmap,Re.displacementmap,{opacity:{value:1}}]),vertexShader:tt.meshnormal_vert,fragmentShader:tt.meshnormal_frag},sprite:{uniforms:Yt([Re.sprite,Re.fog]),vertexShader:tt.sprite_vert,fragmentShader:tt.sprite_frag},background:{uniforms:{uvTransform:{value:new je},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:tt.background_vert,fragmentShader:tt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new je}},vertexShader:tt.backgroundCube_vert,fragmentShader:tt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:tt.cube_vert,fragmentShader:tt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:tt.equirect_vert,fragmentShader:tt.equirect_frag},distance:{uniforms:Yt([Re.common,Re.displacementmap,{referencePosition:{value:new O},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:tt.distance_vert,fragmentShader:tt.distance_frag},shadow:{uniforms:Yt([Re.lights,Re.fog,{color:{value:new He(0)},opacity:{value:1}}]),vertexShader:tt.shadow_vert,fragmentShader:tt.shadow_frag}};Zn.physical={uniforms:Yt([Zn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new je},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new je},clearcoatNormalScale:{value:new be(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new je},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new je},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new je},sheen:{value:0},sheenColor:{value:new He(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new je},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new je},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new je},transmissionSamplerSize:{value:new be},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new je},attenuationDistance:{value:0},attenuationColor:{value:new He(0)},specularColor:{value:new He(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new je},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new je},anisotropyVector:{value:new be},anisotropyMap:{value:null},anisotropyMapTransform:{value:new je}}]),vertexShader:tt.meshphysical_vert,fragmentShader:tt.meshphysical_frag};var Ll={r:0,b:0,g:0},w_=new vt,_f=new je;_f.set(-1,0,0,0,1,0,0,0,1);function T_(n,e,t,i,r,s){let o=new He(0),a=r===!0?0:1,c,l,u=null,d=0,h=null;function f(S){let T=S.isScene===!0?S.background:null;if(T&&T.isTexture){let y=S.backgroundBlurriness>0;T=e.get(T,y)}return T}function g(S){let T=!1,y=f(S);y===null?m(o,a):y&&y.isColor&&(m(y,1),T=!0);let E=n.xr.getEnvironmentBlendMode();E==="additive"?t.buffers.color.setClear(0,0,0,1,s):E==="alpha-blend"&&t.buffers.color.setClear(0,0,0,0,s),(n.autoClear||T)&&(t.buffers.depth.setTest(!0),t.buffers.depth.setMask(!0),t.buffers.color.setMask(!0),n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil))}function b(S,T){let y=f(T);y&&(y.isCubeTexture||y.mapping===no)?(l===void 0&&(l=new zt(new bi(1,1,1),new Ht({name:"BackgroundCubeMaterial",uniforms:sr(Zn.backgroundCube.uniforms),vertexShader:Zn.backgroundCube.vertexShader,fragmentShader:Zn.backgroundCube.fragmentShader,side:Gt,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute("normal"),l.geometry.deleteAttribute("uv"),l.onBeforeRender=function(E,A,U){this.matrixWorld.copyPosition(U.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(l)),l.material.uniforms.envMap.value=y,l.material.uniforms.backgroundBlurriness.value=T.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=T.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(w_.makeRotationFromEuler(T.backgroundRotation)).transpose(),y.isCubeTexture&&y.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(_f),l.material.toneMapped=rt.getTransfer(y.colorSpace)!==ct,(u!==y||d!==y.version||h!==n.toneMapping)&&(l.material.needsUpdate=!0,u=y,d=y.version,h=n.toneMapping),l.layers.enableAll(),S.unshift(l,l.geometry,l.material,0,0,null)):y&&y.isTexture&&(c===void 0&&(c=new zt(new Ki(2,2),new Ht({name:"BackgroundMaterial",uniforms:sr(Zn.background.uniforms),vertexShader:Zn.background.vertexShader,fragmentShader:Zn.background.fragmentShader,side:Ri,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=y,c.material.uniforms.backgroundIntensity.value=T.backgroundIntensity,c.material.toneMapped=rt.getTransfer(y.colorSpace)!==ct,y.matrixAutoUpdate===!0&&y.updateMatrix(),c.material.uniforms.uvTransform.value.copy(y.matrix),(u!==y||d!==y.version||h!==n.toneMapping)&&(c.material.needsUpdate=!0,u=y,d=y.version,h=n.toneMapping),c.layers.enableAll(),S.unshift(c,c.geometry,c.material,0,0,null))}function m(S,T){S.getRGB(Ll,vh(n)),t.buffers.color.setClear(Ll.r,Ll.g,Ll.b,T,s)}function p(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(S,T=1){o.set(S),a=T,m(o,a)},getClearAlpha:function(){return a},setClearAlpha:function(S){a=S,m(o,a)},render:g,addToRenderList:b,dispose:p}}function E_(n,e){let t=n.getParameter(n.MAX_VERTEX_ATTRIBS),i={},r=h(null),s=r,o=!1;function a(X,W,re,G,se){let _e=!1,ee=d(X,G,re,W);s!==ee&&(s=ee,l(s.object)),_e=f(X,G,re,se),_e&&g(X,G,re,se),se!==null&&e.update(se,n.ELEMENT_ARRAY_BUFFER),(_e||o)&&(o=!1,y(X,W,re,G),se!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,e.get(se).buffer))}function c(){return n.createVertexArray()}function l(X){return n.bindVertexArray(X)}function u(X){return n.deleteVertexArray(X)}function d(X,W,re,G){let se=G.wireframe===!0,_e=i[W.id];_e===void 0&&(_e={},i[W.id]=_e);let ee=X.isInstancedMesh===!0?X.id:0,Y=_e[ee];Y===void 0&&(Y={},_e[ee]=Y);let he=Y[re.id];he===void 0&&(he={},Y[re.id]=he);let de=he[se];return de===void 0&&(de=h(c()),he[se]=de),de}function h(X){let W=[],re=[],G=[];for(let se=0;se<t;se++)W[se]=0,re[se]=0,G[se]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:W,enabledAttributes:re,attributeDivisors:G,object:X,attributes:{},index:null}}function f(X,W,re,G){let se=s.attributes,_e=W.attributes,ee=0,Y=re.getAttributes();for(let he in Y)if(Y[he].location>=0){let ye=se[he],Oe=_e[he];if(Oe===void 0&&(he==="instanceMatrix"&&X.instanceMatrix&&(Oe=X.instanceMatrix),he==="instanceColor"&&X.instanceColor&&(Oe=X.instanceColor)),ye===void 0||ye.attribute!==Oe||Oe&&ye.data!==Oe.data)return!0;ee++}return s.attributesNum!==ee||s.index!==G}function g(X,W,re,G){let se={},_e=W.attributes,ee=0,Y=re.getAttributes();for(let he in Y)if(Y[he].location>=0){let ye=_e[he];ye===void 0&&(he==="instanceMatrix"&&X.instanceMatrix&&(ye=X.instanceMatrix),he==="instanceColor"&&X.instanceColor&&(ye=X.instanceColor));let Oe={};Oe.attribute=ye,ye&&ye.data&&(Oe.data=ye.data),se[he]=Oe,ee++}s.attributes=se,s.attributesNum=ee,s.index=G}function b(){let X=s.newAttributes;for(let W=0,re=X.length;W<re;W++)X[W]=0}function m(X){p(X,0)}function p(X,W){let re=s.newAttributes,G=s.enabledAttributes,se=s.attributeDivisors;re[X]=1,G[X]===0&&(n.enableVertexAttribArray(X),G[X]=1),se[X]!==W&&(n.vertexAttribDivisor(X,W),se[X]=W)}function S(){let X=s.newAttributes,W=s.enabledAttributes;for(let re=0,G=W.length;re<G;re++)W[re]!==X[re]&&(n.disableVertexAttribArray(re),W[re]=0)}function T(X,W,re,G,se,_e,ee){ee===!0?n.vertexAttribIPointer(X,W,re,se,_e):n.vertexAttribPointer(X,W,re,G,se,_e)}function y(X,W,re,G){b();let se=G.attributes,_e=re.getAttributes(),ee=W.defaultAttributeValues;for(let Y in _e){let he=_e[Y];if(he.location>=0){let de=se[Y];if(de===void 0&&(Y==="instanceMatrix"&&X.instanceMatrix&&(de=X.instanceMatrix),Y==="instanceColor"&&X.instanceColor&&(de=X.instanceColor)),de!==void 0){let ye=de.normalized,Oe=de.itemSize,Ne=e.get(de);if(Ne===void 0)continue;let Ke=Ne.buffer,Ze=Ne.type,Je=Ne.bytesPerElement,F=Ze===n.INT||Ze===n.UNSIGNED_INT||de.gpuType===Ya;if(de.isInterleavedBufferAttribute){let D=de.data,L=D.stride,R=de.offset;if(D.isInstancedInterleavedBuffer){for(let k=0;k<he.locationSize;k++)p(he.location+k,D.meshPerAttribute);X.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=D.meshPerAttribute*D.count)}else for(let k=0;k<he.locationSize;k++)m(he.location+k);n.bindBuffer(n.ARRAY_BUFFER,Ke);for(let k=0;k<he.locationSize;k++)T(he.location+k,Oe/he.locationSize,Ze,ye,L*Je,(R+Oe/he.locationSize*k)*Je,F)}else{if(de.isInstancedBufferAttribute){for(let D=0;D<he.locationSize;D++)p(he.location+D,de.meshPerAttribute);X.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=de.meshPerAttribute*de.count)}else for(let D=0;D<he.locationSize;D++)m(he.location+D);n.bindBuffer(n.ARRAY_BUFFER,Ke);for(let D=0;D<he.locationSize;D++)T(he.location+D,Oe/he.locationSize,Ze,ye,Oe*Je,Oe/he.locationSize*D*Je,F)}}else if(ee!==void 0){let ye=ee[Y];if(ye!==void 0)switch(ye.length){case 2:n.vertexAttrib2fv(he.location,ye);break;case 3:n.vertexAttrib3fv(he.location,ye);break;case 4:n.vertexAttrib4fv(he.location,ye);break;default:n.vertexAttrib1fv(he.location,ye)}}}}S()}function E(){C();for(let X in i){let W=i[X];for(let re in W){let G=W[re];for(let se in G){let _e=G[se];for(let ee in _e)u(_e[ee].object),delete _e[ee];delete G[se]}}delete i[X]}}function A(X){if(i[X.id]===void 0)return;let W=i[X.id];for(let re in W){let G=W[re];for(let se in G){let _e=G[se];for(let ee in _e)u(_e[ee].object),delete _e[ee];delete G[se]}}delete i[X.id]}function U(X){for(let W in i){let re=i[W];for(let G in re){let se=re[G];if(se[X.id]===void 0)continue;let _e=se[X.id];for(let ee in _e)u(_e[ee].object),delete _e[ee];delete se[X.id]}}}function v(X){for(let W in i){let re=i[W],G=X.isInstancedMesh===!0?X.id:0,se=re[G];if(se!==void 0){for(let _e in se){let ee=se[_e];for(let Y in ee)u(ee[Y].object),delete ee[Y];delete se[_e]}delete re[G],Object.keys(re).length===0&&delete i[W]}}}function C(){z(),o=!0,s!==r&&(s=r,l(s.object))}function z(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:a,reset:C,resetDefaultState:z,dispose:E,releaseStatesOfGeometry:A,releaseStatesOfObject:v,releaseStatesOfProgram:U,initAttributes:b,enableAttribute:m,disableUnusedAttributes:S}}function A_(n,e,t){let i;function r(c){i=c}function s(c,l){n.drawArrays(i,c,l),t.update(l,i,1)}function o(c,l,u){u!==0&&(n.drawArraysInstanced(i,c,l,u),t.update(l,i,u))}function a(c,l,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,c,0,l,0,u);let h=0;for(let f=0;f<u;f++)h+=l[f];t.update(h,i,1)}this.setMode=r,this.render=s,this.renderInstances=o,this.renderMultiDraw=a}function C_(n,e,t,i){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){let U=e.get("EXT_texture_filter_anisotropic");r=n.getParameter(U.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function o(U){return!(U!==Mn&&i.convert(U)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(U){let v=U===Fn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(U!==an&&U!==Un&&!v&&i.convert(U)!==n.getParameter(n.IMPLEMENTATION_COLOR_READ_TYPE))}function c(U){if(U==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";U="mediump"}return U==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let l=t.precision!==void 0?t.precision:"highp",u=c(l);u!==l&&(qe("WebGLRenderer:",l,"not supported, using",u,"instead."),l=u);let d=t.logarithmicDepthBuffer===!0,h=t.reversedDepthBuffer===!0&&e.has("EXT_clip_control");t.reversedDepthBuffer===!0&&h===!1&&qe("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");let f=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),g=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),b=n.getParameter(n.MAX_TEXTURE_SIZE),m=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),p=n.getParameter(n.MAX_VERTEX_ATTRIBS),S=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),T=n.getParameter(n.MAX_VARYING_VECTORS),y=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),E=n.getParameter(n.MAX_SAMPLES),A=n.getParameter(n.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:a,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:h,maxTextures:f,maxVertexTextures:g,maxTextureSize:b,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:S,maxVaryings:T,maxFragmentUniforms:y,maxSamples:E,samples:A}}function R_(n){let e=this,t=null,i=0,r=!1,s=!1,o=new qt,a=new je,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(d,h){let f=d.length!==0||h||i!==0||r;return r=h,i=d.length,f},this.beginShadows=function(){s=!0,u(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,h){t=u(d,h,0)},this.setState=function(d,h,f){let g=d.clippingPlanes,b=d.clipIntersection,m=d.clipShadows,p=n.get(d);if(!r||g===null||g.length===0||s&&!m)s?u(null):l();else{let S=s?0:i,T=S*4,y=p.clippingState||null;c.value=y,y=u(g,h,T,f);for(let E=0;E!==T;++E)y[E]=t[E];p.clippingState=y,this.numIntersection=b?this.numPlanes:0,this.numPlanes+=S}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function u(d,h,f,g){let b=d!==null?d.length:0,m=null;if(b!==0){if(m=c.value,g!==!0||m===null){let p=f+b*4,S=h.matrixWorldInverse;a.getNormalMatrix(S),(m===null||m.length<p)&&(m=new Float32Array(p));for(let T=0,y=f;T!==b;++T,y+=4)o.copy(d[T]).applyMatrix4(S,a),o.normal.toArray(m,y),m[y+3]=o.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=b,e.numIntersection=0,m}}var is=4,P_=6,I_=20,D_=256,uo=new Ti,$d=new He,Sh=null,wh=0,Th=0,Eh=!1,L_=new O,or=new O,Ul=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,i=.1,r=100,s={}){let{size:o=256,position:a=L_}=s;Sh=this._renderer.getRenderTarget(),wh=this._renderer.getActiveCubeFace(),Th=this._renderer.getActiveMipmapLevel(),Eh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);let c=this._allocateTargets();return c.depthBuffer=!0,this._sceneToCubeUV(e,i,r,c,a),t>0&&this._blur(c,0,0,t),this._applyPMREM(c),this._cleanup(c),c}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Jd(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Zd(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(Sh,wh,Th),this._renderer.xr.enabled=Eh,e.scissorTest=!1,ns(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Pi||e.mapping===rr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Sh=this._renderer.getRenderTarget(),wh=this._renderer.getActiveCubeFace(),Th=this._renderer.getActiveMipmapLevel(),Eh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Nt,minFilter:Nt,generateMipmaps:!1,type:Fn,format:Mn,colorSpace:Es,depthBuffer:!1},r=Yd(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Yd(e,t,i);let{_lodMax:s}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=N_(s)),this._blurMaterial=F_(s,e,t),this._ggxMaterial=U_(s,e,t)}return r}_compileMaterial(e){let t=new zt(new wt,e);this._renderer.compile(t,uo)}_sceneToCubeUV(e,t,i,r,s){let c=new $t(90,1,t,i),l=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],d=this._renderer,h=d.autoClear,f=d.toneMapping;d.getClearColor($d),d.toneMapping=Ln,d.autoClear=!1,d.state.buffers.depth.getReversed()&&(d.setRenderTarget(r),d.clearDepth(),d.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new zt(new bi,new jn({name:"PMREM.Background",side:Gt,depthWrite:!1,depthTest:!1})));let b=this._backgroundBox,m=b.material,p=!1,S=e.background;S?S.isColor&&(m.color.copy(S),e.background=null,p=!0):(m.color.copy($d),p=!0);for(let T=0;T<6;T++){let y=T%3;y===0?(c.up.set(0,l[T],0),c.position.set(s.x,s.y,s.z),c.lookAt(s.x+u[T],s.y,s.z)):y===1?(c.up.set(0,0,l[T]),c.position.set(s.x,s.y,s.z),c.lookAt(s.x,s.y+u[T],s.z)):(c.up.set(0,l[T],0),c.position.set(s.x,s.y,s.z),c.lookAt(s.x,s.y,s.z+u[T]));let E=this._cubeSize;ns(r,y*E,T>2?E:0,E,E),d.setRenderTarget(r),p&&d.render(b,c),d.render(e,c)}d.toneMapping=f,d.autoClear=h,e.background=S}_textureToCubeUV(e,t){let i=this._renderer,r=e.mapping===Pi||e.mapping===rr;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Jd()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Zd());let s=r?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];o.material=s;let a=s.uniforms;a.envMap.value=e;let c=this._cubeSize;ns(t,0,0,3*c,2*c),i.setRenderTarget(t),i.render(o,uo)}_applyPMREM(e){let t=this._renderer,i=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let s=1;s<r;s++)this._applyGGXFilter(e,s-1,s);t.autoClear=i}_applyGGXFilter(e,t,i){let r=this._renderer,s=this._pingPongRenderTarget,o=this._ggxMaterial,a=this._lodMeshes[i];a.material=o;let c=o.uniforms,l=i/(this._lodMeshes.length-1),u=t/(this._lodMeshes.length-1),d=Math.sqrt(l*l-u*u),h=l*1.25,f=d*h,{_lodMax:g}=this,b=this._sizeLods[i],m=3*b*(i>g-is?i-g+is:0),p=4*(this._cubeSize-b);c.envMap.value=e.texture,c.roughness.value=f,c.mipInt.value=g-t,ns(s,m,p,3*b,2*b),r.setRenderTarget(s),r.render(a,uo),c.envMap.value=s.texture,c.roughness.value=0,c.mipInt.value=g-i,ns(e,m,p,3*b,2*b),r.setRenderTarget(e),r.render(a,uo)}_blur(e,t,i,r){let s=this._pingPongRenderTarget,o=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,s,t,i,o),this._blurPass(s,e,i,i,o)}_blurPass(e,t,i,r,s){let o=this._renderer,a=this._blurMaterial,c=this._lodMeshes[r];c.material=a;let l=a.uniforms;l.envMap.value=e.texture,l.sigma.value=s,l.mipInt.value=this._lodMax-i;let u=this._sizeLods[r],d=3*u*(r>this._lodMax-is?r-this._lodMax+is:0),h=4*(this._cubeSize-u);ns(t,d,h,3*u,2*u),o.setRenderTarget(t),o.render(c,uo)}};function N_(n){let e=[],t=[],i=n,r=n-is+1+P_;for(let s=0;s<r;s++){let o=Math.pow(2,i);e.push(o);let a=1/(o-2),c=-a,l=1+a,u=[c,c,l,c,l,l,c,c,l,l,c,l],d=6,h=6,f=3,g=new Float32Array(f*h*d),b=new Float32Array(f*h*d);for(let p=0;p<d;p++){let S=p%3*2/3-1,T=p>2?0:-1,y=[S,T,0,S+2/3,T,0,S+2/3,T+1,0,S,T,0,S+2/3,T+1,0,S,T+1,0];g.set(y,f*h*p);for(let E=0;E<h;E++){let A=u[E*2]*2-1,U=u[E*2+1]*2-1;p===0?or.set(1,U,A):p===1?or.set(-A,1,-U):p===2?or.set(-A,U,1):p===3?or.set(-1,U,-A):p===4?or.set(-A,-1,U):or.set(A,U,-1),or.toArray(b,(p*h+E)*f)}}let m=new wt;m.setAttribute("position",new Ct(g,f)),m.setAttribute("outputDirection",new Ct(b,f)),t.push(new zt(m,null)),i>is&&i--}return{lodMeshes:t,sizeLods:e}}function Yd(n,e,t){let i=new sn(n,e,t);return i.texture.mapping=no,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function ns(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function U_(n,e,t){return new Ht({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:D_,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Bl(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function F_(n,e,t){return new Ht({name:"SphericalGaussianBlur",defines:{SAMPLES:I_,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Bl(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Zd(){return new Ht({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Jd(){return new Ht({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Bl(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:$n,depthTest:!1,depthWrite:!1})}function Bl(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var Fl=class extends sn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];this.texture=new Bs(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new bi(5,5,5),s=new Ht({name:"CubemapFromEquirect",uniforms:sr(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Gt,blending:$n});s.uniforms.tEquirect.value=t;let o=new zt(r,s),a=t.minFilter;return t.minFilter===Ii&&(t.minFilter=Nt),new Wa(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t=!0,i=!0,r=!0){let s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,i,r);e.setRenderTarget(s)}};function O_(n){let e=new WeakMap,t=new WeakMap,i=null;function r(h,f=!1){return h==null?null:f?o(h):s(h)}function s(h){if(h&&h.isTexture){let f=h.mapping;if(f===ja||f===qa)if(e.has(h)){let g=e.get(h).texture;return a(g,h.mapping)}else{let g=h.image;if(g&&g.height>0){let b=new Fl(g.height);return b.fromEquirectangularTexture(n,h),e.set(h,b),h.addEventListener("dispose",l),a(b.texture,h.mapping)}else return null}}return h}function o(h){if(h&&h.isTexture){let f=h.mapping,g=f===ja||f===qa,b=f===Pi||f===rr;if(g||b){let m=t.get(h),p=m!==void 0?m.texture.pmremVersion:0;if(h.isRenderTargetTexture&&h.pmremVersion!==p)return i===null&&(i=new Ul(n)),m=g?i.fromEquirectangular(h,m):i.fromCubemap(h,m),m.texture.pmremVersion=h.pmremVersion,t.set(h,m),m.texture;if(m!==void 0)return m.texture;{let S=h.image;return g&&S&&S.height>0||b&&S&&c(S)?(i===null&&(i=new Ul(n)),m=g?i.fromEquirectangular(h):i.fromCubemap(h),m.texture.pmremVersion=h.pmremVersion,t.set(h,m),h.addEventListener("dispose",u),m.texture):null}}}return h}function a(h,f){return f===ja?h.mapping=Pi:f===qa&&(h.mapping=rr),h}function c(h){let f=0,g=6;for(let b=0;b<g;b++)h[b]!==void 0&&f++;return f===g}function l(h){let f=h.target;f.removeEventListener("dispose",l);let g=e.get(f);g!==void 0&&(e.delete(f),g.dispose())}function u(h){let f=h.target;f.removeEventListener("dispose",u);let g=t.get(f);g!==void 0&&(t.delete(f),g.dispose())}function d(){e=new WeakMap,t=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:r,dispose:d}}function B_(n){let e={};function t(i){if(e[i]!==void 0)return e[i];let r=n.getExtension(i);return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){let r=t(i);return r===null&&ji("WebGLRenderer: "+i+" extension not supported."),r}}}function k_(n,e,t,i){let r={},s=new WeakMap;function o(d){let h=d.target;h.index!==null&&e.remove(h.index);for(let g in h.attributes)e.remove(h.attributes[g]);h.removeEventListener("dispose",o),delete r[h.id];let f=s.get(h);f&&(e.remove(f),s.delete(h)),i.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function a(d,h){return r[h.id]===!0||(h.addEventListener("dispose",o),r[h.id]=!0,t.memory.geometries++),h}function c(d){let h=d.attributes;for(let f in h)e.update(h[f],n.ARRAY_BUFFER)}function l(d){let h=[],f=d.index,g=d.attributes.position,b=0;if(g===void 0)return;if(f!==null){let S=f.array;b=f.version;for(let T=0,y=S.length;T<y;T+=3){let E=S[T+0],A=S[T+1],U=S[T+2];h.push(E,A,A,U,U,E)}}else{let S=g.array;b=g.version;for(let T=0,y=S.length/3-1;T<y;T+=3){let E=T+0,A=T+1,U=T+2;h.push(E,A,A,U,U,E)}}let m=new(g.count>=65535?Ns:Ls)(h,1);m.version=b;let p=s.get(d);p&&e.remove(p),s.set(d,m)}function u(d){let h=s.get(d);if(h){let f=d.index;f!==null&&h.version<f.version&&l(d)}else l(d);return s.get(d)}return{get:a,update:c,getWireframeAttribute:u}}function z_(n,e,t){let i;function r(d){i=d}let s,o;function a(d){s=d.type,o=d.bytesPerElement}function c(d,h){n.drawElements(i,h,s,d*o),t.update(h,i,1)}function l(d,h,f){f!==0&&(n.drawElementsInstanced(i,h,s,d*o,f),t.update(h,i,f))}function u(d,h,f){if(f===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,h,0,s,d,0,f);let b=0;for(let m=0;m<f;m++)b+=h[m];t.update(b,i,1)}this.setMode=r,this.setIndex=a,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function V_(n){let e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,o,a){switch(t.calls++,o){case n.TRIANGLES:t.triangles+=a*(s/3);break;case n.LINES:t.lines+=a*(s/2);break;case n.LINE_STRIP:t.lines+=a*(s-1);break;case n.LINE_LOOP:t.lines+=a*s;break;case n.POINTS:t.points+=a*s;break;default:Ye("WebGLInfo: Unknown draw mode:",o);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function H_(n,e,t){let i=new WeakMap,r=new St;function s(o,a,c){let l=o.morphTargetInfluences,u=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=u!==void 0?u.length:0,h=i.get(a);if(h===void 0||h.count!==d){let C=function(){U.dispose(),i.delete(a),a.removeEventListener("dispose",C)};h!==void 0&&h.texture.dispose();let f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,b=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],S=a.morphAttributes.color||[],T=0;f===!0&&(T=1),g===!0&&(T=2),b===!0&&(T=3);let y=a.attributes.position.count*T,E=1;y>e.maxTextureSize&&(E=Math.ceil(y/e.maxTextureSize),y=e.maxTextureSize);let A=new Float32Array(y*E*4*d),U=new Ps(A,y,E,d);U.type=Un,U.needsUpdate=!0;let v=T*4;for(let z=0;z<d;z++){let X=m[z],W=p[z],re=S[z],G=y*E*4*z;for(let se=0;se<X.count;se++){let _e=se*v;f===!0&&(r.fromBufferAttribute(X,se),A[G+_e+0]=r.x,A[G+_e+1]=r.y,A[G+_e+2]=r.z,A[G+_e+3]=0),g===!0&&(r.fromBufferAttribute(W,se),A[G+_e+4]=r.x,A[G+_e+5]=r.y,A[G+_e+6]=r.z,A[G+_e+7]=0),b===!0&&(r.fromBufferAttribute(re,se),A[G+_e+8]=r.x,A[G+_e+9]=r.y,A[G+_e+10]=r.z,A[G+_e+11]=re.itemSize===4?r.w:1)}}h={count:d,texture:U,size:new be(y,E)},i.set(a,h),a.addEventListener("dispose",C)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)c.getUniforms().setValue(n,"morphTexture",o.morphTexture,t);else{let f=0;for(let b=0;b<l.length;b++)f+=l[b];let g=a.morphTargetsRelative?1:1-f;c.getUniforms().setValue(n,"morphTargetBaseInfluence",g),c.getUniforms().setValue(n,"morphTargetInfluences",l)}c.getUniforms().setValue(n,"morphTargetsTexture",h.texture,t),c.getUniforms().setValue(n,"morphTargetsTextureSize",h.size)}return{update:s}}function G_(n,e,t,i,r){let s=new WeakMap;function o(l){let u=r.render.frame,d=l.geometry,h=e.get(l,d);if(s.get(h)!==u&&(e.update(h),s.set(h,u)),l.isInstancedMesh&&(l.hasEventListener("dispose",c)===!1&&l.addEventListener("dispose",c),s.get(l)!==u&&(t.update(l.instanceMatrix,n.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,n.ARRAY_BUFFER),s.set(l,u))),l.isSkinnedMesh){let f=l.skeleton;s.get(f)!==u&&(f.update(),s.set(f,u))}return h}function a(){s=new WeakMap}function c(l){let u=l.target;u.removeEventListener("dispose",c),i.releaseStatesOfObject(u),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:o,dispose:a}}var W_={[th]:"LINEAR_TONE_MAPPING",[nh]:"REINHARD_TONE_MAPPING",[ih]:"CINEON_TONE_MAPPING",[rh]:"ACES_FILMIC_TONE_MAPPING",[oh]:"AGX_TONE_MAPPING",[ah]:"NEUTRAL_TONE_MAPPING",[sh]:"CUSTOM_TONE_MAPPING"};function X_(n,e,t,i,r,s){let o=new sn(e,t,{type:n,depthBuffer:r,stencilBuffer:s,samples:i?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),a=null,c=null,l=new wt;l.setAttribute("position",new _t([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute("uv",new _t([0,2,0,0,2,0],2));let u=new Ia({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new zt(l,u),h=new Ti(-1,1,1,-1,0,1),f=null,g=null,b=!1,m,p=null,S=[],T=!1;this.setSize=function(y,E){o.setSize(y,E),a!==null&&a.setSize(y,E),c!==null&&c.setSize(y,E);for(let A=0;A<S.length;A++){let U=S[A];U.setSize&&U.setSize(y,E)}},this.setEffects=function(y){S=y,T=S.length>0&&S[0].isRenderPass===!0;let E=o.width,A=o.height;S.length>0&&a===null&&(a=new sn(E,A,{type:Fn,depthBuffer:!1,stencilBuffer:!1}),c=new sn(E,A,{type:Fn,depthBuffer:!1,stencilBuffer:!1}));for(let U=0;U<S.length;U++){let v=S[U];v.setSize&&v.setSize(E,A)}},this.begin=function(y,E){if(b||y.toneMapping===Ln&&S.length===0)return!1;if(p=E,E!==null){let A=E.width,U=E.height;(o.width!==A||o.height!==U)&&this.setSize(A,U)}return T===!1&&y.setRenderTarget(o),m=y.toneMapping,y.toneMapping=Ln,!0},this.hasRenderPass=function(){return T},this.end=function(y,E){y.toneMapping=m,b=!0;let A=o,U=a;for(let v=0;v<S.length;v++){let C=S[v];C.enabled!==!1&&(C.render(y,U,A,E),C.needsSwap!==!1&&(A=U,U=U===a?c:a))}if(f!==y.outputColorSpace||g!==y.toneMapping){f=y.outputColorSpace,g=y.toneMapping,u.defines={},rt.getTransfer(f)===ct&&(u.defines.SRGB_TRANSFER="");let v=W_[g];v&&(u.defines[v]=""),u.needsUpdate=!0}u.uniforms.tDiffuse.value=A.texture,y.setRenderTarget(p),y.render(d,h),p=null,b=!1},this.isCompositing=function(){return b},this.dispose=function(){o.dispose(),a!==null&&a.dispose(),c!==null&&c.dispose(),l.dispose(),u.dispose()}}var yf=new tn,Rh=new xi(1,1),vf=new Ps,xf=new ya,bf=new Bs,Kd=[],Qd=[],ef=new Float32Array(16),tf=new Float32Array(9),nf=new Float32Array(4);function ss(n,e,t){let i=n[0];if(i<=0||i>0)return n;let r=e*t,s=Kd[r];if(s===void 0&&(s=new Float32Array(r),Kd[r]=s),e!==0){i.toArray(s,0);for(let o=1,a=0;o!==e;++o)a+=t,n[o].toArray(s,a)}return s}function Ut(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function Ft(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function kl(n,e){let t=Qd[e];t===void 0&&(t=new Int32Array(e),Qd[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function j_(n,e){let t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function q_(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;n.uniform2fv(this.addr,e),Ft(t,e)}}function $_(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Ut(t,e))return;n.uniform3fv(this.addr,e),Ft(t,e)}}function Y_(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;n.uniform4fv(this.addr,e),Ft(t,e)}}function Z_(n,e){let t=this.cache,i=e.elements;if(i===void 0){if(Ut(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),Ft(t,e)}else{if(Ut(t,i))return;nf.set(i),n.uniformMatrix2fv(this.addr,!1,nf),Ft(t,i)}}function J_(n,e){let t=this.cache,i=e.elements;if(i===void 0){if(Ut(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),Ft(t,e)}else{if(Ut(t,i))return;tf.set(i),n.uniformMatrix3fv(this.addr,!1,tf),Ft(t,i)}}function K_(n,e){let t=this.cache,i=e.elements;if(i===void 0){if(Ut(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),Ft(t,e)}else{if(Ut(t,i))return;ef.set(i),n.uniformMatrix4fv(this.addr,!1,ef),Ft(t,i)}}function Q_(n,e){let t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function ey(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;n.uniform2iv(this.addr,e),Ft(t,e)}}function ty(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ut(t,e))return;n.uniform3iv(this.addr,e),Ft(t,e)}}function ny(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;n.uniform4iv(this.addr,e),Ft(t,e)}}function iy(n,e){let t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function ry(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Ut(t,e))return;n.uniform2uiv(this.addr,e),Ft(t,e)}}function sy(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Ut(t,e))return;n.uniform3uiv(this.addr,e),Ft(t,e)}}function oy(n,e){let t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Ut(t,e))return;n.uniform4uiv(this.addr,e),Ft(t,e)}}function ay(n,e,t){let i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);let s;this.type===n.SAMPLER_2D_SHADOW?(Rh.compareFunction=t.isReversedDepthBuffer()?Dl:Il,s=Rh):s=yf,t.setTexture2D(e||s,r)}function ly(n,e,t){let i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||xf,r)}function cy(n,e,t){let i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||bf,r)}function hy(n,e,t){let i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||vf,r)}function uy(n){switch(n){case 5126:return j_;case 35664:return q_;case 35665:return $_;case 35666:return Y_;case 35674:return Z_;case 35675:return J_;case 35676:return K_;case 5124:case 35670:return Q_;case 35667:case 35671:return ey;case 35668:case 35672:return ty;case 35669:case 35673:return ny;case 5125:return iy;case 36294:return ry;case 36295:return sy;case 36296:return oy;case 35678:case 36198:case 36298:case 36306:case 35682:return ay;case 35679:case 36299:case 36307:return ly;case 35680:case 36300:case 36308:case 36293:return cy;case 36289:case 36303:case 36311:case 36292:return hy}}function dy(n,e){n.uniform1fv(this.addr,e)}function fy(n,e){let t=ss(e,this.size,2);n.uniform2fv(this.addr,t)}function py(n,e){let t=ss(e,this.size,3);n.uniform3fv(this.addr,t)}function my(n,e){let t=ss(e,this.size,4);n.uniform4fv(this.addr,t)}function gy(n,e){let t=ss(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function _y(n,e){let t=ss(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function yy(n,e){let t=ss(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function vy(n,e){n.uniform1iv(this.addr,e)}function xy(n,e){n.uniform2iv(this.addr,e)}function by(n,e){n.uniform3iv(this.addr,e)}function My(n,e){n.uniform4iv(this.addr,e)}function Sy(n,e){n.uniform1uiv(this.addr,e)}function wy(n,e){n.uniform2uiv(this.addr,e)}function Ty(n,e){n.uniform3uiv(this.addr,e)}function Ey(n,e){n.uniform4uiv(this.addr,e)}function Ay(n,e,t){let i=this.cache,r=e.length,s=kl(t,r);Ut(i,s)||(n.uniform1iv(this.addr,s),Ft(i,s));let o;this.type===n.SAMPLER_2D_SHADOW?o=Rh:o=yf;for(let a=0;a!==r;++a)t.setTexture2D(e[a]||o,s[a])}function Cy(n,e,t){let i=this.cache,r=e.length,s=kl(t,r);Ut(i,s)||(n.uniform1iv(this.addr,s),Ft(i,s));for(let o=0;o!==r;++o)t.setTexture3D(e[o]||xf,s[o])}function Ry(n,e,t){let i=this.cache,r=e.length,s=kl(t,r);Ut(i,s)||(n.uniform1iv(this.addr,s),Ft(i,s));for(let o=0;o!==r;++o)t.setTextureCube(e[o]||bf,s[o])}function Py(n,e,t){let i=this.cache,r=e.length,s=kl(t,r);Ut(i,s)||(n.uniform1iv(this.addr,s),Ft(i,s));for(let o=0;o!==r;++o)t.setTexture2DArray(e[o]||vf,s[o])}function Iy(n){switch(n){case 5126:return dy;case 35664:return fy;case 35665:return py;case 35666:return my;case 35674:return gy;case 35675:return _y;case 35676:return yy;case 5124:case 35670:return vy;case 35667:case 35671:return xy;case 35668:case 35672:return by;case 35669:case 35673:return My;case 5125:return Sy;case 36294:return wy;case 36295:return Ty;case 36296:return Ey;case 35678:case 36198:case 36298:case 36306:case 35682:return Ay;case 35679:case 36299:case 36307:return Cy;case 35680:case 36300:case 36308:case 36293:return Ry;case 36289:case 36303:case 36311:case 36292:return Py}}var Ph=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=uy(t.type)}},Ih=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Iy(t.type)}},Dh=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){let r=this.seq;for(let s=0,o=r.length;s!==o;++s){let a=r[s];a.setValue(e,t[a.id],i)}}},Ah=/(\w+)(\])?(\[|\.)?/g;function rf(n,e){n.seq.push(e),n.map[e.id]=e}function Dy(n,e,t){let i=n.name,r=i.length;for(Ah.lastIndex=0;;){let s=Ah.exec(i),o=Ah.lastIndex,a=s[1],c=s[2]==="]",l=s[3];if(c&&(a=a|0),l===void 0||l==="["&&o+2===r){rf(t,l===void 0?new Ph(a,n,e):new Ih(a,n,e));break}else{let d=t.map[a];d===void 0&&(d=new Dh(a),rf(t,d)),t=d}}}var rs=class{constructor(e,t){this.seq=[],this.map={};let i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let o=0;o<i;++o){let a=e.getActiveUniform(t,o),c=e.getUniformLocation(t,a.name);Dy(a,c,this)}let r=[],s=[];for(let o of this.seq)o.type===e.SAMPLER_2D_SHADOW||o.type===e.SAMPLER_CUBE_SHADOW||o.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(o):s.push(o);r.length>0&&(this.seq=r.concat(s))}setValue(e,t,i,r){let s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){let r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,o=t.length;s!==o;++s){let a=t[s],c=i[a.id];c.needsUpdate!==!1&&a.setValue(e,c.value,r)}}static seqWithValue(e,t){let i=[];for(let r=0,s=e.length;r!==s;++r){let o=e[r];o.id in t&&i.push(o)}return i}};function sf(n,e,t){let i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}var Ly=37297,Ny=0;function Uy(n,e){let t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=r;o<s;o++){let a=o+1;i.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return i.join(`
`)}var of=new je;function Fy(n){rt._getMatrix(of,rt.workingColorSpace,n);let e=`mat3( ${of.elements.map(t=>t.toFixed(4))} )`;switch(rt.getTransfer(n)){case As:return[e,"LinearTransferOETF"];case ct:return[e,"sRGBTransferOETF"];default:return qe("WebGLProgram: Unsupported color space: ",n),[e,"LinearTransferOETF"]}}function af(n,e,t){let i=n.getShaderParameter(e,n.COMPILE_STATUS),s=(n.getShaderInfoLog(e)||"").trim();if(i&&s==="")return"";let o=/ERROR: 0:(\d+)/.exec(s);if(o){let a=parseInt(o[1]);return t.toUpperCase()+`

`+s+`

`+Uy(n.getShaderSource(e),a)}else return s}function Oy(n,e){let t=Fy(e);return[`vec4 ${n}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}var By={[th]:"Linear",[nh]:"Reinhard",[ih]:"Cineon",[rh]:"ACESFilmic",[oh]:"AgX",[ah]:"Neutral",[sh]:"Custom"};function ky(n,e){let t=By[e];return t===void 0?(qe("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+n+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}var Nl=new O;function zy(){rt.getLuminanceCoefficients(Nl);let n=Nl.x.toFixed(4),e=Nl.y.toFixed(4),t=Nl.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${n}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Vy(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",n.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(po).join(`
`)}function Hy(n){let e=[];for(let t in n){let i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function Gy(n,e){let t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){let s=n.getActiveAttrib(e,r),o=s.name,a=1;s.type===n.FLOAT_MAT2&&(a=2),s.type===n.FLOAT_MAT3&&(a=3),s.type===n.FLOAT_MAT4&&(a=4),t[o]={type:s.type,location:n.getAttribLocation(e,o),locationSize:a}}return t}function po(n){return n!==""}function lf(n,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_SUN_LIGHTS/g,e.numSunLights).replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,e.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function cf(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var Wy=/^[ \t]*#include +<([\w\d./]+)>/gm;function Lh(n){return n.replace(Wy,jy)}var Xy=new Map;function jy(n,e){let t=tt[e];if(t===void 0){let i=Xy.get(e);if(i!==void 0)t=tt[i],qe('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("THREE.WebGLProgram: Can not resolve #include <"+e+">")}return Lh(t)}var qy=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function hf(n){return n.replace(qy,$y)}function $y(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function uf(n){let e=`precision ${n.precision} float;
	precision ${n.precision} int;
	precision ${n.precision} sampler2D;
	precision ${n.precision} samplerCube;
	precision ${n.precision} sampler3D;
	precision ${n.precision} sampler2DArray;
	precision ${n.precision} sampler2DShadow;
	precision ${n.precision} samplerCubeShadow;
	precision ${n.precision} sampler2DArrayShadow;
	precision ${n.precision} isampler2D;
	precision ${n.precision} isampler3D;
	precision ${n.precision} isamplerCube;
	precision ${n.precision} isampler2DArray;
	precision ${n.precision} usampler2D;
	precision ${n.precision} usampler3D;
	precision ${n.precision} usamplerCube;
	precision ${n.precision} usampler2DArray;
	`;return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}var Yy={[nr]:"SHADOWMAP_TYPE_PCF",[Jr]:"SHADOWMAP_TYPE_VSM"};function Zy(n){return Yy[n.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}var Jy={[Pi]:"ENVMAP_TYPE_CUBE",[rr]:"ENVMAP_TYPE_CUBE",[no]:"ENVMAP_TYPE_CUBE_UV"};function Ky(n){return n.envMap===!1?"ENVMAP_TYPE_CUBE":Jy[n.envMapMode]||"ENVMAP_TYPE_CUBE"}var Qy={[rr]:"ENVMAP_MODE_REFRACTION"};function ev(n){return n.envMap===!1?"ENVMAP_MODE_REFLECTION":Qy[n.envMapMode]||"ENVMAP_MODE_REFLECTION"}var tv={[eh]:"ENVMAP_BLENDING_MULTIPLY",[Sd]:"ENVMAP_BLENDING_MIX",[wd]:"ENVMAP_BLENDING_ADD"};function nv(n){return n.envMap===!1?"ENVMAP_BLENDING_NONE":tv[n.combine]||"ENVMAP_BLENDING_NONE"}function iv(n){let e=n.envMapCubeUVHeight;if(e===null)return null;let t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function rv(n,e,t,i){let r=n.getContext(),s=t.defines,o=t.vertexShader,a=t.fragmentShader,c=Zy(t),l=Ky(t),u=ev(t),d=nv(t),h=iv(t),f=Vy(t),g=Hy(s),b=r.createProgram(),m,p,S=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(po).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(po).join(`
`),p.length>0&&(p+=`
`)):(m=[uf(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexNormals?"#define HAS_NORMAL":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(po).join(`
`),p=[uf(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+u:"",t.envMap?"#define "+d:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.retroreflection?"#define USE_RETROREFLECTION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas||t.batchingColor?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Ln?"#define TONE_MAPPING":"",t.toneMapping!==Ln?tt.tonemapping_pars_fragment:"",t.toneMapping!==Ln?ky("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",tt.colorspace_pars_fragment,Oy("linearToOutputTexel",t.outputColorSpace),zy(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(po).join(`
`)),o=Lh(o),o=lf(o,t),o=cf(o,t),a=Lh(a),a=lf(a,t),a=cf(a,t),o=hf(o),a=hf(a),t.isRawShaderMaterial!==!0&&(S=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===gh?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===gh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);let T=S+m+o,y=S+p+a,E=sf(r,r.VERTEX_SHADER,T),A=sf(r,r.FRAGMENT_SHADER,y);r.attachShader(b,E),r.attachShader(b,A),t.index0AttributeName!==void 0?r.bindAttribLocation(b,0,t.index0AttributeName):t.hasPositionAttribute===!0&&r.bindAttribLocation(b,0,"position"),r.linkProgram(b);function U(X){if(n.debug.checkShaderErrors){let W=r.getProgramInfoLog(b)||"",re=r.getShaderInfoLog(E)||"",G=r.getShaderInfoLog(A)||"",se=W.trim(),_e=re.trim(),ee=G.trim(),Y=!0,he=!0;if(r.getProgramParameter(b,r.LINK_STATUS)===!1)if(Y=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,b,E,A);else{let de=af(r,E,"vertex"),ye=af(r,A,"fragment");Ye("WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(b,r.VALIDATE_STATUS)+`

Material Name: `+X.name+`
Material Type: `+X.type+`

Program Info Log: `+se+`
`+de+`
`+ye)}else se!==""?qe("WebGLProgram: Program Info Log:",se):(_e===""||ee==="")&&(he=!1);he&&(X.diagnostics={runnable:Y,programLog:se,vertexShader:{log:_e,prefix:m},fragmentShader:{log:ee,prefix:p}})}r.deleteShader(E),r.deleteShader(A),v=new rs(r,b),C=Gy(r,b)}let v;this.getUniforms=function(){return v===void 0&&U(this),v};let C;this.getAttributes=function(){return C===void 0&&U(this),C};let z=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return z===!1&&(z=r.getProgramParameter(b,Ly)),z},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(b),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Ny++,this.cacheKey=e,this.usedTimes=1,this.program=b,this.vertexShader=E,this.fragmentShader=A,this}var sv=0,Nh=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,i){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(i)===!1&&(r.add(i),i.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){let t=this.shaderCache,i=t.get(e);return i===void 0&&(i=new Uh(e),t.set(e,i)),i}},Uh=class{constructor(e){this.id=sv++,this.code=e,this.usedTimes=0}};function ov(n){return n===Li||n===lo||n===co}function av(n,e,t,i,r,s){let o=new Is,a=new Nh,c=new Set,l=[],u=new Map,d=i.logarithmicDepthBuffer,h=i.precision,f={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function g(v){return c.add(v),v===0?"uv":`uv${v}`}function b(v,C,z,X,W,re){let G=X.fog,se=W.geometry,_e=v.isMeshStandardMaterial||v.isMeshLambertMaterial||v.isMeshPhongMaterial?X.environment:null,ee=v.isMeshStandardMaterial||v.isMeshLambertMaterial&&!v.envMap||v.isMeshPhongMaterial&&!v.envMap,Y=e.get(v.envMap||_e,ee),he=Y&&Y.mapping===no?Y.image.height:null,de=f[v.type];v.precision!==null&&(h=i.getMaxPrecision(v.precision),h!==v.precision&&qe("WebGLProgram.getParameters:",v.precision,"not supported, using",h,"instead."));let ye=se.morphAttributes.position||se.morphAttributes.normal||se.morphAttributes.color,Oe=ye!==void 0?ye.length:0,Ne=0;se.morphAttributes.position!==void 0&&(Ne=1),se.morphAttributes.normal!==void 0&&(Ne=2),se.morphAttributes.color!==void 0&&(Ne=3);let Ke,Ze,Je,F;if(de){let ft=Zn[de];Ke=ft.vertexShader,Ze=ft.fragmentShader}else{Ke=v.vertexShader,Ze=v.fragmentShader;let ft=a.getVertexShaderStage(v),at=a.getFragmentShaderStage(v);a.update(v,ft,at),Je=ft.id,F=at.id}let D=n.getRenderTarget(),L=n.state.buffers.depth.getReversed(),R=W.isInstancedMesh===!0,k=W.isBatchedMesh===!0,le=!!v.map,Se=!!v.matcap,B=!!Y,ae=!!v.aoMap,Z=!!v.lightMap,pe=!!v.bumpMap&&v.wireframe===!1,me=!!v.normalMap,Me=!!v.displacementMap,Le=!!v.emissiveMap,Te=!!v.metalnessMap,K=!!v.roughnessMap,x=v.anisotropy>0,Be=v.clearcoat>0,Xe=v.dispersion>0,P=v.retroreflectivity>0,_=v.iridescence>0,j=v.sheen>0,w=v.transmission>0,N=x&&!!v.anisotropyMap,J=Be&&!!v.clearcoatMap,oe=Be&&!!v.clearcoatNormalMap,$=Be&&!!v.clearcoatRoughnessMap,q=_&&!!v.iridescenceMap,fe=_&&!!v.iridescenceThicknessMap,ge=j&&!!v.sheenColorMap,te=j&&!!v.sheenRoughnessMap,ce=!!v.specularMap,we=!!v.specularColorMap,Pe=!!v.specularIntensityMap,$e=w&&!!v.transmissionMap,V=w&&!!v.thicknessMap,Ee=!!v.gradientMap,ve=!!v.alphaMap,Ae=v.alphaTest>0,Ce=!!v.alphaHash,xe=!!v.extensions,We=Ln;v.toneMapped&&(D===null||D.isXRRenderTarget===!0)&&(We=n.toneMapping);let ke={shaderID:de,shaderType:v.type,shaderName:v.name,vertexShader:Ke,fragmentShader:Ze,defines:v.defines,customVertexShaderID:Je,customFragmentShaderID:F,isRawShaderMaterial:v.isRawShaderMaterial===!0,glslVersion:v.glslVersion,precision:h,batching:k,batchingColor:k&&W._colorsTexture!==null,instancing:R,instancingColor:R&&W.instanceColor!==null,instancingMorph:R&&W.morphTexture!==null,outputColorSpace:D===null?n.outputColorSpace:D.isXRRenderTarget===!0?D.texture.colorSpace:rt.workingColorSpace,alphaToCoverage:!!v.alphaToCoverage,map:le,matcap:Se,envMap:B,envMapMode:B&&Y.mapping,envMapCubeUVHeight:he,aoMap:ae,lightMap:Z,bumpMap:pe,normalMap:me,displacementMap:Me,emissiveMap:Le,normalMapObjectSpace:me&&v.normalMapType===Ad,normalMapTangentSpace:me&&v.normalMapType===ho,packedNormalMap:me&&v.normalMapType===ho&&ov(v.normalMap.format),metalnessMap:Te,roughnessMap:K,anisotropy:x,anisotropyMap:N,clearcoat:Be,clearcoatMap:J,clearcoatNormalMap:oe,clearcoatRoughnessMap:$,dispersion:Xe,retroreflection:P,iridescence:_,iridescenceMap:q,iridescenceThicknessMap:fe,sheen:j,sheenColorMap:ge,sheenRoughnessMap:te,specularMap:ce,specularColorMap:we,specularIntensityMap:Pe,transmission:w,transmissionMap:$e,thicknessMap:V,gradientMap:Ee,opaque:v.transparent===!1&&v.blending===Kr&&v.alphaToCoverage===!1,alphaMap:ve,alphaTest:Ae,alphaHash:Ce,combine:v.combine,mapUv:le&&g(v.map.channel),aoMapUv:ae&&g(v.aoMap.channel),lightMapUv:Z&&g(v.lightMap.channel),bumpMapUv:pe&&g(v.bumpMap.channel),normalMapUv:me&&g(v.normalMap.channel),displacementMapUv:Me&&g(v.displacementMap.channel),emissiveMapUv:Le&&g(v.emissiveMap.channel),metalnessMapUv:Te&&g(v.metalnessMap.channel),roughnessMapUv:K&&g(v.roughnessMap.channel),anisotropyMapUv:N&&g(v.anisotropyMap.channel),clearcoatMapUv:J&&g(v.clearcoatMap.channel),clearcoatNormalMapUv:oe&&g(v.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:$&&g(v.clearcoatRoughnessMap.channel),iridescenceMapUv:q&&g(v.iridescenceMap.channel),iridescenceThicknessMapUv:fe&&g(v.iridescenceThicknessMap.channel),sheenColorMapUv:ge&&g(v.sheenColorMap.channel),sheenRoughnessMapUv:te&&g(v.sheenRoughnessMap.channel),specularMapUv:ce&&g(v.specularMap.channel),specularColorMapUv:we&&g(v.specularColorMap.channel),specularIntensityMapUv:Pe&&g(v.specularIntensityMap.channel),transmissionMapUv:$e&&g(v.transmissionMap.channel),thicknessMapUv:V&&g(v.thicknessMap.channel),alphaMapUv:ve&&g(v.alphaMap.channel),vertexTangents:!!se.attributes.tangent&&(me||x),vertexNormals:!!se.attributes.normal,vertexColors:v.vertexColors,vertexAlphas:v.vertexColors===!0&&!!se.attributes.color&&se.attributes.color.itemSize===4,pointsUvs:W.isPoints===!0&&!!se.attributes.uv&&(le||ve),fog:!!G,useFog:v.fog===!0,fogExp2:!!G&&G.isFogExp2,flatShading:v.wireframe===!1&&(v.flatShading===!0||se.attributes.normal===void 0&&me===!1&&(v.isMeshLambertMaterial||v.isMeshPhongMaterial||v.isMeshStandardMaterial||v.isMeshPhysicalMaterial)),sizeAttenuation:v.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:L,skinning:W.isSkinnedMesh===!0,hasPositionAttribute:se.attributes.position!==void 0,morphTargets:se.morphAttributes.position!==void 0,morphNormals:se.morphAttributes.normal!==void 0,morphColors:se.morphAttributes.color!==void 0,morphTargetsCount:Oe,morphTextureStride:Ne,numSunLights:C.sun.length,numDirLights:C.directional.length,numPointLights:C.point.length,numSpotLights:C.spot.length,numSpotLightMaps:C.spotLightMap.length,numRectAreaLights:C.rectArea.length,numHemiLights:C.hemi.length,numSunLightShadows:C.sunShadowMap.length,numDirLightShadows:C.directionalShadowMap.length,numPointLightShadows:C.pointShadowMap.length,numSpotLightShadows:C.spotShadowMap.length,numSpotLightShadowsWithMaps:C.numSpotLightShadowsWithMaps,numLightProbes:C.numLightProbes,numLightProbeGrids:re.length,numClippingPlanes:s.numPlanes,numClipIntersection:s.numIntersection,dithering:v.dithering,shadowMapEnabled:n.shadowMap.enabled&&z.length>0,shadowMapType:n.shadowMap.type,toneMapping:We,decodeVideoTexture:le&&v.map.isVideoTexture===!0&&rt.getTransfer(v.map.colorSpace)===ct,decodeVideoTextureEmissive:Le&&v.emissiveMap.isVideoTexture===!0&&rt.getTransfer(v.emissiveMap.colorSpace)===ct,premultipliedAlpha:v.premultipliedAlpha,doubleSided:v.side===nn,flipSided:v.side===Gt,useDepthPacking:v.depthPacking>=0,depthPacking:v.depthPacking||0,index0AttributeName:v.index0AttributeName,extensionClipCullDistance:xe&&v.extensions.clipCullDistance===!0&&t.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(xe&&v.extensions.multiDraw===!0||k)&&t.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:t.has("KHR_parallel_shader_compile"),customProgramCacheKey:v.customProgramCacheKey()};return ke.vertexUv1s=c.has(1),ke.vertexUv2s=c.has(2),ke.vertexUv3s=c.has(3),c.clear(),ke}function m(v){let C=[];if(v.shaderID?C.push(v.shaderID):(C.push(v.customVertexShaderID),C.push(v.customFragmentShaderID)),v.defines!==void 0)for(let z in v.defines)C.push(z),C.push(v.defines[z]);return v.isRawShaderMaterial===!1&&(p(C,v),S(C,v),C.push(n.outputColorSpace)),C.push(v.customProgramCacheKey),C.join()}function p(v,C){v.push(C.precision),v.push(C.outputColorSpace),v.push(C.envMapMode),v.push(C.envMapCubeUVHeight),v.push(C.mapUv),v.push(C.alphaMapUv),v.push(C.lightMapUv),v.push(C.aoMapUv),v.push(C.bumpMapUv),v.push(C.normalMapUv),v.push(C.displacementMapUv),v.push(C.emissiveMapUv),v.push(C.metalnessMapUv),v.push(C.roughnessMapUv),v.push(C.anisotropyMapUv),v.push(C.clearcoatMapUv),v.push(C.clearcoatNormalMapUv),v.push(C.clearcoatRoughnessMapUv),v.push(C.iridescenceMapUv),v.push(C.iridescenceThicknessMapUv),v.push(C.sheenColorMapUv),v.push(C.sheenRoughnessMapUv),v.push(C.specularMapUv),v.push(C.specularColorMapUv),v.push(C.specularIntensityMapUv),v.push(C.transmissionMapUv),v.push(C.thicknessMapUv),v.push(C.combine),v.push(C.fogExp2),v.push(C.sizeAttenuation),v.push(C.morphTargetsCount),v.push(C.morphAttributeCount),v.push(C.numSunLights),v.push(C.numDirLights),v.push(C.numPointLights),v.push(C.numSpotLights),v.push(C.numSpotLightMaps),v.push(C.numHemiLights),v.push(C.numRectAreaLights),v.push(C.numSunLightShadows),v.push(C.numDirLightShadows),v.push(C.numPointLightShadows),v.push(C.numSpotLightShadows),v.push(C.numSpotLightShadowsWithMaps),v.push(C.numLightProbes),v.push(C.shadowMapType),v.push(C.toneMapping),v.push(C.numClippingPlanes),v.push(C.numClipIntersection),v.push(C.depthPacking)}function S(v,C){o.disableAll(),C.instancing&&o.enable(0),C.instancingColor&&o.enable(1),C.instancingMorph&&o.enable(2),C.matcap&&o.enable(3),C.envMap&&o.enable(4),C.normalMapObjectSpace&&o.enable(5),C.normalMapTangentSpace&&o.enable(6),C.clearcoat&&o.enable(7),C.iridescence&&o.enable(8),C.alphaTest&&o.enable(9),C.vertexColors&&o.enable(10),C.vertexAlphas&&o.enable(11),C.vertexUv1s&&o.enable(12),C.vertexUv2s&&o.enable(13),C.vertexUv3s&&o.enable(14),C.vertexTangents&&o.enable(15),C.anisotropy&&o.enable(16),C.alphaHash&&o.enable(17),C.batching&&o.enable(18),C.dispersion&&o.enable(19),C.retroreflection&&o.enable(24),C.batchingColor&&o.enable(20),C.gradientMap&&o.enable(21),C.packedNormalMap&&o.enable(22),C.vertexNormals&&o.enable(23),v.push(o.mask),o.disableAll(),C.fog&&o.enable(0),C.useFog&&o.enable(1),C.flatShading&&o.enable(2),C.logarithmicDepthBuffer&&o.enable(3),C.reversedDepthBuffer&&o.enable(4),C.skinning&&o.enable(5),C.morphTargets&&o.enable(6),C.morphNormals&&o.enable(7),C.morphColors&&o.enable(8),C.premultipliedAlpha&&o.enable(9),C.shadowMapEnabled&&o.enable(10),C.doubleSided&&o.enable(11),C.flipSided&&o.enable(12),C.useDepthPacking&&o.enable(13),C.dithering&&o.enable(14),C.transmission&&o.enable(15),C.sheen&&o.enable(16),C.opaque&&o.enable(17),C.pointsUvs&&o.enable(18),C.decodeVideoTexture&&o.enable(19),C.decodeVideoTextureEmissive&&o.enable(20),C.alphaToCoverage&&o.enable(21),C.numLightProbeGrids>0&&o.enable(22),C.hasPositionAttribute&&o.enable(23),v.push(o.mask)}function T(v){let C=f[v.type],z;if(C){let X=Zn[C];z=Xd.clone(X.uniforms)}else z=v.uniforms;return z}function y(v,C){let z=u.get(C);return z!==void 0?++z.usedTimes:(z=new rv(n,C,v,r),l.push(z),u.set(C,z)),z}function E(v){if(--v.usedTimes===0){let C=l.indexOf(v);l[C]=l[l.length-1],l.pop(),u.delete(v.cacheKey),v.destroy()}}function A(v){a.remove(v)}function U(){a.dispose()}return{getParameters:b,getProgramCacheKey:m,getUniforms:T,acquireProgram:y,releaseProgram:E,releaseShaderCache:A,programs:l,dispose:U}}function lv(){let n=new WeakMap;function e(o){return n.has(o)}function t(o){let a=n.get(o);return a===void 0&&(a={},n.set(o,a)),a}function i(o){n.delete(o)}function r(o,a,c){n.get(o)[a]=c}function s(){n=new WeakMap}return{has:e,get:t,remove:i,update:r,dispose:s}}function cv(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.materialVariant!==e.materialVariant?n.materialVariant-e.materialVariant:n.z!==e.z?n.z-e.z:n.id-e.id}function df(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function ff(){let n=[],e=0,t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function o(h){let f=0;return h.isInstancedMesh&&(f+=2),h.isSkinnedMesh&&(f+=1),f}function a(h,f,g,b,m,p){let S=n[e];return S===void 0?(S={id:h.id,object:h,geometry:f,material:g,materialVariant:o(h),groupOrder:b,renderOrder:h.renderOrder,z:m,group:p},n[e]=S):(S.id=h.id,S.object=h,S.geometry=f,S.material=g,S.materialVariant=o(h),S.groupOrder=b,S.renderOrder=h.renderOrder,S.z=m,S.group=p),e++,S}function c(h,f,g,b,m,p,S){S.reversedDepth===!0&&(m=-m);let T=a(h,f,g,b,m,p);g.transmission>0?i.push(T):g.transparent===!0?r.push(T):t.push(T)}function l(h,f,g,b,m,p){let S=a(h,f,g,b,m,p);g.transmission>0?i.unshift(S):g.transparent===!0?r.unshift(S):t.unshift(S)}function u(h,f){t.length>1&&t.sort(h||cv),i.length>1&&i.sort(f||df),r.length>1&&r.sort(f||df)}function d(){for(let h=e,f=n.length;h<f;h++){let g=n[h];if(g.id===null)break;g.id=null,g.object=null,g.geometry=null,g.material=null,g.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:c,unshift:l,finish:d,sort:u}}function hv(){let n=new WeakMap;function e(i,r){let s=n.get(i),o;return s===void 0?(o=new ff,n.set(i,[o])):r>=s.length?(o=new ff,s.push(o)):o=s[r],o}function t(){n=new WeakMap}return{get:e,dispose:t}}function uv(){let n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={direction:new O,color:new He};break;case"SpotLight":t={position:new O,direction:new O,color:new He,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new O,color:new He,distance:0,decay:0};break;case"HemisphereLight":t={direction:new O,skyColor:new He,groundColor:new He};break;case"RectAreaLight":t={color:new He,position:new O,halfWidth:new O,halfHeight:new O};break}return n[e.id]=t,t}}}function dv(){let n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"SunLight":case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}var fv=0;function pv(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function mv(n){let e=new uv,t=dv(),i={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let l=0;l<9;l++)i.probe.push(new O);let r=new O,s=new vt,o=new vt;function a(l){let u=0,d=0,h=0;for(let W=0;W<9;W++)i.probe[W].set(0,0,0);let f=0,g=0,b=0,m=0,p=0,S=0,T=0,y=0,E=0,A=0,U=0,v=0,C=0,z=0;l.sort(pv);for(let W=0,re=l.length;W<re;W++){let G=l[W],se=G.color,_e=G.intensity,ee=G.distance,Y=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===Li?Y=G.shadow.map.texture:Y=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)u+=se.r*_e,d+=se.g*_e,h+=se.b*_e;else if(G.isLightProbe){for(let he=0;he<9;he++)i.probe[he].addScaledVector(G.sh.coefficients[he],_e);z++}else if(G.isSunLight){let he=e.get(G);if(he.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){let de=G.shadow,ye=t.get(G);ye.shadowIntensity=de.intensity,ye.shadowBias=de.bias,ye.shadowNormalBias=de.normalBias,ye.shadowRadius=de.radius,ye.shadowMapSize.copy(de.mapSize).multiply(de.getFrameExtents()),i.sunShadow[g]=ye,i.sunShadowMap[g]=Y;let Oe=de.getViewportCount();for(let Ne=0;Ne<Oe;Ne++)i.sunShadowMatrix[b+Ne]=de.getMatrix(Ne),i.sunShadowCascade[b+Ne]=de._cascadeData[Ne];b+=Oe,g++}i.sun[f]=he,f++}else if(G.isDirectionalLight){let he=e.get(G);if(he.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){let de=G.shadow,ye=t.get(G);ye.shadowIntensity=de.intensity,ye.shadowBias=de.bias,ye.shadowNormalBias=de.normalBias,ye.shadowRadius=de.radius,ye.shadowMapSize=de.mapSize,i.directionalShadow[m]=ye,i.directionalShadowMap[m]=Y,i.directionalShadowMatrix[m]=G.shadow.matrix,E++}i.directional[m]=he,m++}else if(G.isSpotLight){let he=e.get(G);he.position.setFromMatrixPosition(G.matrixWorld),he.color.copy(se).multiplyScalar(_e),he.distance=ee,he.coneCos=Math.cos(G.angle),he.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),he.decay=G.decay,i.spot[S]=he;let de=G.shadow;if(G.map&&(i.spotLightMap[v]=G.map,v++,de.updateMatrices(G),G.castShadow&&C++),i.spotLightMatrix[S]=de.matrix,G.castShadow){let ye=t.get(G);ye.shadowIntensity=de.intensity,ye.shadowBias=de.bias,ye.shadowNormalBias=de.normalBias,ye.shadowRadius=de.radius,ye.shadowMapSize=de.mapSize,i.spotShadow[S]=ye,i.spotShadowMap[S]=Y,U++}S++}else if(G.isRectAreaLight){let he=e.get(G);he.color.copy(se).multiplyScalar(_e),he.halfWidth.set(G.width*.5,0,0),he.halfHeight.set(0,G.height*.5,0),i.rectArea[T]=he,T++}else if(G.isPointLight){let he=e.get(G);if(he.color.copy(G.color).multiplyScalar(G.intensity),he.distance=G.distance,he.decay=G.decay,G.castShadow){let de=G.shadow,ye=t.get(G);ye.shadowIntensity=de.intensity,ye.shadowBias=de.bias,ye.shadowNormalBias=de.normalBias,ye.shadowRadius=de.radius,ye.shadowMapSize=de.mapSize,ye.shadowCameraNear=de.camera.near,ye.shadowCameraFar=de.camera.far,i.pointShadow[p]=ye,i.pointShadowMap[p]=Y,i.pointShadowMatrix[p]=G.shadow.matrix,A++}i.point[p]=he,p++}else if(G.isHemisphereLight){let he=e.get(G);he.skyColor.copy(G.color).multiplyScalar(_e),he.groundColor.copy(G.groundColor).multiplyScalar(_e),i.hemi[y]=he,y++}}T>0&&(n.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=Re.LTC_FLOAT_1,i.rectAreaLTC2=Re.LTC_FLOAT_2):(i.rectAreaLTC1=Re.LTC_HALF_1,i.rectAreaLTC2=Re.LTC_HALF_2)),i.ambient[0]=u,i.ambient[1]=d,i.ambient[2]=h;let X=i.hash;(X.sunLength!==f||X.directionalLength!==m||X.pointLength!==p||X.spotLength!==S||X.rectAreaLength!==T||X.hemiLength!==y||X.numSunShadows!==g||X.numDirectionalShadows!==E||X.numPointShadows!==A||X.numSpotShadows!==U||X.numSpotMaps!==v||X.numLightProbes!==z)&&(i.sun.length=f,i.directional.length=m,i.spot.length=S,i.rectArea.length=T,i.point.length=p,i.hemi.length=y,i.sunShadow.length=g,i.sunShadowMap.length=g,i.sunShadowMatrix.length=b,i.sunShadowCascade.length=b,i.directionalShadow.length=E,i.directionalShadowMap.length=E,i.directionalShadowMatrix.length=E,i.pointShadow.length=A,i.pointShadowMap.length=A,i.pointShadowMatrix.length=A,i.spotShadow.length=U,i.spotShadowMap.length=U,i.spotLightMatrix.length=U+v-C,i.spotLightMap.length=v,i.numSpotLightShadowsWithMaps=C,i.numLightProbes=z,X.sunLength=f,X.directionalLength=m,X.pointLength=p,X.spotLength=S,X.rectAreaLength=T,X.hemiLength=y,X.numSunShadows=g,X.numDirectionalShadows=E,X.numPointShadows=A,X.numSpotShadows=U,X.numSpotMaps=v,X.numLightProbes=z,i.version=fv++)}function c(l,u){let d=0,h=0,f=0,g=0,b=0,m=0,p=u.matrixWorldInverse;for(let S=0,T=l.length;S<T;S++){let y=l[S];if(y.isSunLight){let E=i.sun[d];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(p),d++}else if(y.isDirectionalLight){let E=i.directional[h];E.direction.setFromMatrixPosition(y.matrixWorld),r.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(p),h++}else if(y.isSpotLight){let E=i.spot[g];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(p),E.direction.setFromMatrixPosition(y.matrixWorld),r.setFromMatrixPosition(y.target.matrixWorld),E.direction.sub(r),E.direction.transformDirection(p),g++}else if(y.isRectAreaLight){let E=i.rectArea[b];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(p),o.identity(),s.copy(y.matrixWorld),s.premultiply(p),o.extractRotation(s),E.halfWidth.set(y.width*.5,0,0),E.halfHeight.set(0,y.height*.5,0),E.halfWidth.applyMatrix4(o),E.halfHeight.applyMatrix4(o),b++}else if(y.isPointLight){let E=i.point[f];E.position.setFromMatrixPosition(y.matrixWorld),E.position.applyMatrix4(p),f++}else if(y.isHemisphereLight){let E=i.hemi[m];E.direction.setFromMatrixPosition(y.matrixWorld),E.direction.transformDirection(p),m++}}}return{setup:a,setupView:c,state:i}}function pf(n){let e=new mv(n),t=[],i=[],r=[];function s(h){d.camera=h,t.length=0,i.length=0,r.length=0}function o(h){t.push(h)}function a(h){i.push(h)}function c(h){r.push(h)}function l(){e.setup(t)}function u(h){e.setupView(t,h)}let d={lightsArray:t,shadowsArray:i,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:s,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:a,pushLightProbeGrid:c}}function gv(n){let e=new WeakMap;function t(r,s=0){let o=e.get(r),a;return o===void 0?(a=new pf(n),e.set(r,[a])):s>=o.length?(a=new pf(n),o.push(a)):a=o[s],a}function i(){e=new WeakMap}return{get:t,dispose:i}}var _v=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,yv=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,vv=[new O(1,0,0),new O(-1,0,0),new O(0,1,0),new O(0,-1,0),new O(0,0,1),new O(0,0,-1)],xv=[new O(0,-1,0),new O(0,-1,0),new O(0,0,1),new O(0,0,-1),new O(0,-1,0),new O(0,-1,0)],mf=new vt,fo=new O,Ch=new O;function bv(n,e,t){let i=new Xr,r=new be,s=new be,o=new St,a=new Da,c=new La,l={},u=t.maxTextureSize,d={[Ri]:Gt,[Gt]:Ri,[nn]:nn},h=new Ht({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new be},radius:{value:4}},vertexShader:_v,fragmentShader:yv}),f=h.clone();f.defines.HORIZONTAL_PASS=1;let g=new wt;g.setAttribute("position",new Ct(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let b=new zt(g,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=nr;let p=this.type;this.render=function(A,U,v){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||A.length===0)return;this.type===rd&&(qe("WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead."),this.type=nr);let C=n.getRenderTarget(),z=n.getActiveCubeFace(),X=n.getActiveMipmapLevel(),W=n.state;W.setBlending($n),W.buffers.depth.getReversed()===!0?W.buffers.color.setClear(0,0,0,0):W.buffers.color.setClear(1,1,1,1),W.buffers.depth.setTest(!0),W.setScissorTest(!1);let re=p!==this.type;re&&U.traverse(function(G){G.material&&(Array.isArray(G.material)?G.material.forEach(se=>se.needsUpdate=!0):G.material.needsUpdate=!0)});for(let G=0,se=A.length;G<se;G++){let _e=A[G],ee=_e.shadow;if(ee===void 0){qe("WebGLShadowMap:",_e,"has no shadow.");continue}if(ee.autoUpdate===!1&&ee.needsUpdate===!1)continue;r.copy(ee.mapSize);let Y=ee.getFrameExtents();r.multiply(Y),s.copy(ee.mapSize),(r.x>u||r.y>u)&&(r.x>u&&(s.x=Math.floor(u/Y.x),r.x=s.x*Y.x,ee.mapSize.x=s.x),r.y>u&&(s.y=Math.floor(u/Y.y),r.y=s.y*Y.y,ee.mapSize.y=s.y));let he=n.state.buffers.depth.getReversed();if(ee.camera._reversedDepth=he,ee.map===null||re===!0){if(ee.map!==null&&(ee.map.depthTexture!==null&&(ee.map.depthTexture.dispose(),ee.map.depthTexture=null),ee.map.dispose()),this.type===Jr){if(_e.isPointLight){qe("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}ee.map=new sn(r.x,r.y,{format:Li,type:Fn,minFilter:Nt,magFilter:Nt,generateMipmaps:!1}),ee.map.texture.name=_e.name+".shadowMap",ee.map.depthTexture=new xi(r.x,r.y,Un),ee.map.depthTexture.name=_e.name+".shadowMapDepth",ee.map.depthTexture.format=Xn,ee.map.depthTexture.compareFunction=null,ee.map.depthTexture.minFilter=Dt,ee.map.depthTexture.magFilter=Dt}else _e.isPointLight?(ee.map=new Fl(r.x),ee.map.depthTexture=new Sa(r.x,Nn)):(ee.map=new sn(r.x,r.y),ee.map.depthTexture=new xi(r.x,r.y,Nn)),ee.map.depthTexture.name=_e.name+".shadowMap",ee.map.depthTexture.format=Xn,this.type===nr?(ee.map.depthTexture.compareFunction=he?Dl:Il,ee.map.depthTexture.minFilter=Nt,ee.map.depthTexture.magFilter=Nt):(ee.map.depthTexture.compareFunction=null,ee.map.depthTexture.minFilter=Dt,ee.map.depthTexture.magFilter=Dt);ee.camera.updateProjectionMatrix()}ee.map.isWebGLCubeRenderTarget!==!0&&(ee.map.width!==r.x||ee.map.height!==r.y)&&ee.map.setSize(r.x,r.y);let de=ee.map.isWebGLCubeRenderTarget?6:ee.getViewportCount();_e.isPointLight!==!0&&ee.updateMatrices(_e,v);for(let ye=0;ye<de;ye++){let Oe=ee.getCamera(ye);if(_e.isPointLight){let Ne=ee.camera,Ke=ee.matrix,Ze=_e.distance||Ne.far;Ze!==Ne.far&&(Ne.far=Ze,Ne.updateProjectionMatrix()),fo.setFromMatrixPosition(_e.matrixWorld),Ne.position.copy(fo),Ch.copy(Ne.position),Ch.add(vv[ye]),Ne.up.copy(xv[ye]),Ne.lookAt(Ch),Ne.updateMatrixWorld(),Ke.makeTranslation(-fo.x,-fo.y,-fo.z),mf.multiplyMatrices(Ne.projectionMatrix,Ne.matrixWorldInverse),ee._frustum.setFromProjectionMatrix(mf,Ne.coordinateSystem,Ne.reversedDepth)}if(ee.map.isWebGLCubeRenderTarget)n.setRenderTarget(ee.map,ye),n.clear();else{ye===0&&(n.setRenderTarget(ee.map),n.clear());let Ne=ee.getViewport(ye);o.set(s.x*Ne.x,s.y*Ne.y,s.x*Ne.z,s.y*Ne.w),W.viewport(o)}i=ee.getFrustum(ye),y(U,v,Oe,_e,this.type)}ee.isPointLightShadow!==!0&&this.type===Jr&&S(ee,v),ee.needsUpdate=!1}p=this.type,m.needsUpdate=!1,n.setRenderTarget(C,z,X)};function S(A,U){let v=e.update(b);h.defines.VSM_SAMPLES!==A.blurSamples&&(h.defines.VSM_SAMPLES=A.blurSamples,f.defines.VSM_SAMPLES=A.blurSamples,h.needsUpdate=!0,f.needsUpdate=!0),A.mapPass===null?A.mapPass=new sn(r.x,r.y,{format:Li,type:Fn}):(A.mapPass.width!==A.map.width||A.mapPass.height!==A.map.height)&&A.mapPass.setSize(A.map.width,A.map.height),h.uniforms.shadow_pass.value=A.map.depthTexture,h.uniforms.resolution.value.set(A.map.width,A.map.height),h.uniforms.radius.value=A.radius,n.setRenderTarget(A.mapPass),n.clear(),n.renderBufferDirect(U,null,v,h,b,null),f.uniforms.shadow_pass.value=A.mapPass.texture,f.uniforms.resolution.value.set(A.map.width,A.map.height),f.uniforms.radius.value=A.radius,n.setRenderTarget(A.map),n.clear(),n.renderBufferDirect(U,null,v,f,b,null)}function T(A,U,v,C){let z=null,X=v.isPointLight===!0?A.customDistanceMaterial:A.customDepthMaterial;if(X!==void 0)z=X;else if(z=v.isPointLight===!0?c:a,n.localClippingEnabled&&U.clipShadows===!0&&Array.isArray(U.clippingPlanes)&&U.clippingPlanes.length!==0||U.displacementMap&&U.displacementScale!==0||U.alphaMap&&U.alphaTest>0||U.map&&U.alphaTest>0||U.alphaToCoverage===!0){let W=z.uuid,re=U.uuid,G=l[W];G===void 0&&(G={},l[W]=G);let se=G[re];se===void 0&&(se=z.clone(),G[re]=se,U.addEventListener("dispose",E)),z=se}if(z.visible=U.visible,z.wireframe=U.wireframe,C===Jr?z.side=U.shadowSide!==null?U.shadowSide:U.side:z.side=U.shadowSide!==null?U.shadowSide:d[U.side],z.alphaMap=U.alphaMap,z.alphaTest=U.alphaToCoverage===!0?.5:U.alphaTest,z.map=U.map,z.clipShadows=U.clipShadows,z.clippingPlanes=U.clippingPlanes,z.clipIntersection=U.clipIntersection,z.displacementMap=U.displacementMap,z.displacementScale=U.displacementScale,z.displacementBias=U.displacementBias,z.wireframeLinewidth=U.wireframeLinewidth,z.linewidth=U.linewidth,v.isPointLight===!0&&z.isMeshDistanceMaterial===!0){let W=n.properties.get(z);W.light=v}return z}function y(A,U,v,C,z){if(A.visible===!1)return;if(A.layers.test(U.layers)&&(A.isMesh||A.isLine||A.isPoints)&&(A.castShadow||A.receiveShadow&&z===Jr)&&(!A.frustumCulled||A.intersectsFrustum(i))){A.modelViewMatrix.multiplyMatrices(v.matrixWorldInverse,A.matrixWorld);let re=e.update(A),G=A.material;if(Array.isArray(G)){let se=re.groups;for(let _e=0,ee=se.length;_e<ee;_e++){let Y=se[_e],he=G[Y.materialIndex];if(he&&he.visible){let de=T(A,he,C,z);A.onBeforeShadow(n,A,U,v,re,de,Y),n.renderBufferDirect(v,null,re,de,A,Y),A.onAfterShadow(n,A,U,v,re,de,Y)}}}else if(G.visible){let se=T(A,G,C,z);A.onBeforeShadow(n,A,U,v,re,se,null),n.renderBufferDirect(v,null,re,se,A,null),A.onAfterShadow(n,A,U,v,re,se,null)}}let W=A.children;for(let re=0,G=W.length;re<G;re++)y(W[re],U,v,C,z)}function E(A){A.target.removeEventListener("dispose",E);for(let v in l){let C=l[v],z=A.target.uuid;z in C&&(C[z].dispose(),delete C[z])}}}function Mv(n,e){function t(){let V=!1,Ee=new St,ve=null,Ae=new St(0,0,0,0);return{setMask:function(Ce){ve!==Ce&&!V&&(n.colorMask(Ce,Ce,Ce,Ce),ve=Ce)},setLocked:function(Ce){V=Ce},setClear:function(Ce,xe,We,ke,ft){ft===!0&&(Ce*=ke,xe*=ke,We*=ke),Ee.set(Ce,xe,We,ke),Ae.equals(Ee)===!1&&(n.clearColor(Ce,xe,We,ke),Ae.copy(Ee))},reset:function(){V=!1,ve=null,Ae.set(-1,0,0,0)}}}function i(){let V=!1,Ee=!1,ve=null,Ae=null,Ce=null;return{setReversed:function(xe){if(Ee!==xe){let We=e.get("EXT_clip_control");xe?We.clipControlEXT(We.LOWER_LEFT_EXT,We.ZERO_TO_ONE_EXT):We.clipControlEXT(We.LOWER_LEFT_EXT,We.NEGATIVE_ONE_TO_ONE_EXT),Ee=xe;let ke=Ce;Ce=null,this.setClear(ke)}},getReversed:function(){return Ee},setTest:function(xe){xe?D(n.DEPTH_TEST):L(n.DEPTH_TEST)},setMask:function(xe){ve!==xe&&!V&&(n.depthMask(xe),ve=xe)},setFunc:function(xe){if(Ee&&(xe=Bd[xe]),Ae!==xe){switch(xe){case la:n.depthFunc(n.NEVER);break;case ca:n.depthFunc(n.ALWAYS);break;case ha:n.depthFunc(n.LESS);break;case Fr:n.depthFunc(n.LEQUAL);break;case ua:n.depthFunc(n.EQUAL);break;case da:n.depthFunc(n.GEQUAL);break;case fa:n.depthFunc(n.GREATER);break;case pa:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}Ae=xe}},setLocked:function(xe){V=xe},setClear:function(xe){Ce!==xe&&(Ce=xe,Ee&&(xe=1-xe),n.clearDepth(xe))},reset:function(){V=!1,ve=null,Ae=null,Ce=null,Ee=!1}}}function r(){let V=!1,Ee=null,ve=null,Ae=null,Ce=null,xe=null,We=null,ke=null,ft=null;return{setTest:function(at){V||(at?D(n.STENCIL_TEST):L(n.STENCIL_TEST))},setMask:function(at){Ee!==at&&!V&&(n.stencilMask(at),Ee=at)},setFunc:function(at,un,rn){(ve!==at||Ae!==un||Ce!==rn)&&(n.stencilFunc(at,un,rn),ve=at,Ae=un,Ce=rn)},setOp:function(at,un,rn){(xe!==at||We!==un||ke!==rn)&&(n.stencilOp(at,un,rn),xe=at,We=un,ke=rn)},setLocked:function(at){V=at},setClear:function(at){ft!==at&&(n.clearStencil(at),ft=at)},reset:function(){V=!1,Ee=null,ve=null,Ae=null,Ce=null,xe=null,We=null,ke=null,ft=null}}}let s=new t,o=new i,a=new r,c=new WeakMap,l=new WeakMap,u={},d={},h={},f=new WeakMap,g=[],b=null,m=!1,p=null,S=null,T=null,y=null,E=null,A=null,U=null,v=new He(0,0,0),C=0,z=!1,X=null,W=null,re=null,G=null,se=null,_e=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS),ee=!1,Y=0,he=n.getParameter(n.VERSION);he.indexOf("WebGL")!==-1?(Y=parseFloat(/^WebGL (\d)/.exec(he)[1]),ee=Y>=1):he.indexOf("OpenGL ES")!==-1&&(Y=parseFloat(/^OpenGL ES (\d)/.exec(he)[1]),ee=Y>=2);let de=null,ye={},Oe=n.getParameter(n.SCISSOR_BOX),Ne=n.getParameter(n.VIEWPORT),Ke=new St().fromArray(Oe),Ze=new St().fromArray(Ne);function Je(V,Ee,ve,Ae){let Ce=new Uint8Array(4),xe=n.createTexture();n.bindTexture(V,xe),n.texParameteri(V,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(V,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let We=0;We<ve;We++)V===n.TEXTURE_3D||V===n.TEXTURE_2D_ARRAY?n.texImage3D(Ee,0,n.RGBA,1,1,Ae,0,n.RGBA,n.UNSIGNED_BYTE,Ce):n.texImage2D(Ee+We,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Ce);return xe}let F={};F[n.TEXTURE_2D]=Je(n.TEXTURE_2D,n.TEXTURE_2D,1),F[n.TEXTURE_CUBE_MAP]=Je(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),F[n.TEXTURE_2D_ARRAY]=Je(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),F[n.TEXTURE_3D]=Je(n.TEXTURE_3D,n.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),D(n.DEPTH_TEST),o.setFunc(Fr),pe(!1),me($c),D(n.CULL_FACE),ae($n);function D(V){u[V]!==!0&&(n.enable(V),u[V]=!0)}function L(V){u[V]!==!1&&(n.disable(V),u[V]=!1)}function R(V,Ee){return h[V]!==Ee?(n.bindFramebuffer(V,Ee),h[V]=Ee,V===n.DRAW_FRAMEBUFFER&&(h[n.FRAMEBUFFER]=Ee),V===n.FRAMEBUFFER&&(h[n.DRAW_FRAMEBUFFER]=Ee),!0):!1}function k(V,Ee){let ve=g,Ae=!1;if(V){ve=f.get(Ee),ve===void 0&&(ve=[],f.set(Ee,ve));let Ce=V.textures;if(ve.length!==Ce.length||ve[0]!==n.COLOR_ATTACHMENT0){for(let xe=0,We=Ce.length;xe<We;xe++)ve[xe]=n.COLOR_ATTACHMENT0+xe;ve.length=Ce.length,Ae=!0}}else ve[0]!==n.BACK&&(ve[0]=n.BACK,Ae=!0);Ae&&n.drawBuffers(ve)}function le(V){return b!==V?(n.useProgram(V),b=V,!0):!1}let Se={[ir]:n.FUNC_ADD,[od]:n.FUNC_SUBTRACT,[ad]:n.FUNC_REVERSE_SUBTRACT};Se[ld]=n.MIN,Se[cd]=n.MAX;let B={[hd]:n.ZERO,[ud]:n.ONE,[dd]:n.SRC_COLOR,[Kc]:n.SRC_ALPHA,[yd]:n.SRC_ALPHA_SATURATE,[gd]:n.DST_COLOR,[pd]:n.DST_ALPHA,[fd]:n.ONE_MINUS_SRC_COLOR,[Qc]:n.ONE_MINUS_SRC_ALPHA,[_d]:n.ONE_MINUS_DST_COLOR,[md]:n.ONE_MINUS_DST_ALPHA,[vd]:n.CONSTANT_COLOR,[xd]:n.ONE_MINUS_CONSTANT_COLOR,[bd]:n.CONSTANT_ALPHA,[Md]:n.ONE_MINUS_CONSTANT_ALPHA};function ae(V,Ee,ve,Ae,Ce,xe,We,ke,ft,at){if(V===$n){m===!0&&(L(n.BLEND),m=!1);return}if(m===!1&&(D(n.BLEND),m=!0),V!==sd){if(V!==p||at!==z){if((S!==ir||E!==ir)&&(n.blendEquation(n.FUNC_ADD),S=ir,E=ir),at)switch(V){case Kr:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Yc:n.blendFunc(n.ONE,n.ONE);break;case Zc:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Jc:n.blendFuncSeparate(n.DST_COLOR,n.ONE_MINUS_SRC_ALPHA,n.ZERO,n.ONE);break;default:Ye("WebGLState: Invalid blending: ",V);break}else switch(V){case Kr:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Yc:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE,n.ONE,n.ONE);break;case Zc:Ye("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Jc:Ye("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ye("WebGLState: Invalid blending: ",V);break}T=null,y=null,A=null,U=null,v.set(0,0,0),C=0,p=V,z=at}return}Ce=Ce||Ee,xe=xe||ve,We=We||Ae,(Ee!==S||Ce!==E)&&(n.blendEquationSeparate(Se[Ee],Se[Ce]),S=Ee,E=Ce),(ve!==T||Ae!==y||xe!==A||We!==U)&&(n.blendFuncSeparate(B[ve],B[Ae],B[xe],B[We]),T=ve,y=Ae,A=xe,U=We),(ke.equals(v)===!1||ft!==C)&&(n.blendColor(ke.r,ke.g,ke.b,ft),v.copy(ke),C=ft),p=V,z=!1}function Z(V,Ee){V.side===nn?L(n.CULL_FACE):D(n.CULL_FACE);let ve=V.side===Gt;Ee&&(ve=!ve),pe(ve),V.blending===Kr&&V.transparent===!1?ae($n):ae(V.blending,V.blendEquation,V.blendSrc,V.blendDst,V.blendEquationAlpha,V.blendSrcAlpha,V.blendDstAlpha,V.blendColor,V.blendAlpha,V.premultipliedAlpha),o.setFunc(V.depthFunc),o.setTest(V.depthTest),o.setMask(V.depthWrite),s.setMask(V.colorWrite);let Ae=V.stencilWrite;a.setTest(Ae),Ae&&(a.setMask(V.stencilWriteMask),a.setFunc(V.stencilFunc,V.stencilRef,V.stencilFuncMask),a.setOp(V.stencilFail,V.stencilZFail,V.stencilZPass)),Le(V.polygonOffset,V.polygonOffsetFactor,V.polygonOffsetUnits),V.alphaToCoverage===!0?D(n.SAMPLE_ALPHA_TO_COVERAGE):L(n.SAMPLE_ALPHA_TO_COVERAGE)}function pe(V){X!==V&&(V?n.frontFace(n.CW):n.frontFace(n.CCW),X=V)}function me(V){V!==nd?(D(n.CULL_FACE),V!==W&&(V===$c?n.cullFace(n.BACK):V===id?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):L(n.CULL_FACE),W=V}function Me(V){V!==re&&(ee&&n.lineWidth(V),re=V)}function Le(V,Ee,ve){V?(D(n.POLYGON_OFFSET_FILL),(G!==Ee||se!==ve)&&(G=Ee,se=ve,o.getReversed()&&(Ee=-Ee),n.polygonOffset(Ee,ve))):L(n.POLYGON_OFFSET_FILL)}function Te(V){V?D(n.SCISSOR_TEST):L(n.SCISSOR_TEST)}function K(V){V===void 0&&(V=n.TEXTURE0+_e-1),de!==V&&(n.activeTexture(V),de=V)}function x(V,Ee,ve){ve===void 0&&(de===null?ve=n.TEXTURE0+_e-1:ve=de);let Ae=ye[ve];Ae===void 0&&(Ae={type:void 0,texture:void 0},ye[ve]=Ae),(Ae.type!==V||Ae.texture!==Ee)&&(de!==ve&&(n.activeTexture(ve),de=ve),n.bindTexture(V,Ee||F[V]),Ae.type=V,Ae.texture=Ee)}function Be(){let V=ye[de];V!==void 0&&V.type!==void 0&&(n.bindTexture(V.type,null),V.type=void 0,V.texture=void 0)}function Xe(){try{n.compressedTexImage2D(...arguments)}catch(V){Ye("WebGLState:",V)}}function P(){try{n.compressedTexImage3D(...arguments)}catch(V){Ye("WebGLState:",V)}}function _(){try{n.texSubImage2D(...arguments)}catch(V){Ye("WebGLState:",V)}}function j(){try{n.texSubImage3D(...arguments)}catch(V){Ye("WebGLState:",V)}}function w(){try{n.compressedTexSubImage2D(...arguments)}catch(V){Ye("WebGLState:",V)}}function N(){try{n.compressedTexSubImage3D(...arguments)}catch(V){Ye("WebGLState:",V)}}function J(){try{n.texStorage2D(...arguments)}catch(V){Ye("WebGLState:",V)}}function oe(){try{n.texStorage3D(...arguments)}catch(V){Ye("WebGLState:",V)}}function $(){try{n.texImage2D(...arguments)}catch(V){Ye("WebGLState:",V)}}function q(){try{n.texImage3D(...arguments)}catch(V){Ye("WebGLState:",V)}}function fe(V){return d[V]!==void 0?d[V]:n.getParameter(V)}function ge(V,Ee){d[V]!==Ee&&(n.pixelStorei(V,Ee),d[V]=Ee)}function te(V){Ke.equals(V)===!1&&(n.scissor(V.x,V.y,V.z,V.w),Ke.copy(V))}function ce(V){Ze.equals(V)===!1&&(n.viewport(V.x,V.y,V.z,V.w),Ze.copy(V))}function we(V,Ee){let ve=l.get(Ee);ve===void 0&&(ve=new WeakMap,l.set(Ee,ve));let Ae=ve.get(V);Ae===void 0&&(Ae=n.getUniformBlockIndex(Ee,V.name),ve.set(V,Ae))}function Pe(V,Ee){let Ae=l.get(Ee).get(V);c.get(Ee)!==Ae&&(n.uniformBlockBinding(Ee,Ae,V.__bindingPointIndex),c.set(Ee,Ae))}function $e(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),o.setReversed(!1),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),n.pixelStorei(n.PACK_ALIGNMENT,4),n.pixelStorei(n.UNPACK_ALIGNMENT,4),n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,!1),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,n.BROWSER_DEFAULT_WEBGL),n.pixelStorei(n.PACK_ROW_LENGTH,0),n.pixelStorei(n.PACK_SKIP_PIXELS,0),n.pixelStorei(n.PACK_SKIP_ROWS,0),n.pixelStorei(n.UNPACK_ROW_LENGTH,0),n.pixelStorei(n.UNPACK_IMAGE_HEIGHT,0),n.pixelStorei(n.UNPACK_SKIP_PIXELS,0),n.pixelStorei(n.UNPACK_SKIP_ROWS,0),n.pixelStorei(n.UNPACK_SKIP_IMAGES,0),u={},d={},de=null,ye={},h={},f=new WeakMap,g=[],b=null,m=!1,p=null,S=null,T=null,y=null,E=null,A=null,U=null,v=new He(0,0,0),C=0,z=!1,X=null,W=null,re=null,G=null,se=null,Ke.set(0,0,n.canvas.width,n.canvas.height),Ze.set(0,0,n.canvas.width,n.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:D,disable:L,bindFramebuffer:R,drawBuffers:k,useProgram:le,setBlending:ae,setMaterial:Z,setFlipSided:pe,setCullFace:me,setLineWidth:Me,setPolygonOffset:Le,setScissorTest:Te,activeTexture:K,bindTexture:x,unbindTexture:Be,compressedTexImage2D:Xe,compressedTexImage3D:P,texImage2D:$,texImage3D:q,pixelStorei:ge,getParameter:fe,updateUBOMapping:we,uniformBlockBinding:Pe,texStorage2D:J,texStorage3D:oe,texSubImage2D:_,texSubImage3D:j,compressedTexSubImage2D:w,compressedTexSubImage3D:N,scissor:te,viewport:ce,reset:$e}}function Sv(n,e,t,i,r,s,o){let a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),l=new be,u=new WeakMap,d=new Set,h,f=new WeakMap,g=!1;try{g=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function b(P,_){return g?new OffscreenCanvas(P,_):Cs("canvas")}function m(P,_,j){let w=1,N=Xe(P);if((N.width>j||N.height>j)&&(w=j/Math.max(N.width,N.height)),w<1)if(typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&P instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&P instanceof ImageBitmap||typeof VideoFrame<"u"&&P instanceof VideoFrame){let J=Math.floor(w*N.width),oe=Math.floor(w*N.height);h===void 0&&(h=b(J,oe));let $=_?b(J,oe):h;return $.width=J,$.height=oe,$.getContext("2d").drawImage(P,0,0,J,oe),qe("WebGLRenderer: Texture has been resized from ("+N.width+"x"+N.height+") to ("+J+"x"+oe+")."),$}else return"data"in P&&qe("WebGLRenderer: Image in DataTexture is too big ("+N.width+"x"+N.height+")."),P;return P}function p(P){return P.generateMipmaps}function S(P){n.generateMipmap(P)}function T(P){return P.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:P.isWebGL3DRenderTarget?n.TEXTURE_3D:P.isWebGLArrayRenderTarget||P.isCompressedArrayTexture?n.TEXTURE_2D_ARRAY:n.TEXTURE_2D}function y(P,_,j,w,N,J=!1){if(P!==null){if(n[P]!==void 0)return n[P];qe("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+P+"'")}let oe;w&&(oe=e.get("EXT_texture_norm16"),oe||qe("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let $=_;if(_===n.RED&&(j===n.FLOAT&&($=n.R32F),j===n.HALF_FLOAT&&($=n.R16F),j===n.UNSIGNED_BYTE&&($=n.R8),j===n.UNSIGNED_SHORT&&oe&&($=oe.R16_EXT),j===n.SHORT&&oe&&($=oe.R16_SNORM_EXT)),_===n.RED_INTEGER&&(j===n.UNSIGNED_BYTE&&($=n.R8UI),j===n.UNSIGNED_SHORT&&($=n.R16UI),j===n.UNSIGNED_INT&&($=n.R32UI),j===n.BYTE&&($=n.R8I),j===n.SHORT&&($=n.R16I),j===n.INT&&($=n.R32I)),_===n.RG&&(j===n.FLOAT&&($=n.RG32F),j===n.HALF_FLOAT&&($=n.RG16F),j===n.UNSIGNED_BYTE&&($=n.RG8),j===n.UNSIGNED_SHORT&&oe&&($=oe.RG16_EXT),j===n.SHORT&&oe&&($=oe.RG16_SNORM_EXT)),_===n.RG_INTEGER&&(j===n.UNSIGNED_BYTE&&($=n.RG8UI),j===n.UNSIGNED_SHORT&&($=n.RG16UI),j===n.UNSIGNED_INT&&($=n.RG32UI),j===n.BYTE&&($=n.RG8I),j===n.SHORT&&($=n.RG16I),j===n.INT&&($=n.RG32I)),_===n.RGB_INTEGER&&(j===n.UNSIGNED_BYTE&&($=n.RGB8UI),j===n.UNSIGNED_SHORT&&($=n.RGB16UI),j===n.UNSIGNED_INT&&($=n.RGB32UI),j===n.BYTE&&($=n.RGB8I),j===n.SHORT&&($=n.RGB16I),j===n.INT&&($=n.RGB32I)),_===n.RGBA_INTEGER&&(j===n.UNSIGNED_BYTE&&($=n.RGBA8UI),j===n.UNSIGNED_SHORT&&($=n.RGBA16UI),j===n.UNSIGNED_INT&&($=n.RGBA32UI),j===n.BYTE&&($=n.RGBA8I),j===n.SHORT&&($=n.RGBA16I),j===n.INT&&($=n.RGBA32I)),_===n.RGB&&(j===n.UNSIGNED_SHORT&&oe&&($=oe.RGB16_EXT),j===n.SHORT&&oe&&($=oe.RGB16_SNORM_EXT),j===n.UNSIGNED_INT_5_9_9_9_REV&&($=n.RGB9_E5),j===n.UNSIGNED_INT_10F_11F_11F_REV&&($=n.R11F_G11F_B10F)),_===n.RGBA){let q=J?As:rt.getTransfer(N);j===n.FLOAT&&($=n.RGBA32F),j===n.HALF_FLOAT&&($=n.RGBA16F),j===n.UNSIGNED_BYTE&&($=q===ct?n.SRGB8_ALPHA8:n.RGBA8),j===n.UNSIGNED_SHORT&&oe&&($=oe.RGBA16_EXT),j===n.SHORT&&oe&&($=oe.RGBA16_SNORM_EXT),j===n.UNSIGNED_SHORT_4_4_4_4&&($=n.RGBA4),j===n.UNSIGNED_SHORT_5_5_5_1&&($=n.RGB5_A1)}return($===n.R16F||$===n.R32F||$===n.RG16F||$===n.RG32F||$===n.RGBA16F||$===n.RGBA32F)&&e.get("EXT_color_buffer_float"),$}function E(P,_){let j;return P?_===null||_===Nn||_===es?j=n.DEPTH24_STENCIL8:_===Un?j=n.DEPTH32F_STENCIL8:_===Qr&&(j=n.DEPTH24_STENCIL8,qe("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):_===null||_===Nn||_===es?j=n.DEPTH_COMPONENT24:_===Un?j=n.DEPTH_COMPONENT32F:_===Qr&&(j=n.DEPTH_COMPONENT16),j}function A(P,_){return p(P)===!0||P.isFramebufferTexture&&P.minFilter!==Dt&&P.minFilter!==Nt?Math.log2(Math.max(_.width,_.height))+1:P.mipmaps!==void 0&&P.mipmaps.length>0?P.mipmaps.length:P.isCompressedTexture&&Array.isArray(P.image)?_.mipmaps.length:1}function U(P){let _=P.target;_.removeEventListener("dispose",U),C(_),_.isVideoTexture&&u.delete(_),_.isHTMLTexture&&d.delete(_)}function v(P){let _=P.target;_.removeEventListener("dispose",v),X(_)}function C(P){let _=i.get(P);if(_.__webglInit===void 0)return;let j=P.source,w=f.get(j);if(w){let N=w[_.__cacheKey];N.usedTimes--,N.usedTimes===0&&z(P),Object.keys(w).length===0&&f.delete(j)}i.remove(P)}function z(P){let _=i.get(P);n.deleteTexture(_.__webglTexture);let j=P.source,w=f.get(j);delete w[_.__cacheKey],o.memory.textures--}function X(P){let _=i.get(P);if(P.depthTexture&&(P.depthTexture.dispose(),i.remove(P.depthTexture)),P.isWebGLCubeRenderTarget)for(let w=0;w<6;w++){if(Array.isArray(_.__webglFramebuffer[w]))for(let N=0;N<_.__webglFramebuffer[w].length;N++)n.deleteFramebuffer(_.__webglFramebuffer[w][N]);else n.deleteFramebuffer(_.__webglFramebuffer[w]);_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer[w])}else{if(Array.isArray(_.__webglFramebuffer))for(let w=0;w<_.__webglFramebuffer.length;w++)n.deleteFramebuffer(_.__webglFramebuffer[w]);else n.deleteFramebuffer(_.__webglFramebuffer);if(_.__webglDepthbuffer&&n.deleteRenderbuffer(_.__webglDepthbuffer),_.__webglMultisampledFramebuffer&&n.deleteFramebuffer(_.__webglMultisampledFramebuffer),_.__webglColorRenderbuffer)for(let w=0;w<_.__webglColorRenderbuffer.length;w++)_.__webglColorRenderbuffer[w]&&n.deleteRenderbuffer(_.__webglColorRenderbuffer[w]);_.__webglDepthRenderbuffer&&n.deleteRenderbuffer(_.__webglDepthRenderbuffer)}let j=P.textures;for(let w=0,N=j.length;w<N;w++){let J=i.get(j[w]);J.__webglTexture&&(n.deleteTexture(J.__webglTexture),o.memory.textures--),i.remove(j[w])}i.remove(P)}let W=0;function re(){W=0}function G(){return W}function se(P){W=P}function _e(){let P=W;return P>=r.maxTextures&&qe("WebGLTextures: Trying to use "+(P+1)+" texture units while this GPU supports only "+r.maxTextures),W+=1,P}function ee(P){let _=[];return _.push(P.wrapS),_.push(P.wrapT),_.push(P.wrapR||0),_.push(P.magFilter),_.push(P.minFilter),_.push(P.anisotropy),_.push(P.internalFormat),_.push(P.format),_.push(P.type),_.push(P.generateMipmaps),_.push(P.premultiplyAlpha),_.push(P.flipY),_.push(P.unpackAlignment),_.push(P.colorSpace),_.join()}function Y(P,_){let j=i.get(P);if(P.isVideoTexture&&x(P),P.isRenderTargetTexture===!1&&P.isExternalTexture!==!0&&P.version>0&&j.__version!==P.version){let w=P.image;if(w===null)qe("WebGLRenderer: Texture marked for update but no image data found.");else if(w.complete===!1)qe("WebGLRenderer: Texture marked for update but image is incomplete");else{L(j,P,_);return}}else P.isExternalTexture&&(j.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(n.TEXTURE_2D,j.__webglTexture,n.TEXTURE0+_)}function he(P,_){let j=i.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&j.__version!==P.version){L(j,P,_);return}else P.isExternalTexture&&(j.__webglTexture=P.sourceTexture?P.sourceTexture:null);t.bindTexture(n.TEXTURE_2D_ARRAY,j.__webglTexture,n.TEXTURE0+_)}function de(P,_){let j=i.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&j.__version!==P.version){L(j,P,_);return}t.bindTexture(n.TEXTURE_3D,j.__webglTexture,n.TEXTURE0+_)}function ye(P,_){let j=i.get(P);if(P.isCubeDepthTexture!==!0&&P.version>0&&j.__version!==P.version){R(j,P,_);return}t.bindTexture(n.TEXTURE_CUBE_MAP,j.__webglTexture,n.TEXTURE0+_)}let Oe={[Or]:n.REPEAT,[xn]:n.CLAMP_TO_EDGE,[Br]:n.MIRRORED_REPEAT},Ne={[Dt]:n.NEAREST,[Td]:n.NEAREST_MIPMAP_NEAREST,[io]:n.NEAREST_MIPMAP_LINEAR,[Nt]:n.LINEAR,[$a]:n.LINEAR_MIPMAP_NEAREST,[Ii]:n.LINEAR_MIPMAP_LINEAR},Ke={[Rd]:n.NEVER,[Nd]:n.ALWAYS,[Pd]:n.LESS,[Il]:n.LEQUAL,[Id]:n.EQUAL,[Dl]:n.GEQUAL,[Dd]:n.GREATER,[Ld]:n.NOTEQUAL};function Ze(P,_){if(_.type===Un&&e.has("OES_texture_float_linear")===!1&&(_.magFilter===Nt||_.magFilter===$a||_.magFilter===io||_.magFilter===Ii||_.minFilter===Nt||_.minFilter===$a||_.minFilter===io||_.minFilter===Ii)&&qe("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),n.texParameteri(P,n.TEXTURE_WRAP_S,Oe[_.wrapS]),n.texParameteri(P,n.TEXTURE_WRAP_T,Oe[_.wrapT]),(P===n.TEXTURE_3D||P===n.TEXTURE_2D_ARRAY)&&n.texParameteri(P,n.TEXTURE_WRAP_R,Oe[_.wrapR]),n.texParameteri(P,n.TEXTURE_MAG_FILTER,Ne[_.magFilter]),n.texParameteri(P,n.TEXTURE_MIN_FILTER,Ne[_.minFilter]),_.compareFunction&&(n.texParameteri(P,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(P,n.TEXTURE_COMPARE_FUNC,Ke[_.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(_.magFilter===Dt||_.minFilter!==io&&_.minFilter!==Ii||_.type===Un&&e.has("OES_texture_float_linear")===!1)return;if(_.anisotropy>1||i.get(_).__currentAnisotropy){let j=e.get("EXT_texture_filter_anisotropic");n.texParameterf(P,j.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(_.anisotropy,r.getMaxAnisotropy())),i.get(_).__currentAnisotropy=_.anisotropy}}}function Je(P,_){let j=!1;P.__webglInit===void 0&&(P.__webglInit=!0,_.addEventListener("dispose",U));let w=_.source,N=f.get(w);N===void 0&&(N={},f.set(w,N));let J=ee(_);if(J!==P.__cacheKey){N[J]===void 0&&(N[J]={texture:n.createTexture(),usedTimes:0},o.memory.textures++,j=!0),N[J].usedTimes++;let oe=N[P.__cacheKey];oe!==void 0&&(N[P.__cacheKey].usedTimes--,oe.usedTimes===0&&z(_)),P.__cacheKey=J,P.__webglTexture=N[J].texture}return j}function F(P,_,j){return Math.floor(Math.floor(P/j)/_)}function D(P,_,j,w){let J=P.updateRanges;if(J.length===0)t.texSubImage2D(n.TEXTURE_2D,0,0,0,_.width,_.height,j,w,_.data);else{J.sort((ge,te)=>ge.start-te.start);let oe=0;for(let ge=1;ge<J.length;ge++){let te=J[oe],ce=J[ge],we=te.start+te.count,Pe=F(ce.start,_.width,4),$e=F(te.start,_.width,4);ce.start<=we+1&&Pe===$e&&F(ce.start+ce.count-1,_.width,4)===Pe?te.count=Math.max(te.count,ce.start+ce.count-te.start):(++oe,J[oe]=ce)}J.length=oe+1;let $=t.getParameter(n.UNPACK_ROW_LENGTH),q=t.getParameter(n.UNPACK_SKIP_PIXELS),fe=t.getParameter(n.UNPACK_SKIP_ROWS);t.pixelStorei(n.UNPACK_ROW_LENGTH,_.width);for(let ge=0,te=J.length;ge<te;ge++){let ce=J[ge],we=Math.floor(ce.start/4),Pe=Math.ceil(ce.count/4),$e=we%_.width,V=Math.floor(we/_.width),Ee=Pe,ve=1;t.pixelStorei(n.UNPACK_SKIP_PIXELS,$e),t.pixelStorei(n.UNPACK_SKIP_ROWS,V),t.texSubImage2D(n.TEXTURE_2D,0,$e,V,Ee,ve,j,w,_.data)}P.clearUpdateRanges(),t.pixelStorei(n.UNPACK_ROW_LENGTH,$),t.pixelStorei(n.UNPACK_SKIP_PIXELS,q),t.pixelStorei(n.UNPACK_SKIP_ROWS,fe)}}function L(P,_,j){let w=n.TEXTURE_2D;(_.isDataArrayTexture||_.isCompressedArrayTexture)&&(w=n.TEXTURE_2D_ARRAY),_.isData3DTexture&&(w=n.TEXTURE_3D);let N=Je(P,_),J=_.source;t.bindTexture(w,P.__webglTexture,n.TEXTURE0+j);let oe=i.get(J);if(J.version!==oe.__version||N===!0){if(t.activeTexture(n.TEXTURE0+j),(typeof ImageBitmap<"u"&&_.image instanceof ImageBitmap)===!1){let ve=rt.getPrimaries(rt.workingColorSpace),Ae=_.colorSpace===ai?null:rt.getPrimaries(_.colorSpace),Ce=_.colorSpace===ai||ve===Ae?n.NONE:n.BROWSER_DEFAULT_WEBGL;t.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ce)}t.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment);let q=m(_.image,!1,r.maxTextureSize);q=Be(_,q);let fe=s.convert(_.format,_.colorSpace),ge=s.convert(_.type),te=y(_.internalFormat,fe,ge,_.normalized,_.colorSpace,_.isVideoTexture);Ze(w,_);let ce,we=_.mipmaps,Pe=_.isVideoTexture!==!0,$e=oe.__version===void 0||N===!0,V=J.dataReady,Ee=A(_,q);if(_.isDepthTexture)te=E(_.format===Di,_.type),$e&&(Pe?t.texStorage2D(n.TEXTURE_2D,1,te,q.width,q.height):t.texImage2D(n.TEXTURE_2D,0,te,q.width,q.height,0,fe,ge,null));else if(_.isDataTexture)if(we.length>0){Pe&&$e&&t.texStorage2D(n.TEXTURE_2D,Ee,te,we[0].width,we[0].height);for(let ve=0,Ae=we.length;ve<Ae;ve++)ce=we[ve],Pe?V&&t.texSubImage2D(n.TEXTURE_2D,ve,0,0,ce.width,ce.height,fe,ge,ce.data):t.texImage2D(n.TEXTURE_2D,ve,te,ce.width,ce.height,0,fe,ge,ce.data);_.generateMipmaps=!1}else Pe?($e&&t.texStorage2D(n.TEXTURE_2D,Ee,te,q.width,q.height),V&&D(_,q,fe,ge)):t.texImage2D(n.TEXTURE_2D,0,te,q.width,q.height,0,fe,ge,q.data);else if(_.isCompressedTexture)if(_.isCompressedArrayTexture){Pe&&$e&&t.texStorage3D(n.TEXTURE_2D_ARRAY,Ee,te,we[0].width,we[0].height,q.depth);for(let ve=0,Ae=we.length;ve<Ae;ve++)if(ce=we[ve],_.format!==Mn)if(fe!==null)if(Pe){if(V)if(_.layerUpdates.size>0){let Ce=Mh(ce.width,ce.height,_.format,_.type);for(let xe of _.layerUpdates){let We=ce.data.subarray(xe*Ce/ce.data.BYTES_PER_ELEMENT,(xe+1)*Ce/ce.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,ve,0,0,xe,ce.width,ce.height,1,fe,We)}}else t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,ve,0,0,0,ce.width,ce.height,q.depth,fe,ce.data)}else t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,ve,te,ce.width,ce.height,q.depth,0,ce.data,0,0);else qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Pe?V&&t.texSubImage3D(n.TEXTURE_2D_ARRAY,ve,0,0,0,ce.width,ce.height,q.depth,fe,ge,ce.data):t.texImage3D(n.TEXTURE_2D_ARRAY,ve,te,ce.width,ce.height,q.depth,0,fe,ge,ce.data);_.layerUpdates.size>0&&_.clearLayerUpdates()}else{Pe&&$e&&t.texStorage2D(n.TEXTURE_2D,Ee,te,we[0].width,we[0].height);for(let ve=0,Ae=we.length;ve<Ae;ve++)ce=we[ve],_.format!==Mn?fe!==null?Pe?V&&t.compressedTexSubImage2D(n.TEXTURE_2D,ve,0,0,ce.width,ce.height,fe,ce.data):t.compressedTexImage2D(n.TEXTURE_2D,ve,te,ce.width,ce.height,0,ce.data):qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Pe?V&&t.texSubImage2D(n.TEXTURE_2D,ve,0,0,ce.width,ce.height,fe,ge,ce.data):t.texImage2D(n.TEXTURE_2D,ve,te,ce.width,ce.height,0,fe,ge,ce.data)}else if(_.isDataArrayTexture)if(Pe){if($e&&t.texStorage3D(n.TEXTURE_2D_ARRAY,Ee,te,q.width,q.height,q.depth),V)if(_.layerUpdates.size>0){let ve=Mh(q.width,q.height,_.format,_.type);for(let Ae of _.layerUpdates){let Ce=q.data.subarray(Ae*ve/q.data.BYTES_PER_ELEMENT,(Ae+1)*ve/q.data.BYTES_PER_ELEMENT);t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,Ae,q.width,q.height,1,fe,ge,Ce)}_.clearLayerUpdates()}else t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,q.width,q.height,q.depth,fe,ge,q.data)}else t.texImage3D(n.TEXTURE_2D_ARRAY,0,te,q.width,q.height,q.depth,0,fe,ge,q.data);else if(_.isData3DTexture)Pe?($e&&t.texStorage3D(n.TEXTURE_3D,Ee,te,q.width,q.height,q.depth),V&&t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,q.width,q.height,q.depth,fe,ge,q.data)):t.texImage3D(n.TEXTURE_3D,0,te,q.width,q.height,q.depth,0,fe,ge,q.data);else if(_.isFramebufferTexture){if($e)if(Pe)t.texStorage2D(n.TEXTURE_2D,Ee,te,q.width,q.height);else{let ve=q.width,Ae=q.height;for(let Ce=0;Ce<Ee;Ce++)t.texImage2D(n.TEXTURE_2D,Ce,te,ve,Ae,0,fe,ge,null),ve>>=1,Ae>>=1}}else if(_.isHTMLTexture){if("texElementImage2D"in n){let ve=n.canvas;if(ve.hasAttribute("layoutsubtree")||ve.setAttribute("layoutsubtree","true"),q.parentNode!==ve){ve.appendChild(q),d.add(_),ve.onpaint=Ae=>{let Ce=Ae.changedElements;for(let xe of d)Ce.includes(xe.image)&&(xe.needsUpdate=!0)},ve.requestPaint();return}if(n.texElementImage2D.length===3)n.texElementImage2D(n.TEXTURE_2D,n.RGBA8,q);else{let Ce=n.RGBA,xe=n.RGBA,We=n.UNSIGNED_BYTE;n.texElementImage2D(n.TEXTURE_2D,0,Ce,xe,We,q)}n.texParameteri(n.TEXTURE_2D,n.TEXTURE_MIN_FILTER,n.LINEAR),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(n.TEXTURE_2D,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE)}}else if(we.length>0){if(Pe&&$e){let ve=Xe(we[0]);t.texStorage2D(n.TEXTURE_2D,Ee,te,ve.width,ve.height)}for(let ve=0,Ae=we.length;ve<Ae;ve++)ce=we[ve],Pe?V&&t.texSubImage2D(n.TEXTURE_2D,ve,0,0,fe,ge,ce):t.texImage2D(n.TEXTURE_2D,ve,te,fe,ge,ce);_.generateMipmaps=!1}else if(Pe){if($e){let ve=Xe(q);t.texStorage2D(n.TEXTURE_2D,Ee,te,ve.width,ve.height)}V&&t.texSubImage2D(n.TEXTURE_2D,0,0,0,fe,ge,q)}else t.texImage2D(n.TEXTURE_2D,0,te,fe,ge,q);p(_)&&S(w),oe.__version=J.version,_.onUpdate&&_.onUpdate(_)}P.__version=_.version}function R(P,_,j){if(_.image.length!==6)return;let w=Je(P,_),N=_.source;t.bindTexture(n.TEXTURE_CUBE_MAP,P.__webglTexture,n.TEXTURE0+j);let J=i.get(N);if(N.version!==J.__version||w===!0){t.activeTexture(n.TEXTURE0+j);let oe=rt.getPrimaries(rt.workingColorSpace),$=_.colorSpace===ai?null:rt.getPrimaries(_.colorSpace),q=_.colorSpace===ai||oe===$?n.NONE:n.BROWSER_DEFAULT_WEBGL;t.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,_.flipY),t.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,_.premultiplyAlpha),t.pixelStorei(n.UNPACK_ALIGNMENT,_.unpackAlignment),t.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,q);let fe=_.isCompressedTexture||_.image[0].isCompressedTexture,ge=_.image[0]&&_.image[0].isDataTexture,te=[];for(let xe=0;xe<6;xe++)!fe&&!ge?te[xe]=m(_.image[xe],!0,r.maxCubemapSize):te[xe]=ge?_.image[xe].image:_.image[xe],te[xe]=Be(_,te[xe]);let ce=te[0],we=s.convert(_.format,_.colorSpace),Pe=s.convert(_.type),$e=y(_.internalFormat,we,Pe,_.normalized,_.colorSpace),V=_.isVideoTexture!==!0,Ee=J.__version===void 0||w===!0,ve=N.dataReady,Ae=A(_,ce);Ze(n.TEXTURE_CUBE_MAP,_);let Ce;if(fe){V&&Ee&&t.texStorage2D(n.TEXTURE_CUBE_MAP,Ae,$e,ce.width,ce.height);for(let xe=0;xe<6;xe++){Ce=te[xe].mipmaps;for(let We=0;We<Ce.length;We++){let ke=Ce[We];_.format!==Mn?we!==null?V?ve&&t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We,0,0,ke.width,ke.height,we,ke.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We,$e,ke.width,ke.height,0,ke.data):qe("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):V?ve&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We,0,0,ke.width,ke.height,we,Pe,ke.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We,$e,ke.width,ke.height,0,we,Pe,ke.data)}}}else{if(Ce=_.mipmaps,V&&Ee){Ce.length>0&&Ae++;let xe=Xe(te[0]);t.texStorage2D(n.TEXTURE_CUBE_MAP,Ae,$e,xe.width,xe.height)}for(let xe=0;xe<6;xe++)if(ge){V?ve&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0,0,0,te[xe].width,te[xe].height,we,Pe,te[xe].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0,$e,te[xe].width,te[xe].height,0,we,Pe,te[xe].data);for(let We=0;We<Ce.length;We++){let ft=Ce[We].image[xe].image;V?ve&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We+1,0,0,ft.width,ft.height,we,Pe,ft.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We+1,$e,ft.width,ft.height,0,we,Pe,ft.data)}}else{V?ve&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0,0,0,we,Pe,te[xe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0,$e,we,Pe,te[xe]);for(let We=0;We<Ce.length;We++){let ke=Ce[We];V?ve&&t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We+1,0,0,we,Pe,ke.image[xe]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,We+1,$e,we,Pe,ke.image[xe])}}}p(_)&&S(n.TEXTURE_CUBE_MAP),J.__version=N.version,_.onUpdate&&_.onUpdate(_)}P.__version=_.version}function k(P,_,j,w,N,J){let oe=s.convert(j.format,j.colorSpace),$=s.convert(j.type),q=y(j.internalFormat,oe,$,j.normalized,j.colorSpace),fe=i.get(_),ge=i.get(j);if(ge.__renderTarget=_,!fe.__hasExternalTextures){let te=Math.max(1,_.width>>J),ce=Math.max(1,_.height>>J);N===n.TEXTURE_3D||N===n.TEXTURE_2D_ARRAY?t.texImage3D(N,J,q,te,ce,_.depth,0,oe,$,null):t.texImage2D(N,J,q,te,ce,0,oe,$,null)}t.bindFramebuffer(n.FRAMEBUFFER,P),K(_)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,w,N,ge.__webglTexture,0,Te(_)):(N===n.TEXTURE_2D||N>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&N<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,w,N,ge.__webglTexture,J),t.bindFramebuffer(n.FRAMEBUFFER,null)}function le(P,_,j){if(n.bindRenderbuffer(n.RENDERBUFFER,P),_.depthBuffer){let w=_.depthTexture,N=w&&w.isDepthTexture?w.type:null,J=E(_.stencilBuffer,N),oe=_.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;K(_)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Te(_),J,_.width,_.height):j?n.renderbufferStorageMultisample(n.RENDERBUFFER,Te(_),J,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,J,_.width,_.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,oe,n.RENDERBUFFER,P)}else{let w=_.textures;for(let N=0;N<w.length;N++){let J=w[N],oe=s.convert(J.format,J.colorSpace),$=s.convert(J.type),q=y(J.internalFormat,oe,$,J.normalized,J.colorSpace);K(_)?a.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Te(_),q,_.width,_.height):j?n.renderbufferStorageMultisample(n.RENDERBUFFER,Te(_),q,_.width,_.height):n.renderbufferStorage(n.RENDERBUFFER,q,_.width,_.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function Se(P,_,j){let w=_.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(n.FRAMEBUFFER,P),!(_.depthTexture&&_.depthTexture.isDepthTexture))throw new Error("THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.");let N=i.get(_.depthTexture);if(N.__renderTarget=_,(!N.__webglTexture||_.depthTexture.image.width!==_.width||_.depthTexture.image.height!==_.height)&&(_.depthTexture.image.width=_.width,_.depthTexture.image.height=_.height,_.depthTexture.needsUpdate=!0),w){if(N.__webglInit===void 0&&(N.__webglInit=!0,_.depthTexture.addEventListener("dispose",U)),N.__webglTexture===void 0){N.__webglTexture=n.createTexture(),t.bindTexture(n.TEXTURE_CUBE_MAP,N.__webglTexture),Ze(n.TEXTURE_CUBE_MAP,_.depthTexture);let fe=s.convert(_.depthTexture.format),ge=s.convert(_.depthTexture.type),te;_.depthTexture.format===Xn?te=n.DEPTH_COMPONENT24:_.depthTexture.format===Di&&(te=n.DEPTH24_STENCIL8);for(let ce=0;ce<6;ce++)n.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+ce,0,te,_.width,_.height,0,fe,ge,null)}}else Y(_.depthTexture,0);let J=N.__webglTexture,oe=Te(_),$=w?n.TEXTURE_CUBE_MAP_POSITIVE_X+j:n.TEXTURE_2D,q=_.depthTexture.format===Di?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;if(_.depthTexture.format===Xn)K(_)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,q,$,J,0,oe):n.framebufferTexture2D(n.FRAMEBUFFER,q,$,J,0);else if(_.depthTexture.format===Di)K(_)?a.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,q,$,J,0,oe):n.framebufferTexture2D(n.FRAMEBUFFER,q,$,J,0);else throw new Error("THREE.WebGLTextures: Unknown depthTexture format.")}function B(P){let _=i.get(P),j=P.isWebGLCubeRenderTarget===!0;if(_.__boundDepthTexture!==P.depthTexture){let w=P.depthTexture;if(_.__depthDisposeCallback&&_.__depthDisposeCallback(),w){let N=()=>{delete _.__boundDepthTexture,delete _.__depthDisposeCallback,w.removeEventListener("dispose",N)};w.addEventListener("dispose",N),_.__depthDisposeCallback=N}_.__boundDepthTexture=w}if(P.depthTexture&&!_.__autoAllocateDepthBuffer)if(j)for(let w=0;w<6;w++)Se(_.__webglFramebuffer[w],P,w);else{let w=P.texture.mipmaps;w&&w.length>0?Se(_.__webglFramebuffer[0],P,0):Se(_.__webglFramebuffer,P,0)}else if(j){_.__webglDepthbuffer=[];for(let w=0;w<6;w++)if(t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[w]),_.__webglDepthbuffer[w]===void 0)_.__webglDepthbuffer[w]=n.createRenderbuffer(),le(_.__webglDepthbuffer[w],P,!1);else{let N=P.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,J=_.__webglDepthbuffer[w];n.bindRenderbuffer(n.RENDERBUFFER,J),n.framebufferRenderbuffer(n.FRAMEBUFFER,N,n.RENDERBUFFER,J)}}else{let w=P.texture.mipmaps;if(w&&w.length>0?t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer[0]):t.bindFramebuffer(n.FRAMEBUFFER,_.__webglFramebuffer),_.__webglDepthbuffer===void 0)_.__webglDepthbuffer=n.createRenderbuffer(),le(_.__webglDepthbuffer,P,!1);else{let N=P.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,J=_.__webglDepthbuffer;n.bindRenderbuffer(n.RENDERBUFFER,J),n.framebufferRenderbuffer(n.FRAMEBUFFER,N,n.RENDERBUFFER,J)}}t.bindFramebuffer(n.FRAMEBUFFER,null)}function ae(P,_,j){let w=i.get(P);_!==void 0&&k(w.__webglFramebuffer,P,P.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),j!==void 0&&B(P)}function Z(P){let _=P.texture,j=i.get(P),w=i.get(_);P.addEventListener("dispose",v);let N=P.textures,J=P.isWebGLCubeRenderTarget===!0,oe=N.length>1;if(oe||(w.__webglTexture===void 0&&(w.__webglTexture=n.createTexture()),w.__version=_.version,o.memory.textures++),J){j.__webglFramebuffer=[];for(let $=0;$<6;$++)if(_.mipmaps&&_.mipmaps.length>0){j.__webglFramebuffer[$]=[];for(let q=0;q<_.mipmaps.length;q++)j.__webglFramebuffer[$][q]=n.createFramebuffer()}else j.__webglFramebuffer[$]=n.createFramebuffer()}else{if(_.mipmaps&&_.mipmaps.length>0){j.__webglFramebuffer=[];for(let $=0;$<_.mipmaps.length;$++)j.__webglFramebuffer[$]=n.createFramebuffer()}else j.__webglFramebuffer=n.createFramebuffer();if(oe)for(let $=0,q=N.length;$<q;$++){let fe=i.get(N[$]);fe.__webglTexture===void 0&&(fe.__webglTexture=n.createTexture(),o.memory.textures++)}if(P.samples>0&&K(P)===!1){j.__webglMultisampledFramebuffer=n.createFramebuffer(),j.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,j.__webglMultisampledFramebuffer);for(let $=0;$<N.length;$++){let q=N[$];j.__webglColorRenderbuffer[$]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,j.__webglColorRenderbuffer[$]);let fe=s.convert(q.format,q.colorSpace),ge=s.convert(q.type),te=y(q.internalFormat,fe,ge,q.normalized,q.colorSpace,P.isXRRenderTarget===!0),ce=Te(P);n.renderbufferStorageMultisample(n.RENDERBUFFER,ce,te,P.width,P.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+$,n.RENDERBUFFER,j.__webglColorRenderbuffer[$])}n.bindRenderbuffer(n.RENDERBUFFER,null),P.depthBuffer&&(j.__webglDepthRenderbuffer=n.createRenderbuffer(),le(j.__webglDepthRenderbuffer,P,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(J){t.bindTexture(n.TEXTURE_CUBE_MAP,w.__webglTexture),Ze(n.TEXTURE_CUBE_MAP,_);for(let $=0;$<6;$++)if(_.mipmaps&&_.mipmaps.length>0)for(let q=0;q<_.mipmaps.length;q++)k(j.__webglFramebuffer[$][q],P,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+$,q);else k(j.__webglFramebuffer[$],P,_,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+$,0);p(_)&&S(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(oe){for(let $=0,q=N.length;$<q;$++){let fe=N[$],ge=i.get(fe),te=n.TEXTURE_2D;(P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(te=P.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture(te,ge.__webglTexture),Ze(te,fe),k(j.__webglFramebuffer,P,fe,n.COLOR_ATTACHMENT0+$,te,0),p(fe)&&S(te)}t.unbindTexture()}else{let $=n.TEXTURE_2D;if((P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&($=P.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY),t.bindTexture($,w.__webglTexture),Ze($,_),_.mipmaps&&_.mipmaps.length>0)for(let q=0;q<_.mipmaps.length;q++)k(j.__webglFramebuffer[q],P,_,n.COLOR_ATTACHMENT0,$,q);else k(j.__webglFramebuffer,P,_,n.COLOR_ATTACHMENT0,$,0);p(_)&&S($),t.unbindTexture()}P.depthBuffer&&B(P)}function pe(P){let _=P.textures;for(let j=0,w=_.length;j<w;j++){let N=_[j];if(p(N)){let J=T(P),oe=i.get(N).__webglTexture;t.bindTexture(J,oe),S(J),t.unbindTexture()}}}let me=[],Me=[];function Le(P){if(P.samples>0){if(K(P)===!1){let _=P.textures,j=P.width,w=P.height,N=n.COLOR_BUFFER_BIT,J=P.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,oe=i.get(P),$=_.length>1;if($)for(let fe=0;fe<_.length;fe++)t.bindFramebuffer(n.FRAMEBUFFER,oe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+fe,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,oe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+fe,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,oe.__webglMultisampledFramebuffer);let q=P.texture.mipmaps;q&&q.length>0?t.bindFramebuffer(n.DRAW_FRAMEBUFFER,oe.__webglFramebuffer[0]):t.bindFramebuffer(n.DRAW_FRAMEBUFFER,oe.__webglFramebuffer);for(let fe=0;fe<_.length;fe++){if(P.resolveDepthBuffer&&(P.depthBuffer&&(N|=n.DEPTH_BUFFER_BIT),P.stencilBuffer&&P.resolveStencilBuffer&&(N|=n.STENCIL_BUFFER_BIT)),$){n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,oe.__webglColorRenderbuffer[fe]);let ge=i.get(_[fe]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ge,0)}n.blitFramebuffer(0,0,j,w,0,0,j,w,N,n.NEAREST),c===!0&&(me.length=0,Me.length=0,me.push(n.COLOR_ATTACHMENT0+fe),P.depthBuffer&&P.storeMultisampledDepthBuffer===!1&&(me.push(J),Me.push(J),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,Me)),n.invalidateFramebuffer(n.READ_FRAMEBUFFER,me))}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),$)for(let fe=0;fe<_.length;fe++){t.bindFramebuffer(n.FRAMEBUFFER,oe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+fe,n.RENDERBUFFER,oe.__webglColorRenderbuffer[fe]);let ge=i.get(_[fe]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,oe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+fe,n.TEXTURE_2D,ge,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,oe.__webglMultisampledFramebuffer)}else if(P.depthBuffer&&P.storeMultisampledDepthBuffer===!1&&c){let _=P.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT;n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[_])}}}function Te(P){return Math.min(r.maxSamples,P.samples)}function K(P){let _=i.get(P);return P.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&_.__useRenderToTexture!==!1}function x(P){let _=o.render.frame;u.get(P)!==_&&(u.set(P,_),P.update())}function Be(P,_){let j=P.colorSpace,w=P.format,N=P.type;return P.isCompressedTexture===!0||P.isVideoTexture===!0||j!==Es&&j!==ai&&(rt.getTransfer(j)===ct?(w!==Mn||N!==an)&&qe("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ye("WebGLTextures: Unsupported texture color space:",j)),_}function Xe(P){return typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement?(l.width=P.naturalWidth||P.width,l.height=P.naturalHeight||P.height):typeof VideoFrame<"u"&&P instanceof VideoFrame?(l.width=P.displayWidth,l.height=P.displayHeight):(l.width=P.width,l.height=P.height),l}this.allocateTextureUnit=_e,this.resetTextureUnits=re,this.getTextureUnits=G,this.setTextureUnits=se,this.setTexture2D=Y,this.setTexture2DArray=he,this.setTexture3D=de,this.setTextureCube=ye,this.rebindTextures=ae,this.setupRenderTarget=Z,this.updateRenderTargetMipmap=pe,this.updateMultisampleRenderTarget=Le,this.setupDepthRenderbuffer=B,this.setupFrameBufferTexture=k,this.useMultisampledRTT=K,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function wv(n,e){function t(i,r=ai){let s,o=rt.getTransfer(r);if(i===an)return n.UNSIGNED_BYTE;if(i===Za)return n.UNSIGNED_SHORT_4_4_4_4;if(i===Ja)return n.UNSIGNED_SHORT_5_5_5_1;if(i===uh)return n.UNSIGNED_INT_5_9_9_9_REV;if(i===dh)return n.UNSIGNED_INT_10F_11F_11F_REV;if(i===ch)return n.BYTE;if(i===hh)return n.SHORT;if(i===Qr)return n.UNSIGNED_SHORT;if(i===Ya)return n.INT;if(i===Nn)return n.UNSIGNED_INT;if(i===Un)return n.FLOAT;if(i===Fn)return n.HALF_FLOAT;if(i===fh)return n.ALPHA;if(i===ph)return n.RGB;if(i===Mn)return n.RGBA;if(i===Xn)return n.DEPTH_COMPONENT;if(i===Di)return n.DEPTH_STENCIL;if(i===ts)return n.RED;if(i===Ka)return n.RED_INTEGER;if(i===Li)return n.RG;if(i===Qa)return n.RG_INTEGER;if(i===el)return n.RGBA_INTEGER;if(i===ro||i===so||i===oo||i===ao)if(o===ct)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(i===ro)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===so)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===oo)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===ao)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(i===ro)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===so)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===oo)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===ao)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===tl||i===nl||i===il||i===rl)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(i===tl)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===nl)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===il)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===rl)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===sl||i===ol||i===al||i===ll||i===cl||i===lo||i===hl)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(i===sl||i===ol)return o===ct?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(i===al)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC;if(i===ll)return s.COMPRESSED_R11_EAC;if(i===cl)return s.COMPRESSED_SIGNED_R11_EAC;if(i===lo)return s.COMPRESSED_RG11_EAC;if(i===hl)return s.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===ul||i===dl||i===fl||i===pl||i===ml||i===gl||i===_l||i===yl||i===vl||i===xl||i===bl||i===Ml||i===Sl||i===wl)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(i===ul)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===dl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===fl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===pl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===ml)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===gl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===_l)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===yl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===vl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===xl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===bl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===Ml)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Sl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===wl)return o===ct?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Tl||i===El||i===Al)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(i===Tl)return o===ct?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===El)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Al)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===Cl||i===Rl||i===co||i===Pl)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(i===Cl)return s.COMPRESSED_RED_RGTC1_EXT;if(i===Rl)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===co)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===Pl)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===es?n.UNSIGNED_INT_24_8:n[i]!==void 0?n[i]:null}return{convert:t}}var Tv=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Ev=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,Fh=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let i=new ks(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,i=new Ht({vertexShader:Tv,fragmentShader:Ev,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new zt(new Ki(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},Oh=class extends In{constructor(e,t){super();let i=this,r=null,s=1,o=null,a="local-floor",c=1,l=null,u=null,d=null,h=null,f=null,g=null,b=typeof XRWebGLBinding<"u",m=new Fh,p={},S=t.getContextAttributes(),T=null,y=null,E=[],A=[],U=new be,v=null,C=null,z=new $t;z.viewport=new St;let X=new $t;X.viewport=new St;let W=[z,X],re=new Xa,G=null,se=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(F){let D=E[F];return D===void 0&&(D=new Gr,E[F]=D),D.getTargetRaySpace()},this.getControllerGrip=function(F){let D=E[F];return D===void 0&&(D=new Gr,E[F]=D),D.getGripSpace()},this.getHand=function(F){let D=E[F];return D===void 0&&(D=new Gr,E[F]=D),D.getHandSpace()};function _e(F){let D=A.indexOf(F.inputSource);if(D===-1)return;let L=E[D];L!==void 0&&(L.update(F.inputSource,F.frame,l||o),L.dispatchEvent({type:F.type,data:F.inputSource}))}function ee(){r.removeEventListener("select",_e),r.removeEventListener("selectstart",_e),r.removeEventListener("selectend",_e),r.removeEventListener("squeeze",_e),r.removeEventListener("squeezestart",_e),r.removeEventListener("squeezeend",_e),r.removeEventListener("end",ee),r.removeEventListener("inputsourceschange",Y);for(let F=0;F<E.length;F++){let D=A[F];D!==null&&(A[F]=null,E[F].disconnect(D))}G=null,se=null,m.reset();for(let F in p)delete p[F];if(e.setRenderTarget(T),f=null,h=null,d=null,r=null,y=null,Je.stop(),i.isPresenting=!1,e.setPixelRatio(v),e.setSize(U.width,U.height,!1),C!==null){let F=C.camera;F.fov=C.fov,F.zoom=C.zoom,F.updateProjectionMatrix(),C=null}i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(F){s=F,i.isPresenting===!0&&qe("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(F){a=F,i.isPresenting===!0&&qe("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||o},this.setReferenceSpace=function(F){l=F},this.getBaseLayer=function(){return h!==null?h:f},this.getBinding=function(){return d===null&&b&&(d=new XRWebGLBinding(r,t)),d},this.getFrame=function(){return g},this.getSession=function(){return r},this.setSession=async function(F){if(r=F,r!==null){if(T=e.getRenderTarget(),r.addEventListener("select",_e),r.addEventListener("selectstart",_e),r.addEventListener("selectend",_e),r.addEventListener("squeeze",_e),r.addEventListener("squeezestart",_e),r.addEventListener("squeezeend",_e),r.addEventListener("end",ee),r.addEventListener("inputsourceschange",Y),S.xrCompatible!==!0&&await t.makeXRCompatible(),v=e.getPixelRatio(),e.getSize(U),b&&"createProjectionLayer"in XRWebGLBinding.prototype){let L=null,R=null,k=null;S.depth&&(k=S.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,L=S.stencil?Di:Xn,R=S.stencil?es:Nn);let le={colorFormat:t.RGBA8,depthFormat:k,scaleFactor:s};d=this.getBinding(),h=d.createProjectionLayer(le),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),y=new sn(h.textureWidth,h.textureHeight,{format:Mn,type:an,depthTexture:new xi(h.textureWidth,h.textureHeight,R,void 0,void 0,void 0,void 0,void 0,void 0,L),stencilBuffer:S.stencil,colorSpace:e.outputColorSpace,samples:S.antialias?4:0,resolveDepthBuffer:h.ignoreDepthValues===!1,resolveStencilBuffer:h.ignoreDepthValues===!1,storeMultisampledDepthBuffer:h.ignoreDepthValues===!1,storeMultisampledStencilBuffer:h.ignoreDepthValues===!1})}else{let L={antialias:S.antialias,alpha:!0,depth:S.depth,stencil:S.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(r,t,L),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new sn(f.framebufferWidth,f.framebufferHeight,{format:Mn,type:an,colorSpace:e.outputColorSpace,stencilBuffer:S.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(c),l=null,o=await r.requestReferenceSpace(a),Je.setContext(r),Je.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function Y(F){for(let D=0;D<F.removed.length;D++){let L=F.removed[D],R=A.indexOf(L);R>=0&&(A[R]=null,E[R].disconnect(L))}for(let D=0;D<F.added.length;D++){let L=F.added[D],R=A.indexOf(L);if(R===-1){for(let le=0;le<E.length;le++)if(le>=A.length){A.push(L),R=le;break}else if(A[le]===null){A[le]=L,R=le;break}if(R===-1)break}let k=E[R];k&&k.connect(L)}}let he=new O,de=new O;function ye(F,D,L){he.setFromMatrixPosition(D.matrixWorld),de.setFromMatrixPosition(L.matrixWorld);let R=he.distanceTo(de),k=D.projectionMatrix.elements,le=L.projectionMatrix.elements,Se=k[14]/(k[10]-1),B=k[14]/(k[10]+1),ae=(k[9]+1)/k[5],Z=(k[9]-1)/k[5],pe=(k[8]-1)/k[0],me=(le[8]+1)/le[0],Me=Se*pe,Le=Se*me,Te=R/(-pe+me),K=Te*-pe;if(D.matrixWorld.decompose(F.position,F.quaternion,F.scale),F.translateX(K),F.translateZ(Te),F.matrixWorld.compose(F.position,F.quaternion,F.scale),F.matrixWorldInverse.copy(F.matrixWorld).invert(),k[10]===-1)F.projectionMatrix.copy(D.projectionMatrix),F.projectionMatrixInverse.copy(D.projectionMatrixInverse);else{let x=Se+Te,Be=B+Te,Xe=Me-K,P=Le+(R-K),_=ae*B/Be*x,j=Z*B/Be*x;F.projectionMatrix.makePerspective(Xe,P,_,j,x,Be),F.projectionMatrixInverse.copy(F.projectionMatrix).invert()}}function Oe(F,D){D===null?F.matrixWorld.copy(F.matrix):F.matrixWorld.multiplyMatrices(D.matrixWorld,F.matrix),F.matrixWorldInverse.copy(F.matrixWorld).invert()}this.updateCamera=function(F){if(r===null)return;let D=F.near,L=F.far;m.texture!==null&&(m.depthNear>0&&(D=m.depthNear),m.depthFar>0&&(L=m.depthFar)),re.near=X.near=z.near=D,re.far=X.far=z.far=L,(G!==re.near||se!==re.far)&&(r.updateRenderState({depthNear:re.near,depthFar:re.far}),G=re.near,se=re.far),re.layers.mask=F.layers.mask|6,z.layers.mask=re.layers.mask&-5,X.layers.mask=re.layers.mask&-3;let R=F.parent,k=re.cameras;Oe(re,R);for(let le=0;le<k.length;le++)Oe(k[le],R);k.length===2?ye(re,z,X):re.projectionMatrix.copy(z.projectionMatrix),C===null&&F.isPerspectiveCamera&&(C={camera:F,fov:F.fov,zoom:F.zoom}),Ne(F,re,R)};function Ne(F,D,L){L===null?F.matrix.copy(D.matrixWorld):(F.matrix.copy(L.matrixWorld),F.matrix.invert(),F.matrix.multiply(D.matrixWorld)),F.matrix.decompose(F.position,F.quaternion,F.scale),F.updateMatrixWorld(!0),F.projectionMatrix.copy(D.projectionMatrix),F.projectionMatrixInverse.copy(D.projectionMatrixInverse),F.isPerspectiveCamera&&(F.fov=Vr*2*Math.atan(1/F.projectionMatrix.elements[5]),F.zoom=1)}this.getCamera=function(){return re},this.getFoveation=function(){if(!(h===null&&f===null))return c},this.setFoveation=function(F){c=F,h!==null&&(h.fixedFoveation=F),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=F)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(re)},this.getCameraTexture=function(F){return p[F]};let Ke=null;function Ze(F,D){if(u=D.getViewerPose(l||o),g=D,u!==null){let L=u.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let R=!1;L.length!==re.cameras.length&&(re.cameras.length=0,R=!0);for(let B=0;B<L.length;B++){let ae=L[B],Z=null;if(f!==null)Z=f.getViewport(ae);else{let me=d.getViewSubImage(h,ae);Z=me.viewport,B===0&&(e.setRenderTargetTextures(y,me.colorTexture,me.depthStencilTexture),e.setRenderTarget(y))}let pe=W[B];pe===void 0&&(pe=new $t,pe.layers.enable(B),pe.viewport=new St,W[B]=pe),pe.matrix.fromArray(ae.transform.matrix),pe.matrix.decompose(pe.position,pe.quaternion,pe.scale),pe.projectionMatrix.fromArray(ae.projectionMatrix),pe.projectionMatrixInverse.copy(pe.projectionMatrix).invert(),pe.viewport.set(Z.x,Z.y,Z.width,Z.height),B===0&&(re.matrix.copy(pe.matrix),re.matrix.decompose(re.position,re.quaternion,re.scale)),R===!0&&re.cameras.push(pe)}let k=r.enabledFeatures;if(k&&k.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&b){d=i.getBinding();let B=d.getDepthInformation(L[0]);B&&B.isValid&&B.texture&&m.init(B,r.renderState)}if(k&&k.includes("camera-access")&&b){e.state.unbindTexture(),d=i.getBinding();for(let B=0;B<L.length;B++){let ae=L[B].camera;if(ae){let Z=p[ae];Z||(Z=new ks,p[ae]=Z);let pe=d.getCameraImage(ae);Z.sourceTexture=pe}}}}for(let L=0;L<E.length;L++){let R=A[L],k=E[L];R!==null&&k!==void 0&&k.update(R,D,l||o)}Ke&&Ke(F,D),D.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:D}),g=null}let Je=new gf;Je.setAnimationLoop(Ze),this.setAnimationLoop=function(F){Ke=F},this.dispose=function(){}}},Av=new vt,Mf=new je;Mf.set(-1,0,0,0,1,0,0,0,1);function Cv(n,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function i(m,p){p.color.getRGB(m.fogColor.value,vh(n)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function r(m,p,S,T,y){p.isNodeMaterial?p.uniformsNeedUpdate=!1:p.isMeshBasicMaterial?s(m,p):p.isMeshLambertMaterial?(s(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshToonMaterial?(s(m,p),d(m,p)):p.isMeshPhongMaterial?(s(m,p),u(m,p),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)):p.isMeshStandardMaterial?(s(m,p),h(m,p),p.isMeshPhysicalMaterial&&f(m,p,y)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),b(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?c(m,p,S,T):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Gt&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Gt&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);let S=e.get(p),T=S.envMap,y=S.envMapRotation;T&&(m.envMap.value=T,m.envMapRotation.value.setFromMatrix4(Av.makeRotationFromEuler(y)).transpose(),T.isCubeTexture&&T.isRenderTargetTexture===!1&&m.envMapRotation.value.premultiply(Mf),m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,S,T){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*S,m.scale.value=T*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function u(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function d(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function h(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,S){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Gt&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.retroreflectivity>0&&(m.retroreflectivity.value=p.retroreflectivity),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=S.texture,m.transmissionSamplerSize.value.set(S.width,S.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function b(m,p){let S=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(S.matrixWorld),m.nearDistance.value=S.shadow.camera.near,m.farDistance.value=S.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function Rv(n,e,t,i){let r={},s={},o=[],a=n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS);function c(y,E){let A=E.program;i.uniformBlockBinding(y,A)}function l(y,E){let A=r[y.id];A===void 0&&(m(y),A=u(y),r[y.id]=A,y.addEventListener("dispose",S));let U=E.program;i.updateUBOMapping(y,U);let v=e.render.frame;s[y.id]!==v&&(h(y),s[y.id]=v)}function u(y){let E=d();y.__bindingPointIndex=E;let A=n.createBuffer(),U=y.__size,v=y.usage;return n.bindBuffer(n.UNIFORM_BUFFER,A),n.bufferData(n.UNIFORM_BUFFER,U,v),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,E,A),A}function d(){for(let y=0;y<a;y++)if(o.indexOf(y)===-1)return o.push(y),y;return Ye("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(y){let E=r[y.id],A=y.uniforms,U=y.__cache;n.bindBuffer(n.UNIFORM_BUFFER,E);for(let v=0,C=A.length;v<C;v++){let z=A[v];if(Array.isArray(z))for(let X=0,W=z.length;X<W;X++)f(z[X],v,X,U);else f(z,v,0,U)}n.bindBuffer(n.UNIFORM_BUFFER,null)}function f(y,E,A,U){if(b(y,E,A,U)===!0){let v=y.__offset,C=y.value;if(Array.isArray(C)){let z=0;for(let X=0;X<C.length;X++){let W=C[X],re=p(W);g(W,y.__data,z),typeof W!="number"&&typeof W!="boolean"&&!W.isMatrix3&&!ArrayBuffer.isView(W)&&(z+=re.storage/Float32Array.BYTES_PER_ELEMENT)}}else g(C,y.__data,0);n.bufferSubData(n.UNIFORM_BUFFER,v,y.__data)}}function g(y,E,A){typeof y=="number"||typeof y=="boolean"?E[0]=y:y.isMatrix3?(E[0]=y.elements[0],E[1]=y.elements[1],E[2]=y.elements[2],E[3]=0,E[4]=y.elements[3],E[5]=y.elements[4],E[6]=y.elements[5],E[7]=0,E[8]=y.elements[6],E[9]=y.elements[7],E[10]=y.elements[8],E[11]=0):ArrayBuffer.isView(y)?E.set(new y.constructor(y.buffer,y.byteOffset,E.length)):y.toArray(E,A)}function b(y,E,A,U){let v=y.value,C=E+"_"+A;if(U[C]===void 0)return typeof v=="number"||typeof v=="boolean"?U[C]=v:ArrayBuffer.isView(v)?U[C]=v.slice():U[C]=v.clone(),!0;{let z=U[C];if(typeof v=="number"||typeof v=="boolean"){if(z!==v)return U[C]=v,!0}else{if(ArrayBuffer.isView(v))return!0;if(z.equals(v)===!1)return z.copy(v),!0}}return!1}function m(y){let E=y.uniforms,A=0,U=16;for(let C=0,z=E.length;C<z;C++){let X=Array.isArray(E[C])?E[C]:[E[C]];for(let W=0,re=X.length;W<re;W++){let G=X[W],se=Array.isArray(G.value)?G.value:[G.value];for(let _e=0,ee=se.length;_e<ee;_e++){let Y=se[_e],he=p(Y),de=A%U,ye=de%he.boundary,Oe=de+ye;A+=ye,Oe!==0&&U-Oe<he.storage&&(A+=U-Oe),G.__data=new Float32Array(he.storage/Float32Array.BYTES_PER_ELEMENT),G.__offset=A,A+=he.storage}}}let v=A%U;return v>0&&(A+=U-v),y.__size=A,y.__cache={},this}function p(y){let E={boundary:0,storage:0};return typeof y=="number"||typeof y=="boolean"?(E.boundary=4,E.storage=4):y.isVector2?(E.boundary=8,E.storage=8):y.isVector3||y.isColor?(E.boundary=16,E.storage=12):y.isVector4?(E.boundary=16,E.storage=16):y.isMatrix3?(E.boundary=48,E.storage=48):y.isMatrix4?(E.boundary=64,E.storage=64):y.isTexture?qe("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(y)?(E.boundary=16,E.storage=y.byteLength):qe("WebGLRenderer: Unsupported uniform value type.",y),E}function S(y){let E=y.target;E.removeEventListener("dispose",S);let A=o.indexOf(E.__bindingPointIndex);o.splice(A,1),n.deleteBuffer(r[E.id]),delete r[E.id],delete s[E.id]}function T(){for(let y in r)n.deleteBuffer(r[y]);o=[],r={},s={}}return{bind:c,update:l,dispose:T}}var Pv=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),Yn=null;function Iv(){return Yn===null&&(Yn=new $i(Pv,16,16,Li,Fn),Yn.name="DFG_LUT",Yn.minFilter=Nt,Yn.magFilter=Nt,Yn.wrapS=xn,Yn.wrapT=xn,Yn.generateMipmaps=!1,Yn.needsUpdate=!0),Yn}var Ol=class{constructor(e={}){let{canvas:t=Ud(),context:i=null,depth:r=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:u="default",failIfMajorPerformanceCaveat:d=!1,reversedDepthBuffer:h=!1,outputBufferType:f=an}=e;this.isWebGLRenderer=!0;let g;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");g=i.getContextAttributes().alpha}else g=o;let b=f,m=new Set([el,Qa,Ka]),p=new Set([an,Nn,Qr,es,Za,Ja]),S=new Uint32Array(4),T=new Int32Array(4),y=new O,E=null,A=null,U=[],v=[],C=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Ln,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let z=this,X=!1,W=null,re=null,G=null,se=null;this._outputColorSpace=Qt;let _e=0,ee=0,Y=null,he=-1,de=null,ye=new St,Oe=new St,Ne=null,Ke=new He(0),Ze=0,Je=t.width,F=t.height,D=1,L=null,R=null,k=new St(0,0,Je,F),le=new St(0,0,Je,F),Se=!1,B=new Xr,ae=!1,Z=!1,pe=new vt,me=new O,Me=new St,Le={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},Te=!1;function K(){return Y===null?D:1}let x=i;function Be(M,H){return t.getContext(M,H)}let Xe,P,_,j,w,N,J,oe,$,q,fe,ge,te,ce,we,Pe,$e,V,Ee,ve,Ae,Ce,xe;try{let M={alpha:!0,depth:r,stencil:s,antialias:a,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:u,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${"186"}`),t.addEventListener("webglcontextlost",ft,!1),t.addEventListener("webglcontextrestored",at,!1),t.addEventListener("webglcontextcreationerror",un,!1),x===null){let H="webgl2";if(x=Be(H,M),x===null)throw Be(H)?new Error("THREE.WebGLRenderer: Error creating WebGL context with your selected attributes."):new Error("THREE.WebGLRenderer: Error creating WebGL context.")}We()}catch(M){throw t.removeEventListener("webglcontextlost",ft,!1),t.removeEventListener("webglcontextrestored",at,!1),t.removeEventListener("webglcontextcreationerror",un,!1),Ye("WebGLRenderer: "+M.message),M}function We(){Xe=new B_(x),Xe.init(),Ae=new wv(x,Xe),P=new C_(x,Xe,e,Ae),_=new Mv(x,Xe),P.reversedDepthBuffer&&h&&_.buffers.depth.setReversed(!0),re=x.createFramebuffer(),G=x.createFramebuffer(),se=x.createFramebuffer(),j=new V_(x),w=new lv,N=new Sv(x,Xe,_,w,P,Ae,j),J=new O_(z),oe=new Gm(x),Ce=new E_(x,oe),$=new k_(x,oe,j,Ce),q=new G_(x,$,oe,Ce,j),V=new H_(x,P,N),we=new R_(w),fe=new av(z,J,Xe,P,Ce,we),ge=new Cv(z,w),te=new hv,ce=new gv(Xe),$e=new T_(z,J,_,q,g,c),Pe=new bv(z,q,P),xe=new Rv(x,j,P,_),Ee=new A_(x,Xe,j),ve=new z_(x,Xe,j),j.programs=fe.programs,z.capabilities=P,z.extensions=Xe,z.properties=w,z.renderLists=te,z.shadowMap=Pe,z.state=_,z.info=j}b!==an&&(C=new X_(b,t.width,t.height,a,r,s));let ke=new Oh(z,x);this.xr=ke,this.getContext=function(){return x},this.getContextAttributes=function(){return x.getContextAttributes()},this.forceContextLoss=function(){let M=Xe.get("WEBGL_lose_context");M&&M.loseContext()},this.forceContextRestore=function(){let M=Xe.get("WEBGL_lose_context");M&&M.restoreContext()},this.getPixelRatio=function(){return D},this.setPixelRatio=function(M){M!==void 0&&(D=M,this.setSize(Je,F,!1))},this.getSize=function(M){return M.set(Je,F)},this.setSize=function(M,H,ue=!0){if(ke.isPresenting){qe("WebGLRenderer: Can't change size while VR device is presenting.");return}Je=M,F=H,t.width=Math.floor(M*D),t.height=Math.floor(H*D),ue===!0&&(t.style.width=M+"px",t.style.height=H+"px"),C!==null&&C.setSize(t.width,t.height),this.setViewport(0,0,M,H)},this.getDrawingBufferSize=function(M){return M.set(Je*D,F*D).floor()},this.setDrawingBufferSize=function(M,H,ue){Je=M,F=H,D=ue,t.width=Math.floor(M*ue),t.height=Math.floor(H*ue),this.setViewport(0,0,M,H)},this.setEffects=function(M){if(b===an){Ye("WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(M){for(let H=0;H<M.length;H++)if(M[H].isOutputPass===!0){qe("WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}C.setEffects(M||[])},this.getCurrentViewport=function(M){return M.copy(ye)},this.getViewport=function(M){return M.copy(k)},this.setViewport=function(M,H,ue,ne){M.isVector4?k.set(M.x,M.y,M.z,M.w):k.set(M,H,ue,ne),_.viewport(ye.copy(k).multiplyScalar(D).round())},this.getScissor=function(M){return M.copy(le)},this.setScissor=function(M,H,ue,ne){M.isVector4?le.set(M.x,M.y,M.z,M.w):le.set(M,H,ue,ne),_.scissor(Oe.copy(le).multiplyScalar(D).round())},this.getScissorTest=function(){return Se},this.setScissorTest=function(M){_.setScissorTest(Se=M)},this.setOpaqueSort=function(M){L=M},this.setTransparentSort=function(M){R=M},this.getClearColor=function(M){return M.copy($e.getClearColor())},this.setClearColor=function(){$e.setClearColor(...arguments)},this.getClearAlpha=function(){return $e.getClearAlpha()},this.setClearAlpha=function(){$e.setClearAlpha(...arguments)},this.clear=function(M=!0,H=!0,ue=!0){let ne=0;if(M){let ie=!1;if(Y!==null){let De=Y.texture.format;ie=m.has(De)}if(ie){let De=Y.texture.type,Fe=p.has(De),Ie=$e.getClearColor(),ze=$e.getClearAlpha(),Ge=Ie.r,Qe=Ie.g,it=Ie.b;Fe?(S[0]=Ge,S[1]=Qe,S[2]=it,S[3]=ze,x.clearBufferuiv(x.COLOR,0,S)):(T[0]=Ge,T[1]=Qe,T[2]=it,T[3]=ze,x.clearBufferiv(x.COLOR,0,T))}else ne|=x.COLOR_BUFFER_BIT}H&&(ne|=x.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),ue&&(ne|=x.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),ne!==0&&x.clear(ne)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(M){M.setRenderer(this),W=M},this.dispose=function(){t.removeEventListener("webglcontextlost",ft,!1),t.removeEventListener("webglcontextrestored",at,!1),t.removeEventListener("webglcontextcreationerror",un,!1),$e.dispose(),te.dispose(),ce.dispose(),w.dispose(),J.dispose(),q.dispose(),Ce.dispose(),xe.dispose(),fe.dispose(),ke.dispose(),ke.removeEventListener("sessionstart",ru),ke.removeEventListener("sessionend",su),zi.stop()};function ft(M){M.preventDefault(),Rs("WebGLRenderer: Context Lost."),X=!0}function at(){Rs("WebGLRenderer: Context Restored."),X=!1;let M=j.autoReset,H=Pe.enabled,ue=Pe.autoUpdate,ne=Pe.needsUpdate,ie=Pe.type;We(),j.autoReset=M,Pe.enabled=H,Pe.autoUpdate=ue,Pe.needsUpdate=ne,Pe.type=ie}function un(M){Ye("WebGLRenderer: A WebGL context could not be created. Reason: ",M.statusMessage)}function rn(M){let H=M.target;H.removeEventListener("dispose",rn),ic(H)}function ic(M){pr(M),w.remove(M)}function pr(M){let H=w.get(M).programs;H!==void 0&&(H.forEach(function(ue){fe.releaseProgram(ue)}),M.isShaderMaterial&&fe.releaseShaderCache(M))}this.renderBufferDirect=function(M,H,ue,ne,ie,De){H===null&&(H=Le);let Fe=ie.isMesh&&ie.matrixWorld.determinantAffine()<0,Ie=vp(M,H,ue,ne,ie);_.setMaterial(ne,Fe);let ze=ue.index,Ge=1;if(ne.wireframe===!0){if(ze=$.getWireframeAttribute(ue),ze===void 0)return;Ge=2}let Qe=ue.drawRange,it=ue.attributes.position,Ve=Qe.start*Ge,lt=(Qe.start+Qe.count)*Ge;De!==null&&(Ve=Math.max(Ve,De.start*Ge),lt=Math.min(lt,(De.start+De.count)*Ge)),ze!==null?(Ve=Math.max(Ve,0),lt=Math.min(lt,ze.count)):it!=null&&(Ve=Math.max(Ve,0),lt=Math.min(lt,it.count));let Pt=lt-Ve;if(Pt<0||Pt===1/0)return;Ce.setup(ie,ne,Ie,ue,ze);let bt,gt=Ee;if(ze!==null&&(bt=oe.get(ze),gt=ve,gt.setIndex(bt)),ie.isMesh)ne.wireframe===!0?(_.setLineWidth(ne.wireframeLinewidth*K()),gt.setMode(x.LINES)):gt.setMode(x.TRIANGLES);else if(ie.isLine){let Wt=ne.linewidth;Wt===void 0&&(Wt=1),_.setLineWidth(Wt*K()),ie.isLineSegments?gt.setMode(x.LINES):ie.isLineLoop?gt.setMode(x.LINE_LOOP):gt.setMode(x.LINE_STRIP)}else ie.isPoints?gt.setMode(x.POINTS):ie.isSprite&&gt.setMode(x.TRIANGLES);if(ie.isBatchedMesh)if(Xe.get("WEBGL_multi_draw"))gt.renderMultiDraw(ie._multiDrawStarts,ie._multiDrawCounts,ie._multiDrawCount);else{let Wt=ie._multiDrawStarts,Ue=ie._multiDrawCounts,Jt=ie._multiDrawCount,ot=ze?oe.get(ze).bytesPerElement:1,yn=w.get(ne).currentProgram.getUniforms();for(let Vn=0;Vn<Jt;Vn++)yn.setValue(x,"_gl_DrawID",Vn),gt.render(Wt[Vn]/ot,Ue[Vn])}else if(ie.isInstancedMesh)gt.renderInstances(Ve,Pt,ie.count);else if(ue.isInstancedBufferGeometry){let Wt=ue._maxInstanceCount!==void 0?ue._maxInstanceCount:1/0,Ue=Math.min(ue.instanceCount,Wt);gt.renderInstances(Ve,Pt,Ue)}else gt.render(Ve,Pt)};function Eo(M,H,ue,ne){W!==null&&M.isNodeMaterial&&W.setObject(ne,M),ae===!0&&we.setState(M,ue,!1),M.transparent===!0&&M.side===nn&&M.forceSinglePass===!1?(M.side=Gt,M.needsUpdate=!0,Co(M,H,ne),M.side=Ri,M.needsUpdate=!0,Co(M,H,ne),M.side=nn):Co(M,H,ne)}this.compile=function(M,H,ue=null){ue===null&&(ue=M),W!==null&&W.renderStart(M,H,ue),A=ce.get(ue),A.init(H),v.push(A),ue.traverseVisible(function(ie){ie.isLight&&ie.layers.test(H.layers)&&(A.pushLight(ie),ie.castShadow&&A.pushShadow(ie))}),M!==ue&&M.traverseVisible(function(ie){ie.isLight&&ie.layers.test(H.layers)&&(A.pushLight(ie),ie.castShadow&&A.pushShadow(ie))}),A.setupLights(),W!==null&&W.updateLights(A.state.lightsArray),Z=this.localClippingEnabled,ae=we.init(this.clippingPlanes,Z),ae===!0&&we.setGlobalState(this.clippingPlanes,H),W!==null&&Pe.render(A.state.shadowsArray,ue,H);let ne=new Set;return M.traverse(function(ie){if(!(ie.isMesh||ie.isPoints||ie.isLine||ie.isSprite))return;let De=ie.material;if(De)if(Array.isArray(De))for(let Fe=0;Fe<De.length;Fe++){let Ie=De[Fe];Eo(Ie,ue,H,ie),ne.add(Ie)}else Eo(De,ue,H,ie),ne.add(De)}),A=v.pop(),W!==null&&W.renderEnd(),ne},this.compileAsync=function(M,H,ue=null){let ne=this.compile(M,H,ue);return new Promise(ie=>{function De(){if(ne.forEach(function(Fe){let ze=w.get(Fe).currentProgram;(ze===void 0||ze.isReady())&&ne.delete(Fe)}),ne.size===0){ie(M);return}setTimeout(De,10)}Xe.get("KHR_parallel_shader_compile")!==null?De():setTimeout(De,10)})};let rc=null;function _p(M){rc&&rc(M)}function ru(){zi.stop()}function su(){zi.start()}let zi=new gf;zi.setAnimationLoop(_p),typeof self<"u"&&zi.setContext(self),this.setAnimationLoop=function(M){rc=M,ke.setAnimationLoop(M),M===null?zi.stop():zi.start()},ke.addEventListener("sessionstart",ru),ke.addEventListener("sessionend",su),this.render=function(M,H){if(H!==void 0&&H.isCamera!==!0){Ye("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(X===!0)return;W!==null&&W.renderStart(M,H);let ue=ke.enabled===!0&&ke.isPresenting===!0,ne=C!==null&&(Y===null||ue)&&C.begin(z,Y);if(M.matrixWorldAutoUpdate===!0&&M.updateMatrixWorld(),H.parent===null&&H.matrixWorldAutoUpdate===!0&&H.updateMatrixWorld(),ke.enabled===!0&&ke.isPresenting===!0&&(C===null||C.isCompositing()===!1)&&(ke.cameraAutoUpdate===!0&&ke.updateCamera(H),H=ke.getCamera()),M.isScene===!0&&M.onBeforeRender(z,M,H,Y),A=ce.get(M,v.length),A.init(H),A.state.textureUnits=N.getTextureUnits(),v.push(A),pe.multiplyMatrices(H.projectionMatrix,H.matrixWorldInverse),B.setFromProjectionMatrix(pe,Pn,H.reversedDepth),Z=this.localClippingEnabled,ae=we.init(this.clippingPlanes,Z),E=te.get(M,U.length),E.init(),U.push(E),ke.enabled===!0&&ke.isPresenting===!0){let Fe=z.xr.getDepthSensingMesh();Fe!==null&&sc(Fe,H,-1/0,z.sortObjects)}sc(M,H,0,z.sortObjects),E.finish(),W!==null&&W.updateLights(A.state.lightsArray),z.sortObjects===!0&&E.sort(L,R),Te=ke.enabled===!1||ke.isPresenting===!1||ke.hasDepthSensing()===!1,Te&&$e.addToRenderList(E,M),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),ae===!0&&we.beginShadows();let ie=A.state.shadowsArray;if(Pe.render(ie,M,H),ae===!0&&we.endShadows(),(ne&&C.hasRenderPass())===!1){let Fe=E.opaque,Ie=E.transmissive;if(A.setupLights(),H.isArrayCamera){let ze=H.cameras;if(Ie.length>0)for(let Ge=0,Qe=ze.length;Ge<Qe;Ge++){let it=ze[Ge];au(Fe,Ie,M,it)}Te&&$e.render(M);for(let Ge=0,Qe=ze.length;Ge<Qe;Ge++){let it=ze[Ge];ou(E,M,it,it.viewport)}}else Ie.length>0&&au(Fe,Ie,M,H),Te&&$e.render(M),ou(E,M,H)}Y!==null&&ee===0&&(N.updateMultisampleRenderTarget(Y),N.updateRenderTargetMipmap(Y)),ne&&C.end(z),M.isScene===!0&&M.onAfterRender(z,M,H),Ce.resetDefaultState(),he=-1,de=null,v.pop(),v.length>0?(A=v[v.length-1],N.setTextureUnits(A.state.textureUnits),ae===!0&&we.setGlobalState(z.clippingPlanes,A.state.camera)):A=null,U.pop(),U.length>0?E=U[U.length-1]:E=null,W!==null&&W.renderEnd()};function sc(M,H,ue,ne){if(M.visible===!1)return;if(M.layers.test(H.layers)){if(M.isGroup)ue=M.renderOrder;else if(M.isLOD)M.autoUpdate===!0&&M.update(H);else if(M.isLightProbeGrid)A.pushLightProbeGrid(M);else if(M.isLight)A.pushLight(M),M.castShadow&&A.pushShadow(M);else if(M.isSprite){if(!M.frustumCulled||M.intersectsFrustum(B)){ne&&Me.setFromMatrixPosition(M.matrixWorld).applyMatrix4(pe);let Fe=q.update(M),Ie=M.material;Ie.visible&&E.push(M,Fe,Ie,ue,Me.z,null,H)}}else if((M.isMesh||M.isLine||M.isPoints)&&(!M.frustumCulled||M.intersectsFrustum(B))){let Fe=q.update(M),Ie=M.material;if(ne&&(M.boundingSphere!==void 0?(M.boundingSphere===null&&M.computeBoundingSphere(),Me.copy(M.boundingSphere.center)):(Fe.boundingSphere===null&&Fe.computeBoundingSphere(),Me.copy(Fe.boundingSphere.center)),Me.applyMatrix4(M.matrixWorld).applyMatrix4(pe)),Array.isArray(Ie)){let ze=Fe.groups;for(let Ge=0,Qe=ze.length;Ge<Qe;Ge++){let it=ze[Ge],Ve=Ie[it.materialIndex];Ve&&Ve.visible&&E.push(M,Fe,Ve,ue,Me.z,it,H)}}else Ie.visible&&E.push(M,Fe,Ie,ue,Me.z,null,H)}}let De=M.children;for(let Fe=0,Ie=De.length;Fe<Ie;Fe++)sc(De[Fe],H,ue,ne)}function ou(M,H,ue,ne){let{opaque:ie,transmissive:De,transparent:Fe}=M;A.setupLightsView(ue),ae===!0&&we.setGlobalState(z.clippingPlanes,ue),ne&&_.viewport(ye.copy(ne)),ie.length>0&&Ao(ie,H,ue),De.length>0&&Ao(De,H,ue),Fe.length>0&&Ao(Fe,H,ue),_.buffers.depth.setTest(!0),_.buffers.depth.setMask(!0),_.buffers.color.setMask(!0),_.setPolygonOffset(!1)}function au(M,H,ue,ne){if((ue.isScene===!0?ue.overrideMaterial:null)!==null)return;if(A.state.transmissionRenderTarget[ne.id]===void 0){let Ve=Xe.has("EXT_color_buffer_half_float")||Xe.has("EXT_color_buffer_float");A.state.transmissionRenderTarget[ne.id]=new sn(1,1,{generateMipmaps:!0,type:Ve?Fn:an,minFilter:Ii,samples:Math.max(4,P.samples),stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:rt.workingColorSpace})}let De=A.state.transmissionRenderTarget[ne.id],Fe=ne.viewport||ye;De.setSize(Fe.z*z.transmissionResolutionScale,Fe.w*z.transmissionResolutionScale);let Ie=z.getRenderTarget(),ze=z.getActiveCubeFace(),Ge=z.getActiveMipmapLevel();z.setRenderTarget(De),z.getClearColor(Ke),Ze=z.getClearAlpha(),Ze<1&&z.setClearColor(16777215,.5),z.clear(),Te&&$e.render(ue);let Qe=z.toneMapping;z.toneMapping=Ln;let it=ne.viewport;if(ne.viewport!==void 0&&(ne.viewport=void 0),A.setupLightsView(ne),ae===!0&&we.setGlobalState(z.clippingPlanes,ne),Ao(M,ue,ne),N.updateMultisampleRenderTarget(De),N.updateRenderTargetMipmap(De),Xe.has("WEBGL_multisampled_render_to_texture")===!1){let Ve=!1;for(let lt=0,Pt=H.length;lt<Pt;lt++){let bt=H[lt],{object:gt,geometry:Wt,material:Ue,group:Jt}=bt;if(Ue.side===nn&&gt.layers.test(ne.layers)){let ot=Ue.side;Ue.side=Gt,Ue.needsUpdate=!0,lu(gt,ue,ne,Wt,Ue,Jt),Ue.side=ot,Ue.needsUpdate=!0,Ve=!0}}Ve===!0&&(N.updateMultisampleRenderTarget(De),N.updateRenderTargetMipmap(De))}z.setRenderTarget(Ie,ze,Ge),z.setClearColor(Ke,Ze),it!==void 0&&(ne.viewport=it),z.toneMapping=Qe}function Ao(M,H,ue){let ne=H.isScene===!0?H.overrideMaterial:null;for(let ie=0,De=M.length;ie<De;ie++){let Fe=M[ie],{object:Ie,geometry:ze,group:Ge}=Fe,Qe=Fe.material;Qe.allowOverride===!0&&ne!==null&&(Qe=ne),Ie.layers.test(ue.layers)&&lu(Ie,H,ue,ze,Qe,Ge)}}function lu(M,H,ue,ne,ie,De){W!==null&&ie.isNodeMaterial&&W.setObject(M,ie),M.onBeforeRender(z,H,ue,ne,ie,De),M.modelViewMatrix.multiplyMatrices(ue.matrixWorldInverse,M.matrixWorld),M.normalMatrix.getNormalMatrix(M.modelViewMatrix),ie.onBeforeRender(z,H,ue,ne,M,De),ie.transparent===!0&&ie.side===nn&&ie.forceSinglePass===!1?(ie.side=Gt,ie.needsUpdate=!0,z.renderBufferDirect(ue,H,ne,ie,M,De),ie.side=Ri,ie.needsUpdate=!0,z.renderBufferDirect(ue,H,ne,ie,M,De),ie.side=nn):z.renderBufferDirect(ue,H,ne,ie,M,De),M.onAfterRender(z,H,ue,ne,ie,De)}function Co(M,H,ue){H.isScene!==!0&&(H=Le);let ne=w.get(M),ie=A.state.lights,De=A.state.shadowsArray,Fe=ie.state.version,Ie=fe.getParameters(M,ie.state,De,H,ue,A.state.lightProbeGridArray),ze=fe.getProgramCacheKey(Ie),Ge=ne.programs;ne.environment=M.isMeshStandardMaterial||M.isMeshLambertMaterial||M.isMeshPhongMaterial?H.environment:null,ne.fog=H.fog;let Qe=M.isMeshStandardMaterial||M.isMeshLambertMaterial&&!M.envMap||M.isMeshPhongMaterial&&!M.envMap;ne.envMap=J.get(M.envMap||ne.environment,Qe),ne.envMapRotation=ne.environment!==null&&M.envMap===null?H.environmentRotation:M.envMapRotation,Ge===void 0&&(M.addEventListener("dispose",rn),Ge=new Map,ne.programs=Ge);let it=Ge.get(ze);if(it!==void 0){if(ne.currentProgram===it&&ne.lightsStateVersion===Fe)return hu(M,Ie),it}else Ie.uniforms=fe.getUniforms(M),W!==null&&M.isNodeMaterial&&W.build(M,ue,Ie),M.onBeforeCompile(Ie,z),it=fe.acquireProgram(Ie,ze),Ge.set(ze,it),ne.uniforms=Ie.uniforms;let Ve=ne.uniforms;return(!M.isShaderMaterial&&!M.isRawShaderMaterial||M.clipping===!0)&&(Ve.clippingPlanes=we.uniform),hu(M,Ie),ne.needsLights=bp(M),ne.lightsStateVersion=Fe,ne.needsLights&&(Ve.ambientLightColor.value=ie.state.ambient,Ve.lightProbe.value=ie.state.probe,Ve.sunLights.value=ie.state.sun,Ve.sunLightShadows.value=ie.state.sunShadow,Ve.directionalLights.value=ie.state.directional,Ve.directionalLightShadows.value=ie.state.directionalShadow,Ve.spotLights.value=ie.state.spot,Ve.spotLightShadows.value=ie.state.spotShadow,Ve.rectAreaLights.value=ie.state.rectArea,Ve.ltc_1.value=ie.state.rectAreaLTC1,Ve.ltc_2.value=ie.state.rectAreaLTC2,Ve.pointLights.value=ie.state.point,Ve.pointLightShadows.value=ie.state.pointShadow,Ve.hemisphereLights.value=ie.state.hemi,Ve.sunShadowMatrix.value=ie.state.sunShadowMatrix,Ve.sunShadowCascade.value=ie.state.sunShadowCascade,Ve.directionalShadowMatrix.value=ie.state.directionalShadowMatrix,Ve.spotLightMatrix.value=ie.state.spotLightMatrix,Ve.spotLightMap.value=ie.state.spotLightMap,Ve.pointShadowMatrix.value=ie.state.pointShadowMatrix),ne.lightProbeGrid=A.state.lightProbeGridArray.length>0,ne.currentProgram=it,ne.uniformsList=null,it}function cu(M){if(M.uniformsList===null){let H=M.currentProgram.getUniforms();M.uniformsList=rs.seqWithValue(H.seq,M.uniforms)}return M.uniformsList}function hu(M,H){let ue=w.get(M);ue.outputColorSpace=H.outputColorSpace,ue.batching=H.batching,ue.batchingColor=H.batchingColor,ue.instancing=H.instancing,ue.instancingColor=H.instancingColor,ue.instancingMorph=H.instancingMorph,ue.skinning=H.skinning,ue.morphTargets=H.morphTargets,ue.morphNormals=H.morphNormals,ue.morphColors=H.morphColors,ue.morphTargetsCount=H.morphTargetsCount,ue.numClippingPlanes=H.numClippingPlanes,ue.numIntersection=H.numClipIntersection,ue.vertexAlphas=H.vertexAlphas,ue.vertexTangents=H.vertexTangents,ue.toneMapping=H.toneMapping}function yp(M,H){if(M.length===0)return null;if(M.length===1)return M[0].texture!==null?M[0]:null;y.setFromMatrixPosition(H.matrixWorld);for(let ue=0,ne=M.length;ue<ne;ue++){let ie=M[ue];if(ie.texture!==null&&ie.boundingBox.containsPoint(y))return ie}return null}function vp(M,H,ue,ne,ie){H.isScene!==!0&&(H=Le),N.resetTextureUnits();let De=H.fog,Fe=ne.isMeshStandardMaterial||ne.isMeshLambertMaterial||ne.isMeshPhongMaterial?H.environment:null,Ie=Y===null?z.outputColorSpace:Y.isXRRenderTarget===!0?Y.texture.colorSpace:rt.workingColorSpace,ze=ne.isMeshStandardMaterial||ne.isMeshLambertMaterial&&!ne.envMap||ne.isMeshPhongMaterial&&!ne.envMap,Ge=J.get(ne.envMap||Fe,ze),Qe=ne.vertexColors===!0&&!!ue.attributes.color&&ue.attributes.color.itemSize===4,it=!!ue.attributes.tangent&&(!!ne.normalMap||ne.anisotropy>0),Ve=!!ue.morphAttributes.position,lt=!!ue.morphAttributes.normal,Pt=!!ue.morphAttributes.color,bt=Ln;ne.toneMapped&&(Y===null||Y.isXRRenderTarget===!0)&&(bt=z.toneMapping);let gt=ue.morphAttributes.position||ue.morphAttributes.normal||ue.morphAttributes.color,Wt=gt!==void 0?gt.length:0,Ue=w.get(ne),Jt=A.state.lights;if(ae===!0&&(Z===!0||M!==de)){let yt=M===de&&ne.id===he;we.setState(ne,M,yt)}let ot=!1;ne.version===Ue.__version?(Ue.needsLights&&Ue.lightsStateVersion!==Jt.state.version||Ue.outputColorSpace!==Ie||ie.isBatchedMesh&&Ue.batching===!1||!ie.isBatchedMesh&&Ue.batching===!0||ie.isBatchedMesh&&Ue.batchingColor===!0&&ie._colorsTexture===null||ie.isBatchedMesh&&Ue.batchingColor===!1&&ie._colorsTexture!==null||ie.isInstancedMesh&&Ue.instancing===!1||!ie.isInstancedMesh&&Ue.instancing===!0||ie.isSkinnedMesh&&Ue.skinning===!1||!ie.isSkinnedMesh&&Ue.skinning===!0||ie.isInstancedMesh&&Ue.instancingColor===!0&&ie.instanceColor===null||ie.isInstancedMesh&&Ue.instancingColor===!1&&ie.instanceColor!==null||ie.isInstancedMesh&&Ue.instancingMorph===!0&&ie.morphTexture===null||ie.isInstancedMesh&&Ue.instancingMorph===!1&&ie.morphTexture!==null||Ue.envMap!==Ge||ne.fog===!0&&Ue.fog!==De||Ue.numClippingPlanes!==void 0&&(Ue.numClippingPlanes!==we.numPlanes||Ue.numIntersection!==we.numIntersection)||Ue.vertexAlphas!==Qe||Ue.vertexTangents!==it||Ue.morphTargets!==Ve||Ue.morphNormals!==lt||Ue.morphColors!==Pt||Ue.toneMapping!==bt||Ue.morphTargetsCount!==Wt||!!Ue.lightProbeGrid!=A.state.lightProbeGridArray.length>0)&&(ot=!0):(ot=!0,Ue.__version=ne.version);let yn=Ue.currentProgram;ot===!0&&(yn=Co(ne,H,ie),W&&ne.isNodeMaterial&&W.onUpdateProgram(ne,yn,Ue));let Vn=!1,ui=!1,mr=!1,pt=yn.getUniforms(),At=Ue.uniforms;if(_.useProgram(yn.program)&&(Vn=!0,ui=!0,mr=!0),ne.id!==he&&(he=ne.id,ui=!0),Ue.needsLights){let yt=yp(A.state.lightProbeGridArray,ie);Ue.lightProbeGrid!==yt&&(Ue.lightProbeGrid=yt,ui=!0)}if(Vn||de!==M){_.buffers.depth.getReversed()&&M.reversedDepth!==!0&&(M._reversedDepth=!0,M.updateProjectionMatrix()),pt.setValue(x,"projectionMatrix",M.projectionMatrix),pt.setValue(x,"viewMatrix",M.matrixWorldInverse);let fi=pt.map.cameraPosition;fi!==void 0&&fi.setValue(x,me.setFromMatrixPosition(M.matrixWorld)),P.logarithmicDepthBuffer&&pt.setValue(x,"logDepthBufFC",2/(Math.log(M.far+1)/Math.LN2)),(ne.isMeshPhongMaterial||ne.isMeshToonMaterial||ne.isMeshLambertMaterial||ne.isMeshBasicMaterial||ne.isMeshStandardMaterial||ne.isShaderMaterial)&&pt.setValue(x,"isOrthographic",M.isOrthographicCamera===!0),de!==M&&(de=M,ui=!0,mr=!0)}if(Ue.needsLights&&(Jt.state.sunShadowMap.length>0&&pt.setValue(x,"sunShadowMap",Jt.state.sunShadowMap,N),Jt.state.directionalShadowMap.length>0&&pt.setValue(x,"directionalShadowMap",Jt.state.directionalShadowMap,N),Jt.state.spotShadowMap.length>0&&pt.setValue(x,"spotShadowMap",Jt.state.spotShadowMap,N),Jt.state.pointShadowMap.length>0&&pt.setValue(x,"pointShadowMap",Jt.state.pointShadowMap,N)),ie.isSkinnedMesh){pt.setOptional(x,ie,"bindMatrix"),pt.setOptional(x,ie,"bindMatrixInverse");let yt=ie.skeleton;yt&&(yt.boneTexture===null&&yt.computeBoneTexture(),pt.setValue(x,"boneTexture",yt.boneTexture,N))}ie.isBatchedMesh&&(pt.setOptional(x,ie,"batchingTexture"),pt.setValue(x,"batchingTexture",ie._matricesTexture,N),pt.setOptional(x,ie,"batchingIdTexture"),pt.setValue(x,"batchingIdTexture",ie._indirectTexture,N),pt.setOptional(x,ie,"batchingColorTexture"),ie._colorsTexture!==null&&pt.setValue(x,"batchingColorTexture",ie._colorsTexture,N));let di=ue.morphAttributes;if((di.position!==void 0||di.normal!==void 0||di.color!==void 0)&&V.update(ie,ue,yn),(ui||Ue.receiveShadow!==ie.receiveShadow)&&(Ue.receiveShadow=ie.receiveShadow,pt.setValue(x,"receiveShadow",ie.receiveShadow)),(ne.isMeshStandardMaterial||ne.isMeshLambertMaterial||ne.isMeshPhongMaterial)&&ne.envMap===null&&H.environment!==null&&(At.envMapIntensity.value=H.environmentIntensity),At.dfgLUT!==void 0&&(At.dfgLUT.value=Iv()),ui){if(pt.setValue(x,"toneMappingExposure",z.toneMappingExposure),Ue.needsLights&&xp(At,mr),De&&ne.fog===!0&&ge.refreshFogUniforms(At,De),ge.refreshMaterialUniforms(At,ne,D,F,A.state.transmissionRenderTarget[M.id]),Ue.needsLights&&Ue.lightProbeGrid){let yt=Ue.lightProbeGrid;At.probesSH.value=yt.texture,At.probesMin.value.copy(yt.boundingBox.min),At.probesMax.value.copy(yt.boundingBox.max),At.probesResolution.value.copy(yt.resolution)}rs.upload(x,cu(Ue),At,N)}if(ne.isShaderMaterial&&ne.uniformsNeedUpdate===!0&&(rs.upload(x,cu(Ue),At,N),ne.uniformsNeedUpdate=!1),ne.isSpriteMaterial&&pt.setValue(x,"center",ie.center),pt.setValue(x,"modelViewMatrix",ie.modelViewMatrix),pt.setValue(x,"normalMatrix",ie.normalMatrix),pt.setValue(x,"modelMatrix",ie.matrixWorld),ne.uniformsGroups!==void 0){let yt=ne.uniformsGroups;for(let fi=0,gr=yt.length;fi<gr;fi++){let du=yt[fi];xe.update(du,yn),xe.bind(du,yn)}}return yn}function xp(M,H){M.ambientLightColor.needsUpdate=H,M.lightProbe.needsUpdate=H,M.sunLights.needsUpdate=H,M.sunLightShadows.needsUpdate=H,M.directionalLights.needsUpdate=H,M.directionalLightShadows.needsUpdate=H,M.pointLights.needsUpdate=H,M.pointLightShadows.needsUpdate=H,M.spotLights.needsUpdate=H,M.spotLightShadows.needsUpdate=H,M.rectAreaLights.needsUpdate=H,M.hemisphereLights.needsUpdate=H}function bp(M){return M.isMeshLambertMaterial||M.isMeshToonMaterial||M.isMeshPhongMaterial||M.isMeshStandardMaterial||M.isShadowMaterial||M.isShaderMaterial&&M.lights===!0}this.getActiveCubeFace=function(){return _e},this.getActiveMipmapLevel=function(){return ee},this.getRenderTarget=function(){return Y},this.setRenderTargetTextures=function(M,H,ue){let ne=w.get(M);ne.__autoAllocateDepthBuffer=M.resolveDepthBuffer===!1,ne.__autoAllocateDepthBuffer===!1&&(ne.__useRenderToTexture=!1),w.get(M.texture).__webglTexture=H,w.get(M.depthTexture).__webglTexture=ne.__autoAllocateDepthBuffer?void 0:ue,ne.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(M,H){let ue=w.get(M);ue.__webglFramebuffer=H,ue.__useDefaultFramebuffer=H===void 0},this.setRenderTarget=function(M,H=0,ue=0){Y=M,_e=H,ee=ue;let ne=null,ie=!1,De=!1;if(M){let Ie=w.get(M);if(Ie.__useDefaultFramebuffer!==void 0){_.bindFramebuffer(x.FRAMEBUFFER,Ie.__webglFramebuffer),ye.copy(M.viewport),Oe.copy(M.scissor),Ne=M.scissorTest,_.viewport(ye),_.scissor(Oe),_.setScissorTest(Ne),he=-1;return}else if(Ie.__webglFramebuffer===void 0)N.setupRenderTarget(M);else if(Ie.__hasExternalTextures)N.rebindTextures(M,w.get(M.texture).__webglTexture,w.get(M.depthTexture).__webglTexture);else if(M.depthBuffer){let Qe=M.depthTexture;if(Ie.__boundDepthTexture!==Qe){if(Qe!==null&&w.has(Qe)&&(M.width!==Qe.image.width||M.height!==Qe.image.height))throw new Error("THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.");N.setupDepthRenderbuffer(M)}}let ze=M.texture;(ze.isData3DTexture||ze.isDataArrayTexture||ze.isCompressedArrayTexture)&&(De=!0);let Ge=w.get(M).__webglFramebuffer;M.isWebGLCubeRenderTarget?(Array.isArray(Ge[H])?ne=Ge[H][ue]:ne=Ge[H],ie=!0):M.samples>0&&N.useMultisampledRTT(M)===!1?ne=w.get(M).__webglMultisampledFramebuffer:Array.isArray(Ge)?ne=Ge[ue]:ne=Ge,ye.copy(M.viewport),Oe.copy(M.scissor),Ne=M.scissorTest}else ye.copy(k).multiplyScalar(D).floor(),Oe.copy(le).multiplyScalar(D).floor(),Ne=Se;if(ue!==0&&(ne=re),_.bindFramebuffer(x.FRAMEBUFFER,ne)&&_.drawBuffers(M,ne),_.viewport(ye),_.scissor(Oe),_.setScissorTest(Ne),ie){let Ie=w.get(M.texture);x.framebufferTexture2D(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_CUBE_MAP_POSITIVE_X+H,Ie.__webglTexture,ue)}else if(De){let Ie=H;for(let ze=0;ze<M.textures.length;ze++){let Ge=w.get(M.textures[ze]);x.framebufferTextureLayer(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0+ze,Ge.__webglTexture,ue,Ie)}}else if(M!==null&&ue!==0){let Ie=w.get(M.texture);x.framebufferTexture2D(x.FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,Ie.__webglTexture,ue)}he=-1};function uu(M){let H=w.get(M);return(H.__readFormat!==M.format||H.__readType!==M.type)&&(H.__readFormat=M.format,H.__readType=M.type,H.__formatReadable=P.textureFormatReadable(M.format),H.__typeReadable=P.textureTypeReadable(M.type)),H}this.readRenderTargetPixels=function(M,H,ue,ne,ie,De,Fe,Ie=0){if(!(M&&M.isWebGLRenderTarget)){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ze=w.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&Fe!==void 0&&(ze=ze[Fe]),ze){_.bindFramebuffer(x.FRAMEBUFFER,ze);try{let Ge=M.textures[Ie],Qe=Ge.format,it=Ge.type;M.textures.length>1&&x.readBuffer(x.COLOR_ATTACHMENT0+Ie);let Ve=uu(Ge);if(Ve.__formatReadable===!1){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(Ve.__typeReadable===!1){Ye("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}H>=0&&H<=M.width-ne&&ue>=0&&ue<=M.height-ie&&x.readPixels(H,ue,ne,ie,Ae.convert(Qe),Ae.convert(it),De)}finally{let Ge=Y!==null?w.get(Y).__webglFramebuffer:null;_.bindFramebuffer(x.FRAMEBUFFER,Ge)}}},this.readRenderTargetPixelsAsync=async function(M,H,ue,ne,ie,De,Fe,Ie=0){if(!(M&&M.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let ze=w.get(M).__webglFramebuffer;if(M.isWebGLCubeRenderTarget&&Fe!==void 0&&(ze=ze[Fe]),ze)if(H>=0&&H<=M.width-ne&&ue>=0&&ue<=M.height-ie){_.bindFramebuffer(x.FRAMEBUFFER,ze);let Ge=M.textures[Ie],Qe=Ge.format,it=Ge.type;M.textures.length>1&&x.readBuffer(x.COLOR_ATTACHMENT0+Ie);let Ve=uu(Ge);if(Ve.__formatReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(Ve.__typeReadable===!1)throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");let lt=x.createBuffer();x.bindBuffer(x.PIXEL_PACK_BUFFER,lt),x.bufferData(x.PIXEL_PACK_BUFFER,De.byteLength,x.STREAM_READ),x.readPixels(H,ue,ne,ie,Ae.convert(Qe),Ae.convert(it),0),x.bindBuffer(x.PIXEL_PACK_BUFFER,null);let Pt=Y!==null?w.get(Y).__webglFramebuffer:null;_.bindFramebuffer(x.FRAMEBUFFER,Pt);let bt=x.fenceSync(x.SYNC_GPU_COMMANDS_COMPLETE,0);return x.flush(),await Od(x,bt,4),x.bindBuffer(x.PIXEL_PACK_BUFFER,lt),x.getBufferSubData(x.PIXEL_PACK_BUFFER,0,De),x.bindBuffer(x.PIXEL_PACK_BUFFER,null),x.deleteBuffer(lt),x.deleteSync(bt),De}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(M,H=null,ue=0){let ne=Math.pow(2,-ue),ie=Math.floor(M.image.width*ne),De=Math.floor(M.image.height*ne),Fe=H!==null?H.x:0,Ie=H!==null?H.y:0;N.setTexture2D(M,0),x.copyTexSubImage2D(x.TEXTURE_2D,ue,0,0,Fe,Ie,ie,De),_.unbindTexture()},this.copyTextureToTexture=function(M,H,ue=null,ne=null,ie=0,De=0){let Fe,Ie,ze,Ge,Qe,it,Ve,lt,Pt,bt=M.isCompressedTexture?M.mipmaps[De]:M.image;if(ue!==null)Fe=ue.max.x-ue.min.x,Ie=ue.max.y-ue.min.y,ze=ue.isBox3?ue.max.z-ue.min.z:1,Ge=ue.min.x,Qe=ue.min.y,it=ue.isBox3?ue.min.z:0;else{let At=Math.pow(2,-ie);Fe=Math.floor(bt.width*At),Ie=Math.floor(bt.height*At),M.isDataArrayTexture?ze=bt.depth:M.isData3DTexture?ze=Math.floor(bt.depth*At):ze=1,Ge=0,Qe=0,it=0}ne!==null?(Ve=ne.x,lt=ne.y,Pt=ne.z):(Ve=0,lt=0,Pt=0);let gt=Ae.convert(H.format),Wt=Ae.convert(H.type),Ue;H.isData3DTexture?(N.setTexture3D(H,0),Ue=x.TEXTURE_3D):H.isDataArrayTexture||H.isCompressedArrayTexture?(N.setTexture2DArray(H,0),Ue=x.TEXTURE_2D_ARRAY):(N.setTexture2D(H,0),Ue=x.TEXTURE_2D),_.activeTexture(x.TEXTURE0),_.pixelStorei(x.UNPACK_FLIP_Y_WEBGL,H.flipY),_.pixelStorei(x.UNPACK_PREMULTIPLY_ALPHA_WEBGL,H.premultiplyAlpha),_.pixelStorei(x.UNPACK_ALIGNMENT,H.unpackAlignment);let Jt=_.getParameter(x.UNPACK_ROW_LENGTH),ot=_.getParameter(x.UNPACK_IMAGE_HEIGHT),yn=_.getParameter(x.UNPACK_SKIP_PIXELS),Vn=_.getParameter(x.UNPACK_SKIP_ROWS),ui=_.getParameter(x.UNPACK_SKIP_IMAGES);_.pixelStorei(x.UNPACK_ROW_LENGTH,bt.width),_.pixelStorei(x.UNPACK_IMAGE_HEIGHT,bt.height),_.pixelStorei(x.UNPACK_SKIP_PIXELS,Ge),_.pixelStorei(x.UNPACK_SKIP_ROWS,Qe),_.pixelStorei(x.UNPACK_SKIP_IMAGES,it);let mr=M.isDataArrayTexture||M.isData3DTexture,pt=H.isDataArrayTexture||H.isData3DTexture;if(M.isDepthTexture){let At=w.get(M),di=w.get(H),yt=w.get(At.__renderTarget),fi=w.get(di.__renderTarget);_.bindFramebuffer(x.READ_FRAMEBUFFER,yt.__webglFramebuffer),_.bindFramebuffer(x.DRAW_FRAMEBUFFER,fi.__webglFramebuffer);for(let gr=0;gr<ze;gr++)mr&&(x.framebufferTextureLayer(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,w.get(M).__webglTexture,ie,it+gr),x.framebufferTextureLayer(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,w.get(H).__webglTexture,De,Pt+gr)),x.blitFramebuffer(Ge,Qe,Fe,Ie,Ve,lt,Fe,Ie,x.DEPTH_BUFFER_BIT,x.NEAREST);_.bindFramebuffer(x.READ_FRAMEBUFFER,null),_.bindFramebuffer(x.DRAW_FRAMEBUFFER,null)}else if(ie!==0||M.isRenderTargetTexture||w.has(M)){let At=w.get(M),di=w.get(H);_.bindFramebuffer(x.READ_FRAMEBUFFER,G),_.bindFramebuffer(x.DRAW_FRAMEBUFFER,se);for(let yt=0;yt<ze;yt++)mr?x.framebufferTextureLayer(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,At.__webglTexture,ie,it+yt):x.framebufferTexture2D(x.READ_FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,At.__webglTexture,ie),pt?x.framebufferTextureLayer(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,di.__webglTexture,De,Pt+yt):x.framebufferTexture2D(x.DRAW_FRAMEBUFFER,x.COLOR_ATTACHMENT0,x.TEXTURE_2D,di.__webglTexture,De),ie!==0?x.blitFramebuffer(Ge,Qe,Fe,Ie,Ve,lt,Fe,Ie,x.COLOR_BUFFER_BIT,x.NEAREST):pt?x.copyTexSubImage3D(Ue,De,Ve,lt,Pt+yt,Ge,Qe,Fe,Ie):x.copyTexSubImage2D(Ue,De,Ve,lt,Ge,Qe,Fe,Ie);_.bindFramebuffer(x.READ_FRAMEBUFFER,null),_.bindFramebuffer(x.DRAW_FRAMEBUFFER,null)}else pt?M.isDataTexture||M.isData3DTexture?x.texSubImage3D(Ue,De,Ve,lt,Pt,Fe,Ie,ze,gt,Wt,bt.data):H.isCompressedArrayTexture?x.compressedTexSubImage3D(Ue,De,Ve,lt,Pt,Fe,Ie,ze,gt,bt.data):x.texSubImage3D(Ue,De,Ve,lt,Pt,Fe,Ie,ze,gt,Wt,bt):M.isDataTexture?x.texSubImage2D(x.TEXTURE_2D,De,Ve,lt,Fe,Ie,gt,Wt,bt.data):M.isCompressedTexture?x.compressedTexSubImage2D(x.TEXTURE_2D,De,Ve,lt,bt.width,bt.height,gt,bt.data):x.texSubImage2D(x.TEXTURE_2D,De,Ve,lt,Fe,Ie,gt,Wt,bt);_.pixelStorei(x.UNPACK_ROW_LENGTH,Jt),_.pixelStorei(x.UNPACK_IMAGE_HEIGHT,ot),_.pixelStorei(x.UNPACK_SKIP_PIXELS,yn),_.pixelStorei(x.UNPACK_SKIP_ROWS,Vn),_.pixelStorei(x.UNPACK_SKIP_IMAGES,ui),De===0&&H.generateMipmaps&&x.generateMipmap(Ue),_.unbindTexture()},this.initRenderTarget=function(M){w.get(M).__webglFramebuffer===void 0&&N.setupRenderTarget(M)},this.initTexture=function(M){M.isCubeTexture?N.setTextureCube(M,0):M.isData3DTexture?N.setTexture3D(M,0):M.isDataArrayTexture||M.isCompressedArrayTexture?N.setTexture2DArray(M,0):N.setTexture2D(M,0),_.unbindTexture()},this.resetState=function(){_e=0,ee=0,Y=null,_.reset(),Ce.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Pn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=rt._getDrawingBufferColorSpace(e),t.unpackColorSpace=rt._getUnpackColorSpace()}};var Bh={cutterBase:{enabled:!1,type:"parallel",mode:"overlay",rotation:28,color:"#65584d",thickness:.12,scale:4.8,intensity:.42},blade:{enabled:!1,type:"parallel",mode:"overlay",rotation:-28,color:"#65584d",thickness:.11,scale:4,intensity:.38},stampBase:{enabled:!1,type:"cross",mode:"overlay",rotation:42,color:"#65584d",thickness:.1,scale:5.2,intensity:.38},relief:{enabled:!1,type:"double45",mode:"overlay",rotation:18,color:"#65584d",thickness:.09,scale:3.6,intensity:.34},shadow:{enabled:!1,type:"cross",mode:"replace",rotation:45,color:"#4d443e",thickness:.1,scale:4.4,intensity:.44}},Sn={style:"illustrated",shadeSoftness:.65,background:"#a9eaf8",modelColor:"#ffba24",componentColors:!0,colors:{cutterBase:"#e18e25",blade:"#ffbf28",stampBase:"#38bfb8",relief:"#f07891"},lightAzimuth:-40,lightElevation:55,lightIntensity:2.4,ambient:.8,shadows:!0,groundDistance:4,projectedShadows:!0,modelShadows:!0,modelShadowMode:"soft",aoIntensity:.32,aoRadius:1.4,shadowOpacity:.3,shadowSoftness:3,lineColor:"#382a24",lineWidth:1.4,internalEdges:!0,hatching:.45,hatchMaster:!1,hatchProfiles:structuredClone(Bh),projection:"perspective",showDims:!1,transparent:!1,exportSize:1600};function kh(n){return{...structuredClone(Sn),style:n,...n==="technical"?{background:"#ffffff",modelColor:"#ffffff",componentColors:!1,lineColor:"#454851",lineWidth:.9,internalEdges:!0,shadows:!1,projectedShadows:!1,modelShadows:!1,modelShadowMode:"none",aoIntensity:.18,projection:"orthographic"}:n==="sketch"?{background:"#faf8f0",modelColor:"#eee9dc",componentColors:!1,lineColor:"#39362f",lineWidth:1.15,internalEdges:!0,shadows:!0,groundDistance:3,projectedShadows:!0,modelShadows:!0,modelShadowMode:"soft",aoIntensity:.28,shadowOpacity:.18,projection:"orthographic"}:{}}}function os(n){let e={};for(let[t,i]of Object.entries(Bh))e[t]={...i,...n?.hatchProfiles?.[t]||{}};return e}function Af(n,e={}){let t=n.attributes.position.array,i=n.index?.array||Uint32Array.from({length:t.length/3},(u,d)=>d),r=[],s=[],o=[],a=new Map,c=e.height-e.chamferHeight;for(let u=0;u<i.length;u+=3){let d=[i[u],i[u+1],i[u+2]],h=d.map(T=>[t[T*3],t[T*3+1],t[T*3+2]]),f=h[1].map((T,y)=>T-h[0][y]),g=h[2].map((T,y)=>T-h[0][y]),b=[f[1]*g[2]-f[2]*g[1],f[2]*g[0]-f[0]*g[2],f[0]*g[1]-f[1]*g[0]],m=Math.hypot(...b);if(m<1e-15)continue;b=b.map(T=>T/m);let p=h.map(T=>T[2]),S=Math.abs(b[2])>.9999?"cap:"+Math.round(p[0]*1e4):e.chamfer&&Math.min(...p)>=c-1e-4&&Math.max(...p)>c+1e-4&&b[2]>.001?"bevel":"wall";for(let T=0;T<3;T++){let y=S+":"+d[T],E=a.get(y);E||(E=[],a.set(y,E));let A=E.find(z=>z.n[0]*b[0]+z.n[1]*b[1]+z.n[2]*b[2]>.2);A||(A={n:b,id:r.length/3},E.push(A),r.push(...h[T]),s.push(0,0,0));let U=h[(T+1)%3].map((z,X)=>z-h[T][X]),v=h[(T+2)%3].map((z,X)=>z-h[T][X]),C=Math.acos(Math.max(-1,Math.min(1,(U[0]*v[0]+U[1]*v[1]+U[2]*v[2])/(Math.hypot(...U)*Math.hypot(...v)||1))));for(let z=0;z<3;z++)s[A.id*3+z]+=b[z]*C;o.push(A.id)}}for(let u=0;u<s.length;u+=3){let d=Math.hypot(s[u],s[u+1],s[u+2])||1;for(let h=0;h<3;h++)s[u+h]/=d}let l=new wt;return l.setAttribute("position",new Ct(new Float32Array(r),3)),l.setAttribute("normal",new Ct(new Float32Array(s),3)),l.setIndex(o),l}function zh(n,e){if(!n.gradientMap||n.userData.shadowMode==="hard")return;let t=n.gradientMap.image.data,i=Math.max(0,Math.min(1,e??.65)),r=.001+i*.32,s=(o,a)=>{let c=On.clamp((a-o+r/2)/r,0,1);return c*c*(3-2*c)};for(let o=0;o<t.length;o++){let a=o/(t.length-1);t[o]=Math.round(70+95*s(1/3,a)+90*s(2/3,a))}n.gradientMap.needsUpdate=!0}function wf(n,e){if(n==="hard"){let r=new $i(new Uint8Array([72,72,156,156,255,255]),6,1,ts);return r.minFilter=r.magFilter=Dt,r.needsUpdate=!0,r}let t=new $i(new Uint8Array(256),256,1,ts);return t.minFilter=t.magFilter=Nt,t.needsUpdate=!0,zh({gradientMap:t,userData:{shadowMode:"soft"}},e),t}function Tf(n){return n==="parallel"?1:n==="cross"?2:n==="double45"?3:n==="triple"?4:n==="dots"?5:n==="dotsDense"?6:n==="dotsSparse"?7:n==="dash"?8:n==="scribble"?9:0}function Dv(n){let e=On.degToRad(n.lightAzimuth??-40),t=On.degToRad(n.lightElevation??55);return new O(Math.cos(e)*Math.cos(t),Math.sin(e)*Math.cos(t),Math.sin(t)).normalize()}function Ef(n,e){return{...Bh[e],...n.hatchProfiles?.[e]||{}}}function Lv(n){if(n.userData.rvPresentationShader)return;let e=n.onBeforeCompile;n.onBeforeCompile=t=>{e?.(t);let i=n.userData.rvUniforms={aoIntensity:{value:n.userData.aoIntensity||0},aoAnchor:{value:n.userData.aoAnchor||0},aoRadius:{value:n.userData.aoRadius||1},hatchEnabled:{value:0},hatchType:{value:0},hatchMode:{value:0},hatchRotation:{value:0},hatchColor:{value:new He("#555555")},hatchThickness:{value:.1},hatchScale:{value:4},hatchIntensity:{value:0},shadowHatchEnabled:{value:0},shadowHatchType:{value:0},shadowHatchMode:{value:1},shadowHatchRotation:{value:0},shadowHatchColor:{value:new He("#444444")},shadowHatchThickness:{value:.1},shadowHatchScale:{value:4},shadowHatchIntensity:{value:0},lightDir:{value:new O(.5,-.5,.7).normalize()},baseColor:{value:new He(n.color)},backgroundColor:{value:new He("#ffffff")}};Object.assign(t.uniforms,{rvAOIntensity:i.aoIntensity,rvAOAnchor:i.aoAnchor,rvAORadius:i.aoRadius,rvHatchEnabled:i.hatchEnabled,rvHatchType:i.hatchType,rvHatchMode:i.hatchMode,rvHatchRotation:i.hatchRotation,rvHatchColor:i.hatchColor,rvHatchThickness:i.hatchThickness,rvHatchScale:i.hatchScale,rvHatchIntensity:i.hatchIntensity,rvShadowHatchEnabled:i.shadowHatchEnabled,rvShadowHatchType:i.shadowHatchType,rvShadowHatchMode:i.shadowHatchMode,rvShadowHatchRotation:i.shadowHatchRotation,rvShadowHatchColor:i.shadowHatchColor,rvShadowHatchThickness:i.shadowHatchThickness,rvShadowHatchScale:i.shadowHatchScale,rvShadowHatchIntensity:i.shadowHatchIntensity,rvLightDir:i.lightDir,rvBaseColor:i.baseColor,rvBackgroundColor:i.backgroundColor}),t.vertexShader=`varying vec3 rvObjPos; varying vec3 rvObjNormal; varying vec3 rvWorldNormal;
`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
rvObjPos=position; rvObjNormal=normal; rvWorldNormal=normalize(mat3(modelMatrix)*normal);`),t.fragmentShader=`varying vec3 rvObjPos; varying vec3 rvObjNormal; varying vec3 rvWorldNormal;
  uniform float rvAOIntensity; uniform float rvAOAnchor; uniform float rvAORadius;
  uniform float rvHatchEnabled; uniform int rvHatchType; uniform float rvHatchMode; uniform float rvHatchRotation; uniform vec3 rvHatchColor; uniform float rvHatchThickness; uniform float rvHatchScale; uniform float rvHatchIntensity;
  uniform float rvShadowHatchEnabled; uniform int rvShadowHatchType; uniform float rvShadowHatchMode; uniform float rvShadowHatchRotation; uniform vec3 rvShadowHatchColor; uniform float rvShadowHatchThickness; uniform float rvShadowHatchScale; uniform float rvShadowHatchIntensity; uniform vec3 rvLightDir; uniform vec3 rvBaseColor; uniform vec3 rvBackgroundColor;
  float rvHash21(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453123);}
  float rvHatchLine(vec2 p,float rot,float scale,float thickness){float a=radians(rot),c=cos(a),s=sin(a);vec2 q=mat2(c,-s,s,c)*p;float v=q.y/max(scale,.05);float d=abs(fract(v)-.5);float aa=max(fwidth(v),.001);float t=clamp(thickness,.015,.46);return 1.-smoothstep(t,t+aa,d);}
  float rvDotPattern(vec2 p,float rot,float scale,float thickness,float density){float a=radians(rot),c=cos(a),s=sin(a);vec2 q=mat2(c,-s,s,c)*p/max(scale,.08);vec2 cell=floor(q*density);vec2 fracp=fract(q*density)-.5;vec2 jitter=(vec2(rvHash21(cell),rvHash21(cell+7.13))-.5)*.35;float r=length(fracp-jitter);float rad=max(.06,.16*clamp(thickness*5.,.25,2.))+0.015*(density-1.);float aa=max(fwidth(r),.002);return 1.-smoothstep(rad,rad+aa,r);}
  float rvScribblePattern(vec2 p,float rot,float scale,float thickness){float l1=rvHatchLine(p,rot,scale,thickness*.8);float l2=rvHatchLine(p+vec2(scale*.17,scale*.11),rot+23.,scale*1.2,thickness*.7);return max(l1*.9,l2*.75);}
  float rvHatchPattern(vec2 p,int type,float rot,float scale,float thickness){if(type<=0)return 0.;float a=rvHatchLine(p,rot,scale,thickness);if(type==1)return a;if(type==2)return max(a,rvHatchLine(p,rot+90.,scale,thickness));if(type==3)return max(a,rvHatchLine(p,rot+45.,scale,thickness));if(type==4)return max(a,max(rvHatchLine(p,rot+60.,scale,thickness),rvHatchLine(p,rot-60.,scale,thickness)));if(type==5)return rvDotPattern(p,rot,scale,thickness,1.0);if(type==6)return rvDotPattern(p,rot,scale,thickness,1.6);if(type==7)return rvDotPattern(p,rot,scale,thickness,.7);if(type==8)return a*(1.-rvHatchLine(p,rot+90.,scale*1.7,.3));if(type==9)return rvScribblePattern(p,rot,scale,thickness);return a;}
  float rvTriHatch(vec3 pos,vec3 n,int type,float rot,float scale,float thickness){vec3 wn=normalize(n);vec3 w=pow(abs(wn),vec3(5.));w/=max(w.x+w.y+w.z,.0001);float x=rvHatchPattern(pos.yz,type,rot,scale,thickness),y=rvHatchPattern(pos.xz,type,rot,scale,thickness),z=rvHatchPattern(pos.xy,type,rot,scale,thickness);return x*w.x+y*w.y+z*w.z;}
  `+t.fragmentShader,t.fragmentShader=t.fragmentShader.replace("#include <shadowmap_pars_fragment>",`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`),t.fragmentShader=t.fragmentShader.replace("#include <tonemapping_fragment>",`float rvAOD=abs(rvObjPos.z-rvAOAnchor);float rvAOContact=1.-smoothstep(0.,max(rvAORadius,.001),rvAOD);float rvAOWall=.22+.78*(1.-abs(normalize(rvObjNormal).z));float rvAO=clamp(rvAOIntensity*rvAOContact*rvAOWall,0.,.88);gl_FragColor.rgb*=1.-rvAO;
  float rvProjectedShadow=0.;
  #if defined(USE_SHADOWMAP) && !defined(RV_UNLIT)
  rvProjectedShadow=clamp(1.-getShadowMask(),0.,1.);
  #endif
  if(rvHatchEnabled>.5){float hp=rvTriHatch(rvObjPos,rvObjNormal,rvHatchType,rvHatchRotation,rvHatchScale,rvHatchThickness);float hm=clamp(hp*rvHatchIntensity,0.,1.);if(rvHatchMode>.5){vec3 rvPaper=mix(rvBackgroundColor,gl_FragColor.rgb,.14);gl_FragColor.rgb=mix(rvPaper,rvHatchColor,hm);}else{gl_FragColor.rgb=mix(gl_FragColor.rgb,rvHatchColor,hm);}}
  if(rvShadowHatchEnabled>.5){float rvShadowRegion=max(rvProjectedShadow,rvAO*.82);rvShadowRegion=smoothstep(.06,.24,rvShadowRegion);if(rvShadowRegion>.001){float hp=rvTriHatch(rvObjPos,rvObjNormal,rvShadowHatchType,rvShadowHatchRotation,rvShadowHatchScale,rvShadowHatchThickness);float hm=clamp(hp*rvShadowHatchIntensity*rvShadowRegion,0.,1.);if(rvShadowHatchMode>.5){vec3 rvShadowBase=mix(gl_FragColor.rgb,mix(rvBaseColor*.92,rvBackgroundColor,.15),.72*rvShadowRegion);gl_FragColor.rgb=mix(rvShadowBase,rvShadowHatchColor,hm);}else{gl_FragColor.rgb=mix(gl_FragColor.rgb,rvShadowHatchColor,hm);}}}
  #include <tonemapping_fragment>`),n.userData.flatMode&&(t.fragmentShader=t.fragmentShader.replace("#include <opaque_fragment>",`outgoingLight=diffuseColor.rgb*getShadowMask();
#include <opaque_fragment>`)),n.userData.shader=t,zl(n,n.userData.presentationSettings||Sn,n.userData.role)},n.userData.rvPresentationShader=!0,n.needsUpdate=!0}function Cf(n,e,t,i){t.computeBoundingBox();let r=t.boundingBox,s=r?.min?.z??0,o=r?.max?.z??0;n.userData.aoAnchor=e==="cutterBase"||e==="stampBase"?o:s,n.userData.aoIntensity=i.aoIntensity??0,n.userData.aoRadius=i.aoRadius??1.4,n.userData.role=e,n.userData.presentationSettings=i,Lv(n),zl(n,i,e)}function zl(n,e,t){n.userData.presentationSettings=e,n.userData.role=t;let i=n.userData.rvUniforms||n.userData.shader?.uniforms;if(!i)return;let r=Ef(e,t),s=Ef(e,"shadow"),o=!!e.hatchMaster,a=(l,u)=>{let d=i[l]||i["rv"+l[0].toUpperCase()+l.slice(1)];d&&(d.value=u)};a("aoIntensity",e.aoIntensity??0),a("aoAnchor",n.userData.aoAnchor??0),a("aoRadius",e.aoRadius??1.4),a("hatchEnabled",o&&r.enabled?1:0),a("hatchType",Tf(r.type)),a("hatchMode",r.mode==="replace"?1:0),a("hatchRotation",+r.rotation||0),(i.hatchColor||i.rvHatchColor)?.value&&(i.hatchColor||i.rvHatchColor).value.set(r.color||"#555555"),a("hatchThickness",+r.thickness||.1),a("hatchScale",+r.scale||4),a("hatchIntensity",+r.intensity||0),a("shadowHatchEnabled",o&&s.enabled?1:0),a("shadowHatchType",Tf(s.type)),a("shadowHatchMode",s.mode==="replace"?1:0),a("shadowHatchRotation",+s.rotation||0),(i.shadowHatchColor||i.rvShadowHatchColor)?.value&&(i.shadowHatchColor||i.rvShadowHatchColor).value.set(s.color||"#444444"),a("shadowHatchThickness",+s.thickness||.1),a("shadowHatchScale",+s.scale||4),a("shadowHatchIntensity",+s.intensity||0);let c=Dv(e);(i.lightDir||i.rvLightDir)?.value&&(i.lightDir||i.rvLightDir).value.copy(c),(i.baseColor||i.rvBaseColor)?.value&&(i.baseColor||i.rvBaseColor).value.copy(n.color),(i.backgroundColor||i.rvBackgroundColor)?.value&&(i.backgroundColor||i.rvBackgroundColor).value.set(e.background||"#ffffff")}function Rf(n,e){let t=n.componentColors?n.colors[e]:n.modelColor,i=n.modelShadowMode||(n.modelShadows===!1?"none":"soft"),r;return i==="none"?(r=new er({color:t}),r.userData.flatMode=!0):i==="hard"?(r=new er({color:t,gradientMap:wf("hard",n.shadeSoftness)}),r.userData.shadowMode="hard"):n.style==="illustrated"||n.style==="sketch"?(r=new er({color:t,gradientMap:wf("soft",n.shadeSoftness)}),r.userData.shadowMode="soft"):(r=new Qi({color:t,roughness:1,metalness:0}),r.userData.shadowMode="soft"),r.userData.role=e,r}function Pf(n){return new Ht({side:Gt,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:2,polygonOffsetUnits:2,uniforms:{ink:{value:new He(n.lineColor)},width:{value:n.lineWidth},resolution:{value:800}},vertexShader:"uniform float width; uniform float resolution; void main(){vec4 v=modelViewMatrix*vec4(position,1.);vec4 c=projectionMatrix*v;vec3 n=normalMatrix*normal;vec2 d=normalize(n.xy+vec2(1e-8)); c.xy+=d*width*2./resolution*c.w;gl_Position=c;}",fragmentShader:`uniform vec3 ink;void main(){gl_FragColor=vec4(ink,1.); #include <colorspace_fragment>
}`.replace("; #include",`;
#include`)})}var mo=Qt,go=class n extends tr{constructor(e){super(e),this.defaultDPI=90,this.defaultUnit="px"}load(e,t,i,r){let s=this,o=new Zs(s.manager);o.setPath(s.path),o.setRequestHeader(s.requestHeader),o.setWithCredentials(s.withCredentials),o.load(e,function(a){try{t(s.parse(a))}catch(c){r?r(c):console.error(c),s.manager.itemError(e)}},i,r)}parse(e){let t=this;function i(D,L){if(D.nodeType!==1)return;D.hasAttribute("filter")&&console.warn("THREE.SVGLoader: Filters are not supported.");let R=E(D),k=!1,le=null;switch(D.nodeName){case"svg":L=b(D,L);break;case"style":s(D);break;case"g":L=b(D,L);break;case"path":L=b(D,L),D.hasAttribute("d")&&(le=r(D));break;case"rect":L=b(D,L),le=c(D);break;case"polygon":L=b(D,L),le=l(D);break;case"polyline":L=b(D,L),le=u(D);break;case"circle":L=b(D,L),le=d(D);break;case"ellipse":L=b(D,L),le=h(D);break;case"line":L=b(D,L),le=f(D);break;case"defs":k=!0;break;case"use":L=b(D,L);let ae=(D.getAttributeNS("http://www.w3.org/1999/xlink","href")||"").substring(1),Z=D.viewportElement.getElementById(ae);Z?i(Z,L):console.warn("SVGLoader: 'use node' references non-existent node id: "+ae);break;default:}if(le){L.fill!==void 0&&L.fill!=="none"&&!L.fill.startsWith("url")&&le.color.setStyle(L.fill,mo),v(le,Ze),se.push(le);let B=Object.assign({},L);B.strokeWidth=L.strokeWidth*re(Ze),le.userData={node:D,style:B,transform:Ze.clone(),gradients:ee}}let Se=D.childNodes;for(let B=0;B<Se.length;B++){let ae=Se[B];k&&ae.nodeName!=="style"&&ae.nodeName!=="defs"||i(ae,L)}R&&(Y.pop(),Y.length>0?Ze.copy(Y[Y.length-1]):Ze.identity())}function r(D){let L=new Dn,R=new be,k=new be,le=new be,Se=!0,B=!1,ae=D.getAttribute("d");if(ae===""||ae==="none")return null;let Z=ae.match(/[a-df-z][^a-df-z]*/ig);for(let pe=0,me=Z.length;pe<me;pe++){let Me=Z[pe],Le=Me.charAt(0),Te=Me.slice(1).trim();Se===!0&&(B=!0,Se=!1);let K;switch(Le){case"M":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2)R.x=K[x+0],R.y=K[x+1],k.x=R.x,k.y=R.y,x===0?L.moveTo(R.x,R.y):L.lineTo(R.x,R.y),x===0&&le.copy(R);break;case"H":K=p(Te);for(let x=0,Be=K.length;x<Be;x++)R.x=K[x],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"V":K=p(Te);for(let x=0,Be=K.length;x<Be;x++)R.y=K[x],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"L":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2)R.x=K[x+0],R.y=K[x+1],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"C":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=6)L.bezierCurveTo(K[x+0],K[x+1],K[x+2],K[x+3],K[x+4],K[x+5]),k.x=K[x+2],k.y=K[x+3],R.x=K[x+4],R.y=K[x+5],x===0&&B===!0&&le.copy(R);break;case"S":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=4)L.bezierCurveTo(m(R.x,k.x),m(R.y,k.y),K[x+0],K[x+1],K[x+2],K[x+3]),k.x=K[x+0],k.y=K[x+1],R.x=K[x+2],R.y=K[x+3],x===0&&B===!0&&le.copy(R);break;case"Q":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=4)L.quadraticCurveTo(K[x+0],K[x+1],K[x+2],K[x+3]),k.x=K[x+0],k.y=K[x+1],R.x=K[x+2],R.y=K[x+3],x===0&&B===!0&&le.copy(R);break;case"T":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2){let Xe=m(R.x,k.x),P=m(R.y,k.y);L.quadraticCurveTo(Xe,P,K[x+0],K[x+1]),k.x=Xe,k.y=P,R.x=K[x+0],R.y=K[x+1],x===0&&B===!0&&le.copy(R)}break;case"A":K=p(Te,[3,4],7);for(let x=0,Be=K.length;x<Be;x+=7){if(K[x+5]==R.x&&K[x+6]==R.y)continue;let Xe=R.clone();R.x=K[x+5],R.y=K[x+6],k.x=R.x,k.y=R.y,o(L,K[x],K[x+1],K[x+2],K[x+3],K[x+4],Xe,R),x===0&&B===!0&&le.copy(R)}break;case"m":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2)R.x+=K[x+0],R.y+=K[x+1],k.x=R.x,k.y=R.y,x===0?L.moveTo(R.x,R.y):L.lineTo(R.x,R.y),x===0&&le.copy(R);break;case"h":K=p(Te);for(let x=0,Be=K.length;x<Be;x++)R.x+=K[x],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"v":K=p(Te);for(let x=0,Be=K.length;x<Be;x++)R.y+=K[x],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"l":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2)R.x+=K[x+0],R.y+=K[x+1],k.x=R.x,k.y=R.y,L.lineTo(R.x,R.y),x===0&&B===!0&&le.copy(R);break;case"c":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=6)L.bezierCurveTo(R.x+K[x+0],R.y+K[x+1],R.x+K[x+2],R.y+K[x+3],R.x+K[x+4],R.y+K[x+5]),k.x=R.x+K[x+2],k.y=R.y+K[x+3],R.x+=K[x+4],R.y+=K[x+5],x===0&&B===!0&&le.copy(R);break;case"s":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=4)L.bezierCurveTo(m(R.x,k.x),m(R.y,k.y),R.x+K[x+0],R.y+K[x+1],R.x+K[x+2],R.y+K[x+3]),k.x=R.x+K[x+0],k.y=R.y+K[x+1],R.x+=K[x+2],R.y+=K[x+3],x===0&&B===!0&&le.copy(R);break;case"q":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=4)L.quadraticCurveTo(R.x+K[x+0],R.y+K[x+1],R.x+K[x+2],R.y+K[x+3]),k.x=R.x+K[x+0],k.y=R.y+K[x+1],R.x+=K[x+2],R.y+=K[x+3],x===0&&B===!0&&le.copy(R);break;case"t":K=p(Te);for(let x=0,Be=K.length;x<Be;x+=2){let Xe=m(R.x,k.x),P=m(R.y,k.y);L.quadraticCurveTo(Xe,P,R.x+K[x+0],R.y+K[x+1]),k.x=Xe,k.y=P,R.x=R.x+K[x+0],R.y=R.y+K[x+1],x===0&&B===!0&&le.copy(R)}break;case"a":K=p(Te,[3,4],7);for(let x=0,Be=K.length;x<Be;x+=7){if(K[x+5]==0&&K[x+6]==0)continue;let Xe=R.clone();R.x+=K[x+5],R.y+=K[x+6],k.x=R.x,k.y=R.y,o(L,K[x],K[x+1],K[x+2],K[x+3],K[x+4],Xe,R),x===0&&B===!0&&le.copy(R)}break;case"Z":case"z":L.currentPath.autoClose=!0,L.currentPath.curves.length>0&&(R.copy(le),L.currentPath.currentPoint.copy(R),Se=!0);break;default:console.warn(Me)}B=!1}return L}function s(D){if(!(!D.sheet||!D.sheet.cssRules||!D.sheet.cssRules.length))for(let L=0;L<D.sheet.cssRules.length;L++){let R=D.sheet.cssRules[L];if(R.type!==1)continue;let k=R.selectorText.split(/,/gm).filter(Boolean).map(le=>le.trim());for(let le=0;le<k.length;le++){let Se=Object.fromEntries(Object.entries(R.style).filter(([,B])=>B!==""));_e[k[le]]=Object.assign(_e[k[le]]||{},Se)}}}function o(D,L,R,k,le,Se,B,ae){if(L==0||R==0){D.lineTo(ae.x,ae.y);return}k=k*Math.PI/180,L=Math.abs(L),R=Math.abs(R);let Z=(B.x-ae.x)/2,pe=(B.y-ae.y)/2,me=Math.cos(k)*Z+Math.sin(k)*pe,Me=-Math.sin(k)*Z+Math.cos(k)*pe,Le=L*L,Te=R*R,K=me*me,x=Me*Me,Be=K/Le+x/Te;if(Be>1){let q=Math.sqrt(Be);L=q*L,R=q*R,Le=L*L,Te=R*R}let Xe=Le*x+Te*K,P=(Le*Te-Xe)/Xe,_=Math.sqrt(Math.max(0,P));le===Se&&(_=-_);let j=_*L*Me/R,w=-_*R*me/L,N=Math.cos(k)*j-Math.sin(k)*w+(B.x+ae.x)/2,J=Math.sin(k)*j+Math.cos(k)*w+(B.y+ae.y)/2,oe=a(1,0,(me-j)/L,(Me-w)/R),$=a((me-j)/L,(Me-w)/R,(-me-j)/L,(-Me-w)/R)%(Math.PI*2);D.currentPath.absellipse(N,J,L,R,oe,oe+$,Se===0,k)}function a(D,L,R,k){let le=D*R+L*k,Se=Math.sqrt(D*D+L*L)*Math.sqrt(R*R+k*k),B=Math.acos(Math.max(-1,Math.min(1,le/Se)));return D*k-L*R<0&&(B=-B),B}function c(D){let L=y(D.getAttribute("x")||0),R=y(D.getAttribute("y")||0),k=y(D.getAttribute("rx")||D.getAttribute("ry")||0),le=y(D.getAttribute("ry")||D.getAttribute("rx")||0),Se=y(D.getAttribute("width")),B=y(D.getAttribute("height")),ae=1-.551915024494,Z=new Dn;return Z.moveTo(L+k,R),Z.lineTo(L+Se-k,R),(k!==0||le!==0)&&Z.bezierCurveTo(L+Se-k*ae,R,L+Se,R+le*ae,L+Se,R+le),Z.lineTo(L+Se,R+B-le),(k!==0||le!==0)&&Z.bezierCurveTo(L+Se,R+B-le*ae,L+Se-k*ae,R+B,L+Se-k,R+B),Z.lineTo(L+k,R+B),(k!==0||le!==0)&&Z.bezierCurveTo(L+k*ae,R+B,L,R+B-le*ae,L,R+B-le),Z.lineTo(L,R+le),(k!==0||le!==0)&&Z.bezierCurveTo(L,R+le*ae,L+k*ae,R,L+k,R),Z}function l(D){function L(Se,B,ae){let Z=y(B),pe=y(ae);le===0?k.moveTo(Z,pe):k.lineTo(Z,pe),le++}let R=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,k=new Dn,le=0;return D.getAttribute("points").replace(R,L),k.currentPath.autoClose=!0,k}function u(D){function L(Se,B,ae){let Z=y(B),pe=y(ae);le===0?k.moveTo(Z,pe):k.lineTo(Z,pe),le++}let R=/([+-]?\d*\.?\d+(?:e[+-]?\d+)?)(?:,|\s)([+-]?\d*\.?\d+(?:e[+-]?\d+)?)/g,k=new Dn,le=0;return D.getAttribute("points").replace(R,L),k.currentPath.autoClose=!1,k}function d(D){let L=y(D.getAttribute("cx")||0),R=y(D.getAttribute("cy")||0),k=y(D.getAttribute("r")||0),le=new qn;le.absarc(L,R,k,0,Math.PI*2);let Se=new Dn;return Se.subPaths.push(le),Se}function h(D){let L=y(D.getAttribute("cx")||0),R=y(D.getAttribute("cy")||0),k=y(D.getAttribute("rx")||0),le=y(D.getAttribute("ry")||0),Se=new qn;Se.absellipse(L,R,k,le,0,Math.PI*2);let B=new Dn;return B.subPaths.push(Se),B}function f(D){let L=y(D.getAttribute("x1")||0),R=y(D.getAttribute("y1")||0),k=y(D.getAttribute("x2")||0),le=y(D.getAttribute("y2")||0),Se=new Dn;return Se.moveTo(L,R),Se.lineTo(k,le),Se.currentPath.autoClose=!1,Se}function g(D){let L="http://www.w3.org/1999/xlink",R=D.querySelectorAll("linearGradient, radialGradient"),k=["x1","y1","x2","y2","cx","cy","r","fx","fy","gradientUnits","gradientTransform","spreadMethod"],le={};for(let B of R){let ae=B.getAttribute("id");if(!ae)continue;let Z={type:B.nodeName==="radialGradient"?"radialGradient":"linearGradient",attrs:{},stops:null,href:null},pe=B.getAttributeNS(L,"href")||B.getAttribute("href")||"";pe.startsWith("#")&&(Z.href=pe.substring(1));for(let Me of k)B.hasAttribute(Me)&&(Z.attrs[Me]=B.getAttribute(Me));let me=B.querySelectorAll("stop");if(me.length>0){Z.stops=[];for(let Me of me){let Le=Me.getAttribute("stop-color");!Le&&Me.style&&(Le=Me.style["stop-color"]),Le||(Le="#000");let Te=Me.getAttribute("stop-opacity");(Te===null||Te==="")&&Me.style&&(Te=Me.style["stop-opacity"]),Te=Te===null||Te===""||Te===void 0?1:Math.max(0,Math.min(1,parseFloat(Te)));let K=Math.max(0,Math.min(1,parseFloat(Me.getAttribute("offset")||"0")));Z.stops.push({offset:K,color:Le,opacity:Te})}}le[ae]=Z}function Se(B,ae){let Z=le[B];if(!Z||ae.has(B))return Z;if(ae.add(B),Z.href&&le[Z.href]){let pe=Se(Z.href,ae);if(pe){Z.stops||(Z.stops=pe.stops);for(let me in pe.attrs)me in Z.attrs||(Z.attrs[me]=pe.attrs[me])}}return Z}for(let B in le)Se(B,new Set);for(let B in le){let Me=function(Le){return typeof Le!="string"?0:Le.endsWith("%")?parseFloat(Le)/100:y(Le)},ae=le[B],Z=ae.attrs,pe=Z.gradientUnits==="userSpaceOnUse"?"userSpaceOnUse":"objectBoundingBox",me={type:ae.type,gradientUnits:pe,spreadMethod:Z.spreadMethod==="reflect"||Z.spreadMethod==="repeat"?Z.spreadMethod:"pad",gradientTransform:null,stops:(ae.stops||[]).slice().sort((Le,Te)=>Le.offset-Te.offset)};if(Z.gradientTransform&&(me.gradientTransform=new je,U(Z.gradientTransform,me.gradientTransform)),ae.type==="linearGradient")me.x1=Z.x1!==void 0?Me(Z.x1):0,me.y1=Z.y1!==void 0?Me(Z.y1):0,me.x2=Z.x2!==void 0?Me(Z.x2):pe==="objectBoundingBox"?1:0,me.y2=Z.y2!==void 0?Me(Z.y2):0;else{let Le=pe==="objectBoundingBox"?.5:0,Te=pe==="objectBoundingBox"?.5:0;me.cx=Z.cx!==void 0?Me(Z.cx):Le,me.cy=Z.cy!==void 0?Me(Z.cy):Le,me.r=Z.r!==void 0?Me(Z.r):Te,me.fx=Z.fx!==void 0?Me(Z.fx):me.cx,me.fy=Z.fy!==void 0?Me(Z.fy):me.cy}ee[B]=me}}function b(D,L){L=Object.assign({},L);let R={};if(D.hasAttribute("class")){let B=D.getAttribute("class").split(/\s/).filter(Boolean).map(ae=>ae.trim());for(let ae=0;ae<B.length;ae++)R=Object.assign(R,_e["."+B[ae]])}D.hasAttribute("id")&&(R=Object.assign(R,_e["#"+D.getAttribute("id")]));function k(B,ae,Z){Z===void 0&&(Z=function(me){return me}),D.hasAttribute(B)&&(L[ae]=Z(D.getAttribute(B))),R[ae]&&(L[ae]=Z(R[ae])),D.style&&D.style[B]!==""&&(L[ae]=Z(D.style[B]))}function le(B){return Math.max(0,Math.min(1,y(B)))}function Se(B){return Math.max(0,y(B))}return k("fill","fill"),k("fill-opacity","fillOpacity",le),k("fill-rule","fillRule"),k("opacity","opacity",le),k("stroke","stroke"),k("stroke-opacity","strokeOpacity",le),k("stroke-width","strokeWidth",Se),k("stroke-linejoin","strokeLineJoin"),k("stroke-linecap","strokeLineCap"),k("stroke-miterlimit","strokeMiterLimit",Se),k("visibility","visibility"),L}function m(D,L){return D-(L-D)}function p(D,L,R){if(typeof D!="string")throw new TypeError("Invalid input: "+typeof D);let k={SEPARATOR:/[ \t\r\n\,.\-+]/,WHITESPACE:/[ \t\r\n]/,DIGIT:/[\d]/,SIGN:/[-+]/,POINT:/\./,COMMA:/,/,EXP:/e/i,FLAGS:/[01]/},le=0,Se=1,B=2,ae=3,Z=le,pe=!0,me="",Me="",Le=[];function Te(Xe,P,_){let j=new SyntaxError('Unexpected character "'+Xe+'" at index '+P+".");throw j.partial=_,j}function K(){me!==""&&(Me===""?Le.push(Number(me)):Le.push(Number(me)*Math.pow(10,Number(Me)))),me="",Me=""}let x,Be=D.length;for(let Xe=0;Xe<Be;Xe++){if(x=D[Xe],Array.isArray(L)&&L.includes(Le.length%R)&&k.FLAGS.test(x)){Z=Se,me=x,K();continue}if(Z===le){if(k.WHITESPACE.test(x))continue;if(k.DIGIT.test(x)||k.SIGN.test(x)){Z=Se,me=x;continue}if(k.POINT.test(x)){Z=B,me=x;continue}k.COMMA.test(x)&&(pe&&Te(x,Xe,Le),pe=!0)}if(Z===Se){if(k.DIGIT.test(x)){me+=x;continue}if(k.POINT.test(x)){me+=x,Z=B;continue}if(k.EXP.test(x)){Z=ae;continue}k.SIGN.test(x)&&me.length===1&&k.SIGN.test(me[0])&&Te(x,Xe,Le)}if(Z===B){if(k.DIGIT.test(x)){me+=x;continue}if(k.EXP.test(x)){Z=ae;continue}k.POINT.test(x)&&me[me.length-1]==="."&&Te(x,Xe,Le)}if(Z===ae){if(k.DIGIT.test(x)){Me+=x;continue}if(k.SIGN.test(x)){if(Me===""){Me+=x;continue}Me.length===1&&k.SIGN.test(Me)&&Te(x,Xe,Le)}}k.WHITESPACE.test(x)?(K(),Z=le,pe=!1):k.COMMA.test(x)?(K(),Z=le,pe=!0):k.SIGN.test(x)?(K(),Z=Se,me=x):k.POINT.test(x)?(K(),Z=B,me=x):Te(x,Xe,Le)}return K(),Le}let S=["mm","cm","in","pt","pc","px"],T={mm:{mm:1,cm:.1,in:1/25.4,pt:72/25.4,pc:6/25.4,px:-1},cm:{mm:10,cm:1,in:1/2.54,pt:72/2.54,pc:6/2.54,px:-1},in:{mm:25.4,cm:2.54,in:1,pt:72,pc:6,px:-1},pt:{mm:25.4/72,cm:2.54/72,in:1/72,pt:1,pc:6/72,px:-1},pc:{mm:25.4/6,cm:2.54/6,in:1/6,pt:72/6,pc:1,px:-1},px:{px:1}};function y(D){let L="px";if(typeof D=="string"||D instanceof String)for(let k=0,le=S.length;k<le;k++){let Se=S[k];if(D.endsWith(Se)){L=Se,D=D.substring(0,D.length-Se.length);break}}let R;return L==="px"&&t.defaultUnit!=="px"?R=T.in[t.defaultUnit]/t.defaultDPI:(R=T[L][t.defaultUnit],R<0&&(R=T[L].in*t.defaultDPI)),R*parseFloat(D)}function E(D){if(!(D.hasAttribute("transform")||D.nodeName==="use"&&(D.hasAttribute("x")||D.hasAttribute("y"))))return null;let L=A(D);return Y.length>0&&L.premultiply(Y[Y.length-1]),Ze.copy(L),Y.push(L),L}function A(D){let L=new je;if(D.nodeName==="use"&&(D.hasAttribute("x")||D.hasAttribute("y"))){let R=y(D.getAttribute("x")||0),k=y(D.getAttribute("y")||0);L.makeTranslation(R,k)}return D.hasAttribute("transform")&&U(D.getAttribute("transform"),L),L}function U(D,L){let R=he,k=D.split(")");for(let le=k.length-1;le>=0;le--){let Se=k[le].trim();if(Se==="")continue;let B=Se.indexOf("("),ae=Se.length;if(B>0&&B<ae){let Z=Se.slice(0,B),pe=p(Se.slice(B+1));switch(R.identity(),Z){case"translate":if(pe.length>=1){let me=pe[0],Me=0;pe.length>=2&&(Me=pe[1]),R.makeTranslation(me,Me)}break;case"rotate":if(pe.length>=1){let me=0,Me=0,Le=0;me=pe[0]*Math.PI/180,pe.length>=3&&(Me=pe[1],Le=pe[2]),de.makeTranslation(-Me,-Le),ye.makeRotation(me),Oe.multiplyMatrices(ye,de),de.makeTranslation(Me,Le),R.multiplyMatrices(de,Oe)}break;case"scale":if(pe.length>=1){let me=pe[0],Me=me;pe.length>=2&&(Me=pe[1]),R.makeScale(me,Me)}break;case"skewX":pe.length===1&&R.set(1,Math.tan(pe[0]*Math.PI/180),0,0,1,0,0,0,1);break;case"skewY":pe.length===1&&R.set(1,0,0,Math.tan(pe[0]*Math.PI/180),1,0,0,0,1);break;case"matrix":pe.length===6&&R.set(pe[0],pe[2],pe[4],pe[1],pe[3],pe[5],0,0,1);break}L.premultiply(R)}}return L}function v(D,L){function R(B){Ke.set(B.x,B.y,1).applyMatrix3(L),B.set(Ke.x,Ke.y)}function k(B){let ae=B.xRadius,Z=B.yRadius,pe=Math.cos(B.aRotation),me=Math.sin(B.aRotation),Me=new O(ae*pe,ae*me,0),Le=new O(-Z*me,Z*pe,0),Te=Me.applyMatrix3(L),K=Le.applyMatrix3(L),x=he.set(Te.x,K.x,0,Te.y,K.y,0,0,0,1),Be=de.copy(x).invert(),_=ye.copy(Be).transpose().multiply(Be).elements,j=G(_[0],_[1],_[4]),w=Math.sqrt(j.rt1),N=Math.sqrt(j.rt2);if(B.xRadius=1/w,B.yRadius=1/N,B.aRotation=Math.atan2(j.sn,j.cs),!((B.aEndAngle-B.aStartAngle)%(2*Math.PI)<Number.EPSILON)){let oe=de.set(w,0,0,0,N,0,0,0,1),$=ye.set(j.cs,j.sn,0,-j.sn,j.cs,0,0,0,1),q=oe.multiply($).multiply(x),fe=ge=>{let{x:te,y:ce}=new O(Math.cos(ge),Math.sin(ge),0).applyMatrix3(q);return Math.atan2(ce,te)};B.aStartAngle=fe(B.aStartAngle),B.aEndAngle=fe(B.aEndAngle),C(L)&&(B.aClockwise=!B.aClockwise)}}function le(B){let ae=X(L),Z=W(L);B.xRadius*=ae,B.yRadius*=Z;let pe=ae>Number.EPSILON?Math.atan2(L.elements[1],L.elements[0]):Math.atan2(-L.elements[3],L.elements[4]);B.aRotation+=pe,C(L)&&(B.aStartAngle*=-1,B.aEndAngle*=-1,B.aClockwise=!B.aClockwise)}let Se=D.subPaths;for(let B=0,ae=Se.length;B<ae;B++){let pe=Se[B].curves;for(let me=0;me<pe.length;me++){let Me=pe[me];Me.isLineCurve?(R(Me.v1),R(Me.v2)):Me.isCubicBezierCurve?(R(Me.v0),R(Me.v1),R(Me.v2),R(Me.v3)):Me.isQuadraticBezierCurve?(R(Me.v0),R(Me.v1),R(Me.v2)):Me.isEllipseCurve&&(Ne.set(Me.aX,Me.aY),R(Ne),Me.aX=Ne.x,Me.aY=Ne.y,z(L)?k(Me):le(Me))}}}function C(D){let L=D.elements;return L[0]*L[4]-L[1]*L[3]<0}function z(D){let L=D.elements,R=L[0]*L[3]+L[1]*L[4];if(R===0)return!1;let k=X(D),le=W(D);return Math.abs(R/(k*le))>Number.EPSILON}function X(D){let L=D.elements;return Math.sqrt(L[0]*L[0]+L[1]*L[1])}function W(D){let L=D.elements;return Math.sqrt(L[3]*L[3]+L[4]*L[4])}function re(D){let L=D.elements,R=L[0]*L[4]-L[1]*L[3];return Math.sqrt(Math.abs(R))}function G(D,L,R){let k,le,Se,B,ae,Z=D+R,pe=D-R,me=Math.sqrt(pe*pe+4*L*L);return Z>0?(k=.5*(Z+me),ae=1/k,le=D*ae*R-L*ae*L):Z<0?le=.5*(Z-me):(k=.5*me,le=-.5*me),pe>0?Se=pe+me:Se=pe-me,Math.abs(Se)>2*Math.abs(L)?(ae=-2*L/Se,B=1/Math.sqrt(1+ae*ae),Se=ae*B):Math.abs(L)===0?(Se=1,B=0):(ae=-.5*Se/L,Se=1/Math.sqrt(1+ae*ae),B=ae*Se),pe>0&&(ae=Se,Se=-B,B=ae),{rt1:k,rt2:le,cs:Se,sn:B}}let se=[],_e={},ee={},Y=[],he=new je,de=new je,ye=new je,Oe=new je,Ne=new be,Ke=new O,Ze=new je,Je=new DOMParser().parseFromString(e,"image/svg+xml");return g(Je),i(Je.documentElement,{fill:"#000",fillOpacity:1,strokeOpacity:1,strokeWidth:1,strokeLineJoin:"miter",strokeLineCap:"butt",strokeMiterLimit:4}),{paths:se,gradients:ee,xml:Je.documentElement}}static createFillMaterial(e){let t=e.userData.style;if(t.fill===void 0||t.fill==="none")return null;let i=e.color,r=null,s=If.exec(t.fill);if(s){let a=e.userData.gradients&&e.userData.gradients[s[1]];r=Nv(a,e)}let o=new jn({opacity:t.fillOpacity*(t.opacity||1),transparent:!0,side:nn,depthWrite:!1});return r!==null?o.map=r:o.color=i,o}static createStrokeMaterial(e){let t=e.userData.style;return t.stroke===void 0||t.stroke==="none"?null:(If.test(t.stroke)&&console.warn("THREE.SVGLoader: Gradient strokes are not supported."),new jn({color:new He().setStyle(t.stroke,mo),opacity:t.strokeOpacity*(t.opacity||1),transparent:!0,side:nn,depthWrite:!1}))}static createShapes(e){return console.warn("SVGLoader: createShapes() is deprecated. Use shapePath.toShapes() instead."),e.toShapes()}static getStrokeStyle(e,t,i,r,s){return e=e!==void 0?e:1,t=t!==void 0?t:"#000",i=i!==void 0?i:"miter",r=r!==void 0?r:"butt",s=s!==void 0?s:4,{strokeColor:t,strokeWidth:e,strokeLineJoin:i,strokeLineCap:r,strokeMiterLimit:s}}static pointsToStroke(e,t,i,r){let s=[],o=[],a=[];if(n.pointsToStrokeWithBuffers(e,t,i,r,s,o,a)===0)return null;let c=new wt;return c.setAttribute("position",new _t(s,3)),c.setAttribute("normal",new _t(o,3)),c.setAttribute("uv",new _t(a,2)),c}static pointsToStrokeWithBuffers(e,t,i,r,s,o,a,c){let l=new be,u=new be,d=new be,h=new be,f=new be,g=new be,b=new be,m=new be,p=new be,S=new be,T=new be,y=new be,E=new be,A=new be,U=new be,v=new be,C=new be;i=i!==void 0?i:12,r=r!==void 0?r:.001,c=c!==void 0?c:0,e=Se(e);let z=e.length;if(z<2)return 0;let X=e[0].equals(e[z-1]),W,re=e[0],G,se=t.strokeWidth/2,_e=1/(z-1),ee=0,Y,he,de,ye,Oe=!1,Ne=0,Ke=c*3,Ze=c*2;Je(e[0],e[1],l).multiplyScalar(se),m.copy(e[0]).sub(l),p.copy(e[0]).add(l),S.copy(m),T.copy(p);for(let B=1;B<z;B++){W=e[B],B===z-1?X?G=e[1]:G=void 0:G=e[B+1];let ae=l;if(Je(re,W,ae),d.copy(ae).multiplyScalar(se),y.copy(W).sub(d),E.copy(W).add(d),Y=ee+_e,he=!1,G!==void 0){Je(W,G,u),d.copy(u).multiplyScalar(se),A.copy(W).sub(d),U.copy(W).add(d),de=!0,d.subVectors(G,re),ae.dot(d)<0&&(de=!1),B===1&&(Oe=de),d.subVectors(G,W),d.normalize();let Z=Math.abs(ae.dot(d));if(Z>Number.EPSILON){let pe=se/Z;d.multiplyScalar(-pe),h.subVectors(W,re),f.copy(h).setLength(pe).add(d),v.copy(f).negate();let me=f.length(),Me=h.length();h.divideScalar(Me),g.subVectors(G,W);let Le=g.length();if(g.divideScalar(Le),h.dot(v)<Me&&g.dot(v)<Le&&(he=!0),C.copy(f).add(W),v.add(W),he){let Te=de?p:m,K=(C.x-Te.x)*(v.y-Te.y)-(C.y-Te.y)*(v.x-Te.x);(de&&K<0||!de&&K>0)&&v.copy(Te)}switch(ye=!1,he?de?(U.copy(v),E.copy(v)):(A.copy(v),y.copy(v)):L(),t.strokeLineJoin){case"bevel":R(de,he,Y);break;case"round":k(de,he),de?D(W,y,A,Y,0):D(W,U,E,Y,1);break;default:let Te=se*t.strokeMiterLimit/me;if(Te<1)if(t.strokeLineJoin!=="miter-clip"){R(de,he,Y);break}else k(de,he),de?(g.subVectors(C,y).multiplyScalar(Te).add(y),b.subVectors(C,A).multiplyScalar(Te).add(A),F(y,Y,0),F(g,Y,0),F(W,Y,.5),F(W,Y,.5),F(g,Y,0),F(b,Y,0),F(W,Y,.5),F(b,Y,0),F(A,Y,0)):(g.subVectors(C,E).multiplyScalar(Te).add(E),b.subVectors(C,U).multiplyScalar(Te).add(U),F(E,Y,1),F(g,Y,1),F(W,Y,.5),F(W,Y,.5),F(g,Y,1),F(b,Y,1),F(W,Y,.5),F(b,Y,1),F(U,Y,1));else he?(de?(F(p,ee,1),F(m,ee,0),F(C,Y,0),F(p,ee,1),F(C,Y,0),F(v,Y,1)):(F(p,ee,1),F(m,ee,0),F(C,Y,1),F(m,ee,0),F(v,Y,0),F(C,Y,1)),de?A.copy(C):U.copy(C)):de?(F(y,Y,0),F(C,Y,0),F(W,Y,.5),F(W,Y,.5),F(C,Y,0),F(A,Y,0)):(F(E,Y,1),F(C,Y,1),F(W,Y,.5),F(W,Y,.5),F(C,Y,1),F(U,Y,1)),ye=!0;break}}else L()}else L();!X&&B===z-1&&le(e[0],S,T,de,!0,ee),ee=Y,re=W,m.copy(A),p.copy(U)}if(!X)le(W,y,E,de,!1,Y);else if(he&&s){let B=C,ae=v;Oe!==de&&(B=v,ae=C),de?(ye||Oe)&&(ae.toArray(s,0),ae.toArray(s,9),ye&&B.toArray(s,3)):(ye||!Oe)&&(ae.toArray(s,3),ae.toArray(s,9),ye&&B.toArray(s,0))}if(s){let B=[new be,new be,new be],ae=c*3;for(let Z=ae;Z<Ke;Z+=9)B[0].set(s[Z],s[Z+1]),B[1].set(s[Z+3],s[Z+4]),B[2].set(s[Z+6],s[Z+7]),$r.area(B)<0&&(s[Z+3]=B[0].x,s[Z+4]=B[0].y)}return Ne;function Je(B,ae,Z){return Z.subVectors(ae,B),Z.set(-Z.y,Z.x).normalize()}function F(B,ae,Z){s&&(s[Ke]=B.x,s[Ke+1]=B.y,s[Ke+2]=0,o&&(o[Ke]=0,o[Ke+1]=0,o[Ke+2]=1),Ke+=3,a&&(a[Ze]=ae,a[Ze+1]=Z,Ze+=2)),Ne+=3}function D(B,ae,Z,pe,me){l.copy(ae).sub(B).normalize(),u.copy(Z).sub(B).normalize();let Me=Math.PI,Le=l.dot(u);Math.abs(Le)<1&&(Me=Math.abs(Math.acos(Le))),Me/=i,d.copy(ae);for(let Te=0,K=i-1;Te<K;Te++)h.copy(d).rotateAround(B,Me),F(d,pe,me),F(h,pe,me),F(B,pe,.5),d.copy(h);F(d,pe,me),F(Z,pe,me),F(B,pe,.5)}function L(){F(p,ee,1),F(m,ee,0),F(y,Y,0),F(p,ee,1),F(y,Y,0),F(E,Y,1)}function R(B,ae,Z){ae?B?(F(p,ee,1),F(m,ee,0),F(y,Y,0),F(p,ee,1),F(y,Y,0),F(v,Y,1),F(y,Z,0),F(A,Z,0),F(v,Z,.5)):(F(p,ee,1),F(m,ee,0),F(E,Y,1),F(m,ee,0),F(v,Y,0),F(E,Y,1),F(E,Z,1),F(v,Z,0),F(U,Z,1)):B?(F(y,Z,0),F(A,Z,0),F(W,Z,.5)):(F(E,Z,1),F(U,Z,0),F(W,Z,.5))}function k(B,ae){ae&&(B?(F(p,ee,1),F(m,ee,0),F(y,Y,0),F(p,ee,1),F(y,Y,0),F(v,Y,1),F(y,ee,0),F(W,Y,.5),F(v,Y,1),F(W,Y,.5),F(A,ee,0),F(v,Y,1)):(F(p,ee,1),F(m,ee,0),F(E,Y,1),F(m,ee,0),F(v,Y,0),F(E,Y,1),F(E,ee,1),F(v,Y,0),F(W,Y,.5),F(W,Y,.5),F(v,Y,0),F(U,ee,1)))}function le(B,ae,Z,pe,me,Me){switch(t.strokeLineCap){case"round":me?D(B,Z,ae,Me,.5):D(B,ae,Z,Me,.5);break;case"square":if(me)l.subVectors(ae,B),u.set(l.y,-l.x),d.addVectors(l,u).add(B),h.subVectors(u,l).add(B),pe?(d.toArray(s,3),h.toArray(s,0),h.toArray(s,9)):(d.toArray(s,3),a[7]===1?h.toArray(s,9):d.toArray(s,9),h.toArray(s,0));else{l.subVectors(Z,B),u.set(l.y,-l.x),d.addVectors(l,u).add(B),h.subVectors(u,l).add(B);let Le=s.length;pe?(d.toArray(s,Le-3),h.toArray(s,Le-6),h.toArray(s,Le-12)):(h.toArray(s,Le-6),d.toArray(s,Le-3),h.toArray(s,Le-12))}break;default:break}}function Se(B){let ae=!1;for(let pe=1,me=B.length-1;pe<me;pe++)if(B[pe].distanceTo(B[pe+1])<r){ae=!0;break}if(!ae)return B;let Z=[];Z.push(B[0]);for(let pe=1,me=B.length-1;pe<me;pe++)B[pe].distanceTo(B[pe+1])>=r&&Z.push(B[pe]);return Z.push(B[B.length-1]),Z}}},If=/^\s*url\(\s*(?:["']\s*)?#([^)'"\s]+)(?:\s*["'])?\s*\)\s*$/;function Nv(n,e,t=256){if(!n||!Array.isArray(n.stops)||n.stops.length===0)return null;let i=e.userData.transform,r=n.gradientUnits==="objectBoundingBox",s=null;if(r&&(s=Uv(e,i),s===null))return null;function o(d,h,f){f.set(d,h,1),n.gradientTransform&&f.applyMatrix3(n.gradientTransform),r&&f.set(s.minX+f.x*s.width,s.minY+f.y*s.height,1),i&&f.applyMatrix3(i)}let a=document.createElement("canvas"),c;if(n.type==="linearGradient"){a.width=t,a.height=1;let d=a.getContext("2d"),h=d.createLinearGradient(0,0,t,0);Df(h,n.stops),d.fillStyle=h,d.fillRect(0,0,t,1);let f=new O,g=new O;o(n.x1,n.y1,f),o(n.x2,n.y2,g);let b=g.x-f.x,m=g.y-f.y,p=b*b+m*m||1e-20,S=b/p,T=m/p,y=-(S*f.x+T*f.y);c=new je().set(S,T,y,0,0,.5,0,0,1)}else{let d=n.cx,h=n.cy,f=n.fx,g=n.fy,b=n.r;if(n.gradientTransform){let v=new O;v.set(d,h,1).applyMatrix3(n.gradientTransform),d=v.x,h=v.y,v.set(f,g,1).applyMatrix3(n.gradientTransform),f=v.x,g=v.y}if(r&&(d=s.minX+d*s.width,h=s.minY+h*s.height,f=s.minX+f*s.width,g=s.minY+g*s.height,b=b*Math.sqrt((s.width*s.width+s.height*s.height)/2)),b<=0)return null;a.width=t,a.height=t;let m=a.getContext("2d"),p=d-b,S=h-b,T=2*b,y=t/T;m.setTransform(y,0,0,y,-p*y,-S*y);let E=m.createRadialGradient(f,g,0,d,h,b);Df(E,n.stops),m.fillStyle=E,m.fillRect(p,S,T,T);let A=i?i.clone().invert():new je;c=new je().set(1/T,0,-p/T,0,1/T,-S/T,0,0,1).multiply(A)}let l=new Zi(a);l.colorSpace=mo,l.flipY=!1,l.matrixAutoUpdate=!1,l.matrix=c;let u=n.spreadMethod==="reflect"?Br:n.spreadMethod==="repeat"?Or:xn;return l.wrapS=u,l.wrapT=u,l}function Uv(n,e){let t=e?e.clone().invert():null,i=new be,r=new Ei;for(let s of n.subPaths)for(let o of s.getPoints())i.copy(o),t&&i.applyMatrix3(t),r.expandByPoint(i);return r.isEmpty()?null:{minX:r.min.x,minY:r.min.y,width:r.max.x-r.min.x,height:r.max.y-r.min.y}}function Df(n,e){let t=new He;for(let i of e){let r=i.color;if(i.opacity<1){t.setStyle(i.color,mo);let s=/rgb\(([^)]+)\)/.exec(t.getStyle(mo));s&&(r=`rgba(${s[1]},${i.opacity})`)}n.addColorStop(Math.max(0,Math.min(1,i.offset)),r)}}var li={size:75,wall:.8,height:12.5,rim:4,base:2.5,relief:4.5,reliefInverted:!1,reliefOut:4.5,reliefIn:1,clearance:.9,detailOffset:0,outlineOffset:0,mode:"integrated",mirror:!1,threshold:160,tolerance:.04,stampBase:2.5,stampInset:0,stampExpansion:0,removeOutline:!1,outlineBand:.8,chamfer:!1,tip:.4,chamferHeight:2,wallEdits:[],cornerRadius:2};function ar(n){return n.reduce((e,t,i)=>{let r=n[(i+1)%n.length];return e+t[0]*r[1]-r[0]*t[1]},0)/2}function Vh(n,e){if(n.length<5)return n;let t=(o,a,c)=>{let l=c[0]-a[0],u=c[1]-a[1],d=Math.max(0,Math.min(1,((o[0]-a[0])*l+(o[1]-a[1])*u)/(l*l+u*u||1)));return Math.hypot(o[0]-a[0]-d*l,o[1]-a[1]-d*u)},i=o=>{let a=0,c=0;for(let l=1;l<o.length-1;l++){let u=t(o[l],o[0],o.at(-1));u>a&&(a=u,c=l)}return a>e?[...i(o.slice(0,c+1)).slice(0,-1),...i(o.slice(c))]:[o[0],o.at(-1)]},r=1,s=0;for(let o=1;o<n.length;o++){let a=Math.hypot(n[o][0]-n[0][0],n[o][1]-n[0][1]);a>s&&(s=a,r=o)}return[...i(n.slice(0,r+1)).slice(0,-1),...i([...n.slice(r),n[0]]).slice(0,-1)]}function Hh(n){let e=n.flat();if(!e.length)throw Error("Nenhum contorno fechado encontrado.");let t=1/0,i=-1/0,r=1/0,s=-1/0;for(let[a,c]of e)t=Math.min(a,t),i=Math.max(a,i),r=Math.min(c,r),s=Math.max(c,s);let o=Math.max(i-t,s-r);if(!(o>0))throw Error("Arte sem dimens\xE3o.");return n.map(a=>a.map(([c,l])=>[(c-(t+i)/2)/o,(l-(r+s)/2)/o]))}function Gh(n){if(n?.format==="rv-cad-13"&&Array.isArray(n.objects)&&n.objects.length<=1e3){for(let t of n.objects)Gh({format:"rv-cad-12",loops:t.loops});return n}if(n?.format!=="rv-cad-12"||!Array.isArray(n.loops)||!n.loops.length)throw Error("Este arquivo n\xE3o \xE9 um projeto RV CAD 12.");let e=0;for(let t of n.loops){if(!Array.isArray(t)||t.length<3)throw Error("Contorno inv\xE1lido.");for(let i of t)if(i.length!==2||!i.every(Number.isFinite)||i.some(r=>Math.abs(r)>10))throw Error("Coordenada inv\xE1lida.");e+=t.length}if(e>2e5)throw Error("Projeto excede o limite de 200 mil pontos.");return n}function Vl(n={}){let e={...li,...n,stampBase:n.stampBase??n.base??li.stampBase};return Number.isFinite(e.reliefOut)||(e.reliefOut=e.reliefInverted?li.relief:e.relief),Number.isFinite(e.reliefIn)||(e.reliefIn=e.reliefInverted?e.relief:Math.min(1,Math.max(.1,(e.mode==="integrated"?e.base:e.stampBase)*.4))),e}function Wh(n,e){let t=!1;for(let i=0,r=n.length-1;i<n.length;r=i++){let s=n[i],o=n[r];s[1]>e[1]!=o[1]>e[1]&&e[0]<(o[0]-s[0])*(e[1]-s[1])/(o[1]-s[1])+s[0]&&(t=!t)}return t}function Lf(n,e=.015){let t=n.slice().sort((s,o)=>Math.abs(ar(o))-Math.abs(ar(s))),i=[];for(let s of t){let o=i.find(a=>Wh(a[0],s[0]));o?o.push(s):i.push([s])}let r=Math.max(...i.map(s=>Math.abs(ar(s[0]))));return i.filter(s=>Math.abs(ar(s[0]))>=r*e).slice(0,1e3).map(s=>Hh(s))}function Xh(n){let e=n.reduce((a,{part:c})=>a+c.positions.length/c.stride,0),t=n.reduce((a,{part:c})=>a+c.indices.length,0),i=new Float32Array(e*3),r=new Uint32Array(t),s=0,o=0;for(let{part:a,position:c=[0,0,0]}of n){let l=s/3;for(let u=0;u<a.positions.length;u+=a.stride)i[s++]=a.positions[u]+c[0],i[s++]=a.positions[u+1]+c[1],i[s++]=a.positions[u+2]+c[2];for(let u of a.indices)r[o++]=u+l}return{positions:i,indices:r,stride:3}}var Nf={type:"change"},qh={type:"start"},Ff={type:"end"},Hl=new oi,Uf=new qt,Fv=Math.cos(70*On.DEG2RAD),Ot=new O,ln=2*Math.PI,ut={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},jh=1e-6,Gl=class extends to{constructor(e,t=null){super(e,t),this.state=ut.NONE,this.target=new O,this.cursor=new O,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ai.ROTATE,MIDDLE:Ai.DOLLY,RIGHT:Ai.PAN},this.touches={ONE:Ci.ROTATE,TWO:Ci.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._cursorStyle="auto",this._domElementKeyEvents=null,this._lastPosition=new O,this._lastQuaternion=new pn,this._lastTargetPosition=new O,this._quat=new pn().setFromUnitVectors(e.up,new O(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Zr,this._sphericalDelta=new Zr,this._scale=1,this._panOffset=new O,this._rotateStart=new be,this._rotateEnd=new be,this._rotateDelta=new be,this._panStart=new be,this._panEnd=new be,this._panDelta=new be,this._dollyStart=new be,this._dollyEnd=new be,this._dollyDelta=new be,this._dollyDirection=new O,this._mouse=new be,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=Bv.bind(this),this._onPointerDown=Ov.bind(this),this._onPointerUp=kv.bind(this),this._onContextMenu=jv.bind(this),this._onMouseWheel=Hv.bind(this),this._onKeyDown=Gv.bind(this),this._onTouchStart=Wv.bind(this),this._onTouchMove=Xv.bind(this),this._onMouseDown=zv.bind(this),this._onMouseMove=Vv.bind(this),this._interceptControlDown=qv.bind(this),this._interceptControlUp=$v.bind(this),this.domElement!==null&&this.connect(this.domElement),this.update()}set cursorStyle(e){this._cursorStyle=e,e==="grab"?this.domElement.style.cursor="grab":this.domElement.style.cursor="auto"}get cursorStyle(){return this._cursorStyle}connect(e){super.connect(e),this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.state=ut.NONE,this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents();let e=this.domElement.getRootNode();e.removeEventListener("keydown",this._interceptControlDown,{capture:!0}),e.removeEventListener("keyup",this._interceptControlUp,{capture:!0}),this._controlActive=!1,this._pointers.length=0,this._pointerPositions={},this.domElement.style.touchAction="",this.domElement.style.cursor="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Nf),this.update(),this.state=ut.NONE}pan(e,t){this._pan(e,t),this.update()}dollyIn(e){this._dollyIn(e),this.update()}dollyOut(e){this._dollyOut(e),this.update()}rotateLeft(e){this._rotateLeft(e),this.update()}rotateUp(e){this._rotateUp(e),this.update()}update(e=null){let t=this.object.position;Ot.copy(t).sub(this.target),Ot.applyQuaternion(this._quat),this._spherical.setFromVector3(Ot),this.autoRotate&&this.state===ut.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let i=this.minAzimuthAngle,r=this.maxAzimuthAngle;isFinite(i)&&isFinite(r)&&(i<-Math.PI?i+=ln:i>Math.PI&&(i-=ln),r<-Math.PI?r+=ln:r>Math.PI&&(r-=ln),i<=r?this._spherical.theta=Math.max(i,Math.min(r,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(i+r)/2?Math.max(i,this._spherical.theta):Math.min(r,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{let o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=o!=this._spherical.radius}if(Ot.setFromSpherical(this._spherical),Ot.applyQuaternion(this._quatInverse),t.copy(this.target).add(Ot),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){let a=Ot.length();o=this._clampDistance(a*this._scale);let c=a-o;this.object.position.addScaledVector(this._dollyDirection,c),this.object.updateMatrixWorld(),s=!!c}else if(this.object.isOrthographicCamera){let a=new O(this._mouse.x,this._mouse.y,0);a.unproject(this.object);let c=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=c!==this.object.zoom;let l=new O(this._mouse.x,this._mouse.y,0);l.unproject(this.object),this.object.position.sub(l).add(a),this.object.updateMatrixWorld(),o=Ot.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(Hl.origin.copy(this.object.position),Hl.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Hl.direction))<Fv?this.object.lookAt(this.target):(Uf.setFromNormalAndCoplanarPoint(this.object.up,this.target),Hl.intersectPlane(Uf,this.target))))}else if(this.object.isOrthographicCamera){let o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),s=!0)}return this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>jh||8*(1-this._lastQuaternion.dot(this.object.quaternion))>jh||this._lastTargetPosition.distanceToSquared(this.target)>jh?(this.dispatchEvent(Nf),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?ln/60*this.autoRotateSpeed*e:ln/60/60*this.autoRotateSpeed}_getZoomScale(e){let t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){Ot.setFromMatrixColumn(t,0),Ot.multiplyScalar(-e),this._panOffset.add(Ot)}_panUp(e,t){this.screenSpacePanning===!0?Ot.setFromMatrixColumn(t,1):(Ot.setFromMatrixColumn(t,0),Ot.crossVectors(this.object.up,Ot)),Ot.multiplyScalar(e),this._panOffset.add(Ot)}_pan(e,t){let i=this.domElement;if(this.object.isPerspectiveCamera){let r=this.object.position;Ot.copy(r).sub(this.target);let s=Ot.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*s/i.clientHeight,this.object.matrix),this._panUp(2*t*s/i.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/i.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/i.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;let i=this.domElement.getBoundingClientRect(),r=e-i.left,s=t-i.top,o=i.width,a=i.height;this._mouse.x=r/o*2-1,this._mouse.y=-(s/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(ln*this._rotateDelta.x/t.clientHeight),this._rotateUp(ln*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(ln*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-ln*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(ln*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-ln*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._rotateStart.set(i,r)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panStart.set(i,r)}}_handleTouchStartDolly(e){let t=this._getSecondPointerPosition(e),i=e.pageX-t.x,r=e.pageY-t.y,s=Math.sqrt(i*i+r*r);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{let i=this._getSecondPointerPosition(e),r=.5*(e.pageX+i.x),s=.5*(e.pageY+i.y);this._rotateEnd.set(r,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);let t=this.domElement;this._rotateLeft(ln*this._rotateDelta.x/t.clientHeight),this._rotateUp(ln*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{let t=this._getSecondPointerPosition(e),i=.5*(e.pageX+t.x),r=.5*(e.pageY+t.y);this._panEnd.set(i,r)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){let t=this._getSecondPointerPosition(e),i=e.pageX-t.x,r=e.pageY-t.y,s=Math.sqrt(i*i+r*r);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);let o=(e.pageX+t.x)*.5,a=(e.pageY+t.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new be,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){let t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){let t=e.deltaMode,i={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:i.deltaY*=16;break;case 2:i.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(i.deltaY*=10),i}};function Ov(n){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(n.pointerId),this.domElement.ownerDocument.addEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(n)&&(this._addPointer(n),n.pointerType==="touch"?this._onTouchStart(n):this._onMouseDown(n),this._cursorStyle==="grab"&&(this.domElement.style.cursor="grabbing")))}function Bv(n){this.enabled!==!1&&(n.pointerType==="touch"?this._onTouchMove(n):this._onMouseMove(n))}function kv(n){switch(this._removePointer(n),this._pointers.length){case 0:this.domElement.releasePointerCapture(n.pointerId),this.domElement.ownerDocument.removeEventListener("pointermove",this._onPointerMove),this.domElement.ownerDocument.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(Ff),this.state=ut.NONE,this._cursorStyle==="grab"&&(this.domElement.style.cursor="grab");break;case 1:let e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function zv(n){let e;switch(n.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Ai.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(n),this.state=ut.DOLLY;break;case Ai.ROTATE:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=ut.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=ut.ROTATE}break;case Ai.PAN:if(n.ctrlKey||n.metaKey||n.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(n),this.state=ut.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(n),this.state=ut.PAN}break;default:this.state=ut.NONE}this.state!==ut.NONE&&this.dispatchEvent(qh)}function Vv(n){switch(this.state){case ut.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(n);break;case ut.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(n);break;case ut.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(n);break}}function Hv(n){this.enabled===!1||this.enableZoom===!1||this.state!==ut.NONE||(n.preventDefault(),this.dispatchEvent(qh),this._handleMouseWheel(this._customWheelEvent(n)),this.dispatchEvent(Ff))}function Gv(n){this.enabled!==!1&&this._handleKeyDown(n)}function Wv(n){switch(this._trackPointer(n),this._pointers.length){case 1:switch(this.touches.ONE){case Ci.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(n),this.state=ut.TOUCH_ROTATE;break;case Ci.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(n),this.state=ut.TOUCH_PAN;break;default:this.state=ut.NONE}break;case 2:switch(this.touches.TWO){case Ci.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(n),this.state=ut.TOUCH_DOLLY_PAN;break;case Ci.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(n),this.state=ut.TOUCH_DOLLY_ROTATE;break;default:this.state=ut.NONE}break;default:this.state=ut.NONE}this.state!==ut.NONE&&this.dispatchEvent(qh)}function Xv(n){switch(this._trackPointer(n),this.state){case ut.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(n),this.update();break;case ut.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(n),this.update();break;case ut.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(n),this.update();break;case ut.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(n),this.update();break;default:this.state=ut.NONE}}function jv(n){this.enabled!==!1&&n.preventDefault()}function qv(n){n.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function $v(n){n.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}var $h={cutterBase:"Base do cortador",blade:"L\xE2mina / chanfro",stampBase:"Base do carimbo",relief:"Relevo do carimbo"},Ni={cutterBase:"#78a9ee",blade:"#e9b45e",stampBase:"#659ea9",relief:"#7be0b6"};function Yv(n,e=!1){let t=n.filter(a=>a.result),i=Math.max(1,Math.ceil(Math.sqrt(t.length))),r=0,s=0;return t.map(a=>{let c=0,l=a.result.parts.map(h=>{let f=[c-h.bounds.min[0],-h.bounds.min[1],0];return e?(f[0]=-a.result.parts[0].bounds.min[0],f[1]=-a.result.parts[0].bounds.min[1]):c+=h.bounds.max[0]-h.bounds.min[0]+10,{part:h,position:f}}),u=e?Math.max(...a.result.parts.map(h=>h.bounds.max[0]-h.bounds.min[0])):c-10,d=Math.max(...a.result.parts.map(h=>h.bounds.max[1]-h.bounds.min[1]));return r=Math.max(r,u),s=Math.max(s,d),{object:a,parts:l,w:u,d}}).map((a,c)=>({...a,position:[c%i*(r+18),Math.floor(c/i)*(s+18),0]}))}function Of(n,e=()=>{},t=()=>{}){let i=new Ds,r=new en,s=new en,o=[],a={},c=null,l=null,u=!1;i.add(r,s);let d=new Ol({antialias:!0,alpha:!0});d.setPixelRatio(Math.min(devicePixelRatio,1.75)),d.localClippingEnabled=!0,n.appendChild(d.domElement);let h=new Ks(15003391,2503495,2.1);i.add(h),d.shadowMap.enabled=!0,d.shadowMap.autoUpdate=!1,d.shadowMap.needsUpdate=!0,d.shadowMap.type=nr;let f=new Yr(16777215,2.5);f.position.set(60,-45,100),i.add(f,f.target),f.castShadow=!0,f.shadow.mapSize.set(2048,2048),f.shadow.bias=-1e-4,f.shadow.normalBias=.03;let g=new zt(new Ki(1,1),new $s({opacity:.3}));g.position.z=-.04,g.receiveShadow=!0,i.add(g);let b=new Yr(10931967,1);b.position.set(-70,60,30),i.add(b);let m=new eo(1e3,100,4809342,2965076);m.rotation.x=Math.PI/2,m.position.z=-.08,i.add(m);let p=new $t(35,1,.1,1e4),S=new Ti(-100,100,100,-100,.1,1e4);p.up.set(0,0,1),S.up.set(0,1,0);let T=p,y,E=new Map,A={ray:new oi,near:0,far:1/0,camera:null},U=new be,v=[],C=0,z=null;function X(){u||(u=!0,requestAnimationFrame(()=>{u=!1,n.clientWidth&&n.clientHeight&&!n.hidden&&d.render(i,T)}))}function W(w){y?.dispose(),y=new Gl(T,d.domElement),y.target.copy(w),y.enableRotate=T===p||a.presentationMode,y.addEventListener("change",X),y.addEventListener("end",()=>{a.presentationMode&&e(Le())}),y.update()}function re(w){w.traverse(N=>{N.geometry?.dispose(),N.material&&(N.material.map?.dispose(),N.material.gradientMap?.dispose(),N.material.dispose())})}function G(w){let N=new Ht({side:nn,transparent:!1,depthTest:!0,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-2,polygonOffsetUnits:-2,uniforms:{ink:{value:new He(w.lineColor)},width:{value:w.lineWidth},resolution:{value:new be(Math.max(1,n.clientWidth),Math.max(1,n.clientHeight))}},vertexShader:"attribute vec3 edgeStart;attribute vec3 edgeEnd;attribute float edgeSide;attribute float edgeAlong;uniform float width;uniform vec2 resolution;void main(){vec4 a=projectionMatrix*modelViewMatrix*vec4(edgeStart,1.0);vec4 b=projectionMatrix*modelViewMatrix*vec4(edgeEnd,1.0);vec2 an=a.xy/a.w,bn=b.xy/b.w;vec2 dp=(bn-an)*resolution*.5;float len=max(length(dp),0.0001);vec2 perp=vec2(-dp.y,dp.x)/len;vec4 c=mix(a,b,edgeAlong);c.xy+=perp*(width/resolution)*c.w*edgeSide;gl_Position=c;}",fragmentShader:`uniform vec3 ink;void main(){gl_FragColor=vec4(ink,1.0);
#include <colorspace_fragment>}`});return N.userData.presentationEdge=!0,N}function se(w,N){let J=w.attributes.position?.array||[],oe=[],$=[],q=[],fe=[];for(let ce=0;ce<J.length;ce+=6){let we=[J[ce],J[ce+1],J[ce+2]],Pe=[J[ce+3],J[ce+4],J[ce+5]];for(let[$e,V]of[[0,-1],[0,1],[1,1],[0,-1],[1,1],[1,-1]])oe.push(...we),$.push(...Pe),q.push(V),fe.push($e)}let ge=new wt;ge.setAttribute("position",new _t(oe,3)),ge.setAttribute("edgeStart",new _t(oe,3)),ge.setAttribute("edgeEnd",new _t($,3)),ge.setAttribute("edgeSide",new _t(q,1)),ge.setAttribute("edgeAlong",new _t(fe,1));let te=new zt(ge,G(N));return te.frustumCulled=!1,te.renderOrder=4,te.userData.presentationEdge=!0,te}function _e(w,N){let J=new en,oe=new zs(w,75);return J.add(se(oe,N)),oe.dispose(),J.userData.presentationEdges=!0,J}function ee(w,N=!1){let J=w.isEmpty()?new O(35,35,0):w.getCenter(new O),oe=w.isEmpty()?new O(80,80,10):w.getSize(new O),$=Math.max(oe.x,oe.y,oe.z,30);T=N?S:p,T.up.set(0,N?1:0,N?0:1),N?(S.userData.span=$*1.5,T.position.copy(J).add(new O(0,0,$*3))):T.position.copy(J).add(new O(.75,-1.05,1.1).multiplyScalar($*1.6)),T.lookAt(J),W(J),ye(),X()}function Y(){let w=new on;for(let N of E.values())N.visible&&(N.updateMatrixWorld(!0),w.expandByObject(N));return w}function he(w=!1){ee(Y(),w)}function de(w,N=!1){let J=E.get(w);return J?(J.updateMatrixWorld(!0),ee(new on().setFromObject(J),N),!0):!1}function ye(){let w=n.clientWidth,N=n.clientHeight;if(!w||!N)return;d.setSize(w,N,!1),p.aspect=w/N,p.updateProjectionMatrix();let J=S.userData.span||100;S.left=-J*w/N/2,S.right=-S.left,S.top=J/2,S.bottom=-J/2,S.updateProjectionMatrix(),r.traverse(oe=>{oe.material?.userData.presentationEdge&&oe.material.uniforms.resolution.value.set(w,N)}),X()}new ResizeObserver(ye).observe(n);function Oe(w=null){for(let[N,J]of E)w&&!w.has(N)||J.traverse(oe=>{if(!oe.isMesh||!oe.userData.role||!oe.material)return;if(D(oe.material,oe.userData.role),a.presentationMode){oe.material.emissive&&oe.material.emissive.set(0);return}let $=N===c,q=N===l&&!$;oe.material.emissive?(oe.material.emissive.set($?2980024:q?1588569:0),oe.material.emissiveIntensity=$?.34:q?.18:0):($||q)&&oe.material.color&&oe.material.color.lerp(new He($?9554175:7710933),$?.18:.1)});X()}function Ne(w){let N=E.has(w)?w:null;if(N===l)return;let J=l;l=N,d.domElement.style.cursor=N?"pointer":"default",Oe(new Set([J,N]))}function Ke(){v=[];for(let[w,N]of E){if(!N.visible)continue;N.updateMatrixWorld(!0);let J=[];N.traverse(oe=>{oe.isMesh&&(oe.userData.role||oe.userData.proxy)&&(oe.userData.objectId=w,J.push(oe))}),J.length&&v.push({id:w,box:new on().setFromObject(N),meshes:J})}}function Ze(w,N){let J=d.domElement.getBoundingClientRect();U.x=(w-J.left)/Math.max(J.width,1)*2-1,U.y=-((N-J.top)/Math.max(J.height,1))*2+1,T.updateMatrixWorld(),A.camera=T,T.isPerspectiveCamera?(A.ray.origin.setFromMatrixPosition(T.matrixWorld),A.ray.direction.set(U.x,U.y,.5).unproject(T).sub(A.ray.origin).normalize()):(A.ray.origin.set(U.x,U.y,(T.near+T.far)/(T.near-T.far)).unproject(T),A.ray.direction.set(0,0,-1).transformDirection(T.matrixWorld))}function Je(w){let N=[];for(let J of w)J.raycast?.(A,N);return N.sort((J,oe)=>J.distance-oe.distance),N}function F(w,N,J=!0){if(Ze(w,N),J){let q=s.children.filter(ge=>ge.userData.dimensionAxis),fe=Je(q)[0];if(fe)return{dimension:fe.object.userData}}let oe=null,$=1/0;for(let q of v){if(!A.ray.intersectsBox(q.box))continue;let fe=Je(q.meshes)[0];fe&&fe.distance<$&&($=fe.distance,oe=q.id)}return oe?{id:oe}:null}d.domElement.addEventListener("pointermove",w=>{if(C||z)return;let N=w.clientX,J=w.clientY;C=requestAnimationFrame(()=>{C=0;let oe=F(N,J,!1),$=oe?.id||null;Ne($),t({type:"hover",id:$})})}),d.domElement.addEventListener("pointerleave",()=>{Ne(null),t({type:"hover",id:null})}),d.domElement.addEventListener("pointerdown",w=>{z={x:w.clientX,y:w.clientY,time:performance.now()}}),d.domElement.addEventListener("pointerup",w=>{let N=z;if(z=null,!N||Math.hypot(w.clientX-N.x,w.clientY-N.y)>5)return;let J=F(w.clientX,w.clientY,!0);if(J?.dimension){t({type:"dimension",...J.dimension,clientX:w.clientX,clientY:w.clientY});return}t({type:"select",id:J?.id||null})}),d.domElement.addEventListener("dblclick",w=>{let N=F(w.clientX,w.clientY,!1);N?.id&&(t({type:"focus",id:N.id}),de(N.id))});function D(w,N){if(w.userData.presentationEdge){if(w.visible=!a.presentationMode||me().lineWidth>0,a.presentationMode){let q=me();w.uniforms.ink.value.set(q.lineColor),w.uniforms.width.value=q.lineWidth,w.uniforms.resolution.value.set(Math.max(1,n.clientWidth),Math.max(1,n.clientHeight))}return}if(w.userData.presentationLine){a.presentationMode&&w.color.set(me().lineColor);return}if(w.userData.chamferLine){w.visible=!a.presentationMode||me().lineWidth>0,w.color.set(a.presentationMode?me().lineColor:"#343a43"),w.clippingPlanes=!a.presentationMode&&a.sliceEnabled?[new qt(new O(0,0,-1),a.sliceHeight)]:[];return}if(a.presentationMode){let q=me();if(w.gradientMap&&w.userData.softness!==q.shadeSoftness&&(zh(w,q.shadeSoftness),w.userData.softness=q.shadeSoftness),w.uniforms?.ink){w.visible=q.lineWidth>0,w.uniforms.ink.value.set(q.lineColor),w.uniforms.width.value=q.lineWidth,w.uniforms.resolution.value=n.clientHeight;return}w.color?.set(N?q.componentColors?q.colors[N]:q.modelColor:q.lineColor),zl(w,q,N);return}let J={pla:[.65,.02],matte:[.98,0],silk:[.22,.3]},oe=J[a.material]||J.pla;w.color.set(a.componentColors?a.colors[N]:a.colors.blade),w.roughness=oe[0],w.metalness=oe[1],w.wireframe=!!a.wire;let $=w.clippingPlanes?.length||0;w.clippingPlanes=a.sliceEnabled?[new qt(new O(0,0,-1),a.sliceHeight)]:[],w.userData.stripes=!!a.layerLines,w.userData.shader&&(w.userData.shader.uniforms.rvStripes.value=a.layerLines?1:0),$!==w.clippingPlanes.length&&(w.needsUpdate=!0)}function L(w){if(a.presentationMode)return Rf(me(),w);let N=new Qi;return N.userData.role=w,N.onBeforeCompile=J=>{J.uniforms.rvStripes={value:a.layerLines?1:0},J.vertexShader=`varying float rvZ; varying float rvVertical;
`+J.vertexShader,J.vertexShader=J.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
rvZ=position.z; rvVertical=1.0-abs(normal.z);`),J.fragmentShader=`varying float rvZ; varying float rvVertical; uniform float rvStripes;
`+J.fragmentShader,J.fragmentShader=J.fragmentShader.replace("#include <dithering_fragment>",`float rvPhase=mod(rvZ,0.2); float rvAA=max(fwidth(rvZ),0.002); float rvLine=1.0-smoothstep(0.015-rvAA,0.015+rvAA,abs(rvPhase-0.025)); gl_FragColor.rgb *= 1.0-0.15*rvLine*rvStripes*rvVertical;
#include <dithering_fragment>`),N.userData.shader=J},D(N,w),N}let R=new WeakMap;function k(w,N){if(N.released){let fe=new on(new O(...w.bounds.min),new O(...w.bounds.max)),ge=fe.getSize(new O),te=new en,ce=new zt(new bi(ge.x,ge.y,ge.z),new jn({color:7902904,wireframe:!0}));return ce.position.copy(fe.getCenter(new O)),ce.userData.proxy=!0,te.add(ce),te}let J=new en,oe={cutterBase:[],blade:[],stampBase:[],relief:[]},$=N.params,q=R.get(w);if(!q&&w.renderData){q={};for(let[fe,ge]of Object.entries(w.renderData)){let te=new wt;te.setAttribute("position",new Ct(ge.positions,3)),te.setAttribute("normal",new Ct(ge.normals,3)),te.setIndex(new Ct(ge.indices,1)),te.computeBoundingBox(),te.computeBoundingSphere(),q[fe]={indices:ge.indices,geometry:te}}R.set(w,q)}if(q)for(let fe of Object.keys(oe))oe[fe]=q[fe]?.indices||[];else for(let fe=0;fe<w.indices.length;fe+=3){let ge=[w.indices[fe],w.indices[fe+1],w.indices[fe+2]],te=[0,0,0];for(let we of ge)for(let Pe=0;Pe<3;Pe++)te[Pe]+=w.positions[we*w.stride+Pe]/3;let ce,rvIn=N.reliefOutline?.length?N.reliefOutline.reduce((we,Pe)=>we!==Wh(Pe,te),!1):!1;if(w.name==="Carimbo")ce=$.reliefInverted?rvIn&&te[2]<$.stampBase-.001?"relief":"stampBase":te[2]<=$.stampBase+.001?"stampBase":"relief";else if(w.name==="Cortador")ce=te[2]<=$.base+.001?"cutterBase":"blade";else{let we=Wh(N.outline[0],te);ce=$.reliefInverted&&rvIn&&te[2]<$.base-.001?"relief":te[2]<=$.base+.001?we?"stampBase":"cutterBase":we?"relief":"blade"}oe[ce].push(...ge)}for(let[fe,ge]of Object.entries(oe)){if(!ge.length)continue;let te=q?.[fe]?.geometry;if(!te){let we=new wt;we.setAttribute("position",new Ct(w.positions,w.stride)),we.setIndex(ge),te=Af(we,$),we.dispose()}if(!q){let we=R.get(w);we||(we={},R.set(w,we)),we[fe]={indices:ge,geometry:te}}let ce=new zt(te,L(fe));if(a.presentationMode&&Cf(ce.material,fe,te,me()),ce.material.polygonOffset=!0,ce.material.polygonOffsetFactor=1,ce.material.polygonOffsetUnits=1,ce.userData.role=fe,ce.castShadow=!0,ce.receiveShadow=!0,J.add(ce),a.presentationMode){let we=new zt(te,Pf(me()));we.renderOrder=-1,J.add(we),me().internalEdges!==!1&&J.add(_e(te,me()))}}if($.chamfer&&w.name!=="Carimbo"&&($.tip<$.wall||$.wallEdits?.length)){let fe=N.bladeProfile||[],ge=fe.reduce((te,ce)=>Math.abs(ar(te))>Math.abs(ar(ce))?te:ce,[]);if(ge.length){let te=ge.map(([$e,V])=>new O($e,V,$.height-$.chamferHeight)),ce=new wt().setFromPoints(te),we=new vi({color:a.presentationMode?me().lineColor:"#343a43",depthTest:!0});we.userData.chamferLine=!0;let Pe=new Os(ce,we);Pe.userData.chamferLine=!0,Pe.renderOrder=2,J.add(Pe)}}return J}function le(w,N,J){d.shadowMap.needsUpdate=!0;let oe=N.presentationMode&&!a.presentationMode,$=!N.presentationMode&&a.presentationMode;oe&&(pe=Le()),o=w,a=N,c=J;let q=Yv(o,a.arrangement==="nested"),fe=new Set(q.map(ge=>ge.object.id));for(let[ge,te]of E)fe.has(ge)||(r.remove(te),re(te),E.delete(ge));for(let ge of q){let te=E.get(ge.object.id);if(te&&!te.userData.unloaded&&ge.object.viewerVisible!==!1&&te.userData.signature===Me()&&te.userData.result!==ge.object.result&&te.children.length===ge.parts.length){for(let ce=0;ce<ge.parts.length;ce++){if(te.userData.result.parts[ce]===ge.parts[ce].part)continue;let we=te.children[ce],Pe=k(ge.parts[ce].part,ge.object.result);te.remove(we),re(we),te.add(Pe);let $e=te.children;$e.splice($e.indexOf(Pe),1),$e.splice(ce,0,Pe)}te.userData.result=ge.object.result}if(!te||te.userData.result!==ge.object.result||te.userData.signature!==Me()||te.userData.unloaded!==(ge.object.viewerVisible===!1)){if(te&&(r.remove(te),re(te),ge.object.viewerVisible===!1))for(let ce of ge.object.result.parts)R.delete(ce);te=new en,te.userData.result=ge.object.result,te.userData.signature=Me(),te.userData.objectId=ge.object.id;for(let ce of ge.parts)te.add(ge.object.viewerVisible===!1?new en:k(ce.part,ge.object.result));te.userData.unloaded=ge.object.viewerVisible===!1,E.set(ge.object.id,te),r.add(te)}te.position.set(...ge.position),te.visible=ge.object.viewerVisible!==!1;for(let ce=0;ce<ge.parts.length;ce++)te.children[ce]?.position.set(...ge.parts[ce].position);te.traverse(ce=>{if(ce.material&&!ce.userData.proxy&&D(ce.material,ce.userData.role),ce.isMesh&&ce.userData.role){ce.userData.objectId=ge.object.id;let we=me(),Pe=!!we.projectedShadows;ce.castShadow=!a.presentationMode||!!we.shadows||Pe,ce.receiveShadow=!a.presentationMode||Pe}})}return Be(),oe&&me().camera&&Te(me().camera),$&&pe&&Te(pe),m.visible=!a.presentationMode&&a.grid!==!1,Z(),Ke(),Oe(),X(),q}function Se(w){if(a=w,[...E.values()].some(N=>N.userData.signature!==Me()))return le(o,w,c);r.traverse(N=>{N.material&&!N.userData.proxy&&(D(N.material,N.userData.role),(N.material.userData.presentationEdge||N.material.uniforms?.ink)&&(N.visible=me().lineWidth>0),N.userData.role&&(N.castShadow=!!me().shadows||!!me().projectedShadows,N.receiveShadow=!!me().projectedShadows))}),Be(),Z(),X()}function B(w,N,J,oe={}){let $=document.createElement("canvas"),q=$.getContext("2d");$.width=512,$.height=90;let fe=a.presentationMode?me():null;q.fillStyle=a.presentationMode?"rgba(255,255,255,.92)":"rgba(15,24,38,.88)",q.fillRect(0,0,512,90),q.font="40px Arial",q.textAlign="center",q.textBaseline="middle",q.fillStyle=a.presentationMode?fe?.lineColor||"#27313d":oe.editable?"#e8f4ff":"#c8d9ea",q.fillText(w+(oe.editable?"  \u270E":""),256,45);let ge=new Zi($),te=new Fs(new Wr({map:ge,depthTest:!1,depthWrite:!1,transparent:!0}));te.position.copy(N),te.scale.set(J*1.65,J*.29,1),te.renderOrder=100,te.frustumCulled=!1,Object.assign(te.userData,oe),s.add(te)}let ae="";function Z(){let w=E.get(c),N=me(),J=JSON.stringify([c,w?.visible,w?.userData.result?.parts?.map(xe=>xe.bounds),w?.position.toArray(),a.arrangement,a.presentationMode,a.showDims,N.showDims,N.lineColor]);if(J===ae)return;ae=J;for(let xe of[...s.children])s.remove(xe),re(xe);let oe=a.presentationMode?!!me().showDims:!!a.showDims;if(s.visible=oe,!oe)return;let $=E.get(c);if(!$||!$.visible||!$.userData.result?.parts?.length)return;$.updateMatrixWorld(!0);let q=$.children[0],fe=$.userData.result.parts[0],ge=new on().setFromObject(q),te=ge.min,ce=ge.max,we=fe.bounds.max[0]-fe.bounds.min[0],Pe=fe.bounds.max[1]-fe.bounds.min[1],$e=fe.bounds.max[2]-fe.bounds.min[2],V=Math.max(we,Pe,30)*.2,Ee=Math.max(we,Pe)*.12,ve=a.presentationMode?me().lineColor:"#b0cbed",Ae=(xe,We,ke,ft,at,un)=>{let rn=[new O(...xe),new O(...We)],ic=new wt().setFromPoints(rn),pr=new Yi(ic,new vi({color:ve,depthTest:!1,depthWrite:!1,transparent:!0}));pr.userData.dimensionLine=!0,pr.renderOrder=100,pr.frustumCulled=!1,s.add(pr);let Eo=rn[0].clone().lerp(rn[1],.5);B(ke,Eo,V,{dimensionAxis:ft,dimensionValue:at,editable:un,objectId:c})},Ce=te.z;Ae([te.x,te.y-Ee,Ce],[ce.x,te.y-Ee,Ce],we.toFixed(2)+" mm","x",we,!0),Ae([te.x-Ee,te.y,Ce],[te.x-Ee,ce.y,Ce],Pe.toFixed(2)+" mm","y",Pe,!0),Ae([ce.x+Ee,ce.y,Ce],[ce.x+Ee,ce.y,ce.z],$e.toFixed(2)+" mm","z",$e,fe.name!=="Carimbo")}let pe=null;function me(){let w={...Sn,...a.presentation,colors:{...Sn.colors,...a.presentation?.colors}};return w.hatchProfiles=os(w),w}function Me(){let w=me();return a.presentationMode?"presentation:"+w.style+":"+(w.modelShadowMode||(w.modelShadows===!1?"none":"soft"))+":"+(w.internalEdges!==!1?"edges":"clean"):"model"}function Le(){return{position:T.position.toArray(),target:y.target.toArray(),projection:T===S?"orthographic":"perspective",zoom:T.zoom,span:S.userData.span,up:T.up.toArray()}}function Te(w){!w?.position?.every(Number.isFinite)||!w?.target?.every(Number.isFinite)||(T=w.projection==="orthographic"?S:p,T.up.fromArray(w.up||(Math.abs(w.position[0]-w.target[0])+Math.abs(w.position[1]-w.target[1])<.001?[0,1,0]:[0,0,1])),T.position.fromArray(w.position),T.zoom=w.zoom||1,S.userData.span=w.span||100,W(new O(...w.target)),ye())}function K(w){let N=y.target.clone();if(T===S==(w==="orthographic"))return;let J=T.position.clone();S.userData.span=J.distanceTo(N)*2*Math.tan(On.degToRad(35/2)),T=w==="orthographic"?S:p,T.zoom=1,T.up.set(0,0,1),T.position.copy(J),W(N),ye()}let x="";function Be(){d.shadowMap.enabled=!!a.presentationMode;let w=me(),N=Y(),J=JSON.stringify([a.presentationMode,w.shadows,w.projectedShadows,w.lightAzimuth,w.lightElevation,w.groundDistance,w.shadowSoftness,N.min.toArray(),N.max.toArray()]);if(J!==x&&(x=J,d.shadowMap.needsUpdate=!0),g.visible=!!a.presentationMode&&w.shadows,!a.presentationMode){i.background=null,h.intensity=2.1,f.intensity=2.5,f.position.set(60,-45,100),f.target.position.set(0,0,0),b.intensity=1;return}i.background=new He(w.background),h.intensity=w.ambient,b.intensity=w.ambient*.35,f.intensity=w.lightIntensity,K(w.projection);let oe=Y(),$=oe.isEmpty()?new O:oe.getCenter(new O),q=oe.isEmpty()?100:Math.max(...oe.getSize(new O).toArray(),30),fe=On.degToRad(w.lightAzimuth),ge=On.degToRad(w.lightElevation);f.position.copy($).add(new O(Math.cos(fe)*Math.cos(ge),Math.sin(fe)*Math.cos(ge),Math.sin(ge)).multiplyScalar(q*3)),f.target.position.copy($),Object.assign(f.shadow.camera,{left:-q*1.1,right:q*1.1,top:q*1.1,bottom:-q*1.1,near:.1,far:q*10}),f.shadow.camera.updateProjectionMatrix(),f.shadow.radius=w.shadowSoftness,f.shadow.bias=-1e-4,f.shadow.normalBias=Math.max(.025,Math.min(.09,q*8e-4));let te=oe.isEmpty()?0:oe.min.z;g.position.set($.x,$.y,te-.04-Math.max(0,w.groundDistance||0)),g.scale.set(q*8,q*8,1),g.material.opacity=w.shadowOpacity}function Xe(w,N){let J=i.background,oe=d.getPixelRatio(),$=n.clientWidth,q=n.clientHeight;try{d.setPixelRatio(1),d.setSize(w,w,!1),p.aspect=1,p.updateProjectionMatrix();let fe=S.userData.span||100;return S.left=-fe/2,S.right=fe/2,S.top=fe/2,S.bottom=-fe/2,S.updateProjectionMatrix(),r.traverse(ge=>{ge.material?.userData.presentationEdge?ge.material.uniforms.resolution.value.set(w,w):ge.material?.uniforms?.resolution&&(ge.material.uniforms.resolution.value=w)}),N&&(i.background=null),d.render(i,T),Uint8Array.from(atob(d.domElement.toDataURL("image/png").split(",")[1]),ge=>ge.charCodeAt(0))}finally{i.background=J,d.setPixelRatio(oe),d.setSize($,q,!1),r.traverse(fe=>{fe.material?.userData.presentationEdge?fe.material.uniforms.resolution.value.set($,q):fe.material?.uniforms?.resolution&&(fe.material.uniforms.resolution.value=q)}),ye()}}function P(w){let N=c;c=w,l===w&&(l=null),Z(),Oe(new Set([N,w])),X()}function _(w,N=c){let J=o.map(oe=>({...oe,viewerVisible:w instanceof Map?w.get(oe.id)!==!1:w?.[oe.id]!==!1}));le(J,a,N)}function j(){cancelAnimationFrame(C),C=0,z=null;for(let w of E.values())r.remove(w),re(w);E.clear();for(let w of[...s.children])s.remove(w),re(w);R=new WeakMap,o=[],v=[],c=null,l=null,ae="",d.renderLists.dispose(),d.shadowMap.needsUpdate=!0,X()}return he(),{clear:j,update:le,updateAppearance:Se,fit:he,focus:de,setHover:Ne,setActive:P,setVisibility:_,resize:ye,invalidate:X,renderer:d,root:r,dimensionRoot:s,dispose:re,capture:Xe,getCamera:Le,restoreCamera:Te}}function Bf(n,e){let t=[-.65,-.65,1.3,1.3],i="select",r=-1,s=-1,o=null,a=null,c="http://www.w3.org/2000/svg",l=(m,p)=>{let S=document.createElementNS(c,m);return Object.entries(p).forEach(([T,y])=>S.setAttribute(T,y)),S},u=m=>{let p=new DOMPoint(m.clientX,m.clientY).matrixTransform(n.getScreenCTM().inverse());return[p.x,-p.y]},d=m=>"M"+m.map(([p,S])=>`${p},${-S}`).join("L");function h(){if(n.hasAttribute("hidden")){n.replaceChildren();return}let m=e.object();n.replaceChildren(),n.setAttribute("viewBox",t.join(" ")),m&&(m.result?.bladeProfile?.length&&n.appendChild(l("path",{class:"blade-preview",d:m.result.bladeProfile.map(p=>d(p.map(([S,T])=>[S/m.result.params.size*(m.result.params.mirror?-1:1),T/m.result.params.size]))+"Z").join(" "),fill:"#d99c32","fill-opacity":.65,"fill-rule":"evenodd","pointer-events":"none"})),n.appendChild(l("path",{d:m.loops.map(p=>d(p)+"Z").join(" "),fill:"#476a90","fill-rule":"evenodd","fill-opacity":.42,"pointer-events":"none"})),m.loops.forEach((p,S)=>n.appendChild(l("path",{d:d(p)+"Z",fill:"none",stroke:S===r?"#e5852d":S===0?"#286bbb":"#597a97","stroke-width":S===r?2:1.1,"vector-effect":"non-scaling-stroke","pointer-events":"stroke","data-loop":S}))),r>=0&&m.loops[r]&&i==="select"&&m.loops[r].forEach(([p,S],T)=>n.appendChild(l("circle",{cx:p,cy:-S,r:t[2]*.004,fill:T===s?"#e88024":"white",stroke:"#bd6c21","stroke-width":1,"vector-effect":"non-scaling-stroke","data-node":T}))),o&&n.appendChild(l("path",{d:d(o)+"Z",fill:"#7cbfff33",stroke:"#147bd6","stroke-dasharray":"5 4","stroke-width":1.5,"vector-effect":"non-scaling-stroke","pointer-events":"none"})),a?.points?.length&&n.appendChild(l("path",{d:d(a.points),fill:"none",stroke:i==="erase"?"#f18787":"#138898","stroke-width":(+document.getElementById("brushWidth").value||.8)/m.params.size,"stroke-linecap":"round","pointer-events":"none"})),document.getElementById("selection").textContent=o?"Regi\xE3o selecionada: o ajuste de espessura ser\xE1 limitado a esta \xE1rea.":r>=0?`Contorno ${r+1} \xB7 ${m.loops[r]?.length||0} pontos`:"Selecione um contorno ou escolha uma ferramenta.")}function f(){t=[-.65,-.65,1.3,1.3],r=-1,s=-1,o=null,a=null,h()}async function g(m){let p=e.object();if(!p)return;let S=p.loops;try{e.status("Aplicando edi\xE7\xE3o vetorial\u2026");let T=await e.request({action:"edit",loops:S,op:{...m,size:p.params.size}});if(e.object()?.id!==p.id||p.loops!==S){e.status("Edi\xE7\xE3o cancelada porque o objeto mudou.");return}e.history(),p.loops=T,r=-1,s=-1,e.changed(),h()}catch(T){e.status(T.message)}}n.onpointerdown=m=>{let p=e.object();if(!p)return;n.setPointerCapture(m.pointerId);let S=u(m),T=m.target.dataset.node,y=m.target.dataset.loop;if(m.button===1||m.button===2){a={kind:"pan",x:m.clientX,y:m.clientY,view:[...t]};return}if(["draw","erase","line"].includes(i)){a={kind:"stroke",points:[S]};return}if(i==="region"){o=[S,S,S,S],a={kind:"region",start:S},h();return}if(i==="move"&&y!==void 0){e.history(),r=+y,a={kind:"move",start:S,original:p.loops[r].map(E=>E.slice())};return}T!==void 0?(e.history(),s=+T,a={kind:"node"}):y!==void 0?(r=+y,s=-1,h()):(r=-1,s=-1,a={kind:"pan",x:m.clientX,y:m.clientY,view:[...t]},h())},n.onpointermove=m=>{let p=e.object();if(!a||!p)return;let S=u(m);if(a.kind==="node")p.loops[r][s]=S,h();else if(a.kind==="move")p.loops[r]=a.original.map(T=>[T[0]+S[0]-a.start[0],T[1]+S[1]-a.start[1]]),h();else if(a.kind==="region"){let T=a.start;o=[[Math.min(T[0],S[0]),Math.min(T[1],S[1])],[Math.max(T[0],S[0]),Math.min(T[1],S[1])],[Math.max(T[0],S[0]),Math.max(T[1],S[1])],[Math.min(T[0],S[0]),Math.max(T[1],S[1])]],h()}else if(a.kind==="stroke")i==="line"?a.points=[a.points[0],S]:Math.hypot(S[0]-a.points.at(-1)[0],S[1]-a.points.at(-1)[1])>.001&&a.points.length<1500&&a.points.push(S),h();else{let T=n.getBoundingClientRect(),y=Math.max(t[2]/T.width,t[3]/T.height);t=[a.view[0]-(m.clientX-a.x)*y,a.view[1]-(m.clientY-a.y)*y,...a.view.slice(2)],h()}},n.onpointerup=()=>{if(!a)return;let m=a;a=null,["node","move"].includes(m.kind)&&e.changed(),m.kind==="stroke"&&m.points.length&&g({type:"stroke",points:m.points,width:+document.getElementById("brushWidth").value||.8,subtract:i==="erase"}),h()},n.onpointercancel=()=>{a&&["node","move"].includes(a.kind)&&e.changed(),a=null,h()},n.oncontextmenu=m=>m.preventDefault(),n.onwheel=m=>{m.preventDefault();let p=m.deltaY>0?1.12:1/1.12;if(t[2]*p<.015||t[2]*p>12)return;let[S,T]=u(m),y=-T;t=[S+(t[0]-S)*p,y+(t[1]-y)*p,t[2]*p,t[3]*p],h()},n.ondblclick=m=>{if(i!=="select"||m.target.dataset.loop===void 0)return;let p=e.object();r=+m.target.dataset.loop;let S=p.loops[r],T=u(m),y=0,E=1/0;for(let A=0;A<S.length;A++){let U=S[A],v=S[(A+1)%S.length],C=v[0]-U[0],z=v[1]-U[1],X=Math.max(0,Math.min(1,((T[0]-U[0])*C+(T[1]-U[1])*z)/(C*C+z*z||1))),W=Math.hypot(T[0]-U[0]-X*C,T[1]-U[1]-X*z);W<E&&(E=W,y=A+1)}e.history(),S.splice(y,0,T),s=y,e.changed(),h()};function b(){let m=e.object();r>=0&&s>=0&&m?.loops[r].length>3&&(e.history(),m.loops[r].splice(s,1),s=-1,e.changed(),h())}return{render:h,reset:f,fit:()=>{t=[-.65,-.65,1.3,1.3],h()},setTool:m=>{i=m,h()},removeNode:b,clearRegion:()=>{o=null,h()},offset:m=>{if(r<0){e.status("Selecione um contorno primeiro.");return}g({type:"offset",selected:r,distance:m})},thickness:m=>g({type:"thickness",distance:m,region:o}),removeContour:()=>{let m=e.object();if(!(r<0)){if(r===0){e.status("Para alterar a silhueta, mova os pontos ou use a borracha.");return}e.history(),m.loops.splice(r,1),r=-1,e.changed(),h()}},getSelection:()=>({selected:r,node:s,region:o})}}var I=n=>document.getElementById(n),lr=()=>crypto.randomUUID(),Q={id:lr(),name:"Novo projeto",source:null,objects:[],activeId:null,history:[],future:[],view:{arrangement:"spread",material:"pla",componentColors:!0,colors:{...Ni},showDims:!0,layerLines:!1,sliceEnabled:!1,sliceHeight:12.5,wire:!1,grid:!0},stage:"3d",screen:"home",homePreview:null},Et=()=>Q.objects.find(n=>n.id===Q.activeId),dt,Lt,mt=null,So=null,Ui=new Set,Jn=n=>!!n&&(mt?n.id===mt:n.visible!==!1),Zv=[["Tamanho",null,[["size","Tamanho do desenho",10,300,.5],["outlineOffset","Expans\xE3o externa",0,10,.1]]],["Cortador","cutterBase",[["wall","Espessura da l\xE2mina",.3,5,.05],["cornerRadius","Prote\xE7\xE3o de cantos",0,10,.1],["height","Altura total",4,50,.1],["rim","Largura da base de apoio",1,15,.1],["base","Altura da base do cortador",.5,10,.1]]],["Carimbo","stampBase",[["stampBase","Altura da base do carimbo",.5,15,.1],["stampExpansion","Expans\xE3o da base",0,10,.05],["stampInset","Recuo lateral da base",0,5,.05],["clearance","Folga entre cortador e carimbo",.1,5,.05]]],["Relevo","relief",[["detailOffset","Espessura dos detalhes",-.4,1.5,.05],["relief","Altura / profundidade do relevo",.05,20,.1]]]],cs=([n,e,t,i,r],s)=>`<div class="range-pair" data-param="${n}"><label for="${n}">${s?`<i class="swatch" data-color="${s}"></i>`:""}${e}</label><input id="${n}" type="number" step="${r}" value="${li[n]}" title="Digite livremente. A barra mant\xE9m apenas uma faixa pr\xE1tica de arraste."><input id="${n}Range" type="range" min="${t}" max="${i}" step="${r}" value="${li[n]}" aria-label="${e}"></div>`;I("params").innerHTML=Zv.map(([n,e,t],i)=>`<details class="param-group" ${i<2?"open":""}><summary>${e?`<i class="swatch" data-color="${e}"></i>`:""}${n}</summary><div class="param-content">${t.map(r=>cs(r,e)).join("")}</div></details>`).join("");var rvReliefContent=document.querySelector('[data-param="relief"]')?.closest(".param-content");if(rvReliefContent){let n=document.createElement("button");n.id="invertRelief",n.className="secondary-accent",n.type="button",n.title="Alterna o relevo entre saliente e gravado para dentro",rvReliefContent.appendChild(n)}I("wallControl").innerHTML='<p class="hint">A espessura geral est\xE1 na se\xE7\xE3o Cortador, dispon\xEDvel no 2D e no 3D. O ajuste dos detalhes move cada lado do tra\xE7o pelo valor indicado.</p>';I("chamferParams").innerHTML=cs(["tip","Espessura final da ponta",.15,5,.05],"blade")+cs(["chamferHeight","Altura vertical do chanfro",.1,20,.1],"blade");I("outlineParams").innerHTML=cs(["outlineBand","Faixa externa a remover",.1,5,.05],"relief");I("precisionParams").innerHTML=cs(["tolerance","Simplifica\xE7\xE3o (mm)",.005,.3,.005])+cs(["threshold","Limiar da imagem",20,245,1]);I("colorKeys").innerHTML=Object.entries($h).map(([n,e])=>`<label class="color-key"><input id="color-${n}" type="color" value="${Q.view.colors[n]}" aria-label="Cor: ${e}">${e}</label>`).join("");var _n,Jv=0,kn=new Map;function Kv(){return _n||(_n=new Worker("worker.js",{type:"module"}),_n.onmessage=({data:n})=>{let e=kn.get(n.id);if(e&&(kn.delete(n.id),n.error?e.reject(Error(n.error)):e.resolve(n.result??n.loops),n.error&&/memory|heap|allocation|out of bounds/i.test(n.error))){_n?.terminate(),_n=null;for(let t of kn.values())t.reject(Error("Motor reiniciado ap\xF3s atingir o limite de mem\xF3ria."));kn.clear()}},_n.onerror=n=>{for(let e of kn.values())e.reject(Error(n.message));kn.clear(),_n?.terminate(),_n=null,nt("Falha no motor geom\xE9trico. Tente novamente.")},_n)}function Oi(n){return Q.screen!=="studio"?Promise.reject(Object.assign(Error("Nenhum projeto ativo."),{name:"AbortError"})):new Promise((e,t)=>{let i=++Jv;kn.set(i,{resolve:e,reject:t});try{Kv().postMessage({...n,id:i},n.action==="stl"?[n.mesh.positions.buffer,n.mesh.indices.buffer]:n.action==="zip"?Object.values(n.files).map(r=>r.buffer):[])}catch(r){kn.delete(i),t(r)}})}function nt(n){I("status").textContent=n,I("homeStatus").textContent=n}function Vf(n){return{id:n.id,name:n.name,loops:n.loops,params:n.params,visible:n.visible,geometryRecord:n.geometryRecord}}function $l(n=!0){return Q.stage==="presentation"&&dt&&(xt().camera=dt.getCamera()),{format:"rv-cad-13",version:"14.22.0",projectType:"cutter",parametricGraph:{version:Vi,nodes:Ro},id:Q.id,name:Q.name,source:Q.source,objects:Q.objects.map(Vf),activeId:Q.activeId,view:Q.view,...n&&Q.homePreview?{previewImage:Q.homePreview}:{},savedAt:new Date().toISOString()}}var kf=new WeakMap;function Kh(){let n=$l(!1);return{...n,objects:Q.objects.map(e=>{let t=kf.get(e.loops);return(!t||t.version!==(e.contourVersion||0))&&(t={version:e.contourVersion||0,text:JSON.stringify(e.loops)},kf.set(e.loops,t)),{...Vf(e),params:structuredClone(e.params),loops:t.text}}),view:structuredClone(n.view)}}function Qv(){let n=()=>{let e=new Set,t=0;for(let i of[...Q.history,...Q.future]){i.source&&!e.has(i.source)&&(e.add(i.source),t+=i.source.length*2);for(let r of i.objects)e.has(r.loops)||(e.add(r.loops),t+=r.loops.length*2),t+=JSON.stringify(r.params).length*2}return t};for(;Q.history.length>24||n()>16*1024*1024&&Q.history.length>1;)Q.history.shift();for(;n()>16*1024*1024&&Q.future.length;)Q.future.shift()}function zn(){Q.history.push(Kh()),Q.future=[],Qv(),Yl()}function Yl(){I("undo").disabled=!Q.history.length,I("redo").disabled=!Q.future.length}function Zl(n){Gh(n),ec(),mt=null,So=null,Ui.clear(),Q.id=typeof n.id=="string"&&/^[\w-]{10,80}$/.test(n.id)?n.id:lr(),Q.name=String(n.name||"Projeto"),Q.source=typeof n.source=="string"&&n.source.startsWith("data:image/")?n.source:null,Q.homePreview=typeof n.previewImage=="string"&&n.previewImage.startsWith("data:image/")?n.previewImage:null,Q.objects=n.objects?n.objects.map(e=>({...e,id:e.id||lr(),params:Vl(e.params),visible:e.visible!==!1,result:null,cacheKey:null})):[{id:lr(),name:Q.name,loops:n.loops,params:Vl(n.params),visible:!0,result:null}],Q.activeId=Q.objects.some(e=>e.id===n.activeId)?n.activeId:Q.objects[0]?.id,Q.view={...Q.view,...n.view,presentation:{...structuredClone(Sn),...n.view?.presentation,colors:{...Sn.colors,...n.view?.presentation?.colors}},colors:{...Ni,...n.view?.colors}},n.view?.presentation&&!Object.prototype.hasOwnProperty.call(n.view.presentation,"modelShadowMode")&&(Q.view.presentation.modelShadowMode=n.view.presentation.modelShadows===!1?"none":"soft"),Rt(),Lt?.reset()}function Hf(n){let e=typeof n=="string"?JSON.parse(n):{...n,objects:n.objects.map(t=>({...t,loops:JSON.parse(t.loops)}))};Zl(e),Vt(),Yl()}I("undo").onclick=()=>{Q.history.length&&(Q.future.push(Kh()),Hf(Q.history.pop()))};I("redo").onclick=()=>{Q.future.length&&(Q.history.push(Kh()),Hf(Q.future.pop()))};var Xl,Yh=null,Bn=!1;async function Bi(){if(clearTimeout(Xl),!Q.objects.length)return!0;let n=JSON.stringify([Q.id,Q.name,Q.homePreview,Q.view,Q.objects.map(t=>[t.id,t.name,t.params,t.visible,t.contourVersion||0,t.geometryRecord?.cacheKey])]);if(n===Yh)return!0;let e=$l();try{return window.desktop?.catalogSave?await window.desktop.catalogSave(JSON.stringify(e)):await Gf(e),Yh=n,!0}catch(t){return nt("Falha ao salvar hist\xF3rico: "+t.message),!1}}function st(){Q.screen!=="studio"||Bn||(clearTimeout(Xl),Xl=setTimeout(Bi,1800))}window.RVDesktopFlush=Bi;var ex;function Jl(){return ex??=new Promise((n,e)=>{let t=indexedDB.open("rv-cutter-catalog",1);t.onupgradeneeded=()=>t.result.createObjectStore("projects",{keyPath:"id"}),t.onsuccess=()=>n(t.result),t.onerror=()=>e(t.error)})}async function Gf(n){let e=await Jl();return new Promise((t,i)=>{let r=e.transaction("projects","readwrite");r.objectStore("projects").put(n),r.oncomplete=t,r.onerror=()=>i(r.error)})}async function Wf(){if(window.desktop?.catalogList)return window.desktop.catalogList();let n=await Jl();return new Promise((e,t)=>{let i=[],r=n.transaction("projects").objectStore("projects").openCursor();r.onsuccess=()=>{let s=r.result;if(!s){e(i.sort((a,c)=>c.updatedAt.localeCompare(a.updatedAt)));return}let o=s.value;i.push({id:o.id,name:o.name,updatedAt:o.savedAt,count:o.objects.length,preview:o.objects[0]?.loops?.[0]?.filter((a,c)=>c%8===0),previewImage:o.previewImage||null}),s.continue()},r.onerror=()=>t(r.error)})}async function Xf(n){if(window.desktop?.catalogOpen)return JSON.parse(await window.desktop.catalogOpen(n));let e=await Jl();return new Promise((t,i)=>{let r=e.transaction("projects").objectStore("projects").get(n);r.onsuccess=()=>t(r.result),r.onerror=()=>i(r.error)})}async function jf(n,e){if(e=String(e).trim().slice(0,160),!e)throw Error("Informe um nome.");if(window.desktop?.catalogRename)return window.desktop.catalogRename(n,e);let t=await Xf(n);t.name=e,await Gf(t)}async function qf(n){if(window.desktop?.catalogDelete)return window.desktop.catalogDelete(n);let e=await Jl();await new Promise((t,i)=>{let r=e.transaction("projects","readwrite");r.objectStore("projects").delete(n),r.oncomplete=t,r.onabort=()=>i(r.error)})}async function tx(n){let e=await $f("Renomear projeto",n.name);if(e)try{await jf(n.id,e),await us()}catch(t){nt(t.message)}}async function nx(n){if(confirm("Excluir \u201C"+n.name+"\u201D da biblioteca? Arquivos exportados n\xE3o ser\xE3o alterados."))try{await qf(n.id),await us()}catch(e){nt(e.message)}}function $f(n,e=""){return new Promise(t=>{let i=I("nameDialog");I("nameDialogTitle").textContent=n,I("entryName").value=e,i.onclose=()=>t(i.returnValue==="ok"?I("entryName").value.trim():null),i.showModal(),I("entryName").focus()})}var dr=[];async function ix(){try{dr=window.desktop?.presetsList?await window.desktop.presetsList():JSON.parse(localStorage.getItem("rv-presets-v1")||"[]")}catch(n){nt("Falha ao ler presets: "+n.message)}Yf()}function Yf(){let n=I("savedPreset");n.replaceChildren(new Option("Escolha um preset",""));for(let e of dr)n.add(new Option(e.name,e.id))}async function Zf(n){window.desktop?.presetsSave?await window.desktop.presetsSave(n):localStorage.setItem("rv-presets-v1",JSON.stringify(n)),dr=n,Yf()}async function Jf(n){let e=Et();if(!e)throw Error("Selecione um objeto.");if(n=String(n||"").trim().slice(0,80),!n)throw Error("Informe um nome.");let t=structuredClone(e.params);t.wallEdits=[];let i={id:lr(),name:n,params:t,version:1};return await Zf([...dr,i]),I("savedPreset").value=i.id,i}function Kf(n){let e=dr.find(i=>i.id===n);if(!e||!Et())return;zn();let t=yo();for(let i of t){let r=i.params.wallEdits;i.params=Vl(structuredClone(e.params)),i.params.wallEdits=r||[]}Rt(),Vt(t.map(i=>i.id)),st(),nt("Preset aplicado: "+e.name)}I("savePreset").onclick=async()=>{if(!Et())return nt("Selecione um objeto primeiro.");let n=await $f("Salvar configura\xE7\xF5es como preset");if(n)try{await Jf(n),nt("Preset salvo.")}catch(e){nt(e.message)}};I("applyPreset").onclick=()=>Kf(I("savedPreset").value);I("deletePreset").onclick=async()=>{let n=I("savedPreset").value;if(!(!n||!confirm("Excluir este preset?")))try{await Zf(dr.filter(e=>e.id!==n))}catch(e){nt(e.message)}};function rx(n){let e=document.createElement("canvas");e.width=300,e.height=160;let t=e.getContext("2d");return t.fillStyle="#eaf0f8",t.fillRect(0,0,300,160),n?.length&&(t.beginPath(),n.forEach(([i,r],s)=>t[s?"lineTo":"moveTo"](150+i*130,80-r*130)),t.closePath(),t.fillStyle="#a6c5e9",t.fill(),t.strokeStyle="#446a97",t.lineWidth=2,t.stroke()),e.toDataURL("image/png")}function sx(n){return new Promise((e,t)=>{let i=new FileReader;i.onload=()=>e(i.result),i.onerror=()=>t(i.error),i.readAsDataURL(new Blob([n],{type:"image/png"}))})}async function ox(){if(!(!dt||Q.screen!=="studio"||!Q.objects.some(n=>n.result)))try{Q.homePreview=await sx(dt.capture(420,!1))}catch(n){console.warn("Pr\xE9via indispon\xEDvel:",n)}}async function us(n=0){if(n=Number.isInteger(n)?n:0,!Bn){Bn=!0;try{if(Q.screen==="studio"&&await ox(),!await Bi())return;ec(),Object.assign(Q,{id:null,name:"",source:null,objects:[],activeId:null,history:[],future:[],homePreview:null}),mt=null,So=null,Ui.clear(),Q.screen="home",Lt?.reset(),I("layers").replaceChildren(),I("busy").hidden=!0,bo(),nt("Biblioteca \xB7 nenhum projeto ativo"),I("studio").hidden=!0,I("home").hidden=!1,I("export").disabled=!0;let e=I("recentProjects");e.replaceChildren();try{let t=await Wf();if(!t.length){let i=document.createElement("div");i.className="empty-recents",i.textContent="Seus projetos aparecer\xE3o aqui depois da primeira edi\xE7\xE3o.",e.appendChild(i)}for(let i of t.slice(n*60,(n+1)*60)){let r=document.createElement("div");r.className="project-card";let s=document.createElement("button");s.className="recent-card";let o=new Image;o.loading="lazy",o.decoding="async",o.src=i.previewImage||rx(i.preview),o.alt=i.previewImage?"Pr\xE9via 3D do projeto":"Pr\xE9via do projeto";let a=document.createElement("strong");a.textContent=i.name;let c=document.createElement("small");c.textContent=`${i.count} objeto(s) \xB7 ${new Date(i.updatedAt).toLocaleString("pt-BR")}`,s.append(o,a,c),s.onclick=async()=>{try{if(Bn)return;Bn=!0;let u=await Xf(i.id);if(!await Bi())return;Zl(u),Q.history=[],Q.future=[],Kl(),Bn=!1,Vt()}catch(u){nt(u.message)}finally{Bn=!1}};let l=document.createElement("div");l.className="project-actions";for(let[u,d]of[["Renomear",()=>tx(i)],["Excluir",()=>nx(i)]]){let h=document.createElement("button");h.textContent=u,h.onclick=d,l.appendChild(h)}r.append(s,l),e.appendChild(r)}if(t.length>60){let i=document.createElement("div");i.className="project-actions";for(let[r,s]of[["Anterior",n-1],["Pr\xF3xima",n+1]]){let o=document.createElement("button");o.textContent=r,o.disabled=s<0||s*60>=t.length,o.onclick=()=>us(s),i.appendChild(o)}e.appendChild(i)}}catch(t){nt("N\xE3o foi poss\xEDvel abrir o hist\xF3rico: "+t.message)}}finally{Bn=!1}}}function Kl(){I("recentProjects").replaceChildren(),Q.screen="studio",I("home").hidden=!0,I("studio").hidden=!1,Rt(),dt.resize()}async function Qh(){return Bn||!await Bi()?!1:(ec(),mt=null,So=null,Ui.clear(),Object.assign(Q,{id:lr(),name:"Novo cortador",source:null,objects:[],activeId:null,history:[],future:[],homePreview:null}),Kl(),Lt.reset(),Tn(),Yl(),nt("Importe sua arte para come\xE7ar."),!0)}I("homeBtn").onclick=us;I("newProject").onclick=Qh;I("openHome").onclick=()=>I("projectFile").click();function Rt(){ds();let n=Et();I("name").value=Q.name,I("modelTitle").textContent=n?.name||"Novo projeto",I("activeObject").textContent=n?.name||"nenhum objeto",I("modelSubtitle").textContent=n?`${Q.objects.length} objeto(s) \xB7 mil\xEDmetros`:"Importe uma arte para come\xE7ar";for(let[e,t]of Object.entries(n?.params||li)){let i=I(e),r=I(e+"Range");i&&(i.type==="checkbox"?i.checked=t:i.value=t),r&&(r.value=t)}for(let[e,t]of Object.entries(Q.view)){let i=I(e);i&&(i.type==="checkbox"?i.checked=t:e!=="colors"&&(i.value=t))}for(let e of Object.keys(Ni))I("color-"+e).value=Q.view.colors[e],document.querySelectorAll(`[data-color="${e}"]`).forEach(t=>t.style.background=Q.view.colors[e]);I("sliceRange").value=Q.view.sliceHeight,I("emptyCanvas").hidden=!!Q.objects.length,I("chamferParams").hidden=!n?.params.chamfer,I("outlineParams").hidden=!n?.params.removeOutline,document.querySelectorAll("[data-mode-choice]").forEach(e=>e.classList.toggle("active",e.dataset.modeChoice===(n?.params.mode||li.mode))),document.querySelectorAll("[data-scope-choice]").forEach(e=>e.classList.toggle("active",e.dataset.scopeChoice===I("paramScope").value)),I("stampExpansion").disabled=!n||!["separate","stamp"].includes(n.params.mode),I("stampExpansionRange").disabled=I("stampExpansion").disabled,I("stampBase").disabled=n?.params.mode==="integrated",I("stampBaseRange").disabled=I("stampBase").disabled,I("stampInset").disabled=n?.params.mode==="integrated",I("stampInsetRange").disabled=I("stampInset").disabled;let rvInv=I("invertRelief");if(rvInv){let e=!!n?.params.reliefInverted;rvInv.disabled=!n||n.params.mode==="cutter",rvInv.textContent=e?"↕ Relevo para dentro · inverter para fora":"↕ Relevo para fora · inverter para dentro",rvInv.classList.toggle("active",e);let t=document.querySelector('label[for="relief"]');t&&(t.innerHTML=`<i class="swatch" data-color="relief"></i>${e?"Profundidade do relevo":"Altura do relevo"}`);let i=I("reliefRange"),r=Number(n?.params.relief)||li.relief;i.min=e?.05:.5,i.max=Math.max(20,r,e?(n?.params.mode==="integrated"?n?.params.base:n?.params.stampBase)||0:0),i.value=Math.min(+i.max,Math.max(+i.min,r))}cr(),eu(),Q.stage==="2d"&&Lt?.render(),Yl()}function ax(n){let e=String(n||"").replace(/\.[^.]+$/,"").replace(/[_-]+/g," ").replace(/\b(?:img|image|imagem|scan|arquivo|file|export|final|novo|nova|copy|copia)\b/gi," ").replace(/\b[a-f0-9]{8,}\b/gi," ").replace(/\b\d{6,}\b/g," ").replace(/\s+/g," ").trim();return/(?:flor|flower|rosa|rose)/i.test(e)?"Flor":/(?:folha|leaf)/i.test(e)?"Folha":!e||e.length>28||/\d{4,}/.test(e)?"Objeto":e.replace(/\b\w/g,t=>t.toUpperCase())}function lx(n){let e=prompt("Nome do objeto",n.name);e?.trim()&&(zn(),n.name=e.trim().slice(0,80),Rt(),st())}I("objectSearch").oninput=()=>cr();I("isolationBanner").onclick=()=>{mt=null,Rt(),ur(),nt("Isolamento encerrado.")};function cx(n){return n?.bounds?{name:n.name||"Pe\xE7a",x:n.bounds.max[0]-n.bounds.min[0],y:n.bounds.max[1]-n.bounds.min[1],z:n.bounds.max[2]-n.bounds.min[2]}:null}function wo(n){let e=(n?.result?.parts||[]).map(cx).filter(Boolean);return e.length?{parts:e,x:Math.max(...e.map(t=>t.x)),y:Math.max(...e.map(t=>t.y)),z:Math.max(...e.map(t=>t.z)),primary:e[0]}:null}function Zt(n,e=2){return Number.isFinite(n)?n.toFixed(e).replace(".",","):"\u2014"}function jl(n){So=n,document.querySelectorAll(".layer[data-object-id]").forEach(e=>e.classList.toggle("hover",e.dataset.objectId===n))}function as(n,{focus:e=!1}={}){if(n&&!Q.objects.some(i=>i.id===n))return;Q.activeId=n||Q.activeId,Rt(),Lt?.reset(),dt?.setActive(Q.activeId),e&&n&&dt?.focus(n);let t=Et();t&&Jn(t)&&(!t.result||t.cacheKey!==wn(t))&&Vt([t.id])}function Ql(n=Q.activeId){n&&(mt=mt===n?null:n,mt&&(Q.activeId=n),Rt(),ur(),nt(mt?`Isolando ${Et()?.name||"objeto"}. As demais pe\xE7as continuam no projeto.`:"Isolamento encerrado."))}function eu(){let n=I("objectMetrics"),e=I("metricRows"),t=Et(),i=wo(t);if(!n||!e||(n.hidden=!t,e.replaceChildren(),!t))return;let r=(s,o,a=!1,c=null)=>{let l=document.createElement(a?"button":"div");l.className="metric-row"+(a?" editable":"");let u=document.createElement("span");u.textContent=s;let d=document.createElement("strong");d.textContent=o,l.append(u,d),a&&c&&(l.onclick=h=>rp({objectId:t.id,dimensionAxis:c,dimensionValue:i?.primary?.[c]??i?.[c],editable:!0,clientX:h.clientX,clientY:h.clientY})),e.appendChild(l)};if(!i){r("Geometria","Aguardando reconstru\xE7\xE3o");return}for(let s of i.parts){let o=document.createElement("div");o.className="metric-part";let a=document.createElement("span");a.textContent=s.name;let c=document.createElement("strong");c.textContent=`${Zt(s.x)} \xD7 ${Zt(s.y)} \xD7 ${Zt(s.z)} mm`,o.append(a,c),e.appendChild(o)}r("Largura da pe\xE7a ativa",Zt(i.primary.x)+" mm",!0,"x"),r("Profundidade da pe\xE7a ativa",Zt(i.primary.y)+" mm",!0,"y"),r("Altura da pe\xE7a ativa",Zt(i.primary.z)+" mm",i.parts[0]?.name!=="Carimbo","z"),n.classList.toggle("isolated",mt===t.id)}function hx(n=null){document.querySelectorAll(".layer-menu[open]").forEach(e=>{e!==n&&(e.open=!1)})}function cr(){let n=I("layers");n.replaceChildren(),I("objectCount").textContent=Q.objects.length+" objetos";let e=(I("objectSearch")?.value||"").trim().toLocaleLowerCase("pt-BR");for(let t of Q.objects){if(e&&!t.name.toLocaleLowerCase("pt-BR").includes(e))continue;let i=document.createElement("div");i.dataset.objectId=t.id,i.className="layer"+(t.id===Q.activeId?" active":"")+(t.visible?"":" dim")+(mt===t.id?" isolated":"")+(So===t.id?" hover":"");let r=document.createElement("button");r.className="layer-expand";let s=["separate","cutter","stamp","integrated"].includes(t.params.mode);r.textContent=Ui.has(t.id)?"\u2304":"\u203A",r.disabled=!s,r.title="Mostrar componentes",r.onclick=g=>{g.stopPropagation(),Ui.has(t.id)?Ui.delete(t.id):Ui.add(t.id),cr()};let o=document.createElement("button");o.className="layer-eye",o.textContent=t.visible?"\u25C9":"\u25CB",o.title=t.visible?"Ocultar objeto":"Exibir objeto",o.setAttribute("aria-label",o.title+" "+t.name),o.onclick=g=>{g.stopPropagation(),t.visible=!t.visible,!t.visible&&mt===t.id&&(mt=null),t.visible&&(!t.result||t.cacheKey!==wn(t))?Vt([t.id]):ur(),cr(),st()};let a=document.createElement("button");a.className="layer-name",a.append(document.createTextNode(t.name));let c=document.createElement("small"),l=wo(t);c.textContent=l?`${Zt(l.primary.x)} \xD7 ${Zt(l.primary.y)} mm \xB7 ${t.result.parts.length} pe\xE7a(s)`:`${Zt(t.params.size,1)} mm \xB7 aguardando`,a.appendChild(c),a.onclick=()=>as(t.id),a.ondblclick=()=>{as(t.id),dt?.focus(t.id)},i.onmouseenter=()=>{dt?.setHover(t.id),jl(t.id)},i.onmouseleave=()=>{dt?.setHover(null),jl(null)};let u=document.createElement("details");u.className="layer-menu";let d=document.createElement("summary");d.textContent="\u2022\u2022\u2022",d.title="A\xE7\xF5es do objeto",u.appendChild(d);let h=document.createElement("div");h.className="layer-menu-popup";let f=(g,b)=>{let m=document.createElement("button");m.textContent=g,m.onclick=p=>{p.stopPropagation(),u.open=!1,b()},h.appendChild(m)};if(f("Renomear",()=>lx(t)),f("Enquadrar",()=>{as(t.id),dt?.focus(t.id)}),f(mt===t.id?"Sair do isolamento":"Isolar",()=>Ql(t.id)),f(t.visible?"Ocultar":"Mostrar",()=>{t.visible=!t.visible,!t.visible&&mt===t.id&&(mt=null),t.visible&&(!t.result||t.cacheKey!==wn(t))?Vt([t.id]):ur(),cr(),st()}),f("Excluir",()=>Qf(t.id)),u.appendChild(h),u.ontoggle=()=>{u.open&&hx(u)},i.append(r,o,a,u),n.appendChild(i),Ui.has(t.id)){let g=document.createElement("div");g.className="layer-children";let b=t.params.mode==="separate"?["Cortador","Carimbo"]:t.params.mode==="stamp"?["Carimbo"]:t.params.mode==="cutter"?["Cortador"]:["Conjunto"];for(let[m,p]of b.entries()){let S=document.createElement("div");S.className="layer-child";let T=document.createElement("span");T.textContent="\u2514";let y=document.createElement("span"),E=l?.parts?.[m];y.textContent=E?`${p} \xB7 ${Zt(E.x)} \xD7 ${Zt(E.y)} \xD7 ${Zt(E.z)} mm`:p,S.append(T,y),g.appendChild(S)}n.appendChild(g)}}if(I("isolationBanner").hidden=!mt,mt){let t=Q.objects.find(i=>i.id===mt);I("isolationBanner").textContent=`Isolado: ${t?.name||"objeto"} \xB7 clique para sair`}}function Qf(n){Q.objects.find(t=>t.id===n)&&(zn(),Q.objects=Q.objects.filter(t=>t.id!==n),mt===n&&(mt=null),Q.activeId===n&&(Q.activeId=Q.objects[0]?.id),Rt(),Lt?.reset(),Tn(),st())}function ep(n){zn(),Q.name=n.trim().slice(0,120)||"Projeto",I("name").value=Q.name,st(),nt("Nome do projeto atualizado.")}I("name").onchange=()=>ep(I("name").value);I("renameProject").onclick=()=>{I("renameValue").value=Q.name,I("renameDialog").showModal(),I("renameValue").focus()};I("cancelRename").onclick=()=>I("renameDialog").close();I("confirmRename").onclick=()=>{ep(I("renameValue").value),I("renameDialog").close()};function yo(){return I("paramScope").value==="all"?Q.objects:[Et()].filter(Boolean)}function tp(n,e){if(typeof e==="number"&&!Number.isFinite(e))return;let t=yo();for(let r of t)r.params[n]=e,n==="relief"&&(r.params.reliefInverted?r.params.reliefIn=e:r.params.reliefOut=e),n==="wall"&&r.params.tip>e&&(r.params.tip=e);Rt(),Vt(t.map(r=>r.id)),st()}for(let n of Object.keys(li)){let e=I(n),t=I(n+"Range");if(e&&(e.addEventListener("change",()=>{zn(),tp(n,e.type==="checkbox"?e.checked:e.tagName==="SELECT"?e.value:+e.value)}),t)){let i=!1;t.oninput=()=>{i||(zn(),i=!0);let r=+t.value;e.value=r;let s=yo();for(let o of s)o.params[n]=r,n==="relief"&&(o.params.reliefInverted?o.params.reliefIn=r:o.params.reliefOut=r),n==="wall"&&o.params.tip>r&&(o.params.tip=r);nt("Solte o controle para aplicar a medida.")},t.onchange=()=>{i=!1,Rt(),Vt(yo().map(r=>r.id)),st()},t.onblur=()=>{i&&(i=!1,Rt(),Vt(yo().map(r=>r.id)),st())}}}document.querySelectorAll("[data-mode-choice]").forEach(n=>n.onclick=()=>{Et()&&(I("mode").value=n.dataset.modeChoice,I("mode").dispatchEvent(new Event("change",{bubbles:!0})))});document.querySelectorAll("[data-scope-choice]").forEach(n=>n.onclick=()=>{I("paramScope").value=n.dataset.scopeChoice,document.querySelectorAll("[data-scope-choice]").forEach(e=>e.classList.toggle("active",e===n))});for(let[n,e]of[["lineDelta","lineDeltaRange"],["offsetAmount","offsetRange"]])I(n).oninput=()=>I(e).value=I(n).value,I(e).oninput=()=>I(n).value=I(e).value;var tu=0,hr=!1,xo,cn=0,ci=new Set,wn=n=>JSON.stringify([n.contourVersion||0,n.params]),Wl=new WeakMap,zf=new WeakMap,rw=Promise.resolve();function ec(){clearTimeout(Xl),cancelAnimationFrame(vo),vo=0,Fi=null,I("importCandidates").replaceChildren(),I("importDialog").close(),Yh=null,hi++,cn++,tu++,clearTimeout(xo),ci.clear(),hr=!1,_n?.terminate(),_n=null;for(let n of kn.values())n.reject(Object.assign(Error("Opera\xE7\xE3o cancelada ao trocar de projeto."),{name:"AbortError"}));kn.clear(),dt?.clear(),Zh=!0,Jh=""}async function ls(n){let e=wn(n),t=cn;if(n.result&&n.cacheKey===e)return n.result;let i=Wl.get(n);if(i?.key===e&&i.epoch===t)return i.promise;let r=(async()=>{let s=zf.get(n);(!s||s.loops!==n.loops||s.revision!==(n.contourVersion||0))&&(s={loops:n.loops,revision:n.contourVersion||0,hash:await Po(JSON.stringify(n.loops))},zf.set(n,s));let o=structuredClone(n.params),a=await Po(Vi+s.hash+JSON.stringify(o)),c=()=>t===cn&&Q.objects.includes(n)&&e===wn(n);if(!c())throw Object.assign(Error("Opera\xE7\xE3o substitu\xEDda."),{name:"AbortError"});let l=await gu(a);if(!c())throw Object.assign(Error("Opera\xE7\xE3o substitu\xEDda."),{name:"AbortError"});if(l)l.calculation={...l.calculation,loadedFromDisk:!0,computed:[]};else{if(l=await Oi({action:"build",loops:n.loops,params:o,sourceHash:s.hash}),!c())throw Object.assign(Error("Opera\xE7\xE3o substitu\xEDda."),{name:"AbortError"});await _u(a,l)}if(c()){let u=Object.fromEntries(await Promise.all(Object.entries(pu(s.hash,o)).map(async([d,h])=>[d,{fields:h.fields,parents:Ro[d].parents,key:await Po(h.key)}])));if(!c())throw Object.assign(Error("Opera\xE7\xE3o substitu\xEDda."),{name:"AbortError"});for(let d=0;d<l.parts.length;d++){let h=l.parts[d],f=h.name==="Cortador"?"cutter":h.name==="Carimbo"?"stamp":"integrated",g=n.result?.parts.find(b=>b.name===h.name);g?.positions.length&&n.geometryRecord?.nodes?.[f]?.key===u[f].key&&(l.parts[d]=g)}n.result=l,n.cacheKey=e,n.error=null,n.geometryRecord={version:Vi,sourceHash:s.hash,cacheKey:a,nodes:u}}return l})().finally(()=>{Wl.get(n)?.promise===r&&Wl.delete(n)});return Wl.set(n,{key:e,promise:r,epoch:t}),r}function Vt(n=null){if(Q.screen!=="studio"||Bn)return;tu++;let e=n??Q.objects.filter(Jn).map(t=>t.id);for(let t of e)t&&ci.add(t);clearTimeout(xo),I("export").disabled=!0,xo=setTimeout(np,220)}function ql(){return Q.objects.reduce((n,e)=>n+(e.result?.parts||[]).reduce((t,i)=>t+i.positions.byteLength+i.indices.byteLength+Object.values(i.renderData||{}).reduce((r,s)=>r+s.positions.byteLength+s.normals.byteLength+s.indices.byteLength,0),0),0)}async function np(){if(hr||Q.screen!=="studio"||Bn)return;let n=cn;hr=!0,I("busy").hidden=!1;let e=performance.now(),t=!1,i=0;try{for(;ci.size&&n===cn;){let r=ci.values().next().value;ci.delete(r);let s=Q.objects.find(o=>o.id===r);if(!(!s||!Jn(s))){I("busy").textContent="Atualizando "+s.name+"\u2026";try{await ls(s)}catch(o){if(n!==cn)return;if(o.name==="AbortError"){ci.add(r);continue}s.result=null,s.cacheKey=null,s.error=o.message}if(n!==cn)return;ip(s.id),(performance.now()-i>180||!ci.size)&&(Tn(),i=performance.now()),await new Promise(o=>setTimeout(o,0))}}if(n===cn){Tn();let r=Q.objects.filter(s=>Jn(s)&&s.error);if(I("validation").className="validation"+(r.length?" error":""),I("validation").textContent=r.length?r.map(s=>s.name+": "+s.error).join(" \xB7 "):"Projeto ativo \xB7 "+Q.objects.filter(s=>s.result).length+" geometrias dispon\xEDveis \xB7 "+Math.round(ql()/1048576)+" MB de malhas"+(Q.objects.some(s=>s.result?.released)?" \xB7 pe\xE7as em caixas leves: selecione para detalhar":""),!r.length&&!t){let s=Et()?.result?.calculation;nt(s?.loadedFromDisk?"Geometria restaurada do cache \xB7 sem rec\xE1lculo.":"Atualizado em "+Math.round(performance.now()-e)+" ms \xB7 "+(s?.computed?.length||0)+" etapas calculadas, "+(s?.reused?.length||0)+" reutilizadas.")}st()}}finally{n===cn&&(hr=!1,I("busy").hidden=!0,I("export").disabled=!Q.objects.length,ci.size&&(xo=setTimeout(np,0)))}}function ux(n){!n.result||n.result.released||(n.result={...n.result,released:!0,parts:n.result.parts.map(e=>({...e,positions:new Float32Array,indices:new Uint32Array,renderData:null}))},n.cacheKey=null)}function ip(n,e=96*1024*1024){if(!(ql()<=e)){for(let t of Q.objects)if(!(t.id===n||t.id===Q.activeId)&&(ux(t),ql()<=e*.75))break}}function dx(){let n=new Map;for(let e of Q.objects)n.set(e.id,Jn(e));return n}function ur(){for(let e of Q.objects)if(!Jn(e)&&e.result&&!e.result.released){for(let t of e.result.parts)t.positions=new Float32Array,t.indices=new Uint32Array,t.renderData=null;e.result.released=!0,e.result.hiddenRelease=!0,e.cacheKey=null}dt?.setVisibility(dx(),Q.activeId),eu(),cr(),Q.stage==="2d"&&Lt?.render();let n=Q.objects.filter(e=>Jn(e)&&(!e.result||(!e.result.released||e.result.hiddenRelease)&&e.cacheKey!==wn(e))).map(e=>e.id);n.length&&Vt(n)}var Zh=!0,Jh="";function Tn(){if(!dt)return;let n=Q.objects.filter(a=>a.result&&(a.cacheKey===wn(a)||a.result.released)),e=n.map(a=>({...a,viewerVisible:Jn(a)}));dt.update(e,{...Q.view,presentation:xt(),presentationMode:Q.stage==="presentation"},Q.activeId),I("export").disabled=!Q.objects.length;let t=n.filter(a=>Jn(a)&&!a.result.released),i=t.reduce((a,c)=>a+c.result.parts.reduce((l,u)=>l+u.stats.triangles,0),0);I("meshStats").textContent=i?i.toLocaleString("pt-BR")+" tri\xE2ngulos":"";let r=Et(),s=wo(r);I("dimensions").textContent=s?s.parts.map(a=>`${a.name}: ${Zt(a.x)} \xD7 ${Zt(a.y)} \xD7 ${Zt(a.z)} mm`).join("  \xB7  "):"",eu();let o=n.map(a=>a.id+a.params.mode).join(":")+Q.view.arrangement;n.length&&(Zh||o!==Jh)&&(dt.fit(),Q.stage==="presentation"&&xt().camera&&dt.restoreCamera(xt().camera)),Jh=o,Zh=!n.length,Q.stage==="2d"&&Lt?.render()}for(let n of["arrangement","material","componentColors","showDims","layerLines","sliceEnabled","wire","grid"])I(n).onchange=()=>{let e=I(n);Q.view[n]=e.type==="checkbox"?e.checked:e.value,Tn(),st()};for(let n of Object.keys(Ni))I("color-"+n).oninput=()=>{Q.view.colors[n]=I("color-"+n).value,Rt(),Tn(),st()};I("randomColors").onclick=()=>{for(let n of Object.keys(Ni)){let e=new He().setHSL(Math.random(),.55,.62);Q.view.colors[n]="#"+e.getHexString()}Rt(),Tn(),st()};for(let n of["sliceRange","sliceHeight"])I(n).oninput=()=>{Q.view.sliceHeight=+I(n).value,I(n==="sliceRange"?"sliceHeight":"sliceRange").value=Q.view.sliceHeight,Tn()};I("showAll").onclick=()=>{mt=null,Q.objects.forEach(e=>e.visible=!0),Rt();let n=Q.objects.filter(e=>!e.result||e.cacheKey!==wn(e)).map(e=>e.id);n.length?Vt(n):ur()};I("hideOthers").onclick=()=>Ql();I("removeObject").onclick=()=>{Et()&&Qf(Q.activeId)};I("focusActive").onclick=()=>Et()&&dt?.focus(Q.activeId);I("isolateActive").onclick=()=>Ql();I("visibilityActive").onclick=()=>{let n=Et();n&&(n.visible=!n.visible,!n.visible&&mt===n.id&&(mt=null),Rt(),n.visible&&(!n.result||n.cacheKey!==wn(n))?Vt([n.id]):ur(),st())};function rp(n){if(!n?.editable||!n.objectId)return;let e=Q.objects.find(o=>o.id===n.objectId);if(!e||!e.result)return;Q.activeId=e.id;let t=I("dimensionEditor"),i=I("dimensionValue"),r=I("dimensionAxisLabel");t.dataset.objectId=e.id,t.dataset.axis=n.dimensionAxis,r.textContent=n.dimensionAxis==="x"?"Largura":n.dimensionAxis==="y"?"Profundidade":"Altura",i.value=Number(n.dimensionValue).toFixed(2);let s=I("viewport").getBoundingClientRect();t.style.left=Math.max(12,Math.min(s.width-190,(n.clientX??s.left+s.width/2)-s.left+8))+"px",t.style.top=Math.max(56,Math.min(s.height-70,(n.clientY??s.top+s.height/2)-s.top-22))+"px",t.hidden=!1,i.focus(),i.select(),Rt()}function bo(){I("dimensionEditor")&&(I("dimensionEditor").hidden=!0)}function _o(n,e){return wo(n)?.primary?.[e]??NaN}async function sp(){let n=I("dimensionEditor"),e=Q.objects.find(s=>s.id===n.dataset.objectId),t=n.dataset.axis,i=+I("dimensionValue").value;if(!e||!Number.isFinite(i)||i<=0){nt("Informe uma medida v\xE1lida em mil\xEDmetros.");return}let r=_o(e,t);if(Number.isFinite(r)){if(t==="z"&&e.result.parts[0]?.name==="Carimbo"){nt("A altura total do carimbo \xE9 resultante. Ajuste base e relevo nos par\xE2metros."),bo();return}zn(),tu++,clearTimeout(xo),I("busy").hidden=!1,I("busy").textContent="Ajustando cota com precis\xE3o\u2026";try{if(t==="z")e.params.height=Math.max(4,Math.min(50,i)),await ls(e);else{let o=e.params.size,a=r,c=Math.max(10,Math.min(300,o*i/a));e.params.size=c,await ls(e);let l=_o(e,t);for(let u=0;u<2&&Math.abs(l-i)>.01;u++){let d=Math.abs(c-o)>1e-6?(l-a)/(c-o):l/Math.max(c,1);if(!Number.isFinite(d)||Math.abs(d)<1e-5)break;let h=Math.max(10,Math.min(300,c+(i-l)/d));o=c,a=l,c=h,e.params.size=c,await ls(e),l=_o(e,t)}}Rt(),Tn(),st();let s=_o(e,t);nt(`Cota ajustada: ${Zt(s)} mm${Math.abs(s-i)<=.02?"":" (limite geom\xE9trico aproximado)"}.`)}catch(s){nt("N\xE3o foi poss\xEDvel ajustar a cota: "+s.message)}finally{I("busy").hidden=!0,bo()}}}I("dimensionValue").onkeydown=n=>{n.key==="Enter"?(n.preventDefault(),sp()):n.key==="Escape"&&(n.preventDefault(),bo())};I("dimensionApply").onclick=sp;I("dimensionCancel").onclick=bo;function fx(n){if(n.type==="hover"){jl(n.id);return}if(n.type==="select"){n.id?as(n.id):jl(null);return}if(n.type==="focus"){n.id&&as(n.id);return}n.type==="dimension"&&rp(n)}function tc(n){Q.stage==="presentation"&&(xt().camera=dt.getCamera(),st()),Q.stage=n,document.body.classList.toggle("presenting",n==="presentation"),I("presentationPanel").hidden=n!=="presentation",I("tabPresentation").classList.toggle("active",n==="presentation"),ds();let e=n==="2d";I("editor").toggleAttribute("hidden",!e),I("three").hidden=e,I("editTools").hidden=!e,I("thickness2d").hidden=!e,I("goThickness").hidden=e,I("tab2d").classList.toggle("active",e),I("tab3d").classList.toggle("active",n==="3d"),document.querySelector(".viewport-title").hidden=e,document.querySelector(".right").classList.toggle("editing-2d",e),I("rightTitle").textContent=e?"Editar desenho":n==="presentation"?"Apresenta\xE7\xE3o":"Configurar pe\xE7a",Tn(),e?Lt.render():dt.resize()}I("tabPresentation").onclick=()=>tc("presentation");I("tab2d").onclick=()=>tc("2d");I("tab3d").onclick=()=>tc("3d");I("goThickness").onclick=()=>{tc("2d"),I("thickness2d").scrollIntoView({block:"start"})};I("fit").onclick=()=>{Q.stage==="2d"?Lt.fit():(dt.fit(),Tn())};function op(n){dt.fit(n),Q.stage==="presentation"&&(xt().projection=n?"orthographic":"perspective",xt().camera=dt.getCamera(),ds(),st())}I("top").onclick=()=>op(!0);I("iso").onclick=()=>op(!1);try{dt=Of(I("three"),n=>{xt().camera=n,st()},fx)}catch(n){nt("N\xE3o foi poss\xEDvel iniciar o 3D: "+n.message)}Lt=Bf(I("editor"),{object:Et,history:zn,status:nt,request:Oi,changed:()=>{let n=Et();n&&(n.contourVersion=(n.contourVersion||0)+1),Vt(n?[n.id]:null),st(),cr()}});document.querySelectorAll("[data-tool]").forEach(n=>n.onclick=()=>{document.querySelectorAll("[data-tool]").forEach(e=>e.classList.remove("active")),n.classList.add("active"),Lt.setTool(n.dataset.tool)});I("deleteLoop").onclick=()=>Lt.removeContour();I("clearRegion").onclick=()=>Lt.clearRegion();I("applyOffset").onclick=()=>Lt.offset(+I("offsetAmount").value);I("applyThickness").onclick=()=>{let n=+I("lineDelta").value;if(!Number.isFinite(n)||n<-1||n>2){nt("Use uma varia\xE7\xE3o entre -1 e 2 mm.");return}if(I("thicknessTarget").value==="art"){Lt.thickness(n);return}let e=Et();if(!e)return;let{region:t}=Lt.getSelection();zn(),t?e.params.wallEdits=[...e.params.wallEdits||[],{region:t.map(i=>i.slice()),delta:n}]:(e.params.wall=Math.max(.3,Math.min(5,e.params.wall+n)),e.params.tip=Math.min(e.params.tip,e.params.wall)),Rt(),Vt([e.id]),st()};I("resetWallEdits").onclick=()=>{let n=Et();n&&(zn(),n.params.wallEdits=[],Vt([n.id]),st(),nt("Ajustes locais da l\xE2mina removidos."))};window.addEventListener("keydown",n=>{["INPUT","TEXTAREA","SELECT"].includes(n.target.tagName)||(n.ctrlKey&&n.key.toLowerCase()==="z"&&(n.preventDefault(),I("undo").click()),n.ctrlKey&&n.key.toLowerCase()==="y"&&(n.preventDefault(),I("redo").click()),n.ctrlKey&&n.key.toLowerCase()==="s"&&(n.preventDefault(),I("save").click()),n.key==="Escape"&&mt&&(mt=null,Rt(),ur(),nt("Isolamento encerrado.")),n.key.toLowerCase()==="f"&&Et()&&Q.stage!=="2d"&&(n.preventDefault(),dt?.focus(Q.activeId)),n.key==="Delete"&&Q.stage==="2d"&&Lt.removeNode())});function ap(n){return new Promise((e,t)=>{let i=new FileReader;i.onload=()=>e(i.result),i.onerror=t,i.readAsDataURL(n)})}async function px(n){let e=new Image;e.decoding="async",await new Promise((t,i)=>{let r=!1,s=(o,a)=>{r||(r=!0,clearTimeout(c),e.onload=null,e.onerror=null,o(a))},c=setTimeout(()=>s(i,Error("A imagem demorou demais para carregar. Tente novamente ou use PNG/JPG.")),15e3);e.onload=()=>s(t),e.onerror=()=>s(i,Error("Não foi possível carregar a imagem selecionada.")),e.src=n});let t=e.naturalWidth||e.width,i=e.naturalHeight||e.height;if(!(t>0&&i>0))throw Error("A imagem não possui dimensões válidas.");let r=Math.min(1,1800/Math.max(t,i)),s=document.createElement("canvas");s.width=Math.max(1,Math.round(t*r)),s.height=Math.max(1,Math.round(i*r));let o=s.getContext("2d",{willReadFrequently:!0});return o.fillStyle="white",o.fillRect(0,0,s.width,s.height),o.drawImage(e,0,0,s.width,s.height),{pixels:o.getImageData(0,0,s.width,s.height).data,w:s.width,h:s.height}}async function lp(n,e=hi){let t=await px(n);if(e!==hi)throw Object.assign(Error("Importa\xE7\xE3o cancelada"),{name:"AbortError"});return(await Oi({action:"trace",...t,threshold:Et()?.params.threshold??160})).map(r=>Vh(r,1e-4))}var Fi=null,hi=0;function mx(n,e){return{id:lr(),name:e,loops:n.map(t=>Vh(t,.015/75)),params:{...li},visible:!0,result:null,cacheKey:null}}function nu(n,e,t,i=!1){zn(),i||(mt=null);let r=ax(e),s=n.map((o,a)=>mx(o,n.length===1?r:`${r} ${a+1}`));Q.objects=i?[...Q.objects,...s]:s,Q.activeId=s[0]?.id,(Q.name==="Novo cortador"||Q.name==="Novo projeto"||!i)&&(Q.name=e),Q.source=t,Kl(),Lt.reset(),Rt(),Vt()}function cp(n,e,t,i=!0){let r=Lf(n,.012);if(!r.length)throw Error("N\xE3o foram encontrados objetos fechados.");if(!i){nu(r,e,t);return}Fi={groups:r,name:e,source:t};let s=I("importCandidates");s.replaceChildren(),r.forEach((o,a)=>{let c=document.createElement("div");c.className="candidate";let l=document.createElementNS("http://www.w3.org/2000/svg","svg");l.setAttribute("viewBox","-.6 -.6 1.2 1.2");let u=document.createElementNS(l.namespaceURI,"path");u.setAttribute("d",o.map(f=>"M"+f.map(([g,b])=>g+","+-b).join("L")+"Z").join(" ")),u.setAttribute("fill","#365673"),u.setAttribute("fill-rule","evenodd"),l.appendChild(u);let d=document.createElement("label"),h=document.createElement("input");h.type="checkbox",h.checked=!0,h.dataset.candidate=a,d.append(h,document.createTextNode("Objeto "+(a+1))),c.append(l,d),s.appendChild(c)}),I("appendObjects").checked=Q.objects.length>0,I("importDialog").showModal()}I("confirmImport").onclick=()=>{if(!Fi)return;let n=[...I("importCandidates").querySelectorAll("input:checked")].map(e=>Fi.groups[+e.dataset.candidate]);if(!n.length){nt("Selecione ao menos um objeto.");return}nu(n,Fi.name,Fi.source,I("appendObjects").checked),I("importDialog").close(),Fi=null};I("cancelImport").onclick=()=>{I("importDialog").close(),Fi=null};async function nc(n,e,t=!0){let i=++hi;I("busy").hidden=!1,I("busy").textContent="Detectando objetos\u2026";try{let r=await lp(n,i);i===hi&&cp(r,e,n,t)}catch(r){i===hi&&nt(r.message)}finally{i===hi&&(I("busy").hidden=!0)}}var hp=.01;function gx(n){let e=[];function t(i,r,s,o,a){let c=(i+r)/2,l=n.getPoint(c),u=n.getPoint((3*i+r)/4),d=n.getPoint((i+3*r)/4),h=(f,g)=>f.distanceTo(s.clone().lerp(o,g));a<16&&Math.max(h(l,.5),h(u,.25),h(d,.75))>hp?(t(i,c,s,l,a+1),t(c,r,l,o,a+1)):e.push([s.x,-s.y])}return t(0,1,n.getPoint(0),n.getPoint(1),0),e}async function up(n,e,t=!0){let i=++hi,r=new DOMParser().parseFromString(n,"image/svg+xml");if(r.querySelector("parsererror"))throw Error("SVG inv\xE1lido.");if(r.querySelector("script,foreignObject,image,use,text"))throw Error("Converta texto e refer\xEAncias do SVG em caminhos antes de importar.");let s=new go().parse(n),o=new Ei;for(let l of s.paths)for(let u of l.subPaths)for(let d of u.getPoints(32))o.expandByPoint(d);hp=Math.max(o.max.x-o.min.x,o.max.y-o.min.y)*5e-5;let a=[];for(let l of s.paths){if(l.userData.style.fill==="none"){if(l.userData.style.stroke!=="none")throw Error("Converta tra\xE7os em caminhos preenchidos no editor SVG.");continue}for(let u of go.createShapes(l)){let d=[];for(let h of[u,...u.holes]){let f=h.curves.flatMap(gx);f.length>=3&&d.push(f)}d.length&&a.push(d)}}let c=Hh(await Oi({action:"svg",shapes:a}));i===hi&&cp(c,e,null,t)}I("import").onclick=()=>I("artFile").click();I("importEmpty").onclick=()=>I("artFile").click();I("artFile").onchange=async()=>{let n=I("artFile").files[0];if(n){try{if(n.size>25*1024*1024)throw Error("Use uma imagem de at\xE9 25 MB.");let e=n.name.replace(/\.[^.]+$/,"");n.name.toLowerCase().endsWith(".svg")?await up(await n.text(),e):await nc(await ap(n),e)}catch(e){nt(e.message)}I("artFile").value=""}};I("retrace").onclick=()=>Q.source?nc(Q.source,Q.name):nt("Este projeto n\xE3o tem imagem original para reprocessar.");async function To(n,e=!1){if(e&&!await Qh())return;let t=cn,i=await fetch(n==="Porquinho"?"examples/pig.jpg":n==="Flores"?"examples/flowers.png":"examples/cow.jpg"),r=await ap(await i.blob());t===cn&&Q.screen==="studio"&&await nc(r,n,!1)}I("pig").onclick=()=>To("Porquinho");I("cow").onclick=()=>To("Vaquinha");I("homePig").onclick=()=>To("Porquinho",!0);I("homeCow").onclick=()=>To("Vaquinha",!0);I("homeFlowers").onclick=()=>To("Flores",!0);async function Mo(n,e,t){if(window.desktop)try{return await window.desktop.save(n,typeof e=="string"?e:new Uint8Array(e),t)}catch(s){return nt("Falha ao salvar: "+s.message),null}let i=URL.createObjectURL(new Blob([e])),r=document.createElement("a");return r.href=i,r.download=n,r.click(),setTimeout(()=>URL.revokeObjectURL(i),3e3),n}I("save").onclick=async()=>{if(!Q.objects.length){nt("Importe uma arte primeiro.");return}await Bi(),await Mo(Q.name+".rvcad",JSON.stringify($l()),"project")&&nt("Projeto salvo.")};I("open").onclick=()=>I("projectFile").click();I("projectFile").onchange=async()=>{try{let n=I("projectFile").files[0];if(!n)return;if(n.size>80*1024*1024)throw Error("Projeto excede 80 MB.");let e=JSON.parse(await n.text());if(!await Bi())return;Zl(e),Q.history=[],Q.future=[],Kl(),Vt()}catch(n){nt(n.message)}I("projectFile").value=""};I("exportSvg").onclick=()=>{let n=Et();if(!n)return;let e=n.loops.map(t=>"M"+t.map(([i,r])=>`${(i+.6)*n.params.size},${(.6-r)*n.params.size}`).join("L")+"Z").join(" ");Mo(n.name+".svg",`<svg xmlns="http://www.w3.org/2000/svg" width="${n.params.size*1.2}mm" height="${n.params.size*1.2}mm" viewBox="0 0 ${n.params.size*1.2} ${n.params.size*1.2}"><path fill="black" fill-rule="evenodd" d="${e}"/></svg>`,"svg")};function dp(){let n=Q.objects.filter(e=>!I("exportVisible").checked||e.visible);I("exportSummary").textContent=`${n.length} objetos selecionados. Modos com v\xE1rios arquivos entregam um ZIP com os STLs.`}I("export").onclick=()=>{dp(),I("exportDialog").showModal()};I("exportVisible").onchange=dp;I("closeExport").onclick=()=>I("exportDialog").close();function _x(n){let e=n.map(c=>{let l=c.result.parts||[];if(!l.length)throw Error("Objeto sem geometria para exportar.");let u=l.map(S=>{if(S.bounds?.min?.length>=2&&S.bounds?.max?.length>=2)return{minX:S.bounds.min[0],minY:S.bounds.min[1],maxX:S.bounds.max[0],maxY:S.bounds.max[1]};let T=1/0,y=1/0,E=-1/0,A=-1/0;for(let U=0;U<S.positions.length;U+=S.stride){let v=S.positions[U],C=S.positions[U+1];T=Math.min(T,v),y=Math.min(y,C),E=Math.max(E,v),A=Math.max(A,C)}return{minX:T,minY:y,maxX:E,maxY:A}}),d=Math.min(...u.map(S=>S.minX)),h=Math.min(...u.map(S=>S.minY)),f=Math.max(...u.map(S=>S.maxX)),g=Math.max(...u.map(S=>S.maxY)),b=(d+f)/2,m=(h+g)/2,p=[-b,-m,0];return{object:c,parts:l.map(S=>({part:S,position:[...p]})),w:f-d,d:g-h}}),t=Math.max(1,Math.ceil(Math.sqrt(e.length))),i=Math.max(1,Math.ceil(e.length/t)),r=Math.max(...e.map(c=>c.w),1),s=Math.max(...e.map(c=>c.d),1),o=18,a=(i-1)*(s+o);return e.map((c,l)=>{let u=Math.floor(l/t),d=l%t,h=Math.min(t,e.length-u*t),f=(h-1)*(r+o);return{...c,position:[d*(r+o)-f/2,u*(s+o)-a/2,0]}})}async function fp(n,e=!0){let t=cn,i=Q.objects.filter(l=>!e||l.visible);if(!i.length)throw Error("Nenhum objeto para exportar.");let r=new Map(i.map(l=>[l.id,wn(l)])),s=()=>{if(t!==cn||i.some(l=>wn(l)!==r.get(l.id)))throw Error("Exporta\xE7\xE3o cancelada porque o projeto ou os par\xE2metros mudaram. Repita a exporta\xE7\xE3o.")},o=new Set(i.filter(l=>!l.result||l.result.released)),a=l=>{if(!(!o.has(l)||!l.result)){for(let u of l.result.parts)u.positions=new Float32Array,u.indices=new Uint32Array,u.renderData=null;l.result.released=!0,l.cacheKey=null}},c=l=>l.replace(/[<>:"/\\|?*]/g,"_").slice(0,80);try{for(let g of i)s(),await ls(g),s(),a(g);let l=_x(i),u={},d,h=84,f=0;if(n==="all"){if(f=i.reduce((g,b)=>g+b.result.parts.reduce((m,p)=>m+p.stats.triangles,0),0),84+f*50>150*1024*1024)throw Error("Lote excede 150 MB. Exporte por conjunto ou divida o lote.");d=new Uint8Array(84+f*50),new DataView(d.buffer).setUint32(80,f,!0)}for(let g=0;g<i.length;g++){s();let b=i[g];await ls(b);let m=l[g],p=b.result.parts.map((T,y)=>({part:T,position:m.parts[y].position.map((E,A)=>E+(n==="all"?m.position[A]:0))})),S=String(g+1).padStart(2,"0")+"_"+c(i.length===1?Q.name:b.name);if(n==="part")for(let[T,y]of p.entries())u[S+"_"+(T+1)+"_"+c(y.part.name)+".stl"]=await Oi({action:"stl",mesh:Xh([y])});else{let T=await Oi({action:"stl",mesh:Xh(p)});d?(d.set(T.subarray(84),h),h+=T.length-84):u[S+"_Conjunto.stl"]=T}s(),a(b),await new Promise(T=>setTimeout(T,0))}return s(),d&&(u[c(Q.name)+"_Lote.stl"]=d),u}finally{for(let l of i)a(l)}}I("confirmExport").onclick=async()=>{let n=I("confirmExport");n.disabled=!0,n.textContent="Preparando arquivos\u2026";try{let e=await fp(I("exportMode").value,I("exportVisible").checked),t=Object.keys(e);(t.length===1?await Mo(t[0],e[t[0]].buffer,"stl"):await Mo(Q.name+"_STLs.zip",(await Oi({action:"zip",files:e})).buffer,"zip"))&&(nt(`${t.length} arquivo(s) STL exportado(s).`),I("exportDialog").close())}catch(e){nt("Exporta\xE7\xE3o bloqueada: "+e.message)}finally{n.disabled=!1,n.textContent="Exportar"}};I("invertRelief").onclick=()=>{let n=Et();if(!n||n.params.mode==="cutter")return;zn();let e=n.params.mode==="integrated"?n.params.base:n.params.stampBase;if(n.params.reliefInverted)n.params.reliefIn=n.params.relief,n.params.reliefInverted=!1,n.params.relief=Math.max(.05,Number.isFinite(n.params.reliefOut)?n.params.reliefOut:li.relief),nt("Relevo invertido: para fora.");else{n.params.reliefOut=n.params.relief,n.params.reliefInverted=!0;let t=Number.isFinite(n.params.reliefIn)?n.params.reliefIn:Math.max(.05,Math.min(li.relief,e*.4));n.params.relief=Math.max(.05,t),n.params.reliefIn=n.params.relief,nt("Relevo invertido: para dentro · profundidade medida a partir da base do carimbo.")}Rt(),Vt([n.id]),st()};I("help").onclick=()=>I("helpDialog").showModal();I("closeHelp").onclick=()=>I("helpDialog").close();var vo=0;function hn(){vo||(vo=requestAnimationFrame(()=>{vo=0,dt?.updateAppearance({...Q.view,presentation:xt(),presentationMode:Q.stage==="presentation"})}))}function xt(){Q.view.presentation||(Q.view.presentation=structuredClone(Sn));let n=Q.view.presentation;return n.modelShadowMode||(n.modelShadowMode=n.modelShadows===!1?"none":"soft"),n.internalEdges===void 0&&(n.internalEdges=!0),n.projectedShadows===void 0&&(n.projectedShadows=!0),n.groundDistance===void 0&&(n.groundDistance=Sn.groundDistance),n.aoIntensity===void 0&&(n.aoIntensity=Sn.aoIntensity),n.aoRadius===void 0&&(n.aoRadius=Sn.aoRadius),n.hatchMaster===void 0&&(n.hatchMaster=!1),n.hatchProfiles=os(n),n.modelShadows=n.modelShadowMode!=="none",n}var pp=[["shadeSoftness","Suavidade das cores (Ilustrado)",0,1,.01],["lightAzimuth","Dire\xE7\xE3o da luz (\xB0)",-180,180,1],["lightElevation","Eleva\xE7\xE3o da luz (\xB0)",5,85,1],["lightIntensity","Intensidade da luz",0,6,.1],["ambient","Luz ambiente",0,3,.05],["groundDistance","Dist\xE2ncia do ch\xE3o",0,20,.1],["aoIntensity","Oclus\xE3o de ambiente",0,1,.05],["aoRadius","Raio da oclus\xE3o (mm)",.2,6,.1],["shadowOpacity","Intensidade da sombra no ch\xE3o",0,1,.05],["shadowSoftness","Suavidade da sombra",0,8,.1],["lineWidth","Espessura do contorno (px)",0,4,.1]];I("presentationControls").innerHTML=pp.map(([n,e,t,i,r])=>`<div class="range-pair"><label for="pres-${n}">${e}</label><input id="pres-${n}" type="number" min="${t}" step="${r}" title="Valor livre; o slider usa a faixa recomendada"><input id="pres-${n}Range" type="range" min="${t}" max="${i}" step="${r}" aria-label="${e}"></div>`).join("");I("presentationColors").innerHTML=Object.entries($h).map(([n,e])=>`<label class="color-key">${e}<input type="color" id="pres-color-${n}" aria-label="${e}"></label>`).join("");var iu=[["rotation","Rota\xE7\xE3o (\xB0)",-180,180,1],["thickness","Espessura do tra\xE7o",.02,.45,.01],["scale","Escala / espa\xE7amento (mm)",.4,20,.1],["intensity","Intensidade",0,1,.05]],mp=[["none","Nenhuma"],["parallel","Linhas paralelas"],["cross","Cruzada 90\xB0"],["double45","Dupla 45\xB0"],["triple","Tripla"],["dots","Pontos m\xE9dios"],["dotsDense","Pontos densos"],["dotsSparse","Pontos espa\xE7ados"],["dash","Tracejada"],["scribble","Rabisco leve"]];I("pres-hatchType").innerHTML=mp.map(([n,e])=>`<option value="${n}">${e}</option>`).join("");I("hatchControls").innerHTML=iu.map(([n,e,t,i,r])=>`<div class="range-pair"><label for="pres-hatch-${n}">${e}</label><input id="pres-hatch-${n}" type="number" min="${t}" step="${r}" title="Valor livre; o slider usa a faixa recomendada"><input id="pres-hatch-${n}Range" type="range" min="${t}" max="${i}" step="${r}" aria-label="${e}"></div>`).join("");function yx(){return[...document.querySelectorAll("#hatchBulkRoles input[type=checkbox]:checked")].map(n=>n.dataset.role).filter(Boolean)}function gp(){let n=xt(),e=I("pres-hatchRole")?.value||"cutterBase";return n.hatchProfiles=os(n),n.hatchProfiles[e]}function vx(){let n=yx();return n.length?n:[I("pres-hatchRole")?.value||"cutterBase"]}function ki(n){let e=xt();e.hatchProfiles=os(e);for(let t of vx())n(e.hatchProfiles[t],t,e)}function xx(n,e){let t=n.getContext("2d"),i=n.width=108,r=n.height=68;t.fillStyle="#f3f4f6",t.fillRect(0,0,i,r),t.strokeStyle="#4e5b68",t.fillStyle="#4e5b68";let s=(a,c,l)=>{t.save(),t.translate(i/2,r/2),t.rotate(a*Math.PI/180),t.lineWidth=l;for(let u=-r;u<r;u+=c)t.beginPath(),t.moveTo(-i*1.2,u),t.lineTo(i*1.2,u),t.stroke();t.restore()},o=(a,c,l=0)=>{for(let u=a/2;u<r;u+=a)for(let d=a/2;d<i;d+=a){let h=((Math.sin(d*12.3+u*4.7)+1)/2-.5)*l,f=((Math.cos(d*7.1+u*9.2)+1)/2-.5)*l;t.beginPath(),t.arc(d+h,u+f,c,0,Math.PI*2),t.fill()}};switch(e){case"parallel":s(25,9,1.5);break;case"cross":s(0,10,1.3),s(90,10,1.3);break;case"double45":s(45,11,1.2),s(-45,11,1.2);break;case"triple":s(0,13,1.1),s(60,13,1.1),s(-60,13,1.1);break;case"dots":o(11,1.6,1);break;case"dotsDense":o(8,1.5,1.2);break;case"dotsSparse":o(15,1.7,.7);break;case"dash":s(24,9,1.4),t.clearRect(0,0,i,r),t.fillStyle="#f3f4f6",t.fillRect(0,0,i,r),t.strokeStyle="#4e5b68",t.save(),t.translate(i/2,r/2),t.rotate(24*Math.PI/180),t.setLineDash([10,8]),t.lineWidth=1.6;for(let a=-r;a<r;a+=10)t.beginPath(),t.moveTo(-i*1.2,a),t.lineTo(i*1.2,a),t.stroke();t.restore();break;case"scribble":s(18,11,1.1),s(43,14,1);break;default:t.strokeStyle="#9aa7b2",t.strokeRect(10,10,i-20,r-20)}}function bx(){let n=I("hatchGallery");if(!n)return;let e=I("pres-hatchType").value||gp().type||"parallel";if(!(n.dataset.current===e&&n.children.length)){n.dataset.current=e,n.innerHTML="";for(let[t,i]of mp.filter(([r])=>r!=="none")){let r=document.createElement("button");r.type="button",r.className="hatch-thumb"+(e===t?" active":""),r.innerHTML=`<canvas aria-hidden="true"></canvas><div class="cap">${i}</div>`,xx(r.querySelector("canvas"),t),r.onclick=()=>{hs(),I("pres-hatchType").value=t,ki(s=>s.type=t),fr(),hn(),st()},n.appendChild(r)}}}function fr(){let n=I("hatchPanel");if(!n)return;n.hidden=!1;let e=xt(),t=gp();I("pres-hatchMaster").checked=!!e.hatchMaster,I("pres-hatchEnabled").checked=t.enabled!==!1,I("pres-hatchType").value=t.type||"parallel",I("pres-hatchMode").value=t.mode||"overlay",I("pres-hatchColor").value=t.color||"#555555";for(let[i]of iu)I("pres-hatch-"+i).value=t[i],I("pres-hatch-"+i+"Range").value=t[i];bx()}function ds(){let n=xt();for(let[e,t]of Object.entries(n)){let i=I("pres-"+e);i&&(i.type==="checkbox"?i.checked=t:i.value=t);let r=I("pres-"+e+"Range");r&&(r.value=t)}for(let e of Object.keys(Ni))I("pres-color-"+e).value=n.colors[e];I("presentationColors").hidden=!n.componentColors,fr()}for(let[n,,e,t]of pp)I("pres-"+n).oninput=()=>{let i=+I("pres-"+n).value;if(!Number.isFinite(i))return;xt()[n]=Math.max(e,["shadeSoftness","aoIntensity","shadowOpacity","lightElevation"].includes(n)?Math.min(t,i):i),I("pres-"+n).value=xt()[n];let r=I("pres-"+n+"Range");r&&(r.value=Math.max(e,Math.min(t,i))),hn(),st()},I("pres-"+n+"Range").oninput=()=>{let i=+I("pres-"+n+"Range").value;Number.isFinite(i)&&(xt()[n]=i,I("pres-"+n).value=i,hn(),st())};for(let n of["background","modelColor","lineColor","componentColors","shadows","projectedShadows","modelShadowMode","internalEdges","showDims","transparent","projection","exportSize","hatchMaster"])I("pres-"+n).oninput=()=>{let e=I("pres-"+n);xt()[n]=e.type==="checkbox"?e.checked:n==="exportSize"?+e.value:e.value,ds(),hn(),st()};for(let n of Object.keys(Ni))I("pres-color-"+n).oninput=()=>{xt().colors[n]=I("pres-color-"+n).value,hn(),st()};I("pres-hatchRole").onchange=fr;I("pres-hatchMaster").oninput=()=>{xt().hatchMaster=I("pres-hatchMaster").checked,hn(),st()};function hs(){let n=xt();n.hatchMaster=!0,I("pres-hatchMaster").checked=!0,ki(e=>e.enabled=!0)}I("pres-hatchEnabled").oninput=()=>{let n=I("pres-hatchEnabled").checked;n&&(xt().hatchMaster=!0),ki(e=>e.enabled=n),fr(),hn(),st()};I("pres-hatchType").oninput=()=>{hs();let n=I("pres-hatchType").value;ki(e=>e.type=n),fr(),hn(),st()};I("pres-hatchMode").oninput=()=>{hs();let n=I("pres-hatchMode").value;ki(e=>e.mode=n),fr(),hn(),st()};I("pres-hatchColor").oninput=()=>{hs();let n=I("pres-hatchColor").value;ki(e=>e.color=n),fr(),hn(),st()};for(let[n,,e,t]of iu)I("pres-hatch-"+n).oninput=()=>{let i=+I("pres-hatch-"+n).value;if(!Number.isFinite(i))return;hs(),ki(s=>s[n]=Math.max(e,["thickness","intensity"].includes(n)?Math.min(t,i):i));let r=I("pres-hatch-"+n+"Range");r&&(r.value=Math.max(e,Math.min(t,i))),hn(),st()},I("pres-hatch-"+n+"Range").oninput=()=>{let i=+I("pres-hatch-"+n+"Range").value;Number.isFinite(i)&&(hs(),ki(r=>r[n]=i),I("pres-hatch-"+n).value=i,hn(),st())};I("pres-style").onchange=()=>{Q.view.presentation={...kh(I("pres-style").value),camera:xt().camera,hatchProfiles:xt().hatchProfiles,hatchMaster:xt().hatchMaster},ds(),hn(),st()};I("pres-reset").onclick=()=>{Q.view.presentation=kh(xt().style),ds(),hn(),dt.fit(),st()};I("exportPng").onclick=async()=>{try{if(!Q.objects.some(t=>Jn(t)&&t.result))throw Error("Exiba um objeto para salvar a imagem.");let n=xt();await Mo(Q.name+".png",dt.capture(n.exportSize,n.transparent),"png")&&nt("Imagem PNG salva.")}catch(n){nt(n.message)}};async function Mx(){Rt(),await ix(),await us()}window.RVTest={enforceBudget:ip,refreshView:Tn,showHome:us,setParam:tp,savePreset:Jf,applyPreset:Kf,presetRows:dr,renameStored:jf,deleteStored:qf,diagnostics:()=>({worker:!!_n,pending:kn.size,queued:ci.size,running:hr,sessionEpoch:cn,screen:Q.screen}),cacheStats:yu,meshBytes:ql,resetSession:ec,state:Q,active:Et,generate:Vt,loadImage:nc,loadSvg:up,project:$l,traceSource:lp,applyProject:Zl,commitImport:nu,exportData:fp,measurements:wo,primaryDimension:_o,selectObject:as,toggleIsolation:Ql,flush:Bi,catalog:Wf,newProject:Qh,editor:Lt,viewer:dt,request:Oi,wait:async()=>{for(let n=0;n<1200;n++){if(await new Promise(t=>setTimeout(t,50)),Q.objects.length&&!hr&&Q.objects.filter(t=>t.visible).every(t=>t.result&&(t.result.released||t.cacheKey===wn(t))))return Q.objects.map(t=>t.result);let e=Q.objects.find(t=>t.visible&&t.error);if(!hr&&e)throw Error(e.error)}throw Error("Tempo de gera\xE7\xE3o excedido")}};Mx();})();
/*! Bundled license information:

three/build/three.core.js:
three/build/three.module.js:
  (**
   * @license
   * Copyright 2010-2026 Three.js Authors
   * SPDX-License-Identifier: MIT
   *)
*/
